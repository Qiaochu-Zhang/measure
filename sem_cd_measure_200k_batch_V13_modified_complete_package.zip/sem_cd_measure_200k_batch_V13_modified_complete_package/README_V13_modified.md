# V13_modified 使用说明：旋转在前，未旋转在后

## 1. 最新版本与 Excel 列顺序

入口：`sem_cd_measure_200k_batch_V13_modified.py`。
本版按最新要求**同时保留旋转与未旋转结果，并明确标注**。
版本名保持 V13_modified，输出格式为 `dual_labeled_24_columns_v2`，修复标识 `partial_results_v3`。

主 Excel 第一张表 `image_summary` 从 A 列开始：

| Excel 列 | 坐标状态 | 算法组 | 四列顺序 |
|---|---|---|---|
| A–D | 旋转 | mixed：V13 算 CD/LWR，V10 算左右 LER | CD、左 LER、右 LER、LWR |
| E–H | 旋转 | 全 V13 | CD、左 LER、右 LER、LWR |
| I–L | 旋转 | 全 V10 | CD、左 LER、右 LER、LWR |
| M–P | 未旋转 | mixed：V13 算 CD/LWR，V10 算左右 LER | CD、左 LER、右 LER、LWR |
| Q–T | 未旋转 | 全 V13 | CD、左 LER、右 LER、LWR |
| U–X | 未旋转 | 全 V10 | CD、左 LER、右 LER、LWR |

单位均为 nm。Y 列开始为图片相对路径、文件名、文件夹、像素尺寸、质量状态、拟合角等。
CSV 与主 Excel 列名和顺序相同。即使图片失败，前 24 列仍保留，失败的值为空。

实际列名示例：

- `旋转_mixed_CD_nm`、`旋转_mixed_LER_left_nm`、`旋转_mixed_LER_right_nm`、`旋转_mixed_LWR_nm`。
- `旋转_V13_CD_nm`、`旋转_V10_LER_left_nm`。
- `未旋转_mixed_CD_nm`、`未旋转_V13_LWR_nm`、`未旋转_V10_LER_right_nm`。

**前 12 列全部旋转矫正；第 13–24 列全部未旋转。**
同一坐标状态内，mixed 的 CD/LWR 等于全 V13 对应值，左右 LER 等于全 V10 对应值。

## 2. 计算定义

检测算法、候选选择、阈值、连续性、Viterbi、ERF、飞点处理和像素尺寸设置沿用 V1.13。
每个引擎独立检测边缘，每条结构使用有效左右边缘中点拟合 PCA/正交最小二乘中心线。

- **旋转**：Y′ 沿中心线、X′ 沿其法向，将检测到的边缘坐标转换后计算。
- **未旋转**：使用原图 X/Y 坐标计算，保留整体倾斜对 LER 的贡献。

| 指标 | 两种坐标各自的统计方式 |
|---|---|
| CD | 有效点左右边缘间距均值 |
| 左/右 LER | 未分组的左/右边缘横向坐标的 3σ |
| LWR | 原采样槽位连续 N 点为一组，对组平均宽度计算 3σ，默认 N=4 |
| 图像级汇总 | 先计算每条入选结构，再求算术平均；两引擎各自沿用原选择规则；无可用入选结构时按下述 REVIEW 规则保留部分结果 |

“未分组”不等于“未旋转”。所有算法组的 LWR 共用 `--group-size`。
组内忽略无效点；尾部不足 N 个槽位的非空组仍参与主 LWR，沿用原版规则。
没有有效点的组不产生结果；支持不足时保留空值，不补成 0。

V10/V13 的检测边缘、拟合角和入选结构可能略有不同。
mixed 的 CD/LWR 使用 V13 的结果，左右 LER 使用 V10 的结果。
旋转是边缘坐标转换，不对原图重新旋转插值，也不额外对左右边缘各自单独去趋势。

本入口适用于 **trench 暗沟槽、line 亮线**。
原包 via 是独立 V1.7 孔检测，不具有这里的 V10/V13 双引擎左右 LER 定义，因此本入口不提供 via。

### 部分结果、REVIEW 和 ERROR

最左侧标准结果仅依赖 **旋转 V13 CD、旋转 V10 左/右 LER、旋转 V13 LWR**。
不需要 V10 和 V13 各自生成完整四指标，也不依赖旧版 raw/group 统计记录或两引擎结构配对成功。

- 每个指标独立保留已有数值，缺项在 Excel/CSV 留空，不用另一引擎替代，也不补零。
- 最左侧四项完整，但后面任一对照组缺项，或引擎质量检查未通过：输出结果并标为 `REVIEW`。
- 一个引擎无候选或运行异常：保留另一个引擎结果，标为 `REVIEW`，记录引擎及失败原因。
- 所有指标都不可用，或图片无法读取等导致没有可用测量：`ERROR`。
- 两引擎角色未配对的结构分别保留在结构表，不影响各引擎的图像级平均。
- 原筛选未留下任何可用结构，但存在部分有值的结构时，汇总这些结构并强制 `REVIEW`；
  `V10_selection_fallback` / `V13_selection_fallback` 标明此情况。检测和有效点判断未放宽。

主表增加 `旋转_mixed_complete`（最左侧四项是否齐全）、`all_result_groups_complete`、
`V10_missing_metrics` / `V13_missing_metrics`、`V10_issues` / `V13_issues`。
`REVIEW` 表示需要人工检查，不能仅凭“有数值”认定测量质量合格。
注释图/PSD 单图导出异常会记入 `processing_errors`，不丢弃已算出的 CD/LER/LWR。
`settings.json` 的 `error_count` 为 ERROR 图片数，`diagnostic_error_count` 为诊断记录数。

## 3. 安装与运行

完整解压，所有 `.py` 依赖文件保持在同一目录。不要只复制主程序。
建议 Python 3.10 以上，本次实际验证 Python 3.12。

```powershell
python -m pip install -r requirements_V13_modified.txt
```

暗沟槽：

```powershell
python sem_cd_measure_200k_batch_V13_modified.py --root "D:\SEM\input" --pattern trench --pixel-size 1.3181
```

亮线：

```powershell
python sem_cd_measure_200k_batch_V13_modified.py --root "D:\SEM\input" --pattern line --pixel-size 1.3181 --max-number 4
```

指定新输出目录：

```powershell
python sem_cd_measure_200k_batch_V13_modified.py --root "D:\SEM\input" --output "D:\SEM\V13_modified_dual_results" --pattern trench --pixel-size 0.87890625 --max-number 4 --group-size 4
```

`--pixel-size` 必须填写实际标定的 nm/pixel，不能只凭 200K 推定，默认仍为 1.3181。
上面的 0.87890625 仅是另一种标定示例。
输入为 PNG 根目录，递归处理子目录中的 PNG，整棵目录统一使用所选 pattern。

默认输出到输入目录下 `CD_measure_output_200K_V13_modified`，自动排除该输出目录。
**若已运行过上一版仅旋转的 V13_modified，请用 `--output` 指定新空目录**，避免混入旧列名或结果。
本格式生成的目录可以再次运行覆盖同名结果。保留不同参数结果时请分别设输出目录。

PowerShell 快捷启动：

```powershell
.\RUN_V13_modified.ps1 -Root "D:\SEM\input" -Pattern trench -PixelSize 1.3181 -MaxNumber 4 -GroupSize 4
```

PyCharm：打开主程序，在 Run Configuration 的 Parameters 中填写同样的 `--root ... --pattern ...` 参数，
项目解释器须安装 requirements 中的依赖。

## 4. 常用参数

| 参数 | 默认值 | 用途 |
|---|---|---|
| --pattern | 必填 | trench / line |
| --pixel-size | 1.3181 | nm/pixel |
| --trench-reference-nm | 自动估计 | 暗沟槽参考宽度 |
| --line-reference-nm | 自动估计 | 亮线参考宽度 |
| --max-number | 3 | 每图结构数上限 |
| --min-number | min(3,max-number) | 所需最少结构数 |
| --sample-number | 128 | 每条结构采样点数 |
| --average-range | 32 | 每点灰度平均行数 |
| --smoothing-pixel | 3 | 灰度曲线平滑像素数 |
| --threshold-left / --threshold-right | 50 | 左右阈值百分数 |
| --group-size | 4 | 所有组 LWR 的分组点数 |
| --viterbi | 0 | 1 开启全局边缘路径 |
| --erf-fit | 0 | 1 开启 ERF 拟合 |
| --edge-continuity | 0 | 连续性强度，0–100 |
| --flyer-mode | reserve | reserve/remove/replace |
| --compact-sample-output | 关闭 | 缩减诊断字段，仍保留两套坐标 |
| --save-debug-masks | 关闭 | 额外生成旋转后的边缘/宽度诊断图 |
| --no-annotated-images | 关闭 | 关闭原图上的边缘叠加图 |
| --skip-statistics-plots | 关闭 | 关闭统计图和机台对照图 |
| --skip-psd | 关闭 | 关闭 PSD |
| --psd-axis | both | both=两套；normal=旋转；unrotated=未旋转 |

`--psd-axis` 只控制 PSD；主表始终输出 24 列。
其他适用于 trench/line 的原版参数保留：

```powershell
python sem_cd_measure_200k_batch_V13_modified.py --help
python sem_cd_measure_200k_batch_V13_modified.py --pattern trench --check-parameters
```

## 5. 输出文件与标注

主 Excel：`CD_measurement_200K_V13_modified_results.xlsx`。

| Sheet | 内容 |
|---|---|
| image_summary | 每图一行，前 24 列为六组明确标注的指标 |
| coordinate_results | 每图六行，首列“坐标状态”为旋转/未旋转，第二列 result_group 为 mixed/V13/V10 |
| condition_summary | 按文件夹汇总两套坐标下三组指标；测量列带旋转_/未旋转_前缀 |
| trench_objects | 两引擎按唯一角色配对，未配对结构也保留，缺失引擎的列留空；前 24 列与主表相同 |
| engine_objects | 每引擎的结构；前四指标旋转、后四指标未旋转，并标记是否参与图像统计 |
| per_sample_results | 每引擎每采样点一行，原图坐标、X′/Y′和局部 CD 均用前缀标注 |
| processing_errors | 图片、引擎、结构或辅助导出失败的阶段与原因 |
| settings | 坐标及列顺序说明 |

另有同名 CSV（UTF-8 BOM）和完整 `settings.json`。
长表由“坐标状态”列标明整行测量值所属坐标；宽表由测量列前缀标明。
同时含两套列的行，其“坐标状态”为“旋转+未旋转”。

原图边缘叠加图输出到 `annotated_未旋转_V13/`、`annotated_未旋转_V10/`。
它们显示原图上的检测位置，不意味着主表前 12 列未校正。
统计图两个面板分别是 Rotated（旋转）与 Unrotated（未旋转），文件名也标明两套状态。
额外诊断图名带 rotated，使用旋转坐标。图内采用英文标识以兼容未安装中文字体的环境。

PSD 默认保留两套，所有谱测量结果行都有“坐标状态”：

- normal → 旋转：幅度沿中心线法向；频率对应沿平均中心线的名义距离。
- unrotated → 未旋转：幅度使用原图 X 坐标；频率对应原图 Y 采样间隔。

每引擎保留 left/right/center/width/width_groupN。
PSD 默认仍做 linear detrend；未旋转 PSD 表示坐标未旋转，不表示没有 PSD 去趋势。
PSD 的窗口、分组和缺失点处理有独立定义，积分粗糙度不保证等于主表 LER/LWR。

## 6. 机台表比较

默认自动检查 root/Data.xlsx，默认 sheet=`v2`、第 2–84 行，
B 列图名、D 列 CD、E 列左 LER、F 列 LWR；可使用原 `--machine-*` 参数修改。
关闭自动读取用 `--no-auto-machine-comparison`。

分别比较旋转 mixed 和未旋转 mixed，误差列明确标注状态。
机台明细表前 24 列也遵循六组顺序。
机台参考数值直接读取，不推断其自身是否进行旋转矫正。
每个指标独立比较；某指标无有效匹配数值时标为 `SKIPPED`、n=0，跳过该指标图表，其他指标照常输出。

## 7. 自检与示例

```powershell
python self_check_V13_modified.py
python self_check_partial_results.py
python sem_cd_measure_200k_batch_V13_modified.py --root examples/input_trench --output example_output_dual --pattern trench --pixel-size 1 --trench-reference-nm 60 --max-number 4 --no-auto-machine-comparison
```

`examples/example_results_trench.xlsx` 是本版实际运行合成图得到的 24 列结果。
示例 PNG 沿用原包合成图，不是真实 SEM 图。验证记录见 `验证记录_V13_modified.md`。
