# V13_modified 双坐标输出验证

日期：2026-09-17。输出格式：dual_labeled_24_columns_v2。修复标识：partial_results_v3。
本记录对应旋转与未旋转均保留的最新版本，取代先前仅旋转版本的记录。

## 数值与来源

使用原版 V1.13 的合成 trench/line PNG，同场景参数保持一致：

| 场景 | 设置 | 配对结构数 | 旋转 mixed 对原版最大差 | 未旋转 mixed 对原版最大差 |
|---|---|---:|---:|---:|
| trench | max=4，group=4，Viterbi/ERF/连续性默认关闭 | 4 | 0.0 nm | 0.0 nm |
| line | max=4，group=8，Viterbi=1，ERF=1，连续性=50 | 4 | 0.0 nm | 0.0 nm |

trench 保留原来的 REVIEW 状态，line 为 OK。未为通过验证修改检测或质量门槛。
另从原版采样明细读取边缘，用独立 SVD 拟合中心线，复算两套坐标的四项指标并对入选结构平均。
与新版两引擎全部指标最大差为：trench 2.8422e-14 nm；line 5.5511e-14 nm。
两套坐标下，mixed CD/LWR 等于 V13，mixed 左右 LER 等于 V10，逐项检查通过。

## 解析几何

self_check_V13_modified.py 检查已知倾斜中心线和周期宽度：

- 旋转 CD 符合法向投影。
- 两套左右 LER 符合直接标准差公式。
- group-size=1/4/8 的两套 LWR 符合独立分组计算。
- 理想倾斜直线旋转后 LER 接近零，未旋转 LER 保留倾斜贡献。
- 前 12 列标注“旋转_”，后 12 列标注“未旋转_”。

## 导出检查

检查三个场景共 44 个可读取 CSV、7 个 Excel 文件：

- 主表、配对结构表、机台明细表前 24 列满足六组顺序。
- coordinate_results 每图六行，前三行旋转，后三行未旋转，组别均为 mixed/V13/V10。
- 原图与旋转后的采样坐标使用不同中文前缀。
- PSD 同时包含 normal 和 unrotated，分别标注旋转与未旋转。
- 机台比较两套百分比误差均使用正确的 mixed 结果。
- 统计图、两套 PSD、原图标注图和旋转诊断图正常生成。
- 全部候选被拒绝时，24 个测量列留空并输出 ERROR 原因。

## 部分结果修复验证

本次移除旧的 V10/V13 raw/group 记录齐套门槛，直接从各引擎检测采样计算两套坐标指标；
图像级输出不依赖两引擎结构配对。V10/V13 检测引擎等 12 个依赖文件与原 V1.13 逐字节一致。
trench、line 的全部 24 项数值与修复前的双坐标 V13_modified 比较，最大差均为 0.0 nm。
以上独立 SVD、机台比较、PSD 和导出检查也在本次修复版本重跑通过。

`self_check_partial_results.py` 通过以下 8 种故障注入场景，逐一验证实际 CSV/Excel 导出：

| 场景 | 结果 |
|---|---|
| V10 仅有左右 LER，V13 仅有 CD/LWR | mixed 四项完整，其他缺项为空，REVIEW |
| V10 引擎异常 | V13 CD/LWR 保留，mixed 左右 LER 为空，REVIEW |
| V13 引擎异常 | V10 左右 LER 保留，mixed CD/LWR 为空，REVIEW |
| V10 无候选 | 保留 V13 结果，REVIEW |
| 两引擎均无候选 | 24 项为空，ERROR，记录双方原因 |
| 两引擎结构角色不匹配 | 独立汇总可用指标，未配对结构均保留 |
| 原统计筛选未留下结构，但仍有部分有效测量 | 保留数值，标明 fallback，REVIEW |
| 原图标注导出异常 | 已有指标保留，REVIEW，记录辅助导出异常 |

其中 V10 异常场景同时带机台参考表：左右 LER 不补零，左 LER 对比项 n=0 / SKIPPED，
CD 和 LWR 仍完成比较与图表输出。全部场景均不生成旧的 raw/group 来源记录。
这验证输出和错误处理逻辑，不代表真实 SEM 测量精度标定。

## 范围

使用解析几何与原包合成图，未使用新的真实 SEM 数据标定测量精度。
环境为 Linux / Python 3.12；NumPy 2.3.5、pandas 2.2.3、SciPy 1.17.0、Matplotlib 3.10.8、
openpyxl 3.1.5、tifffile 2026.9.15、OpenCV headless 5.0.0。
PowerShell 脚本沿用已检查的参数构造，本 Linux 环境未直接执行。
示例 Excel 为本版合成图实际输出。机器可读摘要为 validation_report.json。
