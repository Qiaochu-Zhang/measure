param(
    [Parameter(Mandatory=$true)][string]$Root,
    [ValidateSet("trench","line")][string]$Pattern = "trench",
    [double]$PixelSize = 1.3181,
    [int]$MaxNumber = 3,
    [int]$GroupSize = 4,
    [ValidateSet(0,1)][int]$Viterbi = 0,
    [ValidateSet(0,1)][int]$ErfFit = 0,
    [ValidateRange(0,100)][int]$Continuity = 0,
    [string]$Output = ""
)
$ScriptPath = Join-Path $PSScriptRoot "sem_cd_measure_200k_batch_V13_modified.py"
$CliArguments = @($ScriptPath, "--root", $Root, "--pattern", $Pattern,
    "--pixel-size", $PixelSize.ToString([cultureinfo]::InvariantCulture),
    "--max-number", $MaxNumber, "--group-size", $GroupSize,
    "--viterbi", $Viterbi, "--erf-fit", $ErfFit, "--edge-continuity", $Continuity)
if ($Output) { $CliArguments += @("--output", $Output) }
& python @CliArguments
exit $LASTEXITCODE
