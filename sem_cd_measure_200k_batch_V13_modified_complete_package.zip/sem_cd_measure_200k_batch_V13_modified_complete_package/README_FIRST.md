# V13_modified：旋转在前，未旋转在后

请阅读 `README_V13_modified.md`。本包按最新要求同时保留两套结果。
本次修复标识：`partial_results_v3`。不再要求 V10/V13 全套统计记录齐全。
只要 V13 有旋转 CD/LWR、V10 有旋转左右 LER，最左侧四项就完整输出；其他缺项留空并标为 REVIEW。
推荐入口：`sem_cd_measure_200k_batch_V13_modified.py`。

主 Excel 前 24 列：

1. 旋转 mixed 四指标（V13 CD/LWR + V10 左右 LER）。
2. 旋转全 V13 四指标。
3. 旋转全 V10 四指标。
4. 未旋转 mixed 四指标。
5. 未旋转全 V13 四指标。
6. 未旋转全 V10 四指标。

每组顺序：CD、左 LER、右 LER、LWR。列名直接标注“旋转_”或“未旋转_”。
完整解压并保留同目录依赖文件。

```powershell
python -m pip install -r requirements_V13_modified.txt
python sem_cd_measure_200k_batch_V13_modified.py --root "D:\SEM\input" --output "D:\SEM\V13_modified_dual_results" --pattern trench --pixel-size 1.3181
```

若使用过上一版仅旋转结果包，请为本版选择新输出目录。
