"""Explicit coordinate labels for all exported measurement tables."""
COORDINATE_LABELS = {"rotated": "旋转", "normal": "旋转", "unrotated": "未旋转",
                     "both": "旋转+未旋转"}


def column_label(name):
    name = str(name)
    # Match unrotated first; do not perform substring replacement.
    for prefix, label in (("unrotated_", "未旋转_"), ("rotated_", "旋转_")):
        if name.startswith(prefix):
            return label + name[len(prefix):]
    original_positions = {
        "sample_y": "未旋转_sample_y_px", "left_edge_x": "未旋转_left_edge_x_px",
        "right_edge_x": "未旋转_right_edge_x_px",
        "continuity_original_left_x": "未旋转_continuity_original_left_x_px",
        "continuity_original_right_x": "未旋转_continuity_original_right_x_px",
        "pre_path_left_x": "未旋转_pre_path_left_x_px", "pre_path_right_x": "未旋转_pre_path_right_x_px",
        "coordinate_mode": "坐标状态",
    }
    return original_positions.get(name, name)


def label_frame(frame):
    """Leave numeric results untouched; label wide columns and long-form rows."""
    out = frame.copy()
    if "coordinate_mode" not in out:
        for axis_field in ("axis", "geometry"):
            if axis_field in out:
                out["coordinate_mode"] = out[axis_field]
                break
    if "coordinate_mode" in out:
        out["coordinate_mode"] = out["coordinate_mode"].map(lambda v: COORDINATE_LABELS.get(v, v))
    return out.rename(columns={name: column_label(name) for name in out.columns})
