#!/usr/bin/env python3
"""Exercise partial-output policy with injected failures, not SEM accuracy."""
from contextlib import ExitStack, redirect_stdout, redirect_stderr
from copy import deepcopy
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
import json
import math
import numpy as np
import pandas as pd
from openpyxl import Workbook, load_workbook
import sem_cd_measure_200k_batch_V13_modified as app


def measurement(role="center", empty=False):
    rows = []
    if not empty:
        for i in range(32):
            center = 180 + .2*i
            width = 60 + np.sin(i/2)
            rows.append(dict(space_index=0, space_role=role, sample_index=i, sample_y=float(i),
                             left_edge_x=center-width/2, right_edge_x=center+width/2, valid=True))
    return SimpleNamespace(
        image_row=dict(valid=not empty, triplet_complete=not empty, selected_roles=role,
                       selected_space_count=int(not empty), stable_space_count=int(not empty),
                       warning="no valid SPACE candidate found" if empty else ""),
        space_rows=[] if empty else [dict(space_index=0, stable=True, mean_cd_nm=60, lwr_nm=2)],
        sample_rows=rows, annotation_payload={"spaces": [], "image": np.zeros((32,32))})


def run_checks(output_root):
    input_root = Path(__file__).resolve().parent / "examples/input_trench"
    columns = [app.column_label(c) for c in app.RESULT_COLUMNS]
    complete = {}
    cases = ("only_required_metrics", "v10_exception", "v13_exception", "v10_no_candidates",
             "both_no_candidates", "roles_differ", "selection_fallback", "annotation_failure")
    real_run = app.run_coordinate_engine
    for case in cases:
        out = output_root / case
        m10 = measurement("left" if case == "roles_differ" else "center",
                          empty=case in ("v10_no_candidates", "both_no_candidates"))
        m13 = measurement("right" if case == "roles_differ" else "center", empty=case == "both_no_candidates")
        if case == "selection_fallback":
            for m in (m10,m13):
                m.space_rows[0].update(stable=False, lwr_nm=math.nan)
                m.image_row["valid"] = False
        argv = ["--root",str(input_root),"--output",str(out),"--pattern","trench",
                "--pixel-size","1","--trench-reference-nm","60","--max-number","4",
                "--no-auto-machine-comparison","--skip-psd","--skip-statistics-plots","--save-debug-masks"]
        if case != "annotation_failure":
            argv.append("--no-annotated-images")
        if case == "v10_exception":
            book = Workbook()
            sheet = book.active
            sheet.title="v2"
            sheet.append(["a","file","c","CD","LER","LWR"])
            sheet.append([None,"test.png",None,60,2,.7])
            ref=output_root / "reference.xlsx"
            book.save(ref)
            argv += ["--machine-excel",str(ref)]
            argv.remove("--skip-statistics-plots")
        def partial_engine(engine, *args, **kwargs):
            result = real_run(engine, *args, **kwargs)
            if case == "only_required_metrics":
                for item in [result["aggregate"], *result["metrics"].values()]:
                    for key in list(item):
                        if key.startswith(("rotated_", "unrotated_")) and key.endswith("_nm"):
                            keep = ("LER" in key) if engine == "V10" else ("CD" in key or "LWR" in key)
                            if not keep:
                                item[key] = math.nan
            return result
        log=StringIO()
        with ExitStack() as stack:
            stack.enter_context(patch.object(app.v5,"measure_image",side_effect=RuntimeError("injected V10 failure"))
                                if case=="v10_exception" else patch.object(app.v5,"measure_image",return_value=deepcopy(m10)))
            stack.enter_context(patch.object(app.v13v5,"measure_image",side_effect=RuntimeError("injected V13 failure"))
                                if case=="v13_exception" else patch.object(app.v13v5,"measure_image",return_value=deepcopy(m13)))
            stack.enter_context(patch.object(app,"run_coordinate_engine",side_effect=partial_engine))
            # If legacy raw/group rows are requested, this test fails: none are provided.
            legacy=stack.enter_context(patch.object(app.v7,"process_measurement_variants",side_effect=AssertionError("legacy row gate invoked")))
            if case == "annotation_failure":
                stack.enter_context(patch.object(app.v5,"save_annotated_image",side_effect=OSError("injected annotation failure")))
                stack.enter_context(patch.object(app.v13v5,"save_annotated_image",side_effect=OSError("injected annotation failure")))
            with redirect_stdout(log), redirect_stderr(log):
                rc=app.main(argv)
            assert rc==0, (case,log.getvalue())
            legacy.assert_not_called()
        frame=pd.read_csv(out / "image_summary.csv")
        assert len(frame)==1 and list(frame.columns[:24])==columns
        row=frame.iloc[0]
        expected_status="ERROR" if case=="both_no_candidates" else ("OK" if case=="roles_differ" else "REVIEW")
        assert row.status==expected_status, (case,row.status,log.getvalue())
        if case=="only_required_metrics":
            assert np.isfinite(row[columns[:4]].astype(float)).all()
            assert row["旋转_mixed_complete"]
            assert pd.isna(row["旋转_V10_CD_nm"]) and pd.isna(row["旋转_V13_LER_left_nm"])
        if case in ("v10_exception","v10_no_candidates"):
            assert np.isfinite(row["旋转_mixed_CD_nm"]) and np.isfinite(row["旋转_mixed_LWR_nm"])
            assert pd.isna(row["旋转_mixed_LER_left_nm"]) and pd.isna(row["旋转_mixed_LER_right_nm"])
        if case=="v13_exception":
            assert np.isfinite(row["旋转_mixed_LER_left_nm"]) and np.isfinite(row["旋转_mixed_LER_right_nm"])
            assert pd.isna(row["旋转_mixed_CD_nm"]) and pd.isna(row["旋转_mixed_LWR_nm"])
        if case=="both_no_candidates":
            assert row[columns].isna().all()
            assert "V10" in row.warning and "V13" in row.warning
            assert len(pd.read_csv(out/"processing_errors.csv"))>=1
        if case=="roles_differ":
            assert len(pd.read_csv(out/"trench_objects.csv"))==2
            assert np.isfinite(row[columns].astype(float)).all()
        if case=="selection_fallback":
            assert row.V10_selection_fallback and row.V13_selection_fallback
            assert np.isfinite(row[columns].astype(float)).all()
        if case=="annotation_failure":
            assert np.isfinite(row[columns].astype(float)).all()
            assert len(pd.read_csv(out/"processing_errors.csv"))==2
        if case=="v10_exception":
            statistics=pd.read_csv(out/"V13_modified_statistics_summary.csv")
            missing=statistics[statistics.metric=="LER_left"]
            assert len(missing)==2 and (missing.n==0).all() and (missing.status=="SKIPPED").all()
            assert (statistics[statistics.metric=="CD"].n==1).all()
        book=load_workbook(out/"CD_measurement_200K_V13_modified_results.xlsx",read_only=True,data_only=True)
        values=list(book["image_summary"].values)
        assert list(values[0][:24])==columns and len(values)==2
        if case=="v10_exception":
            assert values[1][1] is None and values[1][2] is None
        book.close()
        complete[case]="PASS"
    return complete


if __name__=="__main__":
    with TemporaryDirectory(prefix="v13_partial_check_") as tmp:
        checks=run_checks(Path(tmp))
    print(json.dumps(checks,ensure_ascii=False,indent=2))
