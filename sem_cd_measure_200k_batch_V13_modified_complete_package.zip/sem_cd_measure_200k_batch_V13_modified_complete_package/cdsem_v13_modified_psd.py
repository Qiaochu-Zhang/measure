"""Spatial PSD on original sampling grids; no gap compression or cross-image FFT."""
from pathlib import Path
import json
import math
import numpy as np
import pandas as pd
from cdsem_output_labels import label_frame
from scipy import signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

KEYS = ['engine', 'axis', 'signal']


def runs(mask):
    edges = np.diff(np.r_[False, mask, False].astype(int))
    return list(zip(np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)))


def fill_short_gaps(values, max_gap):
    x = np.asarray(values, float).copy()
    filled = np.zeros(len(x), bool)
    for a, b in runs(~np.isfinite(x)):
        if a > 0 and b < len(x) and b-a <= max_gap:
            x[a:b] = np.linspace(x[a-1], x[b], b-a+2)[1:-1]
            filled[a:b] = True
    return x, filled


def spectrum(values, spacing_nm, args):
    """Return density and quality; uniform missing slots remain in-place.

    Welch uses a common window length across contiguous runs and weights each
    run by the number of contributing windows. Periodogram uses longest run.
    """
    x = np.asarray(values, float).copy()
    info = dict(input_slots=len(x), input_valid_count=int(np.isfinite(x).sum()),
                psd_interpolated_count=0, used_slots=0, window_count=0)
    if args.psd_gap_mode == 'interpolate':
        x, added = fill_short_gaps(x, args.psd_max_gap)
        info['psd_interpolated_count'] = int(added.sum())
    valid_runs = [(a,b) for a,b in runs(np.isfinite(x)) if b-a >= args.psd_min_segment]
    info['contiguous_runs'] = len(valid_runs)
    if not valid_runs:
        return None, None, {**info, 'status':'SKIPPED', 'reason':'no_long_enough_contiguous_segment'}
    if not np.isfinite(spacing_nm) or spacing_nm <= 0:
        return None, None, {**info, 'status':'SKIPPED', 'reason':'invalid_spacing'}
    detrend = False if args.psd_detrend == 'none' else args.psd_detrend
    fs = 1.0/spacing_nm
    if args.psd_method == 'periodogram':
        a,b = max(valid_runs, key=lambda ab:ab[1]-ab[0])
        n = b-a
        f, power = signal.periodogram(x[a:b], fs=fs, window=args.psd_window,
                     detrend=detrend, scaling='density', return_onesided=True)
        info.update(used_slots=n, window_count=1, nperseg_used=n)
    else:
        longest = max(b-a for a,b in valid_runs)
        n = min(args.psd_nperseg, longest)
        overlap = min(n-1, int(n*args.psd_overlap))
        step = n-overlap
        weighted = []
        for a,b in valid_runs:
            if b-a < n:
                continue
            f, p = signal.welch(x[a:b], fs=fs, window=args.psd_window, nperseg=n,
                  noverlap=overlap, nfft=n, detrend=detrend, scaling='density',
                  return_onesided=True, average='mean')
            count = 1+(b-a-n)//step
            weighted.append((p,count))
            info['used_slots'] += n+(count-1)*step
            info['window_count'] += count
        power = sum(p*w for p,w in weighted)/sum(w for _,w in weighted)
        info['nperseg_used'] = n
    info.update(status='OK', reason='', spacing_nm=spacing_nm,
                frequency_step_per_nm=float(f[1]-f[0]),
                nyquist_per_nm=0.5/spacing_nm)
    return f, power, info


def scalar_metrics(f, power, split_wavelength):
    df = float(f[1]-f[0])
    cutoff = 1.0/split_wavelength
    # Rectangular FFT-bin sum, including DC, matches the density normalization.
    total = float(np.sum(power)*df)
    low = float(np.sum(power[f <= cutoff])*df)
    positive = f > 0
    if positive.any() and np.max(power[positive]) > 0:
        freq_peak = float(f[positive][np.argmax(power[positive])])
    else:
        freq_peak = math.nan
    return dict(variance_psd_nm2=total, roughness_psd_3sigma_nm=3*np.sqrt(max(total,0)),
                low_band_variance_nm2=low, high_band_variance_nm2=total-low,
                low_band_fraction=low/total if total > 0 else math.nan,
                peak_frequency_per_nm=freq_peak,
                peak_wavelength_nm=1/freq_peak if np.isfinite(freq_peak) else math.nan,
                split_frequency_per_nm=cutoff)


def average_curves(curves):
    """Equal weights, common physical frequency interval, no extrapolation."""
    if not curves:
        return None
    if len(curves) == 1:
        f,p = curves[0]
        return f.copy(), p.copy(), np.zeros_like(p), 1
    df = max(float(f[1]-f[0]) for f,p in curves)
    max_f = min(float(f[-1]) for f,p in curves)
    grid = np.arange(int(np.floor(max_f/df+1e-9))+1)*df
    if len(grid) < 2:
        return None
    matrix = np.array([np.interp(grid,f,p) for f,p in curves])
    return grid, matrix.mean(axis=0), matrix.std(axis=0,ddof=1), len(curves)


def strict_group(values, group_size=4):
    """PSD requires identical support in each block; unlike legacy scalar LWR."""
    n = len(values)//group_size
    if n == 0:
        return np.array([])
    blocks = np.asarray(values[:group_size*n]).reshape(n,group_size)
    with np.errstate(invalid='ignore'):
        return np.where(np.isfinite(blocks).all(axis=1), np.mean(blocks,axis=1), np.nan)


def strict_group4(values):
    return strict_group(values, 4)


class PSDBatch:
    def __init__(self,args,output_dir):
        self.args=args
        self.output=Path(output_dir)/'PSD'
        self.objects=[]
        self.images=[]
        self.curves=[]
        self.image_curves=[]
        self.manifest=[]
        self.audit=[]

    def add_measurement(self, measurement, key, engine, params):
        self.manifest.append(dict(image_key=key,engine=engine,
            detected_trenches=len(measurement.annotation_payload.get('spaces',[])),
            measurement_valid=bool(measurement.image_row.get('valid',False)),
            warning=measurement.image_row.get('warning','')))
        rows_by_space={}
        for row in measurement.sample_rows:
            rows_by_space.setdefault(int(row['space_index']),[]).append(row)
            self.audit.append(dict(image_key=key,engine=engine,space_index=row['space_index'],
                space_role=row['space_role'],sample_index=row['sample_index'],sample_y=row['sample_y'], coordinate_mode='unrotated',
                **{k:v for k,v in row.items() if k.startswith(('continuity_','pre_path_','viterbi_','erf_','flyer_'))}))
        for ann in measurement.annotation_payload.get('spaces',[]):
            y=np.asarray(ann['y_values'],float)
            l=np.asarray(ann['left_edges'],float).copy()
            r=np.asarray(ann['right_edges'],float).copy()
            if len(y) < 2 or not np.allclose(np.diff(y),np.diff(y)[0],rtol=1e-7,atol=1e-9):
                raise ValueError('PSD requires the original uniform sampling Y grid')
            synthetic=np.asarray(ann.get('continuity_synthetic',np.zeros(len(y),bool)))
            if not self.args.psd_include_synthetic:
                l[synthetic]=np.nan;r[synthetic]=np.nan
            valid=np.isfinite(l)&np.isfinite(r)&(r>l)
            l[~valid]=np.nan;r[~valid]=np.nan
            px=params.pixel_size_nm
            angle=float(ann.get('centerline_fit',{}).get('angle_from_vertical_deg',0))
            theta=np.deg2rad(angle)
            axes=['normal','unrotated'] if self.args.psd_axis=='both' else [self.args.psd_axis]
            for axis in axes:
                if axis=='normal':
                    # Amplitudes along the fitted normal, frequency coordinate is
                    # uniform NOMINAL distance along the fitted mean line y/cosθ.
                    factor=abs(np.cos(theta))
                    if factor < 1e-6:
                        continue
                    left_nm=(l*np.cos(theta)-y*np.sin(theta))*px
                    right_nm=(r*np.cos(theta)-y*np.sin(theta))*px
                    spacing=float(y[1]-y[0])*px/factor
                else:
                    left_nm=l*px;right_nm=r*px;spacing=float(y[1]-y[0])*px
                signals=dict(left=left_nm,right=right_nm,center=(left_nm+right_nm)/2,
                             width=right_nm-left_nm,
                             **{f'width_group{self.args.group_size}':strict_group(right_nm-left_nm,self.args.group_size)})
                for name,values in signals.items():
                    is_primary=((engine=='V10' and name in ('left','right'))
                                or (engine=='V13' and name==f'width_group{self.args.group_size}'))
                    meta=dict(image_key=key,folder=str(Path(key).parent),engine=engine,axis=axis,pattern=params.pattern_kind,group_size=self.args.group_size,
                        signal=name,space_index=ann['space_index'],space_role=ann['candidate'].role,
                        primary_source=is_primary,synthetic_slot_count=int(synthetic.sum()),
                        relaxed_slot_count=sum(row.get('continuity_source')=='relaxed_redetect'
                                               for row in rows_by_space.get(ann['space_index'],[])),
                        measurement_stable=bool(ann['stable']),
                        synthetic_included=bool(self.args.psd_include_synthetic),
                        edge_continuity=int(params.edge_continuity),
                        average_range_px=int(params.average_range_px),
                        original_sampling_step_px=float(y[1]-y[0]),
                        angle_from_vertical_deg=angle)
                    f,p,info=spectrum(values,spacing*(self.args.group_size if name==f'width_group{self.args.group_size}' else 1),self.args)
                    row={**meta,**info}
                    if f is not None:
                        row.update(scalar_metrics(f,p,self.args.psd_split_wavelength))
                        self.curves.append((meta,f,p))
                    self.objects.append(row)

    def _write_curves(self,path,curves,sd=False):
        records=[]
        for meta,f,p,*rest in curves:
            for i in range(len(f)):
                item={**meta,'frequency_per_nm':float(f[i]),
                      'wavelength_nm':1/float(f[i]) if f[i]>0 else math.nan,
                      'psd_nm3':float(p[i])}
                if rest:
                    item['psd_sd_nm3']=float(rest[0][i])
                records.append(item)
        frame=pd.DataFrame(records)
        if frame.empty:
            frame=pd.DataFrame(columns=['image_key','engine','axis','signal','frequency_per_nm','psd_nm3'])
        label_frame(frame).to_csv(path,index=False,encoding='utf-8-sig')

    def _plot(self, curves, output, title):
        if self.args.skip_statistics_plots or not curves:
            return
        axes_names=sorted(set(m['axis'] for m,f,p,*_ in curves))
        fig,axes=plt.subplots(len(axes_names),2,figsize=(12,4.5*len(axes_names)),squeeze=False)
        for row,axis in enumerate(axes_names):
            for col,engine in enumerate(['V10','V13']):
                ax=axes[row,col]
                for meta,f,p,*_ in curves:
                    if meta['axis']!=axis or meta['engine']!=engine:
                        continue
                    mask=(f>0)&(p>0)
                    if mask.any():
                        ax.loglog(f[mask],p[mask],label=meta['signal'],linewidth=1.2)
                ax.set(title=f'{engine} / '+('Rotated (normal)' if axis=='normal' else 'Unrotated'),xlabel='Spatial frequency (1/nm)',ylabel='PSD (nm^3)')
                ax.grid(True,which='both',alpha=.2)
                if ax.lines:
                    ax.legend(fontsize=8)
                else:
                    ax.text(.5,.5,'No positive PSD / insufficient data',ha='center',transform=ax.transAxes)
        fig.suptitle(title)
        fig.tight_layout();output.parent.mkdir(parents=True,exist_ok=True)
        fig.savefig(output,dpi=self.args.plot_dpi);plt.close(fig)

    def finalize(self):
        self.output.mkdir(parents=True,exist_ok=True)
        obj=pd.DataFrame(self.objects)
        label_frame(pd.DataFrame(self.manifest)).to_csv(self.output/'measurement_manifest.csv',index=False,encoding='utf-8-sig')
        audit=pd.DataFrame(self.audit)
        label_frame(audit).to_csv(self.output/'continuity_audit.csv',index=False,encoding='utf-8-sig')
        label_frame(obj).to_csv(self.output/'per_trench_psd_summary.csv',index=False,encoding='utf-8-sig')
        self._write_curves(self.output/'per_trench_psd_curves.csv',self.curves)
        image_groups={}
        for meta,f,p in self.curves:
            group=tuple(meta[k] for k in ['image_key']+KEYS)
            image_groups.setdefault(group,[]).append((meta,f,p))
        for group,items in image_groups.items():
            averaged=average_curves([(f,p) for m,f,p in items])
            if averaged is None:
                continue
            f,p,sd,count=averaged
            meta={k:items[0][0][k] for k in ['image_key','folder','pattern','group_size']+KEYS+['primary_source']}
            meta['trench_count']=count
            self.image_curves.append((meta,f,p,sd))
            self.images.append({**meta,**scalar_metrics(f,p,self.args.psd_split_wavelength),
                'max_frequency_per_nm':float(f[-1]),'frequency_step_per_nm':float(f[1]-f[0])})
        self._write_curves(self.output/'per_image_psd_curves.csv',self.image_curves)
        image_df=pd.DataFrame(self.images)
        label_frame(image_df).to_csv(self.output/'per_image_psd_summary.csv',index=False,encoding='utf-8-sig')
        # Preserve relative image paths, avoiding collisions between identical filenames.
        for key in dict.fromkeys(m['image_key'] for m,f,p,*_ in self.image_curves):
            subset=[c for c in self.image_curves if c[0]['image_key']==key]
            self._plot(subset,self.output/'images'/Path(key).with_suffix('.psd.png'),
                       'Per-image PSD: '+key)
        groups={}
        for meta,f,p,sd in self.image_curves:
            for scope,name in [('all','ALL'),('folder',meta['folder'])]:
                group=(scope,name)+tuple(meta[k] for k in KEYS)
                groups.setdefault(group,[]).append((meta,f,p))
        aggregate_curves=[];aggregate_rows=[]
        for (scope,name,engine,axis,kind),items in groups.items():
            averaged=average_curves([(f,p) for m,f,p in items])
            if averaged is None:
                continue
            f,p,sd,count=averaged
            meta=dict(scope=scope,group=name,engine=engine,axis=axis,signal=kind,image_count=count)
            aggregate_curves.append((meta,f,p,sd))
            row={**meta,**scalar_metrics(f,p,self.args.psd_split_wavelength)}
            individual=[scalar_metrics(fi,pi,self.args.psd_split_wavelength) for m,fi,pi in items]
            for field in ['roughness_psd_3sigma_nm','low_band_fraction','variance_psd_nm2']:
                vals=np.array([v[field] for v in individual]);vals=vals[np.isfinite(vals)]
                row['per_image_'+field+'_mean']=float(np.mean(vals)) if len(vals) else math.nan
                row['per_image_'+field+'_sd']=float(np.std(vals,ddof=1)) if len(vals)>1 else math.nan
            aggregate_rows.append(row)
        agg=pd.DataFrame(aggregate_rows)
        label_frame(agg).to_csv(self.output/'aggregate_psd_summary.csv',index=False,encoding='utf-8-sig')
        self._write_curves(self.output/'aggregate_psd_curves.csv',aggregate_curves)
        self._plot([c for c in aggregate_curves if c[0]['scope']=='all'],
                   self.output/'PSD_all_images.png','Equal-image mean PSD')
        with pd.ExcelWriter(self.output/'PSD_summary.xlsx',engine='openpyxl') as writer:
            for name,frame in [('per_image',image_df),('per_trench',obj),('aggregate',agg),
                               ('manifest',pd.DataFrame(self.manifest))]:
                label_frame(frame).to_excel(writer,sheet_name=name,index=False)
                ws=writer.book[name];ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
        settings={k:v for k,v in vars(self.args).items() if k.startswith('psd_')}
        settings.update(coordinate_labels={'normal':'旋转','unrotated':'未旋转'}, spatial_frequency_unit='1/nm',density_unit='nm^3',
            aggregation='equal trenches per image, equal images per folder/all; common support; no extrapolation',
            normal_frequency_coordinate='nominal distance along fitted centerline = original_y/cos(theta)',
            synthetic_default='excluded; see --psd-include-synthetic',
            group_policy=f'all {self.args.group_size} samples required for PSD; scalar LWR ignores partial NaN',
            skipped_curve_count=sum(r['status']!='OK' for r in self.objects))
        (self.output/'PSD_settings.json').write_text(json.dumps(settings,indent=2,ensure_ascii=False),encoding='utf-8')
        return self.output/'PSD_summary.xlsx'
