#!/usr/bin/env python3
"""Numerical check against analytic tilted edges; no SEM images required."""
from copy import deepcopy
import math
import numpy as np
import sem_cd_measure_200k_batch_V13_modified as entry


def check_rotation():
    y = np.arange(128, dtype=float)
    slope, pixel = 0.25, 1.25
    width = 60 + 2 * np.sin(2 * np.pi * y / 16)
    center = 200 + slope * y
    rows = [dict(space_index=0, space_role="center", sample_index=i, sample_y=t,
                 left_edge_x=c-w/2, right_edge_x=c+w/2, valid=True)
            for i, (t, c, w) in enumerate(zip(y, center, width))]
    params = entry.v5.MeasurementParams(pixel_size_nm=pixel, standard_deviation_ddof=1)
    factor = 1 / math.sqrt(1 + slope**2)
    for group in (1, 4, 8):
        metrics = entry.coordinate_metrics_by_space(deepcopy(rows), params, group)[0]
        expected_width = width * factor * pixel
        np.testing.assert_allclose(metrics["rotated_raw_CD_nm"], expected_width.mean(), atol=1e-10)
        expected_ler = 3 * np.std(expected_width / 2, ddof=1)
        np.testing.assert_allclose(metrics["rotated_raw_LER_left_nm"], expected_ler, atol=1e-10)
        np.testing.assert_allclose(metrics["rotated_raw_LER_right_nm"], expected_ler, atol=1e-10)
        expected_lwr = 3 * np.std(expected_width.reshape(-1, group).mean(axis=1), ddof=1)
        np.testing.assert_allclose(metrics["rotated_group4_LWR_nm"], expected_lwr, atol=1e-10)
        np.testing.assert_allclose(metrics["unrotated_raw_CD_nm"], width.mean()*pixel, atol=1e-10)
        np.testing.assert_allclose(metrics["unrotated_raw_LER_left_nm"], 3*np.std((center-width/2)*pixel, ddof=1), atol=1e-10)
        np.testing.assert_allclose(metrics["unrotated_raw_LER_right_nm"], 3*np.std((center+width/2)*pixel, ddof=1), atol=1e-10)
        np.testing.assert_allclose(metrics["unrotated_group4_LWR_nm"], 3*np.std((width*pixel).reshape(-1,group).mean(axis=1), ddof=1), atol=1e-10)
    for row in rows:
        row["left_edge_x"] = center[row["sample_index"]] - 30
        row["right_edge_x"] = center[row["sample_index"]] + 30
    metrics = entry.coordinate_metrics_by_space(rows, params, 4)[0]
    assert metrics["rotated_raw_LER_left_nm"] < 1e-10
    assert metrics["rotated_raw_LER_right_nm"] < 1e-10
    assert metrics["rotated_group4_LWR_nm"] < 1e-10
    assert metrics["unrotated_raw_LER_left_nm"] > 1
    assert metrics["unrotated_raw_LER_right_nm"] > 1
    frame = entry.public_frame(entry.result_first(entry.pd.DataFrame([entry.metric_groups(metrics, metrics)])))
    assert len(entry.RESULT_COLUMNS) == 24
    assert all(str(c).startswith('旋转_') for c in frame.columns[:12])
    assert all(str(c).startswith('未旋转_') for c in frame.columns[12:24])
    print("PASS: rotated/unrotated analytic CD/LER/LWR, groups 1/4/8, tilted straight-edge distinction, 24 labeled columns")


if __name__ == "__main__":
    check_rotation()
