"""Select any requested number of distinct coarse objects; dark working polarity."""
import math
import numpy as np


def choose_objects(selected_rows, all_rows, center_x, params, legacy_choose):
    # Exact legacy routing for the original default configuration.
    custom = (params.max_number != 3 or params.min_number != 3
              or params.candidate_dark_mean_tolerance_8bit is not None
              or params.candidate_min_basin_contrast_8bit is not None
              or params.space_reference_nm is not None)
    if not custom:
        return legacy_choose(selected_rows,all_rows,center_x,params)
    def pos(r):return float(r.get('candidate_center_x_px',r.get('basin_center_x_px',math.nan)))
    pool=[r for r in all_rows if np.isfinite(pos(r)) and r.get('basin_valid',False)]
    if not pool:
        return []
    dark=[r for r in pool if r.get('brightness_true_trench',False)]
    # Brightness classified target set is preferred, never fill quota with a
    # known opposite-polarity region simply to satisfy max-number.
    if dark:pool=dark
    center=min(pool,key=lambda r:abs(pos(r)-center_x))
    cp=pos(center)
    if params.candidate_dark_mean_tolerance_8bit is not None:
        ref=float(center.get('brightness_core_mean_raw',center.get('basin_core_mean_raw',math.nan)))
        if np.isfinite(ref):
            pool=[r for r in pool if float(r.get('brightness_core_mean_raw',ref)) <= ref+params.candidate_dark_mean_tolerance_8bit]
    chosen=[center]
    remaining=[r for r in pool if r is not center]
    pitch=(params.target_cd_nm+params.space_reference_nm)/params.pixel_size_nm if params.space_reference_nm else None
    def key(r):
        distance=abs(pos(r)-cp)
        mismatch=abs(distance/pitch-round(distance/pitch)) if pitch else 0.
        # Prior pitch influences neighbor ranking without moving an edge.
        return (distance + (pitch or 0)*mismatch, distance, pos(r))
    for row in sorted(remaining,key=key):
        if len(chosen)>=params.max_number:break
        chosen.append(row)
    left=sorted([r for r in chosen if pos(r)<cp],key=lambda r:cp-pos(r))
    right=sorted([r for r in chosen if pos(r)>cp],key=lambda r:pos(r)-cp)
    named=[('center',center)]
    for side,rows in [('left',left),('right',right)]:
        for i,row in enumerate(rows,1):named.append((side if i==1 else f'{side}{i}',row))
    return named
