"""Validate explicit arguments; do not silently clip unsupported values."""
import math


def validate_args(args, explicit=()):
    explicit={v.split('=')[0] for v in explicit if v.startswith('--')}
    def error(message):raise ValueError(message)
    for key,value in vars(args).items():
        if isinstance(value,float) and not math.isfinite(value):error(f'--{key.replace("_","-")} 必须是有限数')
    positive=['pixel_size','sample_number','average_range','smoothing_pixel','peak_order','max_number',
              'group_size','tracking_radius','tracking_retry_radius','tracking_max_jump','postfilter_edge_tolerance',
              'plot_dpi','psd_nperseg','psd_min_segment','psd_split_wavelength','viterbi_candidates',
              'viterbi_max_jump','viterbi_gap_cost','erf_window','erf_max_shift','erf_max_relative_rmse']
    for key in positive:
        if getattr(args,key)<=0:error(f'--{key.replace("_","-")} 必须大于0')
    nonnegative=['search_in','search_out','topology_min_contrast','postfilter_mad_multiplier',
                 'flyer_left_offset','flyer_right_offset','psd_max_gap','viterbi_weight']
    for key in nonnegative:
        if getattr(args,key)<0:error(f'--{key.replace("_","-")} 不能小于0')
    for key in ['via_reference_nm','trench_reference_nm','line_reference_nm','space_reference_nm',
                'extend_length','meas_area_width','meas_area_height','min_number']:
        value=getattr(args,key)
        if value is not None and value<=0:error(f'--{key.replace("_","-")} 必须大于0')
    for key in ['candidate_dark_tolerance','candidate_min_contrast']:
        value=getattr(args,key)
        if value is not None and value<0:error(f'--{key.replace("_","-")} 不能小于0')
    if args.min_number is None:args.min_number=min(3,args.max_number)
    if args.min_number>args.max_number:error('--min-number 不能大于 --max-number')
    if args.sample_number<2:error('--sample-number 至少2')
    if args.group_size>args.sample_number:error('--group-size 不能大于 --sample-number')
    if not 0<args.minimum_valid_fraction<=1:error('--minimum-valid-fraction 必须在(0,1]')
    if not 0<args.threshold_left<100 or not 0<args.threshold_right<100:error('边缘阈值百分比必须在(0,100)')
    if args.postfilter_window<3:error('--postfilter-window 至少3')
    if not 0<=args.edge_continuity<=100:error('--edge-continuity 必须在0–100')
    if args.psd_nperseg<4 or args.psd_min_segment<4:error('PSD段长度至少4')
    if not args.skip_psd and args.psd_method=='welch' and args.psd_nperseg<args.psd_min_segment:
        error('--psd-nperseg 不能小于 --psd-min-segment')
    if not 0<=args.psd_overlap<1:error('--psd-overlap 必须在[0,1)')
    if args.erf_window<3:error('--erf-window 至少3px')
    if args.machine_start_row<1 or args.machine_end_row<0:error('Excel起始行至少1，结束行0表示末尾')
    if args.machine_end_row and args.machine_end_row<args.machine_start_row:error('Excel结束行不能小于起始行')
    for key in ['machine_image_column','machine_cd_column','machine_ler_left_column','machine_lwr_column']:
        value=getattr(args,key)
        if not isinstance(value,str) or not value.isalpha() or not value.isascii():
            error(f'--{key.replace("_","-")} 请使用Excel列字母，如B或AA')
    if args.pattern=='line':
        if args.line_reference_nm is not None and args.trench_reference_nm is not None and args.line_reference_nm!=args.trench_reference_nm:
            error('line-reference-nm与兼容别名trench-reference-nm不能指定不同值')
        if args.line_reference_nm is not None:args.trench_reference_nm=args.line_reference_nm
    elif args.line_reference_nm is not None:error('--line-reference-nm 仅用于line')
    if args.pattern!='via' and args.via_reference_nm is not None:error('--via-reference-nm 仅用于via')
    if args.pattern=='via':
        supported={'--root','--output','--pattern','--pixel-size','--via-reference-nm','--save-debug-masks',
                   '--stop-on-error','--check-parameters','--help','--skip-psd'}
        ignored=explicit-supported
        if ignored:error('Via不支持这些line/trench参数：'+', '.join(sorted(ignored)))

    if not args.viterbi and explicit & {'--viterbi-weight','--viterbi-max-jump','--viterbi-gap-cost','--viterbi-candidates'}:
        error('设置Viterbi参数时请同时 --viterbi 1')
    if not args.erf_fit and explicit & {'--erf-window','--erf-max-shift','--erf-max-relative-rmse'}:
        error('设置ERF参数时请同时 --erf-fit 1')
    if args.psd_method=='periodogram' and explicit & {'--psd-nperseg','--psd-overlap'}:
        error('psd-nperseg和psd-overlap只适用于Welch')
    if args.psd_gap_mode=='segments' and '--psd-max-gap' in explicit:
        error('psd-max-gap只适用于 --psd-gap-mode interpolate')
    if args.skip_psd and any(v.startswith('--psd-') for v in explicit):
        error('skip-psd与显式PSD计算参数不能同时使用')
