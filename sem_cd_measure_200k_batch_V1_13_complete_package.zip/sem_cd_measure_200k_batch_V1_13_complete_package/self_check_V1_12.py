#!/usr/bin/env python3
"""Numerical checks: PSD units/peak/power, gaps, equal-image averaging, continuity."""
from types import SimpleNamespace
import numpy as np
import sem_cd_measure_200k_batch_V1_12 as entry
import cdsem_v112_psd as psd
from cdsem_v112_continuity import restore_edges


def options(**kwargs):
    args=entry.build_parser().parse_args(['--pattern','trench'])
    for k,v in kwargs.items():setattr(args,k,v)
    return args


def check_psd():
    n=256;dx=2.;amplitude=3.;k=16
    a=amplitude*np.sin(2*np.pi*k*np.arange(n)/n)
    args=options(psd_method='periodogram',psd_window='boxcar',psd_detrend='constant')
    f,p,info=psd.spectrum(a,dx,args)
    stats=psd.scalar_metrics(f,p,100.)
    assert np.isclose(f[np.argmax(p)],k/(n*dx))
    assert np.isclose(stats['variance_psd_nm2'],amplitude**2/2,rtol=1e-10)
    assert np.isclose(stats['roughness_psd_3sigma_nm'],3*amplitude/np.sqrt(2))
    # A complete hole must remain at its original position, never compressed.
    gap=a.copy();gap[70:110]=np.nan
    args=options(psd_nperseg=32,psd_min_segment=16,psd_detrend='constant')
    f,p,info=psd.spectrum(gap,dx,args)
    assert info['contiguous_runs']==2 and info['psd_interpolated_count']==0
    assert np.isclose(info['spacing_nm'],dx)
    assert info['used_slots'] <= n-40
    empty=psd.spectrum(np.full(128,np.nan),dx,args)
    assert empty[2]['status']=='SKIPPED'
    patched,mask=psd.fill_short_gaps(np.array([np.nan,1.,np.nan,np.nan,4.,np.nan]),2)
    assert np.allclose(patched[1:5],[1,2,3,4]) and mask.sum()==2
    assert np.isnan(patched[0]) and np.isnan(patched[-1])
    # Strict support for the diagnostic group4 PSD.
    assert np.isnan(psd.strict_group4(np.array([1.,np.nan,2.,3.]))[0])
    f=np.arange(5,dtype=float)
    one=psd.average_curves([(f,np.ones(5)),(f,np.full(5,3.))])
    assert np.allclose(one[1],2.) and one[3]==2
    # Zero signal is defined zero power, not failed measurement.
    assert np.all(psd.spectrum(np.zeros(128),1.,args)[1]==0)


def check_continuity():
    n=16;y=np.arange(n,dtype=float)
    candidate=SimpleNamespace(global_left_edge_px=20.,global_right_edge_px=60.,center_x_px=40.)
    image=np.zeros((32,100))
    base_l=np.full(n,20.);base_r=np.full(n,60.)
    base_l[[4,5,10]]=np.nan;base_r[[4,5,10]]=np.nan
    # Detect becomes valid at level 50; models a weak but present edge.
    def detect(profile, center, params, **kwargs):
        ok=params.topology_min_contrast_8bit <= 2.5*(1-.95*.5)+1e-12
        return SimpleNamespace(valid=ok,left_edge_x=20.1,right_edge_x=59.9)
    def update(row,edge,cd):
        row.update(left_edge_x=edge.left_edge_x,right_edge_x=edge.right_edge_x,local_cd_nm=cd)
    fake=SimpleNamespace(average_rows_profile=lambda *a:(np.zeros(100),0,32,32),
        moving_average_reflect=lambda a,k:a,detect_edge_pair=detect,update_sample_row_from_edge=update)
    counts=[]
    for strength in [0,25,49,50,75,100]:
        params=entry.v5.MeasurementParams(edge_continuity=strength,average_range_px=32,pixel_size_nm=1.)
        l,r=base_l.copy(),base_r.copy();cd=r-l
        rows=[dict(failure_reason='missing' if not np.isfinite(l[i]) else '',valid=bool(np.isfinite(l[i]))) for i in range(n)]
        reject=np.zeros(n,bool)
        restore_edges(fake,image,candidate,params,y,l,r,cd,rows,reject,2.5,2.5,4.)
        counts.append(np.isfinite(l).sum())
        original=np.isfinite(base_l)
        assert np.array_equal(l[original],base_l[original])
        assert np.array_equal(r[original],base_r[original])
        if strength==0:assert np.array_equal(l,base_l,equal_nan=True)
    assert counts==sorted(counts) and counts[2]==13 and counts[3]==16
    # No image evidence: force only at 100; all synthetic flags recorded.
    fake.detect_edge_pair=lambda *a,**k:SimpleNamespace(valid=False)
    for strength in [99,100]:
        l=np.full(n,np.nan);r=l.copy();cd=l.copy();rows=[dict(failure_reason='no_edge') for _ in y]
        params=entry.v5.MeasurementParams(edge_continuity=strength,pixel_size_nm=1.)
        restore_edges(fake,image,candidate,params,y,l,r,cd,rows,np.zeros(n,bool),2.5,2.5,4.)
        if strength==99:assert np.isnan(l).all()
        else:
            assert np.isfinite(l).all() and np.all(r>l)
            assert all(row['continuity_source']=='forced_global_anchor' for row in rows)
            assert all(row['continuity_synthetic'] for row in rows)


def main():
    # Re-run inherited checks against the V1.12 entry point.
    import self_check_V1_10 as legacy
    legacy.entry=entry
    legacy.check_defaults();legacy.check_source_routing();legacy.check_ideal_tilt_rotation()
    check_psd();check_continuity()
    print('V1.12 SELF-CHECK PASSED: routing, rotation, PSD normalization/peak/gaps, continuity 0..100')

if __name__=='__main__':main()
