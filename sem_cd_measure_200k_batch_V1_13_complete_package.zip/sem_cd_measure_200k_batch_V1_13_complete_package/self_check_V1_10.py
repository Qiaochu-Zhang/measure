#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Dependency, source-routing and dual-coordinate self-check for V1.10."""

from __future__ import annotations

import math
from dataclasses import fields
from pathlib import Path
from types import SimpleNamespace

import numpy as np

import sem_cd_measure_200k_batch_V1_10 as entry


def source_rows(raw_values: dict[str, float], group4_values: dict[str, float]):
    common = {
        "image_name": "set/synthetic.png",
        "aggregation_mode": "mean_per_space",
        "space_count": 3,
    }
    return [
        {**common, "result_id": entry.v10.RAW_RESULT_ID, **raw_values},
        {**common, "result_id": entry.v10.GROUP4_RESULT_ID, **group4_values},
    ]


def check_defaults() -> None:
    parser = entry.build_parser()
    assert abs(parser.get_default("pixel_size") - 1.3181) < 1e-12
    assert parser.get_default("sample_number") == 128
    assert parser.get_default("average_range") == 32
    assert parser.get_default("smoothing_pixel") == 3
    assert parser.get_default("peak_order") == 1
    assert parser.get_default("group_size") == 4
    assert parser.get_default("flyer_mode") == "reserve"

    v10_fields = {item.name for item in fields(entry.v5.MeasurementParams)}
    v13_fields = {item.name for item in fields(entry.v13v5.MeasurementParams)}
    assert v10_fields == v13_fields


def check_source_routing() -> None:
    v10_rows = source_rows(
        {
            "ACD_x_nm": 60.0, "ACD_slant_nm": 59.8,
            "LER_left_nm": 1.20, "LER_right_nm": 1.30,
            "LWR_x_nm": 2.40, "LWR_slant_nm": 2.30,
        },
        {
            "ACD_x_nm": 60.1, "ACD_slant_nm": 59.9,
            "LER_left_nm": 0.90, "LER_right_nm": 1.00,
            "LWR_x_nm": 1.50, "LWR_slant_nm": 1.40,
        },
    )
    v13_rows = source_rows(
        {
            "ACD_x_nm": 61.0, "ACD_slant_nm": 60.7,
            "LER_left_nm": 1.50, "LER_right_nm": 1.60,
            "LWR_x_nm": 2.10, "LWR_slant_nm": 2.00,
        },
        {
            "ACD_x_nm": 61.1, "ACD_slant_nm": 60.8,
            "LER_left_nm": 1.00, "LER_right_nm": 1.10,
            "LWR_x_nm": 1.40, "LWR_slant_nm": 1.30,
        },
    )
    parsed = entry.v17.ParsedImage(
        path=Path("set/synthetic.png"), pattern="trench", folder_name="set",
        folder_nominal_nm=math.nan, pretreatment_nm=math.nan, dose_mj=math.nan,
        sample_id="synthetic", design_trench_nm=60.0,
    )
    general = entry.v17.GeneralConfig(
        root_dir=Path("."), force_pattern="trench", trench_reference_nm=60.0
    )
    base = {
        "valid": True, "triplet_complete": True,
        "selected_roles": "left,center,right", "selected_space_count": 3,
        "stable_space_count": 3, "warning": "",
    }
    raw = entry.hybrid_primary_image(v10_rows, v13_rows, parsed, general, base, base)
    assert raw is not None
    row = entry.add_coordinate_fields_to_image(
        raw,
        {
            "rotated_raw_LER_left_nm": 1.10,
            "rotated_raw_LER_right_nm": 1.15,
            "rotation_angle_mean_deg": 4.0,
            "rotation_angle_abs_mean_deg": 4.0,
        },
        {
            "rotated_raw_CD_nm": 60.85,
            "rotated_group4_LWR_nm": 1.35,
            "rotation_angle_mean_deg": 4.1,
            "rotation_angle_abs_mean_deg": 4.1,
        },
    )
    assert np.isclose(row["unrotated_CD_nm"], 61.0)
    assert np.isclose(row["unrotated_LER_left_nm"], 1.20)
    assert np.isclose(row["unrotated_LER_right_nm"], 1.30)
    assert np.isclose(row["unrotated_LWR_nm"], 1.40)
    assert np.isclose(row["rotated_CD_nm"], 60.85)
    assert np.isclose(row["rotated_LER_left_nm"], 1.10)
    assert np.isclose(row["rotated_LER_right_nm"], 1.15)
    assert np.isclose(row["rotated_LWR_nm"], 1.35)
    assert row["ACD_x_nm"] == row["unrotated_CD_nm"]
    assert row["LER_left_nm"] == row["unrotated_LER_left_nm"]
    assert row["LWR_x_nm"] == row["unrotated_LWR_nm"]
    assert not any("slant" in key.casefold() for key in row)
    assert row["source_CD_engine"] == "V13"
    assert row["source_LER_engine"] == "V10"
    assert row["source_LWR_engine"] == "V13"


def check_ideal_tilt_rotation() -> None:
    slope = 0.1
    width_px = 50.0
    rows = []
    for sample_index in range(128):
        y = float(sample_index)
        left = 100.0 + slope * y
        rows.append(
            {
                "space_index": 0,
                "space_role": "center",
                "sample_index": sample_index,
                "sample_y": y,
                "left_edge_x": left,
                "right_edge_x": left + width_px,
                "valid": True,
            }
        )
    params = SimpleNamespace(
        pixel_size_nm=1.0,
        standard_deviation_ddof=1,
        interpolation_max_gap=0,
        lowpass_cutoff_fraction=0.25,
        lowpass_order=2,
    )
    result = entry.coordinate_metrics_by_space(rows, params, group_size=4)[0]
    expected_angle = math.degrees(math.atan(slope))
    expected_normal_width = width_px / math.sqrt(1.0 + slope * slope)
    assert abs(result["rotation_angle_from_vertical_deg"] - expected_angle) < 0.02
    assert result["unrotated_raw_LER_left_nm"] > 10.0
    assert result["rotated_raw_LER_left_nm"] < 1e-9
    assert abs(result["rotated_raw_CD_nm"] - expected_normal_width) < 1e-9


def main() -> None:
    check_defaults()
    check_source_routing()
    check_ideal_tilt_rotation()

    specs = entry.v10.build_edge_variants_v10(32, 3)
    assert len(specs) == 1 and specs[0].name == "raw_v2"
    assert entry.v10.stat_modes_for_variant_v10("raw_v2") == [
        "all_submean", "group4_mean"
    ]

    print("SELF-CHECK PASSED")
    print("Input/output: V1.9-compatible recursive PNG interface")
    print("Unrotated: original image X/Y coordinates")
    print("Rotated: Y' fitted centerline; X' trench normal")
    print("Trench: V13 raw CD + V10 raw LER + V13 group4 LWR")
    print("Via: complete V1.7 algorithm")


if __name__ == "__main__":
    main()
