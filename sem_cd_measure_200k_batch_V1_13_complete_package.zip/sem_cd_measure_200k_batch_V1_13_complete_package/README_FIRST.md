# V1.13 完整包

主入口：`sem_cd_measure_200k_batch_V1_13.py`。请完整解压，保留依赖文件。

新增亮线 `--pattern line`，解除3条候选数量上限；新增 `--viterbi 0/1` 和 `--erf-fit 0/1`，两者默认0关闭。保留连续性0–100、逐图/综合PSD、混合主结果和两套引擎独立统计。

```powershell
python -m pip install -r requirements_V1_13.txt
python self_check_V1_13.py
python sem_cd_measure_200k_batch_V1_13.py --root "D:\SEM\input" --pattern line --pixel-size 0.87890625 --line-reference-nm 60 --max-number 4 --viterbi 1 --erf-fit 1
```

示例 pixel-size 和参考宽度请换成实际值。

- `运行说明.md`：全部77项参数、适用范围、命令、输出字段和图例。
- `算法说明.md`：亮暗选择、Viterbi、ERF、连续性、混合统计、PSD计算过程。
- `验证记录.md`：自检、合成图端到端与默认回归结果。
- `RUN_V1_13.ps1`：Windows PowerShell快捷入口。

max-number是上限，候选不足时不会造出结构；Viterbi可保留断点，edge-continuity=100的完整性可能使用明确标记的估算点。历史脚本是依赖或对照，应以V1_13入口和上述说明为准。共享引擎已升级，需运行原版时请另行解压原发布包。
