#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CD-SEM V10：Raw-V2 CD/LER + Group4 LWR 混合统计口径
===================================================

V10 的具体边缘只找一次，完全来自此前 V2/V5 跟踪结果。

主输出固定为：
    CD:
        raw_v2__all_submean / mean_per_space
    LER-left / LER-right:
        raw_v2__all_submean / mean_per_space
    LWR:
        raw_v2__group4_mean / mean_per_space

也就是说：
    - CD 保留 raw V2；
    - LER 保留 raw V2；
    - 只有 LWR 在最终 3σ 前把 128 点每连续 4 点先平均，约得到 32 组。

这样不重新移动边缘，不对 Machine 做经验缩放，也不为了降低 LWR 修改 LER。

同时输出：
    x_axis:
        CD_x / LWR_x
    trench_normal / slant:
        CD_slant / LWR_slant

LER-left 在两个几何视图中仍是同一条 V2 左边缘 x-position roughness，
不额外定义投影后的 LER。

固定跳过 5 张低质量图：
    S10_M0120-01MS
    S10_M0232-01MS
    S10_M0344-01MS
    S10_M0456-01MS
    S10_M0568-01MS

Data.xlsx:
    sheet v2
    B: image
    D: CD
    E: LER_left
    F: LWR/CDR
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import traceback
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd

import cdsem_batch_v9_m2_statistics as v9


V10_VERSION = "V10_RAWV2_CD_LER_GROUP4_LWR"
DEFAULT_SKIP_IMAGE_STEMS = v9.DEFAULT_SKIP_IMAGE_STEMS

HYBRID_METHOD_CODE = "V10_RawCD_RawLER_Group4LWR"
HYBRID_RESULT_ID = "raw_v2__raw_cd_ler_group4_lwr"
HYBRID_STAT_MODE = "raw_cd_ler__group4_lwr"
HYBRID_AGGREGATION = "mean_per_space"

RAW_RESULT_ID = "raw_v2__all_submean"
GROUP4_RESULT_ID = "raw_v2__group4_mean"

METHOD = {
    "method_code": HYBRID_METHOD_CODE,
    "result_id": HYBRID_RESULT_ID,
    "edge_variant": "raw_v2",
    "stat_mode": HYBRID_STAT_MODE,
    "aggregation_mode": HYBRID_AGGREGATION,
    "cn_name": "Raw V2 CD/LER + Group4 LWR",
    "physical_meaning": (
        "同一套V2最终左右边缘：CD与LER使用128点raw V2 all_submean；"
        "LWR使用相同边缘的每4点组内平均后约32组CD的3sigma；"
        "每条SPACE先独立计算，最多3条SPACE最终结果算术平均。"
    ),
}

EPS = 1e-12


# =============================================================================
# Measurement engine: raw_v2 edge only, but calculate both all_submean and group4
# =============================================================================

_ORIGINAL_BUILD_EDGE_VARIANTS = v9.v8._ORIGINAL_BUILD_EDGE_VARIANTS
_ORIGINAL_IMAGE_AGGREGATION_ROWS = v9.v8._ORIGINAL_IMAGE_AGGREGATION_ROWS


def build_edge_variants_v10(
    base_average_range: int,
    base_smoothing: int,
) -> list[v9.v8.v7.EdgeVariantSpec]:
    specs = _ORIGINAL_BUILD_EDGE_VARIANTS(
        base_average_range, base_smoothing
    )
    specs = [spec for spec in specs if spec.name == "raw_v2"]
    if len(specs) != 1:
        raise RuntimeError(
            f"Expected exactly one raw_v2 edge spec, got {len(specs)}"
        )
    return specs


def stat_modes_for_variant_v10(variant_name: str) -> list[str]:
    if variant_name == "raw_v2":
        return ["all_submean", "group4_mean"]
    return []


def image_aggregation_rows_v10_sources(
    image_name: str,
    result_id: str,
    edge_variant: str,
    stat_mode: str,
    per_space_records: Sequence[dict[str, Any]],
    per_space_sequences: Sequence[dict[str, Any]],
    ddof: int,
) -> list[dict[str, Any]]:
    """
    During the measurement engine, keep only mean_per_space for the two source modes.
    Hybridization occurs after both source rows exist.
    """
    rows = _ORIGINAL_IMAGE_AGGREGATION_ROWS(
        image_name,
        result_id,
        edge_variant,
        stat_mode,
        per_space_records,
        per_space_sequences,
        ddof,
    )
    if result_id not in {RAW_RESULT_ID, GROUP4_RESULT_ID}:
        return []
    return [
        row for row in rows
        if str(row.get("aggregation_mode")) == "mean_per_space"
    ]


# Patch V7/V8 runtime lookup.
v9.v8.build_edge_variants_v8 = build_edge_variants_v10
v9.v8.stat_modes_for_variant_v8 = stat_modes_for_variant_v10
v9.v8.image_aggregation_rows_v8 = image_aggregation_rows_v10_sources

v9.v8.v7.build_edge_variants = build_edge_variants_v10
v9.v8.v7.stat_modes_for_variant = stat_modes_for_variant_v10
v9.v8.v7.image_aggregation_rows = image_aggregation_rows_v10_sources
v9.v8.v7.ALGORITHM_VERSION = V10_VERSION


# =============================================================================
# Hybridization helpers
# =============================================================================

def _first_record(df: pd.DataFrame, result_id: str) -> pd.Series | None:
    rows = df[df["result_id"].astype(str) == result_id]
    if rows.empty:
        return None
    return rows.iloc[0]


def hybrid_image_rows(source: pd.DataFrame) -> pd.DataFrame:
    """
    One primary hybrid row per image:
      CD/LER <- raw_v2__all_submean
      LWR    <- raw_v2__group4_mean
    """
    required = {
        "image_name",
        "result_id",
        "aggregation_mode",
        "ACD_x_nm",
        "ACD_slant_nm",
        "LER_left_nm",
        "LER_right_nm",
        "LWR_x_nm",
        "LWR_slant_nm",
    }
    missing = sorted(required - set(source.columns))
    if missing:
        raise ValueError(
            "image_variant_results.csv missing columns: "
            + ", ".join(missing)
        )

    rows: list[dict[str, Any]] = []
    for image_name, group in source.groupby("image_name", sort=False):
        raw = _first_record(group, RAW_RESULT_ID)
        grouped = _first_record(group, GROUP4_RESULT_ID)
        if raw is None or grouped is None:
            # Do not invent a hybrid if one source mode failed.
            continue

        row = raw.to_dict()
        row.update(
            {
                "algorithm_version": V10_VERSION,
                "image_name": image_name,
                "method_code": HYBRID_METHOD_CODE,
                "result_id": HYBRID_RESULT_ID,
                "edge_variant": "raw_v2",
                "stat_mode": HYBRID_STAT_MODE,
                "aggregation_mode": HYBRID_AGGREGATION,
                "variant_category": "hybrid_statistics",
                "variant_interpretation": METHOD["physical_meaning"],

                # Primary values
                "ACD_x_nm": float(raw["ACD_x_nm"]),
                "ACD_slant_nm": float(raw["ACD_slant_nm"]),
                "LER_left_nm": float(raw["LER_left_nm"]),
                "LER_right_nm": float(raw["LER_right_nm"]),
                "LWR_x_nm": float(grouped["LWR_x_nm"]),
                "LWR_slant_nm": float(grouped["LWR_slant_nm"]),

                # Traceability
                "source_CD_result_id": RAW_RESULT_ID,
                "source_LER_result_id": RAW_RESULT_ID,
                "source_LWR_result_id": GROUP4_RESULT_ID,
                "CD_stat_mode": "all_submean",
                "LER_stat_mode": "all_submean",
                "LWR_stat_mode": "group4_mean",

                "audit_raw_ACD_x_nm": float(raw["ACD_x_nm"]),
                "audit_raw_ACD_slant_nm": float(raw["ACD_slant_nm"]),
                "audit_raw_LER_left_nm": float(raw["LER_left_nm"]),
                "audit_raw_LER_right_nm": float(raw["LER_right_nm"]),
                "audit_raw_LWR_x_nm": float(raw["LWR_x_nm"]),
                "audit_raw_LWR_slant_nm": float(raw["LWR_slant_nm"]),
                "audit_group4_ACD_x_nm": float(grouped["ACD_x_nm"]),
                "audit_group4_ACD_slant_nm": float(grouped["ACD_slant_nm"]),
                "audit_group4_LER_left_nm": float(grouped["LER_left_nm"]),
                "audit_group4_LER_right_nm": float(grouped["LER_right_nm"]),
                "audit_group4_LWR_x_nm": float(grouped["LWR_x_nm"]),
                "audit_group4_LWR_slant_nm": float(grouped["LWR_slant_nm"]),
            }
        )
        rows.append(row)

    return pd.DataFrame(rows)


def hybrid_space_rows(source: pd.DataFrame) -> pd.DataFrame:
    """
    Per-space audit table following the same hybrid rule.
    This table is not used to refit anything; it is only for traceability.
    """
    required = {
        "image_name", "space_index", "result_id",
        "mean_cd_x_nm", "mean_cd_slant_nm",
        "ler_left_nm", "ler_right_nm",
        "lwr_x_nm", "lwr_slant_nm",
    }
    missing = sorted(required - set(source.columns))
    if missing:
        raise ValueError(
            "per_space_variant_results.csv missing columns: "
            + ", ".join(missing)
        )

    rows: list[dict[str, Any]] = []
    for (image_name, space_index), group in source.groupby(
        ["image_name", "space_index"], sort=False
    ):
        raw = _first_record(group, RAW_RESULT_ID)
        grouped = _first_record(group, GROUP4_RESULT_ID)
        if raw is None or grouped is None:
            continue

        row = raw.to_dict()
        row.update(
            {
                "algorithm_version": V10_VERSION,
                "image_name": image_name,
                "space_index": space_index,
                "method_code": HYBRID_METHOD_CODE,
                "result_id": HYBRID_RESULT_ID,
                "edge_variant": "raw_v2",
                "stat_mode": HYBRID_STAT_MODE,
                "aggregation_mode": HYBRID_AGGREGATION,

                "mean_cd_x_nm": float(raw["mean_cd_x_nm"]),
                "mean_cd_slant_nm": float(raw["mean_cd_slant_nm"]),
                "ler_left_nm": float(raw["ler_left_nm"]),
                "ler_right_nm": float(raw["ler_right_nm"]),
                "lwr_x_nm": float(grouped["lwr_x_nm"]),
                "lwr_slant_nm": float(grouped["lwr_slant_nm"]),

                "source_CD_result_id": RAW_RESULT_ID,
                "source_LER_result_id": RAW_RESULT_ID,
                "source_LWR_result_id": GROUP4_RESULT_ID,
            }
        )
        rows.append(row)
    return pd.DataFrame(rows)


def make_hybrid_primary_outputs(output_dir: Path) -> dict[str, Path]:
    image_path = output_dir / "image_variant_results.csv"
    space_path = output_dir / "per_space_variant_results.csv"

    image_source = pd.read_csv(image_path, encoding="utf-8-sig")
    space_source = pd.read_csv(space_path, encoding="utf-8-sig")

    # Preserve both source statistical modes for audit.
    audit_image = output_dir / "V10_source_image_variants_audit.csv"
    audit_space = output_dir / "V10_source_per_space_variants_audit.csv"
    image_source.to_csv(audit_image, index=False, encoding="utf-8-sig")
    space_source.to_csv(audit_space, index=False, encoding="utf-8-sig")

    hybrid_images = hybrid_image_rows(image_source)
    hybrid_spaces = hybrid_space_rows(space_source)

    if hybrid_images.empty:
        raise RuntimeError("No complete V10 hybrid image results were generated.")
    if hybrid_spaces.empty:
        raise RuntimeError("No complete V10 hybrid per-space results were generated.")

    # Machine comparison will see only the V10 primary hybrid method.
    hybrid_images.to_csv(image_path, index=False, encoding="utf-8-sig")
    hybrid_spaces.to_csv(
        output_dir / "per_space_variant_results_v10_primary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    definition = pd.DataFrame(
        [
            {
                **METHOD,
                "CD_source": RAW_RESULT_ID,
                "LER_source": RAW_RESULT_ID,
                "LWR_source": GROUP4_RESULT_ID,
                "empirical_machine_fit": False,
            }
        ]
    )
    definition.to_csv(
        output_dir / "V10_method_definition.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return {
        "primary_image": image_path,
        "audit_image": audit_image,
        "audit_space": audit_space,
        "primary_space": output_dir / "per_space_variant_results_v10_primary.csv",
        "definition": output_dir / "V10_method_definition.csv",
    }


# =============================================================================
# Statistics: reuse V9 plotting but point it to V10 hybrid
# =============================================================================

def configure_v9_statistics_for_v10() -> None:
    v9.METHOD_CODE = HYBRID_METHOD_CODE
    v9.METHOD = {
        "result_id": HYBRID_RESULT_ID,
        "edge_variant": "raw_v2",
        "stat_mode": HYBRID_STAT_MODE,
        "aggregation_mode": HYBRID_AGGREGATION,
        "cn_name": METHOD["cn_name"],
        "physical_meaning": METHOD["physical_meaning"],
    }
    v9.V9_VERSION = V10_VERSION


def write_v10_method_summary_workbook(
    output_dir: Path,
    comparison_paths: dict[str, Path],
    stat_paths: dict[str, Path],
) -> Path:
    """
    Add one compact workbook focused on V10 source traceability + final Machine statistics.
    """
    stats = pd.read_csv(stat_paths["summary_csv"], encoding="utf-8-sig")
    primary = pd.read_csv(
        output_dir / "image_variant_results.csv",
        encoding="utf-8-sig",
    )
    audit = pd.read_csv(
        output_dir / "V10_source_image_variants_audit.csv",
        encoding="utf-8-sig",
    )
    detailed = pd.read_csv(
        comparison_paths["detailed"],
        encoding="utf-8-sig",
    )
    skipped = pd.read_csv(
        output_dir / "skipped_images.csv",
        encoding="utf-8-sig",
    )
    skipped_machine = pd.read_csv(
        comparison_paths["machine_skipped"],
        encoding="utf-8-sig",
    )

    path = output_dir / "V10_hybrid_results_and_statistics.xlsx"
    run_info = pd.DataFrame(
        [
            ["algorithm_version", V10_VERSION],
            ["method_code", HYBRID_METHOD_CODE],
            ["CD_source", RAW_RESULT_ID],
            ["LER_source", RAW_RESULT_ID],
            ["LWR_source", GROUP4_RESULT_ID],
            ["aggregation_mode", HYBRID_AGGREGATION],
            ["empirical_machine_fit", False],
            [
                "primary_definition",
                "CD/LER use raw V2 all_submean; LWR uses group4_mean",
            ],
            [
                "geometry",
                "x_axis and trench_normal/slant are both reported for CD/LWR",
            ],
            [
                "LER geometry note",
                "LER-left remains the same V2 x-edge roughness in both geometry views",
            ],
        ],
        columns=["item", "value"],
    )

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        stats.to_excel(writer, sheet_name="Statistics_Summary", index=False)
        detailed.to_excel(writer, sheet_name="Machine_Per_Image", index=False)
        primary.to_excel(writer, sheet_name="V10_Primary_Result", index=False)
        audit.to_excel(writer, sheet_name="Source_Audit", index=False)
        skipped.to_excel(writer, sheet_name="Skipped_TIFF", index=False)
        skipped_machine.to_excel(
            writer, sheet_name="Skipped_Machine", index=False
        )
        run_info.to_excel(writer, sheet_name="Run_Info", index=False)

    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill
        from openpyxl.utils import get_column_letter

        wb = load_workbook(path)
        fill = PatternFill("solid", fgColor="1F4E78")
        font = Font(color="FFFFFF", bold=True)
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            if ws.max_row and ws.max_column:
                ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]:
                cell.fill = fill
                cell.font = font
            for col in range(1, ws.max_column + 1):
                max_len = len(str(ws.cell(1, col).value or ""))
                for row in range(2, min(ws.max_row, 160) + 1):
                    value = ws.cell(row, col).value
                    if value is not None:
                        max_len = max(max_len, len(str(value)))
                ws.column_dimensions[get_column_letter(col)].width = min(
                    max(max_len + 2, 11), 36
                )
        wb.save(path)
    except Exception:
        pass
    return path


# =============================================================================
# CLI / main
# =============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = v9.build_parser()
    parser.description = (
        "CD-SEM V10: raw-V2 CD/LER + group4 LWR, "
        "with V9-style Machine comparison and statistics plots."
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    v5_params, variant_params = v9.v8.v7.params_from_args(args)
    output_dir = args.output_dir or (args.input_dir / "cdsem_results_v10")

    try:
        skip_image_stems = (
            []
            if args.no_default_quality_skip
            else list(DEFAULT_SKIP_IMAGE_STEMS)
        )
        skip_image_stems.extend(args.skip_image)
        skip_image_stems = list(dict.fromkeys(skip_image_stems))

        # Use the V8 batch engine with V10's patched raw edge + two stat modes.
        result_code = v9.v8.run_batch_v8(
            args.input_dir,
            output_dir,
            v5_params,
            variant_params,
            recursive=args.recursive,
            save_annotations=not args.no_annotated_images,
            skip_image_stems=skip_image_stems,
        )

        # Convert two source statistical rows into one primary hybrid method.
        source_paths = make_hybrid_primary_outputs(output_dir)

        if args.skip_machine_comparison:
            print("Machine comparison skipped by user.")
            print(f"V10 results: {output_dir.resolve()}")
            return result_code

        machine_excel = args.machine_excel or (args.input_dir / "Data.xlsx")
        config = v9.v8.v7.MachineComparisonConfig(
            excel_path=machine_excel,
            sheet_name=args.machine_sheet,
            start_row=args.machine_start_row,
            end_row=args.machine_end_row,
            image_column=args.machine_image_column,
            cd_column=args.machine_cd_column,
            ler_left_column=args.machine_ler_left_column,
            lwr_column=args.machine_lwr_column,
            strict_expected_row_count=(
                not args.allow_machine_row_count_mismatch
            ),
        )

        comparison_paths = v9.v8.v7.run_machine_comparison(
            args.input_dir,
            output_dir,
            config,
            recursive=args.recursive,
            skip_image_stems=skip_image_stems,
        )

        configure_v9_statistics_for_v10()

        if not args.skip_statistics_plots:
            stat_paths = v9.generate_statistics_and_plots(
                comparison_paths["detailed"],
                output_dir,
                dpi=max(80, int(args.plot_dpi)),
            )

            final_workbook = write_v10_method_summary_workbook(
                output_dir,
                comparison_paths,
                stat_paths,
            )

            print("\n=== V10 Machine comparison summary ===")
            summary = pd.read_csv(
                stat_paths["summary_csv"],
                encoding="utf-8-sig",
            )
            cols = [
                "geometry",
                "metric",
                "n",
                "machine_mean_nm",
                "python_mean_nm",
                "mape_pct",
                "mean_signed_diff_pct",
                "std_signed_diff_pct",
                "pearson_r",
            ]
            print(summary[cols].round(4).to_string(index=False))

            print(f"\nV10 workbook: {final_workbook.resolve()}")
            print(
                f"V9-style statistics workbook: "
                f"{stat_paths['workbook'].resolve()}"
            )
            print(f"Plots: {stat_paths['plot_root'].resolve()}")

        print("\nV10 source traceability:")
        for key, path in source_paths.items():
            print(f"  {key}: {path.resolve()}")

        print(f"\nV10 finished: {output_dir.resolve()}")
        return result_code

    except Exception as exc:
        traceback.print_exc()
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
