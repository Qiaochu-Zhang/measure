#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CD-SEM 多指标候选方案筛选
========================

用途
----
读取已经生成的：
    machine_comparison_method_summary.csv

不重新处理 TIFF，不修改任何 CD/LER/LWR 计算。
将同一个算法方案的三个指标组合起来：
    CD
    LER_left
    LWR

同时评估两种几何口径：
    x_axis:
        CD_x + LER_left + LWR_x
    trench_normal:
        CD_slant + LER_left + LWR_slant

对每个方案输出：
    - CD / LER_left / LWR 的平均机台值
    - CD / LER_left / LWR 的平均计算值
    - 三项 mean absolute % error (MAPE)
    - 三项 mean signed % bias
    - median absolute % error
    - signed % error 标准差
    - RMSE
    - Pearson r
    - coverage
    - Pareto 前沿
    - 三指标平衡评分
    - 候选等级

设计原则
--------
1. 不根据机台结果重新拟合图像算法参数。
2. 不通过一个“经验乘法系数”修正 CD/LWR。
3. 候选筛选优先要求 CD/LER/LWR 三项同时接近。
4. 先用门槛 + Pareto 筛选，再使用固定、透明的综合评分排序。
5. 45%/55% threshold、pre-recovery、flyer remove/replace 等诊断项仍保留在
   All_Ranked 中，但默认不进入 RecommendedCandidates。

默认输入路径
------------
C:\\Users\\z00027644\\PycharmProjects\\dfjy\\tif_images\\
    cdsem_results_v6_physical\\machine_comparison_method_summary.csv

运行
----
python select_cdsem_candidate_methods.py

指定输入：
python select_cdsem_candidate_methods.py ^
  --input "D:\\xxx\\machine_comparison_method_summary.csv"

调整第一档目标：
python select_cdsem_candidate_methods.py ^
  --cd-target 3 ^
  --ler-target 6 ^
  --lwr-target 10 ^
  --top-n 12
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


# =============================================================================
# 默认设置：这些只是“筛选标准”，不会改变任何原始量测结果
# =============================================================================

DEFAULT_SUMMARY = Path(
    r"C:\Users\z00027644\PycharmProjects\dfjy\tif_images"
    r"\cdsem_results_v6_physical\machine_comparison_method_summary.csv"
)

# 第一档目标。默认延续目前讨论的合理目标。
DEFAULT_CD_TARGET_PCT = 3.0
DEFAULT_LER_TARGET_PCT = 6.0
DEFAULT_LWR_TARGET_PCT = 10.0

DEFAULT_MIN_COVERAGE_PCT = 95.0
DEFAULT_TOP_N = 12


# 这些方法不是“错误”，只是更适合作为原因诊断/敏感性分析，
# 默认不进入“推荐候选”池，但仍完整出现在 All_Ranked。
DIAGNOSTIC_EDGE_VARIANTS = {
    "initial_before_recovery",
    "global_plateau_mean45",
    "global_plateau_mean55",
    "avg32_ma5_v2ref",
    "avg32_none_v2ref",
}

DIAGNOSTIC_STAT_MODES = {
    "quadratic_detrend",
    "flyer_remove",
    "flyer_replace",
    "every2",
    "every4",
}


REQUIRED_COLUMNS = {
    "comparison_metric",
    "geometry",
    "result_id",
    "edge_variant",
    "stat_mode",
    "aggregation_mode",
    "n_compared",
    "coverage_pct",
    "mean_machine_nm",
    "mean_calculated_nm",
    "mean_signed_diff_pct",
    "mean_abs_diff_pct",
    "median_abs_diff_pct",
    "std_signed_diff_pct",
    "rmse_nm",
    "pearson_r",
}


METRIC_FAMILIES = {
    "x_axis": {
        "CD": "CD_x",
        "LER": "LER_left",
        "LWR": "LWR_x",
    },
    "trench_normal": {
        "CD": "CD_slant",
        "LER": "LER_left",
        "LWR": "LWR_slant",
    },
}


# =============================================================================
# 基础工具
# =============================================================================

def safe_float(value) -> float:
    try:
        value = float(value)
    except Exception:
        return math.nan
    return value if np.isfinite(value) else math.nan


def first_existing(values: Iterable):
    for value in values:
        if pd.notna(value):
            return value
    return np.nan


def validate_input(df: pd.DataFrame) -> None:
    missing = sorted(REQUIRED_COLUMNS - set(df.columns))
    if missing:
        raise ValueError(
            "输入的 machine_comparison_method_summary.csv 缺少以下列：\n  "
            + "\n  ".join(missing)
        )


def method_identity_columns(df: pd.DataFrame) -> list[str]:
    columns = [
        "result_id",
        "edge_variant",
        "stat_mode",
        "aggregation_mode",
    ]
    for optional in [
        "method_id",
        "variant_category",
        "variant_interpretation",
    ]:
        if optional in df.columns:
            columns.append(optional)
    return columns


def metric_row(
    df: pd.DataFrame,
    identity: dict,
    comparison_metric: str,
) -> pd.Series | None:
    mask = np.ones(len(df), dtype=bool)
    for key in ["result_id", "edge_variant", "stat_mode", "aggregation_mode"]:
        mask &= df[key].astype(str).to_numpy() == str(identity[key])
    mask &= df["comparison_metric"].astype(str).to_numpy() == comparison_metric

    rows = df.loc[mask]
    if rows.empty:
        return None

    # 正常情况下只有一行。如有重复，优先覆盖率最高、MAPE最低的一行。
    rows = rows.sort_values(
        ["coverage_pct", "mean_abs_diff_pct"],
        ascending=[False, True],
        na_position="last",
    )
    return rows.iloc[0]


def add_metric_columns(
    out: dict,
    prefix: str,
    row: pd.Series,
) -> None:
    mapping = {
        "n": "n_compared",
        "coverage_pct": "coverage_pct",
        "machine_mean_nm": "mean_machine_nm",
        "calc_mean_nm": "mean_calculated_nm",
        "mean_diff_nm": "mean_difference_nm",
        "mae_nm": "mae_nm",
        "rmse_nm": "rmse_nm",
        "bias_pct": "mean_signed_diff_pct",
        "mape_pct": "mean_abs_diff_pct",
        "median_abs_pct": "median_abs_diff_pct",
        "std_signed_pct": "std_signed_diff_pct",
        "pearson_r": "pearson_r",
    }
    for suffix, source in mapping.items():
        if source in row.index:
            out[f"{prefix}_{suffix}"] = safe_float(row[source])


def is_diagnostic_method(edge_variant: str, stat_mode: str) -> bool:
    return (
        str(edge_variant) in DIAGNOSTIC_EDGE_VARIANTS
        or str(stat_mode) in DIAGNOSTIC_STAT_MODES
    )


# =============================================================================
# 构造“三指标一行”的宽表
# =============================================================================

def build_method_table(summary: pd.DataFrame) -> pd.DataFrame:
    validate_input(summary)
    summary = summary.copy()

    identity_cols = method_identity_columns(summary)
    base_identity_cols = [
        "result_id",
        "edge_variant",
        "stat_mode",
        "aggregation_mode",
    ]

    identities = (
        summary[identity_cols]
        .drop_duplicates(subset=base_identity_cols)
        .reset_index(drop=True)
    )

    output: list[dict] = []

    for _, identity_row in identities.iterrows():
        identity = {
            key: identity_row[key]
            for key in base_identity_cols
        }

        for geometry_family, metrics in METRIC_FAMILIES.items():
            cd_row = metric_row(summary, identity, metrics["CD"])
            ler_row = metric_row(summary, identity, metrics["LER"])
            lwr_row = metric_row(summary, identity, metrics["LWR"])

            # 一个完整候选必须同时有 CD / LER-left / LWR 三个结果。
            if cd_row is None or ler_row is None or lwr_row is None:
                continue

            row: dict = {
                "geometry_family": geometry_family,
                **identity,
            }

            # Optional metadata.
            for optional in [
                "method_id",
                "variant_category",
                "variant_interpretation",
            ]:
                if optional in summary.columns:
                    vals = []
                    for source_row in [cd_row, ler_row, lwr_row]:
                        if optional in source_row.index:
                            vals.append(source_row[optional])
                    row[optional] = first_existing(vals)

            add_metric_columns(row, "CD", cd_row)
            add_metric_columns(row, "LER", ler_row)
            add_metric_columns(row, "LWR", lwr_row)

            row["is_diagnostic_or_sensitivity"] = is_diagnostic_method(
                row["edge_variant"], row["stat_mode"]
            )

            output.append(row)

    result = pd.DataFrame(output)
    if result.empty:
        raise RuntimeError(
            "没有找到同时具备 CD、LER_left、LWR 的完整方法组合。"
        )
    return result


# =============================================================================
# 多指标评价
# =============================================================================

def assign_threshold_tier(
    df: pd.DataFrame,
    cd_target: float,
    ler_target: float,
    lwr_target: float,
    min_coverage: float,
) -> pd.Series:
    """
    A: 第一档目标
    B: 适度放宽
    C: 再放宽
    D: 未通过前三档，但仍保留排序供查看
    """
    cd = df["CD_mape_pct"]
    ler = df["LER_mape_pct"]
    lwr = df["LWR_mape_pct"]

    coverage = df[
        ["CD_coverage_pct", "LER_coverage_pct", "LWR_coverage_pct"]
    ].min(axis=1)

    tier_a = (
        (coverage >= min_coverage)
        & (cd <= cd_target)
        & (ler <= ler_target)
        & (lwr <= lwr_target)
    )

    tier_b = (
        (coverage >= min_coverage)
        & (cd <= cd_target * 4.0 / 3.0)
        & (ler <= ler_target * 7.0 / 6.0)
        & (lwr <= lwr_target * 1.20)
    )

    tier_c = (
        (coverage >= max(90.0, min_coverage - 5.0))
        & (cd <= cd_target * 5.0 / 3.0)
        & (ler <= ler_target * 4.0 / 3.0)
        & (lwr <= lwr_target * 1.50)
    )

    tier = np.full(len(df), "D_outside", dtype=object)
    tier[tier_c] = "C_broad"
    tier[tier_b] = "B_relaxed"
    tier[tier_a] = "A_strict"
    return pd.Series(tier, index=df.index)


def pareto_front_mask(
    values: np.ndarray,
) -> np.ndarray:
    """
    三个目标均为越小越好。
    若另一个方法在三个指标上都 <= 当前方法，且至少一个严格 <，
    当前方法被支配，不属于 Pareto 前沿。
    """
    n = values.shape[0]
    front = np.ones(n, dtype=bool)
    for i in range(n):
        if not np.all(np.isfinite(values[i])):
            front[i] = False
            continue
        for j in range(n):
            if i == j or not np.all(np.isfinite(values[j])):
                continue
            no_worse = np.all(values[j] <= values[i] + 1e-12)
            strictly_better = np.any(values[j] < values[i] - 1e-12)
            if no_worse and strictly_better:
                front[i] = False
                break
    return front


def score_methods(
    methods: pd.DataFrame,
    cd_target: float,
    ler_target: float,
    lwr_target: float,
    min_coverage: float,
) -> pd.DataFrame:
    df = methods.copy()

    # 三项覆盖率中最差的一个，避免某方法只在少数图片上“看起来很好”。
    df["min_coverage_pct"] = df[
        ["CD_coverage_pct", "LER_coverage_pct", "LWR_coverage_pct"]
    ].min(axis=1)

    # 三指标归一化：1.0 表示刚好达到设定目标。
    df["CD_norm_error"] = df["CD_mape_pct"] / cd_target
    df["LER_norm_error"] = df["LER_mape_pct"] / ler_target
    df["LWR_norm_error"] = df["LWR_mape_pct"] / lwr_target

    norm_cols = ["CD_norm_error", "LER_norm_error", "LWR_norm_error"]
    df["worst_norm_error"] = df[norm_cols].max(axis=1)
    df["mean_norm_error"] = df[norm_cols].mean(axis=1)

    # 固定透明评分，不通过结果学习权重：
    # 65% 看三项中最差的一项，35% 看整体平均。
    # 这样 CD/LER 特别好但 LWR 很差的方案不会被平均值掩盖。
    df["balanced_score"] = (
        0.65 * df["worst_norm_error"]
        + 0.35 * df["mean_norm_error"]
    )

    # Bias 用作附加判断和排序 tie-breaker，不作为图像算法拟合项。
    df["mean_abs_bias_pct"] = (
        df[["CD_bias_pct", "LER_bias_pct", "LWR_bias_pct"]]
        .abs()
        .mean(axis=1)
    )
    df["worst_abs_bias_pct"] = (
        df[["CD_bias_pct", "LER_bias_pct", "LWR_bias_pct"]]
        .abs()
        .max(axis=1)
    )

    # 用户希望“平均结果指标也要显示”：
    # 这里给出三项 MAPE 的简单平均，以及三项误差中的最大值。
    df["mean_of_3_mape_pct"] = df[
        ["CD_mape_pct", "LER_mape_pct", "LWR_mape_pct"]
    ].mean(axis=1)
    df["worst_of_3_mape_pct"] = df[
        ["CD_mape_pct", "LER_mape_pct", "LWR_mape_pct"]
    ].max(axis=1)

    df["threshold_tier"] = assign_threshold_tier(
        df,
        cd_target=cd_target,
        ler_target=ler_target,
        lwr_target=lwr_target,
        min_coverage=min_coverage,
    )

    df["passes_primary_targets"] = (
        (df["min_coverage_pct"] >= min_coverage)
        & (df["CD_mape_pct"] <= cd_target)
        & (df["LER_mape_pct"] <= ler_target)
        & (df["LWR_mape_pct"] <= lwr_target)
    )

    # 推荐池只排除显式诊断/敏感性方法。
    # All_Ranked 仍包含它们。
    df["recommended_pool"] = (
        (~df["is_diagnostic_or_sensitivity"])
        & (df["min_coverage_pct"] >= min_coverage)
    )

    # Pareto 分别在两种 geometry_family 内计算；
    # 这样 x-axis 和 trench-normal 不会相互“吃掉”。
    df["pareto_front"] = False
    for geometry, idx in df.groupby("geometry_family").groups.items():
        loc = list(idx)
        vals = df.loc[
            loc,
            ["CD_mape_pct", "LER_mape_pct", "LWR_mape_pct"],
        ].to_numpy(float)
        df.loc[loc, "pareto_front"] = pareto_front_mask(vals)

    # 候选优先级：门槛等级 > Pareto > balanced score > bias > coverage
    tier_order = {
        "A_strict": 0,
        "B_relaxed": 1,
        "C_broad": 2,
        "D_outside": 3,
    }
    df["_tier_order"] = df["threshold_tier"].map(tier_order).fillna(9)

    df = df.sort_values(
        [
            "recommended_pool",
            "_tier_order",
            "pareto_front",
            "balanced_score",
            "mean_abs_bias_pct",
            "worst_of_3_mape_pct",
            "min_coverage_pct",
        ],
        ascending=[False, True, False, True, True, True, False],
        na_position="last",
    ).reset_index(drop=True)

    df["overall_rank"] = np.arange(1, len(df) + 1)

    # 推荐池内单独排名。
    df["recommended_rank"] = np.nan
    rec_idx = df.index[df["recommended_pool"]]
    df.loc[rec_idx, "recommended_rank"] = np.arange(1, len(rec_idx) + 1)

    return df.drop(columns=["_tier_order"])


# =============================================================================
# 输出
# =============================================================================

DISPLAY_COLUMNS = [
    "overall_rank",
    "recommended_rank",
    "threshold_tier",
    "pareto_front",
    "geometry_family",
    "edge_variant",
    "stat_mode",
    "aggregation_mode",
    "CD_mape_pct",
    "CD_bias_pct",
    "LER_mape_pct",
    "LER_bias_pct",
    "LWR_mape_pct",
    "LWR_bias_pct",
    "mean_of_3_mape_pct",
    "worst_of_3_mape_pct",
    "balanced_score",
    "min_coverage_pct",
]


def select_top_candidates(
    ranked: pd.DataFrame,
    top_n: int,
) -> pd.DataFrame:
    recommended = ranked[ranked["recommended_pool"]].copy()
    if recommended.empty:
        recommended = ranked.copy()

    # 尽量优先给出 A/B/C；如果数量不够，再从后续方案补齐。
    abc = recommended[
        recommended["threshold_tier"].isin(
            ["A_strict", "B_relaxed", "C_broad"]
        )
    ]
    if len(abc) >= top_n:
        return abc.head(top_n).copy()

    selected_idx = list(abc.index)
    remaining = recommended.loc[
        ~recommended.index.isin(selected_idx)
    ]
    selected = pd.concat(
        [abc, remaining.head(max(0, top_n - len(abc)))],
        ignore_index=False,
    )
    return selected.head(top_n).copy()


def column_order(df: pd.DataFrame) -> list[str]:
    priority = [
        "overall_rank",
        "recommended_rank",
        "threshold_tier",
        "passes_primary_targets",
        "pareto_front",
        "recommended_pool",
        "is_diagnostic_or_sensitivity",
        "geometry_family",
        "result_id",
        "edge_variant",
        "stat_mode",
        "aggregation_mode",
        "variant_category",
        "variant_interpretation",
        "method_id",
        "balanced_score",
        "mean_of_3_mape_pct",
        "worst_of_3_mape_pct",
        "mean_abs_bias_pct",
        "worst_abs_bias_pct",
        "min_coverage_pct",
    ]

    for metric in ["CD", "LER", "LWR"]:
        priority.extend(
            [
                f"{metric}_machine_mean_nm",
                f"{metric}_calc_mean_nm",
                f"{metric}_mean_diff_nm",
                f"{metric}_mape_pct",
                f"{metric}_bias_pct",
                f"{metric}_median_abs_pct",
                f"{metric}_std_signed_pct",
                f"{metric}_mae_nm",
                f"{metric}_rmse_nm",
                f"{metric}_pearson_r",
                f"{metric}_coverage_pct",
                f"{metric}_n",
            ]
        )

    priority.extend(
        [
            "CD_norm_error",
            "LER_norm_error",
            "LWR_norm_error",
            "worst_norm_error",
            "mean_norm_error",
        ]
    )

    existing = [c for c in priority if c in df.columns]
    extra = [c for c in df.columns if c not in existing]
    return existing + extra


def style_excel(path: Path) -> None:
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.formatting.rule import ColorScaleRule
    except Exception:
        return

    wb = load_workbook(path)

    header_fill = PatternFill("solid", fgColor="D9EAF7")
    candidate_fill = PatternFill("solid", fgColor="E2F0D9")
    diagnostic_fill = PatternFill("solid", fgColor="FCE4D6")

    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions

        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")

        # reasonable widths
        for col_cells in ws.columns:
            letter = col_cells[0].column_letter
            max_len = 0
            for cell in col_cells[: min(len(col_cells), 200)]:
                value = "" if cell.value is None else str(cell.value)
                max_len = max(max_len, len(value))
            ws.column_dimensions[letter].width = min(max(max_len + 2, 10), 30)

        # Color important MAPE columns.
        header_map = {
            cell.value: cell.column
            for cell in ws[1]
            if cell.value is not None
        }
        for name in ["CD_mape_pct", "LER_mape_pct", "LWR_mape_pct", "balanced_score"]:
            col = header_map.get(name)
            if col is not None and ws.max_row >= 2:
                letter = ws.cell(1, col).column_letter
                ws.conditional_formatting.add(
                    f"{letter}2:{letter}{ws.max_row}",
                    ColorScaleRule(
                        start_type="min",
                        start_color="63BE7B",
                        mid_type="percentile",
                        mid_value=50,
                        mid_color="FFEB84",
                        end_type="max",
                        end_color="F8696B",
                    ),
                )

        # On candidate sheet, visually emphasize rows.
        if ws.title == "Top_Candidates":
            for row in ws.iter_rows(min_row=2):
                for cell in row:
                    cell.fill = candidate_fill

        if ws.title == "All_Ranked":
            diagnostic_col = header_map.get("is_diagnostic_or_sensitivity")
            if diagnostic_col:
                for r in range(2, ws.max_row + 1):
                    if ws.cell(r, diagnostic_col).value in (True, "TRUE", "True", 1):
                        for cell in ws[r]:
                            cell.fill = diagnostic_fill

    wb.save(path)


def write_outputs(
    ranked: pd.DataFrame,
    top: pd.DataFrame,
    output_dir: Path,
    cd_target: float,
    ler_target: float,
    lwr_target: float,
    min_coverage: float,
) -> dict[str, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)

    ranked = ranked[column_order(ranked)]
    top = top[column_order(top)]

    pareto = ranked[
        ranked["pareto_front"] & ranked["recommended_pool"]
    ].copy()

    strict = ranked[
        ranked["passes_primary_targets"] & ranked["recommended_pool"]
    ].copy()

    paths = {
        "top_csv": output_dir / "candidate_methods_top.csv",
        "all_csv": output_dir / "candidate_methods_all_ranked.csv",
        "pareto_csv": output_dir / "candidate_methods_pareto.csv",
        "strict_csv": output_dir / "candidate_methods_strict.csv",
        "xlsx": output_dir / "candidate_method_selection.xlsx",
        "txt": output_dir / "candidate_selection_summary.txt",
    }

    top.to_csv(paths["top_csv"], index=False, encoding="utf-8-sig")
    ranked.to_csv(paths["all_csv"], index=False, encoding="utf-8-sig")
    pareto.to_csv(paths["pareto_csv"], index=False, encoding="utf-8-sig")
    strict.to_csv(paths["strict_csv"], index=False, encoding="utf-8-sig")

    config = pd.DataFrame(
        [
            ["CD target MAPE (%)", cd_target],
            ["LER-left target MAPE (%)", ler_target],
            ["LWR target MAPE (%)", lwr_target],
            ["Minimum coverage (%)", min_coverage],
            [
                "Balanced score",
                "0.65 * worst normalized MAPE + 0.35 * mean normalized MAPE",
            ],
            [
                "A_strict",
                f"CD<={cd_target:g}%, LER<={ler_target:g}%, LWR<={lwr_target:g}%",
            ],
            [
                "B_relaxed",
                f"CD<={cd_target*4/3:.2f}%, LER<={ler_target*7/6:.2f}%, "
                f"LWR<={lwr_target*1.2:.2f}%",
            ],
            [
                "C_broad",
                f"CD<={cd_target*5/3:.2f}%, LER<={ler_target*4/3:.2f}%, "
                f"LWR<={lwr_target*1.5:.2f}%",
            ],
            [
                "Positive bias",
                "Python calculated value > machine value",
            ],
        ],
        columns=["item", "value"],
    )

    with pd.ExcelWriter(paths["xlsx"], engine="openpyxl") as writer:
        top.to_excel(writer, sheet_name="Top_Candidates", index=False)
        pareto.to_excel(writer, sheet_name="Pareto_Candidates", index=False)
        strict.to_excel(writer, sheet_name="Strict_Pass", index=False)
        ranked.to_excel(writer, sheet_name="All_Ranked", index=False)
        config.to_excel(writer, sheet_name="Selection_Rules", index=False)

    style_excel(paths["xlsx"])

    lines = [
        "CD-SEM candidate method selection",
        "=================================",
        f"CD target MAPE: {cd_target:.3f}%",
        f"LER-left target MAPE: {ler_target:.3f}%",
        f"LWR target MAPE: {lwr_target:.3f}%",
        f"Minimum coverage: {min_coverage:.1f}%",
        "",
        "Top candidates:",
    ]

    for _, row in top.iterrows():
        lines.extend(
            [
                (
                    f"#{int(row['overall_rank'])} "
                    f"{row['geometry_family']} | "
                    f"{row['edge_variant']} | "
                    f"{row['stat_mode']} | "
                    f"{row['aggregation_mode']}"
                ),
                (
                    f"  tier={row['threshold_tier']}, "
                    f"Pareto={bool(row['pareto_front'])}, "
                    f"score={row['balanced_score']:.4f}"
                ),
                (
                    f"  CD:  calc mean={row['CD_calc_mean_nm']:.4f} nm, "
                    f"machine mean={row['CD_machine_mean_nm']:.4f} nm, "
                    f"MAPE={row['CD_mape_pct']:.3f}%, "
                    f"bias={row['CD_bias_pct']:.3f}%"
                ),
                (
                    f"  LER: calc mean={row['LER_calc_mean_nm']:.4f} nm, "
                    f"machine mean={row['LER_machine_mean_nm']:.4f} nm, "
                    f"MAPE={row['LER_mape_pct']:.3f}%, "
                    f"bias={row['LER_bias_pct']:.3f}%"
                ),
                (
                    f"  LWR: calc mean={row['LWR_calc_mean_nm']:.4f} nm, "
                    f"machine mean={row['LWR_machine_mean_nm']:.4f} nm, "
                    f"MAPE={row['LWR_mape_pct']:.3f}%, "
                    f"bias={row['LWR_bias_pct']:.3f}%"
                ),
                "",
            ]
        )

    paths["txt"].write_text("\n".join(lines), encoding="utf-8")
    return paths


def print_top(top: pd.DataFrame) -> None:
    pd.set_option("display.max_columns", 50)
    pd.set_option("display.width", 240)
    pd.set_option("display.max_colwidth", 32)

    cols = [c for c in DISPLAY_COLUMNS if c in top.columns]
    display = top[cols].copy()

    numeric_cols = [
        "CD_mape_pct",
        "CD_bias_pct",
        "LER_mape_pct",
        "LER_bias_pct",
        "LWR_mape_pct",
        "LWR_bias_pct",
        "mean_of_3_mape_pct",
        "worst_of_3_mape_pct",
        "balanced_score",
        "min_coverage_pct",
    ]
    for col in numeric_cols:
        if col in display.columns:
            display[col] = pd.to_numeric(display[col], errors="coerce").round(3)

    print("\n=== 推荐候选方案 ===")
    print(display.to_string(index=False))

    print("\n说明：")
    print("  MAPE 越小越好；bias > 0 表示 Python 偏大，bias < 0 表示 Python 偏小。")
    print("  Pareto=True 表示没有另一方案能同时把 CD/LER/LWR 三项 MAPE 都做得更好。")
    print("  balanced_score 越小越好，并且会重点惩罚三项中最差的一项。")


# =============================================================================
# CLI
# =============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="筛选 CD/LER-left/LWR 同时接近机台的候选算法方案"
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_SUMMARY,
        help="machine_comparison_method_summary.csv 路径",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="输出目录；默认=input所在目录/candidate_selection",
    )
    parser.add_argument(
        "--cd-target",
        type=float,
        default=DEFAULT_CD_TARGET_PCT,
        help="第一档 CD MAPE 目标，默认3%%",
    )
    parser.add_argument(
        "--ler-target",
        type=float,
        default=DEFAULT_LER_TARGET_PCT,
        help="第一档 LER-left MAPE 目标，默认6%%",
    )
    parser.add_argument(
        "--lwr-target",
        type=float,
        default=DEFAULT_LWR_TARGET_PCT,
        help="第一档 LWR MAPE 目标，默认10%%",
    )
    parser.add_argument(
        "--min-coverage",
        type=float,
        default=DEFAULT_MIN_COVERAGE_PCT,
        help="最小coverage，默认95%%",
    )
    parser.add_argument(
        "--top-n",
        type=int,
        default=DEFAULT_TOP_N,
        help="输出多少个推荐候选，默认12",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()

    input_path: Path = args.input
    if not input_path.exists():
        raise FileNotFoundError(
            f"找不到输入文件：{input_path}\n"
            "请使用 --input 指定 machine_comparison_method_summary.csv"
        )

    output_dir = (
        args.output_dir
        if args.output_dir is not None
        else input_path.parent / "candidate_selection"
    )

    summary = pd.read_csv(input_path)
    methods = build_method_table(summary)
    ranked = score_methods(
        methods,
        cd_target=float(args.cd_target),
        ler_target=float(args.ler_target),
        lwr_target=float(args.lwr_target),
        min_coverage=float(args.min_coverage),
    )
    top = select_top_candidates(
        ranked,
        top_n=max(1, int(args.top_n)),
    )

    paths = write_outputs(
        ranked,
        top,
        output_dir=output_dir,
        cd_target=float(args.cd_target),
        ler_target=float(args.ler_target),
        lwr_target=float(args.lwr_target),
        min_coverage=float(args.min_coverage),
    )

    print_top(top)

    print("\n输出完成：")
    for key, path in paths.items():
        print(f"  {key}: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
