#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CD-SEM V9：固定 M2_V2_Group4_MeanSpace + Machine 对比 + 统计图
================================================================

V9 只保留 V8 中的 M2：

    edge_variant      = raw_v2
    stat_mode         = group4_mean
    aggregation_mode  = mean_per_space

物理口径：
1. V1.15 Basin-First 只找真实 trench 的粗位置；
2. 具体左右边缘完全使用此前验证较好的 V2/V5 edge tracking；
3. 128 个采样点连续每 4 点做组内平均，约得到 32 组；
4. 每条 SPACE 分别计算 CD / LER-left / LER-right / LWR；
5. 最多 3 条 SPACE 的最终结果再做算术平均；
6. 同时保留：
       x_axis       : 同一 Y 的 right_x - left_x
       trench_normal/slant : 按拟合 trench 倾角换算法向宽度
7. 自动读取 Data.xlsx / v2，与 Machine 的 CD / LER_left / LWR 比较；
8. 自动生成统计 CSV / Excel 和 PNG 图。

固定跳过 5 张低质量图：
    S10_M0120-01MS
    S10_M0232-01MS
    S10_M0344-01MS
    S10_M0456-01MS
    S10_M0568-01MS

没有经验拟合或修正系数。
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import traceback
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import cdsem_batch_v8_three_candidates as v8


V9_VERSION = "V9_M2_V2_GROUP4_MEANSPACE_WITH_STATISTICS"
DEFAULT_INPUT_DIR = Path(
    r"C:\Users\z00027644\PycharmProjects\dfjy\tif_images"
)
DEFAULT_SKIP_IMAGE_STEMS = v8.DEFAULT_SKIP_IMAGE_STEMS

METHOD_CODE = "M2_V2_Group4_MeanSpace"
METHOD = {
    "result_id": "raw_v2__group4_mean",
    "edge_variant": "raw_v2",
    "stat_mode": "group4_mean",
    "aggregation_mode": "mean_per_space",
    "cn_name": "原V2边缘 + 每4点分组平均 + 三SPACE结果平均",
    "physical_meaning": (
        "V1.15只给trench粗位置；具体边缘完全使用V2/V5。"
        "128个采样点连续每4点平均成约32组；"
        "每条SPACE独立计算CD/LER/LWR，最后对最多3条SPACE的结果算术平均。"
    ),
}

EPS = 1e-12


# =============================================================================
# 只保留 M2；不修改 V2 的具体边缘计算
# =============================================================================

def build_edge_variants_v9(
    base_average_range: int,
    base_smoothing: int,
) -> list[v8.v7.EdgeVariantSpec]:
    all_specs = v8._ORIGINAL_BUILD_EDGE_VARIANTS(
        base_average_range, base_smoothing
    )
    specs = [spec for spec in all_specs if spec.name == "raw_v2"]
    if len(specs) != 1:
        raise RuntimeError(
            f"Expected exactly one raw_v2 EdgeVariantSpec, got {len(specs)}"
        )
    return specs


def stat_modes_for_variant_v9(variant_name: str) -> list[str]:
    return ["group4_mean"] if variant_name == "raw_v2" else []


def image_aggregation_rows_v9(
    image_name: str,
    result_id: str,
    edge_variant: str,
    stat_mode: str,
    per_space_records: Sequence[dict[str, Any]],
    per_space_sequences: Sequence[dict[str, Any]],
    ddof: int,
) -> list[dict[str, Any]]:
    rows = v8._ORIGINAL_IMAGE_AGGREGATION_ROWS(
        image_name,
        result_id,
        edge_variant,
        stat_mode,
        per_space_records,
        per_space_sequences,
        ddof,
    )
    if result_id != METHOD["result_id"]:
        return []
    return [
        row for row in rows
        if str(row.get("aggregation_mode"))
        == METHOD["aggregation_mode"]
    ]


# V8 run_batch resolves these globals at runtime.
v8.METHODS = {METHOD_CODE: METHOD}
v8.V8_VERSION = V9_VERSION
v8.build_edge_variants_v8 = build_edge_variants_v9
v8.stat_modes_for_variant_v8 = stat_modes_for_variant_v9
v8.image_aggregation_rows_v8 = image_aggregation_rows_v9

# V7 process_measurement_variants uses its module-level functions.
v8.v7.build_edge_variants = build_edge_variants_v9
v8.v7.stat_modes_for_variant = stat_modes_for_variant_v9
v8.v7.image_aggregation_rows = image_aggregation_rows_v9
v8.v7.ALGORITHM_VERSION = V9_VERSION


def method_definition_rows() -> list[dict[str, Any]]:
    return [
        {
            "method_code": METHOD_CODE,
            "cn_name": METHOD["cn_name"],
            "result_id": METHOD["result_id"],
            "edge_variant": METHOD["edge_variant"],
            "stat_mode": METHOD["stat_mode"],
            "aggregation_mode": METHOD["aggregation_mode"],
            "physical_meaning": METHOD["physical_meaning"],
            "empirical_machine_fit": False,
        }
    ]


# =============================================================================
# Machine-comparison statistic extraction
# =============================================================================

GEOMETRIES = {
    "x_axis": {
        "folder": "x_axis",
        "title": "X-axis distance",
        "metrics": {
            "CD": {
                "machine_col": "machine_CD_nm",
                "calc_col": "ACD_x_nm",
                "signed_pct_col": "CD_x_signed_diff_pct",
                "abs_pct_col": "CD_x_abs_diff_pct",
                "unit": "nm",
                "note": "Horizontal same-Y width: right_x - left_x.",
            },
            "LER_left": {
                "machine_col": "machine_LER_left_nm",
                "calc_col": "LER_left_nm",
                "signed_pct_col": "LER_left_signed_diff_pct",
                "abs_pct_col": "LER_left_abs_diff_pct",
                "unit": "nm",
                "note": "Left-edge x-position roughness.",
            },
            "LWR": {
                "machine_col": "machine_LWR_nm",
                "calc_col": "LWR_x_nm",
                "signed_pct_col": "LWR_x_signed_diff_pct",
                "abs_pct_col": "LWR_x_abs_diff_pct",
                "unit": "nm",
                "note": "3sigma of grouped local CD using x-axis width.",
            },
        },
    },
    "trench_normal": {
        "folder": "slant",
        "title": "Trench-normal / slant",
        "metrics": {
            "CD": {
                "machine_col": "machine_CD_nm",
                "calc_col": "ACD_slant_nm",
                "signed_pct_col": "CD_slant_signed_diff_pct",
                "abs_pct_col": "CD_slant_abs_diff_pct",
                "unit": "nm",
                "note": "Width projected onto the fitted trench normal.",
            },
            "LER_left": {
                "machine_col": "machine_LER_left_nm",
                "calc_col": "LER_left_nm",
                "signed_pct_col": "LER_left_signed_diff_pct",
                "abs_pct_col": "LER_left_abs_diff_pct",
                "unit": "nm",
                "note": (
                    "Same V2 left-edge x roughness as x-axis mode. "
                    "V9 does not invent a new projected LER definition."
                ),
            },
            "LWR": {
                "machine_col": "machine_LWR_nm",
                "calc_col": "LWR_slant_nm",
                "signed_pct_col": "LWR_slant_signed_diff_pct",
                "abs_pct_col": "LWR_slant_abs_diff_pct",
                "unit": "nm",
                "note": "3sigma of grouped local CD after trench-normal width projection.",
            },
        },
    },
}


def _to_numeric_array(series: pd.Series) -> np.ndarray:
    return pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)


def _safe_pearson(x: np.ndarray, y: np.ndarray) -> float:
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 3 or np.std(x) <= EPS or np.std(y) <= EPS:
        return math.nan
    return float(np.corrcoef(x, y)[0, 1])


def metric_statistics(
    df: pd.DataFrame,
    geometry: str,
    metric: str,
) -> dict[str, Any]:
    spec = GEOMETRIES[geometry]["metrics"][metric]
    machine = _to_numeric_array(df[spec["machine_col"]])
    calc = _to_numeric_array(df[spec["calc_col"]])

    valid = (
        np.isfinite(machine)
        & np.isfinite(calc)
        & (np.abs(machine) > EPS)
    )
    m = machine[valid]
    c = calc[valid]
    if m.size == 0:
        raise RuntimeError(
            f"No valid values for geometry={geometry}, metric={metric}"
        )

    diff = c - m
    signed_pct = diff / np.abs(m) * 100.0
    abs_pct = np.abs(signed_pct)

    if m.size > 1:
        diff_sd = float(np.std(diff, ddof=1))
        pct_sd = float(np.std(signed_pct, ddof=1))
    else:
        diff_sd = 0.0
        pct_sd = 0.0

    ba_bias = float(np.mean(diff))
    ba_low = ba_bias - 1.96 * diff_sd
    ba_high = ba_bias + 1.96 * diff_sd

    return {
        "geometry": geometry,
        "geometry_label": GEOMETRIES[geometry]["title"],
        "metric": metric,
        "n": int(m.size),
        "machine_mean_nm": float(np.mean(m)),
        "python_mean_nm": float(np.mean(c)),
        "mean_difference_nm": float(np.mean(diff)),
        "mae_nm": float(np.mean(np.abs(diff))),
        "rmse_nm": float(np.sqrt(np.mean(diff ** 2))),
        "mean_signed_diff_pct": float(np.mean(signed_pct)),
        "mape_pct": float(np.mean(abs_pct)),
        "median_abs_diff_pct": float(np.median(abs_pct)),
        "std_signed_diff_pct": pct_sd,
        "pearson_r": _safe_pearson(m, c),
        "bland_altman_bias_nm": ba_bias,
        "bland_altman_lower_95_nm": ba_low,
        "bland_altman_upper_95_nm": ba_high,
        "metric_note": spec["note"],
    }


# =============================================================================
# Plotting
# =============================================================================

def _plot_title(metric: str, geometry: str, suffix: str) -> str:
    return f"{metric} — {GEOMETRIES[geometry]['title']} — {suffix}"


def _save_machine_vs_python(
    df: pd.DataFrame,
    geometry: str,
    metric: str,
    out_path: Path,
    dpi: int,
) -> None:
    spec = GEOMETRIES[geometry]["metrics"][metric]
    machine = _to_numeric_array(df[spec["machine_col"]])
    calc = _to_numeric_array(df[spec["calc_col"]])
    valid = np.isfinite(machine) & np.isfinite(calc)
    m, c = machine[valid], calc[valid]

    fig = plt.figure(figsize=(7.2, 6.0))
    ax = fig.add_axes([0.12, 0.12, 0.82, 0.80])
    ax.scatter(m, c, alpha=0.75)

    if m.size:
        lo = float(min(np.min(m), np.min(c)))
        hi = float(max(np.max(m), np.max(c)))
        pad = max((hi - lo) * 0.06, 1e-6)
        ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], linestyle="--")

    stats = metric_statistics(df, geometry, metric)
    ax.set_xlabel(f"Machine {metric} (nm)")
    ax.set_ylabel(f"Python {metric} (nm)")
    ax.set_title(_plot_title(metric, geometry, "Machine vs Python"))
    ax.grid(True, alpha=0.25)
    ax.text(
        0.02, 0.98,
        (
            f"n={stats['n']}\n"
            f"MAPE={stats['mape_pct']:.2f}%\n"
            f"Bias={stats['mean_signed_diff_pct']:+.2f}%\n"
            f"r={stats['pearson_r']:.3f}"
        ),
        transform=ax.transAxes,
        va="top",
    )
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def _save_error_by_image(
    df: pd.DataFrame,
    geometry: str,
    metric: str,
    out_path: Path,
    dpi: int,
) -> None:
    spec = GEOMETRIES[geometry]["metrics"][metric]
    machine = _to_numeric_array(df[spec["machine_col"]])
    calc = _to_numeric_array(df[spec["calc_col"]])
    valid = (
        np.isfinite(machine)
        & np.isfinite(calc)
        & (np.abs(machine) > EPS)
    )
    rows = df.loc[valid].copy()
    m = machine[valid]
    c = calc[valid]
    err = (c - m) / np.abs(m) * 100.0

    if "machine_excel_row" in rows.columns:
        x = pd.to_numeric(
            rows["machine_excel_row"], errors="coerce"
        ).to_numpy(dtype=float)
        if not np.all(np.isfinite(x)):
            x = np.arange(1, len(rows) + 1, dtype=float)
            xlabel = "Compared image index"
        else:
            xlabel = "Data.xlsx row"
    else:
        x = np.arange(1, len(rows) + 1, dtype=float)
        xlabel = "Compared image index"

    fig = plt.figure(figsize=(9.2, 5.2))
    ax = fig.add_axes([0.10, 0.16, 0.86, 0.76])
    ax.scatter(x, err, alpha=0.78)
    ax.axhline(0.0, linestyle="--")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Signed difference vs Machine (%)")
    ax.set_title(_plot_title(metric, geometry, "Per-image percent error"))
    ax.grid(True, alpha=0.25)

    # Label the five largest absolute percentage errors.
    if len(err):
        worst = np.argsort(np.abs(err))[-min(5, len(err)):]
        for idx in worst:
            image_name = str(
                rows.iloc[idx].get("image_name", int(idx) + 1)
            )
            label = Path(image_name).stem
            ax.annotate(
                label,
                (x[idx], err[idx]),
                xytext=(4, 4),
                textcoords="offset points",
                fontsize=7,
            )

    fig.savefig(out_path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def _save_error_histogram(
    df: pd.DataFrame,
    geometry: str,
    metric: str,
    out_path: Path,
    dpi: int,
) -> None:
    spec = GEOMETRIES[geometry]["metrics"][metric]
    machine = _to_numeric_array(df[spec["machine_col"]])
    calc = _to_numeric_array(df[spec["calc_col"]])
    valid = (
        np.isfinite(machine)
        & np.isfinite(calc)
        & (np.abs(machine) > EPS)
    )
    err = (calc[valid] - machine[valid]) / np.abs(machine[valid]) * 100.0

    fig = plt.figure(figsize=(7.6, 5.2))
    ax = fig.add_axes([0.12, 0.15, 0.83, 0.76])
    ax.hist(err, bins="auto", alpha=0.8)
    ax.axvline(0.0, linestyle="--")
    if err.size:
        ax.axvline(float(np.mean(err)), linestyle=":")
    ax.set_xlabel("Signed difference vs Machine (%)")
    ax.set_ylabel("Image count")
    ax.set_title(_plot_title(metric, geometry, "Percent-error distribution"))
    ax.grid(True, axis="y", alpha=0.25)

    stats = metric_statistics(df, geometry, metric)
    ax.text(
        0.02, 0.97,
        (
            f"Bias={stats['mean_signed_diff_pct']:+.2f}%\n"
            f"MAPE={stats['mape_pct']:.2f}%\n"
            f"SD={stats['std_signed_diff_pct']:.2f}%"
        ),
        transform=ax.transAxes,
        va="top",
    )
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def _save_bland_altman(
    df: pd.DataFrame,
    geometry: str,
    metric: str,
    out_path: Path,
    dpi: int,
) -> None:
    spec = GEOMETRIES[geometry]["metrics"][metric]
    machine = _to_numeric_array(df[spec["machine_col"]])
    calc = _to_numeric_array(df[spec["calc_col"]])
    valid = np.isfinite(machine) & np.isfinite(calc)
    m, c = machine[valid], calc[valid]

    means = 0.5 * (m + c)
    diff = c - m
    bias = float(np.mean(diff)) if diff.size else math.nan
    sd = float(np.std(diff, ddof=1)) if diff.size > 1 else 0.0
    lower = bias - 1.96 * sd
    upper = bias + 1.96 * sd

    fig = plt.figure(figsize=(7.8, 5.4))
    ax = fig.add_axes([0.12, 0.15, 0.83, 0.76])
    ax.scatter(means, diff, alpha=0.75)
    ax.axhline(bias, linestyle="-")
    ax.axhline(lower, linestyle="--")
    ax.axhline(upper, linestyle="--")
    ax.set_xlabel(f"Mean of Machine and Python {metric} (nm)")
    ax.set_ylabel("Python - Machine (nm)")
    ax.set_title(_plot_title(metric, geometry, "Bland–Altman"))
    ax.grid(True, alpha=0.25)
    ax.text(
        0.02, 0.98,
        (
            f"Bias={bias:+.4f} nm\n"
            f"95% limits=[{lower:+.4f}, {upper:+.4f}] nm"
        ),
        transform=ax.transAxes,
        va="top",
    )
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def _save_geometry_summary_bars(
    summary: pd.DataFrame,
    geometry: str,
    out_dir: Path,
    dpi: int,
) -> list[dict[str, Any]]:
    part = summary[summary["geometry"] == geometry].copy()
    order = ["CD", "LER_left", "LWR"]
    part["metric_order"] = part["metric"].map(
        {name: i for i, name in enumerate(order)}
    )
    part = part.sort_values("metric_order")

    records = []

    fig = plt.figure(figsize=(7.2, 5.0))
    ax = fig.add_axes([0.13, 0.16, 0.82, 0.75])
    ax.bar(part["metric"], part["mape_pct"])
    ax.set_ylabel("MAPE vs Machine (%)")
    ax.set_title(f"{GEOMETRIES[geometry]['title']} — MAPE summary")
    ax.grid(True, axis="y", alpha=0.25)
    path = out_dir / "summary_MAPE.png"
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    records.append({
        "geometry": geometry,
        "metric": "ALL",
        "plot_type": "summary_MAPE",
        "relative_path": str(path),
        "description": "MAPE comparison for CD, LER-left and LWR.",
    })

    fig = plt.figure(figsize=(7.2, 5.0))
    ax = fig.add_axes([0.13, 0.16, 0.82, 0.75])
    ax.bar(part["metric"], part["mean_signed_diff_pct"])
    ax.axhline(0.0, linestyle="--")
    ax.set_ylabel("Mean signed difference vs Machine (%)")
    ax.set_title(f"{GEOMETRIES[geometry]['title']} — Bias summary")
    ax.grid(True, axis="y", alpha=0.25)
    path = out_dir / "summary_Bias.png"
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    records.append({
        "geometry": geometry,
        "metric": "ALL",
        "plot_type": "summary_Bias",
        "relative_path": str(path),
        "description": "Mean signed percent bias for CD, LER-left and LWR.",
    })
    return records


def generate_statistics_and_plots(
    detailed_csv: Path,
    output_dir: Path,
    dpi: int = 180,
) -> dict[str, Path]:
    detailed = pd.read_csv(detailed_csv, encoding="utf-8-sig")

    # Defensive filter: V9 must contain only M2/mean_per_space.
    if "result_id" in detailed.columns:
        detailed = detailed[
            detailed["result_id"].astype(str) == METHOD["result_id"]
        ].copy()
    if "aggregation_mode" in detailed.columns:
        detailed = detailed[
            detailed["aggregation_mode"].astype(str)
            == METHOD["aggregation_mode"]
        ].copy()

    if detailed.empty:
        raise RuntimeError("V9 detailed machine-comparison data is empty.")

    plot_root = output_dir / "plots"
    plot_root.mkdir(parents=True, exist_ok=True)

    summary_rows: list[dict[str, Any]] = []
    plot_index: list[dict[str, Any]] = []

    for geometry, geometry_spec in GEOMETRIES.items():
        geometry_dir = plot_root / geometry_spec["folder"]
        geometry_dir.mkdir(parents=True, exist_ok=True)

        for metric in ["CD", "LER_left", "LWR"]:
            metric_dir = geometry_dir / metric
            metric_dir.mkdir(parents=True, exist_ok=True)

            stats = metric_statistics(detailed, geometry, metric)
            summary_rows.append(stats)

            files = [
                (
                    "machine_vs_python",
                    metric_dir / "01_machine_vs_python.png",
                    _save_machine_vs_python,
                    "Scatter of Machine value vs Python value with 1:1 reference.",
                ),
                (
                    "per_image_percent_error",
                    metric_dir / "02_percent_error_by_image.png",
                    _save_error_by_image,
                    "Signed percent difference for each compared image.",
                ),
                (
                    "percent_error_histogram",
                    metric_dir / "03_percent_error_histogram.png",
                    _save_error_histogram,
                    "Distribution of signed percent difference.",
                ),
                (
                    "bland_altman",
                    metric_dir / "04_bland_altman.png",
                    _save_bland_altman,
                    "Bland–Altman plot of Python minus Machine.",
                ),
            ]
            for plot_type, path, fn, description in files:
                fn(detailed, geometry, metric, path, dpi)
                plot_index.append({
                    "geometry": geometry,
                    "metric": metric,
                    "plot_type": plot_type,
                    "relative_path": str(path.relative_to(output_dir)),
                    "description": description,
                })

        geometry_summary = pd.DataFrame(
            [row for row in summary_rows if row["geometry"] == geometry]
        )
        for rec in _save_geometry_summary_bars(
            geometry_summary, geometry, geometry_dir, dpi
        ):
            rec["relative_path"] = str(
                Path(rec["relative_path"]).relative_to(output_dir)
            )
            plot_index.append(rec)

    summary = pd.DataFrame(summary_rows)
    summary["method_code"] = METHOD_CODE
    summary["method_name"] = METHOD["cn_name"]

    # Place identifying columns first.
    first = [
        "method_code",
        "method_name",
        "geometry",
        "geometry_label",
        "metric",
        "n",
        "machine_mean_nm",
        "python_mean_nm",
        "mean_difference_nm",
        "mae_nm",
        "rmse_nm",
        "mean_signed_diff_pct",
        "mape_pct",
        "median_abs_diff_pct",
        "std_signed_diff_pct",
        "pearson_r",
        "bland_altman_bias_nm",
        "bland_altman_lower_95_nm",
        "bland_altman_upper_95_nm",
        "metric_note",
    ]
    summary = summary[[c for c in first if c in summary.columns]]

    plot_index_df = pd.DataFrame(plot_index)

    summary_csv = output_dir / "V9_statistics_summary.csv"
    plot_index_csv = output_dir / "V9_plot_index.csv"
    workbook = output_dir / "V9_statistics_and_machine_comparison.xlsx"

    summary.to_csv(summary_csv, index=False, encoding="utf-8-sig")
    plot_index_df.to_csv(plot_index_csv, index=False, encoding="utf-8-sig")

    # Geometry-specific per-image sheets.
    x_cols = [
        "machine_excel_row", "machine_image_name_raw", "image_name",
        "machine_CD_nm", "ACD_x_nm",
        "CD_x_signed_diff_pct", "CD_x_abs_diff_pct",
        "machine_LER_left_nm", "LER_left_nm",
        "LER_left_signed_diff_pct", "LER_left_abs_diff_pct",
        "machine_LWR_nm", "LWR_x_nm",
        "LWR_x_signed_diff_pct", "LWR_x_abs_diff_pct",
    ]
    slant_cols = [
        "machine_excel_row", "machine_image_name_raw", "image_name",
        "machine_CD_nm", "ACD_slant_nm",
        "CD_slant_signed_diff_pct", "CD_slant_abs_diff_pct",
        "machine_LER_left_nm", "LER_left_nm",
        "LER_left_signed_diff_pct", "LER_left_abs_diff_pct",
        "machine_LWR_nm", "LWR_slant_nm",
        "LWR_slant_signed_diff_pct", "LWR_slant_abs_diff_pct",
    ]
    x_detail = detailed[[c for c in x_cols if c in detailed.columns]].copy()
    slant_detail = detailed[[c for c in slant_cols if c in detailed.columns]].copy()

    method_def = pd.DataFrame(method_definition_rows())
    run_info = pd.DataFrame(
        [
            ["algorithm_version", V9_VERSION],
            ["method_code", METHOD_CODE],
            ["method_name", METHOD["cn_name"]],
            ["result_id", METHOD["result_id"]],
            ["edge_variant", METHOD["edge_variant"]],
            ["stat_mode", METHOD["stat_mode"]],
            ["aggregation_mode", METHOD["aggregation_mode"]],
            ["empirical_machine_fit", False],
            ["statistics_plot_dpi", dpi],
            [
                "LER geometry note",
                (
                    "LER-left uses the same V2 x-edge roughness in x-axis and "
                    "slant views. V9 only projects CD/LWR width geometry."
                ),
            ],
        ],
        columns=["item", "value"],
    )

    with pd.ExcelWriter(workbook, engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Statistics_Summary", index=False)
        x_detail.to_excel(writer, sheet_name="Per_Image_XAxis", index=False)
        slant_detail.to_excel(writer, sheet_name="Per_Image_Slant", index=False)
        plot_index_df.to_excel(writer, sheet_name="Plot_Index", index=False)
        method_def.to_excel(writer, sheet_name="Method_Definition", index=False)
        run_info.to_excel(writer, sheet_name="Run_Info", index=False)

    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill
        from openpyxl.formatting.rule import ColorScaleRule
        from openpyxl.utils import get_column_letter

        wb = load_workbook(workbook)
        header_fill = PatternFill("solid", fgColor="1F4E78")
        header_font = Font(color="FFFFFF", bold=True)

        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            if ws.max_row > 0 and ws.max_column > 0:
                ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]:
                cell.fill = header_fill
                cell.font = header_font

            for col in range(1, ws.max_column + 1):
                max_len = len(str(ws.cell(1, col).value or ""))
                for row in range(2, min(ws.max_row, 160) + 1):
                    value = ws.cell(row, col).value
                    if value is not None:
                        max_len = max(max_len, len(str(value)))
                ws.column_dimensions[get_column_letter(col)].width = min(
                    max(max_len + 2, 11), 34
                )

            if ws.title == "Statistics_Summary":
                headers = {
                    str(ws.cell(1, c).value): c
                    for c in range(1, ws.max_column + 1)
                }
                for name in ["mape_pct", "mean_signed_diff_pct", "rmse_nm"]:
                    col = headers.get(name)
                    if col and ws.max_row >= 2:
                        letter = get_column_letter(col)
                        ws.conditional_formatting.add(
                            f"{letter}2:{letter}{ws.max_row}",
                            ColorScaleRule(
                                start_type="min",
                                start_color="63BE7B",
                                mid_type="percentile",
                                mid_value=50,
                                mid_color="FFEB84",
                                end_type="max",
                                end_color="F8696B",
                            ),
                        )
        wb.save(workbook)
    except Exception:
        pass

    return {
        "summary_csv": summary_csv,
        "plot_index_csv": plot_index_csv,
        "workbook": workbook,
        "plot_root": plot_root,
    }


def write_v9_method_definition(output_dir: Path) -> None:
    pd.DataFrame(method_definition_rows()).to_csv(
        output_dir / "V9_method_definition.csv",
        index=False,
        encoding="utf-8-sig",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = v8.build_parser()
    parser.description = (
        "CD-SEM V9: M2 only (V2 edge + group4 mean + mean per SPACE) "
        "with Machine comparison and separate x-axis/slant statistics plots."
    )
    parser.add_argument(
        "--plot-dpi",
        type=int,
        default=180,
        help="PNG plot DPI; default 180",
    )
    parser.add_argument(
        "--skip-statistics-plots",
        action="store_true",
        help="Do calculation and Machine comparison but skip PNG statistics plots.",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    v5_params, variant_params = v8.v7.params_from_args(args)
    output_dir = args.output_dir or (args.input_dir / "cdsem_results_v9")

    try:
        skip_image_stems = (
            []
            if args.no_default_quality_skip
            else list(DEFAULT_SKIP_IMAGE_STEMS)
        )
        skip_image_stems.extend(args.skip_image)
        skip_image_stems = list(dict.fromkeys(skip_image_stems))

        result_code = v8.run_batch_v8(
            args.input_dir,
            output_dir,
            v5_params,
            variant_params,
            recursive=args.recursive,
            save_annotations=not args.no_annotated_images,
            skip_image_stems=skip_image_stems,
        )
        write_v9_method_definition(output_dir)

        # The V8 engine writes a V8-named method-definition file. Remove it to
        # keep the V9 output directory unambiguous.
        legacy_def = output_dir / "V8_method_definitions.csv"
        if legacy_def.exists():
            legacy_def.unlink()

        if args.skip_machine_comparison:
            print("Machine comparison skipped by user.")
            return result_code

        machine_excel = args.machine_excel or (args.input_dir / "Data.xlsx")
        comparison_config = v8.v7.MachineComparisonConfig(
            excel_path=machine_excel,
            sheet_name=args.machine_sheet,
            start_row=args.machine_start_row,
            end_row=args.machine_end_row,
            image_column=args.machine_image_column,
            cd_column=args.machine_cd_column,
            ler_left_column=args.machine_ler_left_column,
            lwr_column=args.machine_lwr_column,
            strict_expected_row_count=(
                not args.allow_machine_row_count_mismatch
            ),
        )

        comparison_paths = v8.v7.run_machine_comparison(
            args.input_dir,
            output_dir,
            comparison_config,
            recursive=args.recursive,
            skip_image_stems=skip_image_stems,
        )

        if not args.skip_statistics_plots:
            stat_paths = generate_statistics_and_plots(
                comparison_paths["detailed"],
                output_dir,
                dpi=max(80, int(args.plot_dpi)),
            )

            print("\n=== V9 statistics summary ===")
            summary = pd.read_csv(
                stat_paths["summary_csv"],
                encoding="utf-8-sig",
            )
            cols = [
                "geometry",
                "metric",
                "n",
                "machine_mean_nm",
                "python_mean_nm",
                "mape_pct",
                "mean_signed_diff_pct",
                "std_signed_diff_pct",
                "pearson_r",
            ]
            print(summary[cols].round(4).to_string(index=False))

            print(f"\nStatistics workbook: {stat_paths['workbook'].resolve()}")
            print(f"Plots folder: {stat_paths['plot_root'].resolve()}")

        print(f"\nV9 finished: {output_dir.resolve()}")
        return result_code

    except Exception as exc:
        traceback.print_exc()
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
