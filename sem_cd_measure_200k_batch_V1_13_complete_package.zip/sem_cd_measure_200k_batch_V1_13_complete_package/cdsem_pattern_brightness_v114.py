#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CD-SEM V1.13：自适应暗区宽度 + 平均亮度真trench分群
====================================================

针对V1.12已经解决的部分：
- 真trench暗簇与伪暗纹亮簇的平均灰度有明显区分；
- 继续只使用候选暗区平均亮度判断真假trench。

针对V1.12的新问题：
- Stage-1可能把同一条宽trench拆成两个或多个窄候选；
- 这些窄候选都很暗，因此都会进入真trench簇；
- 最后可能在同一条trench内部出现两条绿色中心线。

V1.13处理流程
-------------
1. Stage-1宽松提供全部有限中心/宽度候选；
2. 沿y方向生成原始float图的稳健代表profile；
3. 对每个候选，在其附近自动寻找暗谷；
4. 对该候选局部profile的灰度做一维两簇K-means：
   - 较暗像素簇；
   - 较亮像素簇；
   两簇中心中点作为该候选自己的局部宽度阈值；
5. 取包含暗谷的连续暗区，得到自适应左右边界和宽度；
6. 自适应暗区高度重叠的候选自动合并；
7. 只对合并后的唯一候选测量暗区平均灰度；
8. 每张图再次对“候选平均灰度”做两簇K-means：
   - 更暗簇 = 真trench；
   - 更亮簇 = 伪暗纹；
9. 在真trench暗簇内部按周期一致性选择3~5条；
10. 将自适应中心和宽度交给下游边缘引擎与统计；是否开启Viterbi/ERF由主入口参数决定。

真假分类不使用边缘突变、梯度集中度或step-vs-ramp特征。
自适应宽度也不预设一个固定trench宽度，只使用：
- Stage-1初始宽度作为局部搜索尺度；
- 当前图片候选中心间距作为安全上限；
- 当前候选局部灰度的两簇分界确定暗区边界。
"""

from __future__ import annotations

import itertools
import math
from typing import Any, Callable, Sequence

import numpy as np
from scipy.ndimage import gaussian_filter1d


EPS = 1e-12


# ============================================================
# 基础统计
# ============================================================


def _finite(values: Sequence[float] | np.ndarray) -> np.ndarray:
    data = np.asarray(values, dtype=float)
    return data[np.isfinite(data)]


def _mad(
    values: Sequence[float] | np.ndarray,
    floor: float = 1e-9,
) -> float:
    data = _finite(values)
    if data.size == 0:
        return float(floor)

    median = float(np.median(data))
    value = 1.4826 * float(np.median(np.abs(data - median)))

    if not np.isfinite(value) or value < floor:
        q25, q75 = np.percentile(data, [25, 75])
        value = float((q75 - q25) / 1.349)

    if not np.isfinite(value) or value < floor:
        value = float(np.std(data))

    return float(max(value, floor))


def _trimmed_mean(
    values: Sequence[float] | np.ndarray,
    trim_fraction: float,
) -> float:
    data = np.sort(_finite(values))
    if data.size == 0:
        return float("nan")

    trim = int(math.floor(
        data.size * float(np.clip(trim_fraction, 0.0, 0.40))
    ))

    if 2 * trim >= data.size:
        return float(np.mean(data))

    if trim > 0:
        data = data[trim:-trim]

    return float(np.mean(data))


def _rank01(
    values: Sequence[float],
    higher_is_better: bool,
) -> np.ndarray:
    x = np.asarray(values, dtype=float)
    output = np.zeros(len(x), dtype=float)
    finite_mask = np.isfinite(x)

    if not np.any(finite_mask):
        return output

    finite_indices = np.where(finite_mask)[0]
    finite_values = x[finite_mask]
    order = np.argsort(finite_values)
    sorted_values = finite_values[order]
    ranks = np.empty(len(finite_values), dtype=float)

    start = 0
    while start < len(finite_values):
        end = start + 1
        while (
            end < len(finite_values)
            and abs(sorted_values[end] - sorted_values[start]) <= 1e-12
        ):
            end += 1

        ranks[order[start:end]] = 0.5 * (start + end - 1)
        start = end

    if len(finite_values) == 1:
        scaled = np.ones(1, dtype=float)
    else:
        scaled = ranks / (len(finite_values) - 1)

    if not higher_is_better:
        scaled = 1.0 - scaled

    output[finite_indices] = scaled
    return output


# ============================================================
# 通用一维两簇K-means
# ============================================================


def kmeans_two_1d(
    values: Sequence[float],
    restarts: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, float]:
    data = np.asarray(values, dtype=float)

    if data.ndim != 1:
        raise ValueError("一维K-means输入必须是一维")

    if len(data) == 0:
        raise ValueError("一维K-means输入不能为空")

    if not np.all(np.isfinite(data)):
        raise ValueError("一维K-means输入包含非有限值")

    count = len(data)

    if count == 1:
        return (
            np.zeros(1, dtype=int),
            np.asarray([data[0], data[0]], dtype=float),
            0.0,
        )

    if float(np.max(data) - np.min(data)) <= EPS:
        labels = np.zeros(count, dtype=int)
        labels[count // 2:] = 1
        centers = np.asarray([data[0], data[0]], dtype=float)
        return labels, centers, 0.0

    rng = np.random.default_rng(seed)

    initial_centers: list[tuple[float, float]] = [
        (
            float(np.percentile(data, 20)),
            float(np.percentile(data, 80)),
        ),
        (
            float(np.min(data)),
            float(np.max(data)),
        ),
    ]

    for _ in range(max(0, int(restarts) - len(initial_centers))):
        chosen = rng.choice(count, size=2, replace=False)
        initial_centers.append((
            float(data[chosen[0]]),
            float(data[chosen[1]]),
        ))

    best_labels = np.zeros(count, dtype=int)
    best_centers = np.asarray(
        [float(np.min(data)), float(np.max(data))],
        dtype=float,
    )
    best_sse = float("inf")

    for initial0, initial1 in initial_centers:
        centers = np.asarray([initial0, initial1], dtype=float)
        labels = np.zeros(count, dtype=int)

        for _ in range(100):
            distance0 = np.abs(data - centers[0])
            distance1 = np.abs(data - centers[1])
            new_labels = (distance1 < distance0).astype(int)

            if np.all(new_labels == 0) or np.all(new_labels == 1):
                break

            new_centers = np.asarray([
                float(np.mean(data[new_labels == 0])),
                float(np.mean(data[new_labels == 1])),
            ])

            converged = (
                np.array_equal(new_labels, labels)
                and np.max(np.abs(new_centers - centers)) < 1e-9
            )

            labels = new_labels
            centers = new_centers

            if converged:
                break

        if np.all(labels == 0) or np.all(labels == 1):
            continue

        sse = float(np.sum(
            (data - centers[labels]) ** 2
        ))

        if sse < best_sse:
            best_sse = sse
            best_labels = labels.copy()
            best_centers = centers.copy()

    if not np.isfinite(best_sse):
        order = np.argsort(data)
        best_labels = np.ones(count, dtype=int)
        best_labels[order[: max(1, count // 2)]] = 0

        if np.all(best_labels == 0) or np.all(best_labels == 1):
            best_labels[order[0]] = 0
            best_labels[order[-1]] = 1

        best_centers = np.asarray([
            float(np.mean(data[best_labels == 0])),
            float(np.mean(data[best_labels == 1])),
        ])
        best_sse = float(np.sum(
            (data - best_centers[best_labels]) ** 2
        ))

    return best_labels, best_centers, best_sse


# ============================================================
# 生成稳健代表profile
# ============================================================


def build_representative_profile(
    measurement_image: np.ndarray,
    fixed: Any,
    detection_summary: dict[str, Any],
    block_profile_fn: Callable[[np.ndarray, float, int], np.ndarray],
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """
    沿y方向取多个block profile，逐x做截尾平均。

    raw_profile:
        原始float灰度代表profile，用于平均亮度诊断。

    smooth_profile:
        仅用于自适应宽度与暗区连通区域，不用于最终CD/LWR。
    """
    image = np.asarray(measurement_image, dtype=np.float64)
    height, _ = image.shape

    center_y = (
        float(fixed.center_y_px)
        if fixed.center_y_px is not None
        else (height - 1) / 2.0
    )

    half_extend = min(
        fixed.extend_length_nm / fixed.pixel_size_nm / 2.0,
        center_y - 3.0,
        height - 4.0 - center_y,
    )

    default_y0 = max(0, int(round(center_y - half_extend)))
    default_y1 = min(height, int(round(center_y + half_extend)))

    y0 = int(detection_summary.get("y_start", default_y0))
    y1 = int(detection_summary.get("y_end", default_y1))
    y0 = int(np.clip(y0, 0, height - 1))
    y1 = int(np.clip(y1, y0 + 1, height))

    sample_count = max(15, int(fixed.width_profile_samples))
    block_height = max(1, int(fixed.width_profile_block_height_px))

    half_block = max(0.5, block_height / 2.0)
    safe_y0 = min(max(y0 + half_block, 0.0), height - 1.0)
    safe_y1 = max(min(y1 - half_block, height - 1.0), safe_y0)

    y_positions = np.linspace(
        safe_y0,
        safe_y1,
        sample_count,
    )

    profiles: list[np.ndarray] = []

    for y in y_positions:
        profile = np.asarray(
            block_profile_fn(
                image,
                float(y),
                block_height,
            ),
            dtype=float,
        )

        if profile.ndim == 1 and np.all(np.isfinite(profile)):
            profiles.append(profile)

    if len(profiles) < max(7, sample_count // 3):
        raise RuntimeError(
            f"代表profile有效采样不足：{len(profiles)}/{sample_count}"
        )

    stack = np.vstack(profiles)
    sorted_stack = np.sort(stack, axis=0)

    trim_fraction = float(np.clip(
        fixed.width_profile_trim_fraction,
        0.0,
        0.30,
    ))
    trim = int(math.floor(
        sorted_stack.shape[0] * trim_fraction
    ))

    if trim > 0 and 2 * trim < sorted_stack.shape[0]:
        trimmed = sorted_stack[trim:-trim]
    else:
        trimmed = sorted_stack

    raw_profile = np.mean(trimmed, axis=0)

    sigma = max(0.0, float(fixed.width_profile_sigma_px))
    smooth_profile = (
        gaussian_filter1d(raw_profile, sigma, mode="nearest")
        if sigma > 0
        else raw_profile.copy()
    )

    diagnostics = {
        "width_profile_requested_samples": sample_count,
        "width_profile_valid_samples": len(profiles),
        "width_profile_y0": y0,
        "width_profile_y1": y1,
        "width_profile_sigma_px": sigma,
    }

    return raw_profile, smooth_profile, diagnostics


# ============================================================
# 自适应宽度估计
# ============================================================


def estimate_candidate_spacing(
    centers: Sequence[float],
    restarts: int,
    seed: int,
) -> float:
    """
    从所有候选中心间距估计局部结构尺度。

    若同一trench被拆成多个候选，小间距会形成一组；
    真正相邻暗结构或真/伪交替结构形成较大间距组。
    这里只用于限制局部搜索窗口，不能决定真假trench。
    """
    sorted_centers = np.sort(_finite(centers))
    if sorted_centers.size < 2:
        return float("nan")

    gaps = np.diff(sorted_centers)
    gaps = gaps[gaps > 1.0]

    if gaps.size == 0:
        return float("nan")

    if gaps.size < 3 or float(np.max(gaps) - np.min(gaps)) < 2.0:
        return float(np.median(gaps))

    labels, gap_centers, _ = kmeans_two_1d(
        gaps,
        restarts=max(4, int(restarts)),
        seed=seed,
    )

    large_label = int(np.argmax(gap_centers))
    large_gaps = gaps[labels == large_label]

    if large_gaps.size == 0:
        return float(np.median(gaps))

    return float(np.median(large_gaps))


def _close_short_false_runs(
    mask: np.ndarray,
    maximum_gap: int,
) -> np.ndarray:
    """
    一维形态闭运算：填补暗区内部很短的亮缝。

    这用于防止同一宽trench内部的局部亮点把暗区拆成两段。
    maximum_gap由Stage-1初始宽度按比例给出，不是固定trench宽度。
    """
    output = np.asarray(mask, dtype=bool).copy()
    n = len(output)
    maximum_gap = max(0, int(maximum_gap))

    if maximum_gap == 0 or n == 0:
        return output

    index = 0

    while index < n:
        if output[index]:
            index += 1
            continue

        start = index

        while index < n and not output[index]:
            index += 1

        end = index
        length = end - start

        has_dark_left = start > 0 and output[start - 1]
        has_dark_right = end < n and output[end]

        if (
            length <= maximum_gap
            and has_dark_left
            and has_dark_right
        ):
            output[start:end] = True

    return output


def _component_containing(
    mask: np.ndarray,
    index: int,
) -> tuple[int, int] | None:
    data = np.asarray(mask, dtype=bool)
    n = len(data)

    if n == 0:
        return None

    index = int(np.clip(index, 0, n - 1))

    if not data[index]:
        true_indices = np.where(data)[0]
        if true_indices.size == 0:
            return None
        index = int(true_indices[
            np.argmin(np.abs(true_indices - index))
        ])

    left = index
    right = index

    while left > 0 and data[left - 1]:
        left -= 1

    while right + 1 < n and data[right + 1]:
        right += 1

    return left, right


def _interpolate_crossing(
    x0: int,
    y0: float,
    x1: int,
    y1: float,
    threshold: float,
) -> float:
    if not all(np.isfinite([y0, y1, threshold])):
        return float(x1)

    if abs(y1 - y0) <= EPS:
        return 0.5 * (x0 + x1)

    fraction = (threshold - y0) / (y1 - y0)
    fraction = float(np.clip(fraction, 0.0, 1.0))

    return float(x0 + fraction * (x1 - x0))


def estimate_adaptive_geometry(
    raw_profile: np.ndarray,
    smooth_profile: np.ndarray,
    candidate: dict[str, Any],
    structure_gap_px: float,
    fixed: Any,
) -> dict[str, Any]:
    """
    使用候选局部灰度两簇，自适应确定暗区左右边界。

    不预设真实trench宽度。
    """
    raw = np.asarray(raw_profile, dtype=float)
    smooth = np.asarray(smooth_profile, dtype=float)
    width_total = len(smooth)

    initial_center = float(
        candidate.get("candidate_center_x_px", np.nan)
    )
    initial_width = float(
        candidate.get("estimated_width_px", np.nan)
    )

    if (
        not np.isfinite(initial_center)
        or not np.isfinite(initial_width)
        or initial_width < 3.0
    ):
        return {
            "adaptive_width_valid": False,
            "adaptive_width_invalid_reason": (
                "invalid_initial_geometry"
            ),
        }

    if np.isfinite(structure_gap_px) and structure_gap_px > 4:
        safety_cap = (
            float(fixed.width_gap_cap_fraction)
            * structure_gap_px
        )
        minimum_scale = (
            float(fixed.width_gap_floor_fraction)
            * structure_gap_px
        )
    else:
        safety_cap = (
            float(fixed.width_image_cap_fraction)
            * width_total
        )
        minimum_scale = 0.0

    search_half = max(
        float(fixed.width_search_multiplier) * initial_width,
        minimum_scale,
        8.0,
    )
    search_half = min(
        search_half,
        max(safety_cap, 8.0),
        float(fixed.width_image_cap_fraction) * width_total,
    )

    # 先在候选附近用较强平滑profile寻找暗谷位置，
    # 防止同一trench内部的小暗纹产生两个中心。
    valley_search_half = min(
        search_half,
        max(
            float(fixed.width_valley_search_multiplier)
            * initial_width,
            6.0,
        ),
    )

    valley0 = int(np.clip(
        math.floor(initial_center - valley_search_half),
        0,
        width_total - 1,
    ))
    valley1 = int(np.clip(
        math.ceil(initial_center + valley_search_half) + 1,
        valley0 + 1,
        width_total,
    ))

    local_valley_index = int(np.argmin(
        smooth[valley0:valley1]
    ))
    valley_x = int(valley0 + local_valley_index)

    segment0 = int(np.clip(
        math.floor(valley_x - search_half),
        0,
        width_total - 1,
    ))
    segment1 = int(np.clip(
        math.ceil(valley_x + search_half) + 1,
        segment0 + 1,
        width_total,
    ))

    segment = smooth[segment0:segment1]

    if segment.size < 9:
        return {
            "adaptive_width_valid": False,
            "adaptive_width_invalid_reason": (
                "adaptive_segment_too_short"
            ),
        }

    labels, centers, local_sse = kmeans_two_1d(
        segment,
        restarts=max(4, int(fixed.width_local_kmeans_restarts)),
        seed=int(fixed.random_seed),
    )

    dark_label = int(np.argmin(centers))
    bright_label = 1 - dark_label
    dark_center = float(centers[dark_label])
    bright_center = float(centers[bright_label])
    threshold = 0.5 * (dark_center + bright_center)

    dark_mask = labels == dark_label

    local_valley = valley_x - segment0

    maximum_internal_gap = int(round(
        float(fixed.width_internal_gap_fraction)
        * initial_width
    ))
    dark_mask = _close_short_false_runs(
        dark_mask,
        maximum_gap=maximum_internal_gap,
    )

    component = _component_containing(
        dark_mask,
        local_valley,
    )

    if component is None:
        return {
            "adaptive_width_valid": False,
            "adaptive_width_invalid_reason": (
                "no_dark_component"
            ),
        }

    left_index, right_index = component
    left_global = segment0 + left_index
    right_global = segment0 + right_index

    # 在线性阈值处插值得到亚像素边界。
    if left_global > 0:
        adaptive_left = _interpolate_crossing(
            left_global - 1,
            float(smooth[left_global - 1]),
            left_global,
            float(smooth[left_global]),
            threshold,
        )
    else:
        adaptive_left = float(left_global)

    if right_global + 1 < width_total:
        adaptive_right = _interpolate_crossing(
            right_global,
            float(smooth[right_global]),
            right_global + 1,
            float(smooth[right_global + 1]),
            threshold,
        )
    else:
        adaptive_right = float(right_global)

    adaptive_width = adaptive_right - adaptive_left
    adaptive_center = 0.5 * (
        adaptive_left + adaptive_right
    )

    if (
        not np.isfinite(adaptive_width)
        or adaptive_width < 3.0
        or adaptive_right <= adaptive_left
    ):
        return {
            "adaptive_width_valid": False,
            "adaptive_width_invalid_reason": (
                "invalid_adaptive_width"
            ),
        }

    dark_pixels = raw[
        max(0, int(math.floor(adaptive_left))):
        min(width_total, int(math.ceil(adaptive_right)) + 1)
    ]

    return {
        "adaptive_width_valid": True,
        "adaptive_initial_center_x_px": initial_center,
        "adaptive_initial_width_px": initial_width,
        "adaptive_structure_gap_px": (
            float(structure_gap_px)
            if np.isfinite(structure_gap_px)
            else np.nan
        ),
        "adaptive_search_half_px": float(search_half),
        "adaptive_valley_x_px": float(valley_x),
        "adaptive_left_x_px": float(adaptive_left),
        "adaptive_right_x_px": float(adaptive_right),
        "adaptive_center_x_px": float(adaptive_center),
        "adaptive_width_px": float(adaptive_width),
        "adaptive_width_ratio": float(
            adaptive_width / max(initial_width, EPS)
        ),
        "adaptive_local_dark_center_raw": dark_center,
        "adaptive_local_bright_center_raw": bright_center,
        "adaptive_local_threshold_raw": threshold,
        "adaptive_local_cluster_gap_raw": (
            bright_center - dark_center
        ),
        "adaptive_local_kmeans_sse": float(local_sse),
        "adaptive_profile_mean_raw": (
            float(np.mean(dark_pixels))
            if dark_pixels.size
            else np.nan
        ),
        "adaptive_width_invalid_reason": "",
    }


# ============================================================
# 合并同一暗区的重复候选
# ============================================================


def _interval_overlap_metrics(
    left1: float,
    right1: float,
    left2: float,
    right2: float,
) -> tuple[float, float]:
    intersection = max(
        0.0,
        min(right1, right2) - max(left1, left2),
    )
    width1 = max(right1 - left1, EPS)
    width2 = max(right2 - left2, EPS)
    union = max(right1, right2) - min(left1, left2)

    overlap_smaller = intersection / min(width1, width2)
    iou = intersection / max(union, EPS)

    return float(overlap_smaller), float(iou)


def merge_duplicate_candidates(
    rows: list[dict[str, Any]],
    fixed: Any,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """
    根据自适应暗区边界合并重复候选。

    合并判断只用于“是否属于同一个空间暗区”，不参与真假亮度分群。
    """
    valid_rows = [
        row for row in rows
        if bool(row.get("adaptive_width_valid", False))
    ]

    if not valid_rows:
        return [], {
            "adaptive_unique_candidate_count": 0,
            "adaptive_merged_duplicate_count": 0,
            "adaptive_merge_group_count": 0,
        }

    valid_rows = sorted(
        valid_rows,
        key=lambda row: float(row["adaptive_center_x_px"]),
    )

    count = len(valid_rows)
    parent = list(range(count))

    def find(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    def union(first: int, second: int) -> None:
        root1 = find(first)
        root2 = find(second)
        if root1 != root2:
            parent[root2] = root1

    overlap_threshold = float(np.clip(
        fixed.width_merge_overlap_fraction,
        0.20,
        0.95,
    ))
    iou_threshold = float(np.clip(
        fixed.width_merge_iou_fraction,
        0.10,
        0.90,
    ))
    center_fraction = float(np.clip(
        fixed.width_merge_center_fraction,
        0.10,
        0.80,
    ))

    for first in range(count):
        row1 = valid_rows[first]
        left1 = float(row1["adaptive_left_x_px"])
        right1 = float(row1["adaptive_right_x_px"])
        center1 = float(row1["adaptive_center_x_px"])
        width1 = float(row1["adaptive_width_px"])

        for second in range(first + 1, count):
            row2 = valid_rows[second]
            left2 = float(row2["adaptive_left_x_px"])
            right2 = float(row2["adaptive_right_x_px"])
            center2 = float(row2["adaptive_center_x_px"])
            width2 = float(row2["adaptive_width_px"])

            # 已完全越过可能重叠范围时提前停止。
            if left2 > right1 + max(width1, width2):
                break

            overlap_smaller, iou = _interval_overlap_metrics(
                left1,
                right1,
                left2,
                right2,
            )

            center_distance = abs(center2 - center1)
            same_spatial_basin = bool(
                overlap_smaller >= overlap_threshold
                or iou >= iou_threshold
                or (
                    center_distance
                    <= center_fraction * min(width1, width2)
                    and max(left1, left2) < min(right1, right2)
                )
            )

            if same_spatial_basin:
                union(first, second)

    groups: dict[int, list[dict[str, Any]]] = {}

    for index, row in enumerate(valid_rows):
        root = find(index)
        groups.setdefault(root, []).append(row)

    representatives: list[dict[str, Any]] = []
    merged_duplicate_count = 0

    ordered_groups = sorted(
        groups.values(),
        key=lambda group: float(np.median([
            row["adaptive_center_x_px"]
            for row in group
        ])),
    )

    for group_id, group in enumerate(ordered_groups):
        # 代表项优先选择局部暗区平均最暗者；
        # 若相同则选择原Stage-1 candidate_score更高者。
        representative = min(
            group,
            key=lambda row: (
                float(row.get(
                    "adaptive_profile_mean_raw",
                    np.inf,
                )),
                -float(row.get("candidate_score", 0.0)),
            ),
        )

        group_left = float(np.median([
            float(row["adaptive_left_x_px"])
            for row in group
        ]))
        group_right = float(np.median([
            float(row["adaptive_right_x_px"])
            for row in group
        ]))
        group_center = 0.5 * (
            group_left + group_right
        )
        group_width = group_right - group_left

        source_centers = [
            float(row.get(
                "candidate_center_x_px",
                np.nan,
            ))
            for row in group
        ]
        source_widths = [
            float(row.get(
                "estimated_width_px",
                np.nan,
            ))
            for row in group
        ]

        for row in group:
            is_representative = row is representative
            row["adaptive_merge_group_id"] = group_id
            row["adaptive_merge_group_size"] = len(group)
            row["adaptive_merge_representative"] = is_representative
            row["adaptive_duplicate_merged"] = (
                not is_representative
            )
            row["adaptive_merged_center_x_px"] = group_center
            row["adaptive_merged_left_x_px"] = group_left
            row["adaptive_merged_right_x_px"] = group_right
            row["adaptive_merged_width_px"] = group_width
            row["adaptive_merge_source_centers_px"] = ",".join(
                f"{value:.3f}" for value in source_centers
            )
            row["adaptive_merge_source_widths_px"] = ",".join(
                f"{value:.3f}" for value in source_widths
            )

        # 更新代表候选几何，供后续平均亮度和边缘引擎使用。
        representative["candidate_center_x_px"] = group_center
        representative["estimated_width_px"] = group_width
        representative["estimated_width_nm"] = (
            group_width * fixed.pixel_size_nm
        )
        representative["adaptive_left_x_px"] = group_left
        representative["adaptive_right_x_px"] = group_right
        representative["adaptive_center_x_px"] = group_center
        representative["adaptive_width_px"] = group_width
        representative["adaptive_width_ratio"] = (
            group_width
            / max(
                float(representative.get(
                    "adaptive_initial_width_px",
                    group_width,
                )),
                EPS,
            )
        )

        representatives.append(representative)
        merged_duplicate_count += max(0, len(group) - 1)

    diagnostics = {
        "adaptive_unique_candidate_count": len(representatives),
        "adaptive_merged_duplicate_count": merged_duplicate_count,
        "adaptive_merge_group_count": len(ordered_groups),
        "adaptive_largest_merge_group": max(
            len(group) for group in ordered_groups
        ),
    }

    return representatives, diagnostics


# ============================================================
# 使用自适应宽度测候选平均亮度
# ============================================================


def candidate_average_brightness(
    measurement_image: np.ndarray,
    candidate: dict[str, Any],
    fixed: Any,
    detection_summary: dict[str, Any],
    block_profile_fn: Callable[[np.ndarray, float, int], np.ndarray],
) -> dict[str, Any]:
    image = np.asarray(measurement_image, dtype=np.float64)
    height, width = image.shape

    center_x = float(
        candidate.get("candidate_center_x_px", np.nan)
    )
    candidate_width_px = float(
        candidate.get("estimated_width_px", np.nan)
    )

    if (
        not np.isfinite(center_x)
        or not np.isfinite(candidate_width_px)
        or candidate_width_px < 3.0
    ):
        return {
            "brightness_valid": False,
            "brightness_invalid_reason": (
                "invalid_adaptive_geometry"
            ),
        }

    center_y = (
        float(fixed.center_y_px)
        if fixed.center_y_px is not None
        else (height - 1) / 2.0
    )

    half_extend = min(
        fixed.extend_length_nm / fixed.pixel_size_nm / 2.0,
        center_y - 3.0,
        height - 4.0 - center_y,
    )

    default_y0 = max(0, int(round(center_y - half_extend)))
    default_y1 = min(height, int(round(center_y + half_extend)))

    y0 = int(detection_summary.get("y_start", default_y0))
    y1 = int(detection_summary.get("y_end", default_y1))
    y0 = int(np.clip(y0, 0, height - 1))
    y1 = int(np.clip(y1, y0 + 1, height))

    sample_count = max(9, int(fixed.brightness_samples))
    block_height = max(1, int(fixed.brightness_block_height_px))

    half_block = max(0.5, block_height / 2.0)
    safe_y0 = min(max(y0 + half_block, 0.0), height - 1.0)
    safe_y1 = max(min(y1 - half_block, height - 1.0), safe_y0)

    y_positions = np.linspace(
        safe_y0,
        safe_y1,
        sample_count,
    )

    core_fraction = float(np.clip(
        fixed.brightness_core_fraction,
        0.30,
        0.95,
    ))
    core_half_width = max(
        1.5,
        0.5 * candidate_width_px * core_fraction,
    )

    core0 = int(np.clip(
        math.floor(center_x - core_half_width),
        0,
        width,
    ))
    core1 = int(np.clip(
        math.ceil(center_x + core_half_width) + 1,
        0,
        width,
    ))

    if core1 - core0 < 3:
        return {
            "brightness_valid": False,
            "brightness_invalid_reason": (
                "brightness_core_too_narrow"
            ),
        }

    per_y_means: list[float] = []
    all_core_pixels: list[np.ndarray] = []

    for y in y_positions:
        profile = np.asarray(
            block_profile_fn(
                image,
                float(y),
                block_height,
            ),
            dtype=float,
        )

        core_values = _finite(profile[core0:core1])

        if core_values.size < 3:
            continue

        per_y_means.append(float(np.mean(core_values)))
        all_core_pixels.append(core_values)

    valid_count = len(per_y_means)

    if valid_count < max(5, sample_count // 3):
        return {
            "brightness_valid": False,
            "brightness_valid_sample_count": valid_count,
            "brightness_sample_count": sample_count,
            "brightness_invalid_reason": (
                "brightness_insufficient_valid_samples"
            ),
        }

    concatenated = np.concatenate(all_core_pixels)

    trim_fraction = float(np.clip(
        fixed.brightness_trim_fraction,
        0.0,
        0.30,
    ))

    core_mean_raw = _trimmed_mean(
        concatenated,
        trim_fraction,
    )

    image_values = _finite(image)
    image_p05, image_p95 = np.percentile(
        image_values,
        [5, 95],
    )
    image_dynamic = max(
        float(image_p95 - image_p05),
        1e-9,
    )
    core_mean_normalized = (
        core_mean_raw - float(image_p05)
    ) / image_dynamic

    per_y_array = np.asarray(per_y_means, dtype=float)
    y_mean_median = float(np.median(per_y_array))
    y_mean_mad = _mad(
        per_y_array,
        floor=max(abs(y_mean_median) * 1e-7, 1e-9),
    )

    return {
        "brightness_valid": True,
        "brightness_valid_sample_count": valid_count,
        "brightness_sample_count": sample_count,
        "brightness_valid_fraction": valid_count / sample_count,
        "brightness_core_x0_px": core0,
        "brightness_core_x1_px": core1,
        "brightness_core_width_px": core1 - core0,
        "brightness_core_mean_raw": float(core_mean_raw),
        "brightness_core_mean_normalized": float(
            core_mean_normalized
        ),
        "brightness_core_median_raw": float(
            np.median(concatenated)
        ),
        "brightness_core_p10_raw": float(
            np.percentile(concatenated, 10)
        ),
        "brightness_core_p90_raw": float(
            np.percentile(concatenated, 90)
        ),
        "brightness_y_mean_median_raw": y_mean_median,
        "brightness_y_mean_mad_raw": y_mean_mad,
        "brightness_y_relative_variation": float(
            y_mean_mad / image_dynamic
        ),
        "brightness_invalid_reason": "",
    }


def _dark_cluster_probability(
    brightness: np.ndarray,
    centers: np.ndarray,
    dark_label: int,
) -> np.ndarray:
    values = np.asarray(brightness, dtype=float)
    centers = np.asarray(centers, dtype=float)

    spread = _mad(
        values,
        floor=max(
            abs(float(np.mean(values))) * 1e-7,
            1e-9,
        ),
    )

    distance_squared = (
        values[:, None] - centers[None, :]
    ) ** 2

    logits = -distance_squared / (2.0 * spread**2)
    logits -= np.max(logits, axis=1, keepdims=True)

    probability = np.exp(logits)
    probability /= np.sum(probability, axis=1, keepdims=True)

    return probability[:, int(dark_label)]


# ============================================================
# 暗簇内部组合选择
# ============================================================


def _selected_intervals_overlap(
    combination: Sequence[dict[str, Any]],
) -> bool:
    ordered = sorted(
        combination,
        key=lambda row: float(row["candidate_center_x_px"]),
    )

    for first, second in zip(ordered[:-1], ordered[1:]):
        right_first = float(
            first.get(
                "adaptive_right_x_px",
                float(first["candidate_center_x_px"])
                + 0.5 * float(first["estimated_width_px"]),
            )
        )
        left_second = float(
            second.get(
                "adaptive_left_x_px",
                float(second["candidate_center_x_px"])
                - 0.5 * float(second["estimated_width_px"]),
            )
        )

        if left_second < right_first:
            return True

    return False


def _group_cost(
    combination: Sequence[dict[str, Any]],
    image_center_x: float,
) -> float:
    if _selected_intervals_overlap(combination):
        return float("inf")

    positions = np.asarray([
        float(row["candidate_center_x_px"])
        for row in combination
    ])
    widths = np.asarray([
        float(row["estimated_width_px"])
        for row in combination
    ])

    pitches = np.diff(positions)

    if pitches.size == 0 or np.min(pitches) <= 0:
        return float("inf")

    pitch_mean = float(np.mean(pitches))
    pitch_cv = float(
        np.std(pitches) / max(pitch_mean, EPS)
    )
    pitch_ratio = float(
        np.max(pitches) / max(np.min(pitches), EPS)
    )
    width_cv = float(
        np.std(widths) / max(np.mean(widths), EPS)
    )
    center_offset = abs(
        float(np.median(positions)) - image_center_x
    )

    darkness_ranks = np.asarray([
        float(row.get("brightness_darkness_rank", 0.0))
        for row in combination
    ])
    dark_probabilities = np.asarray([
        float(row.get("brightness_dark_probability", 0.0))
        for row in combination
    ])

    return float(
        2.35 * pitch_cv
        + 0.82 * max(0.0, pitch_ratio - 1.0)
        + 0.28 * width_cv
        + 0.55 * center_offset / max(pitch_mean, 1.0)
        - 1.10 * float(np.mean(darkness_ranks))
        - 0.45 * float(np.mean(dark_probabilities))
    )


# ============================================================
# 完整入口
# ============================================================


def select_adaptive_width_brightness_trenches(
    measurement_image: np.ndarray,
    stage1_candidates: list[dict[str, Any]],
    candidate_rows: list[dict[str, Any]],
    detection_summary: dict[str, Any],
    fixed: Any,
    block_profile_fn: Callable[[np.ndarray, float, int], np.ndarray],
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    dict[str, Any],
]:
    rows = [dict(row) for row in candidate_rows]
    summary = dict(detection_summary)

    if not fixed.brightness_filter_enabled:
        return stage1_candidates, rows, summary

    for row in rows:
        row["selected_before_adaptive_width"] = bool(
            row.get("selected", False)
        )
        row["selected"] = False
        row["brightness_selected"] = False
        row["brightness_true_trench"] = False
        row["adaptive_duplicate_merged"] = False
        row["adaptive_merge_representative"] = False

    raw_profile, smooth_profile, profile_diagnostics = (
        build_representative_profile(
            measurement_image,
            fixed,
            summary,
            block_profile_fn,
        )
    )

    geometry_rows = [
        row for row in rows
        if (
            np.isfinite(float(
                row.get("candidate_center_x_px", np.nan)
            ))
            and np.isfinite(float(
                row.get("estimated_width_px", np.nan)
            ))
            and float(row.get("estimated_width_px", 0.0)) >= 3.0
        )
    ]

    structure_gap = estimate_candidate_spacing(
        [
            float(row["candidate_center_x_px"])
            for row in geometry_rows
        ],
        restarts=max(4, int(fixed.width_local_kmeans_restarts)),
        seed=int(fixed.random_seed),
    )

    for row in geometry_rows:
        metrics = estimate_adaptive_geometry(
            raw_profile,
            smooth_profile,
            row,
            structure_gap,
            fixed,
        )
        row.update(metrics)

    representatives, merge_diagnostics = merge_duplicate_candidates(
        geometry_rows,
        fixed,
    )

    if len(representatives) < fixed.min_candidate_trenches:
        summary.update({
            "detection_success": False,
            "reason": (
                f"自适应宽度合并后候选不足"
                f"{fixed.min_candidate_trenches}条"
                f"（实际{len(representatives)}条）"
            ),
            "brightness_filter_enabled": True,
            "adaptive_width_candidate_count": len(geometry_rows),
            "adaptive_width_valid_count": sum(
                bool(row.get("adaptive_width_valid", False))
                for row in geometry_rows
            ),
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **merge_diagnostics,
        })
        return [], rows, summary

    eligible: list[dict[str, Any]] = []

    for row in representatives:
        metrics = candidate_average_brightness(
            measurement_image,
            row,
            fixed,
            summary,
            block_profile_fn,
        )
        row.update(metrics)

        if bool(row.get("brightness_valid", False)):
            eligible.append(row)

    if len(eligible) < fixed.min_candidate_trenches:
        summary.update({
            "detection_success": False,
            "reason": (
                f"自适应宽度候选亮度有效不足"
                f"{fixed.min_candidate_trenches}条"
                f"（实际{len(eligible)}条）"
            ),
            "brightness_filter_enabled": True,
            "brightness_valid_candidate_count": len(eligible),
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **merge_diagnostics,
        })
        return [], rows, summary

    brightness_values = np.asarray([
        float(row["brightness_core_mean_raw"])
        for row in eligible
    ])

    labels, centers, brightness_sse = kmeans_two_1d(
        brightness_values,
        restarts=max(4, int(fixed.brightness_kmeans_restarts)),
        seed=int(fixed.random_seed),
    )

    dark_label = int(np.argmin(centers))
    bright_label = 1 - dark_label
    dark_center = float(centers[dark_label])
    bright_center = float(centers[bright_label])
    threshold_raw = 0.5 * (
        dark_center + bright_center
    )

    image_values = _finite(measurement_image)
    image_p05, image_p95 = np.percentile(
        image_values,
        [5, 95],
    )
    image_dynamic = max(
        float(image_p95 - image_p05),
        1e-9,
    )
    threshold_normalized = (
        threshold_raw - float(image_p05)
    ) / image_dynamic

    dark_probability = _dark_cluster_probability(
        brightness_values,
        centers,
        dark_label,
    )
    darkness_rank = _rank01(
        brightness_values,
        higher_is_better=False,
    )

    for index, row in enumerate(eligible):
        is_dark = int(labels[index]) == dark_label

        row["brightness_cluster_label"] = int(labels[index])
        row["brightness_dark_cluster_label"] = dark_label
        row["brightness_bright_cluster_label"] = bright_label
        row["brightness_true_trench"] = bool(is_dark)
        row["brightness_dark_probability"] = float(
            dark_probability[index]
        )
        row["brightness_darkness_rank"] = float(
            darkness_rank[index]
        )
        row["brightness_threshold_raw"] = threshold_raw
        row["brightness_threshold_normalized"] = (
            threshold_normalized
        )
        row["brightness_dark_cluster_center_raw"] = dark_center
        row["brightness_bright_cluster_center_raw"] = bright_center
        row["brightness_cluster_gap_raw"] = (
            bright_center - dark_center
        )
        row["brightness_kmeans_sse"] = brightness_sse

    dark_pool = [
        row for row in eligible
        if bool(row.get("brightness_true_trench", False))
    ]
    bright_pool = [
        row for row in eligible
        if not bool(row.get("brightness_true_trench", False))
    ]

    if len(dark_pool) < fixed.min_candidate_trenches:
        summary.update({
            "detection_success": False,
            "reason": (
                f"自适应宽度后的平均亮度暗簇不足"
                f"{fixed.min_candidate_trenches}条"
                f"（实际{len(dark_pool)}条）"
            ),
            "brightness_filter_enabled": True,
            "brightness_valid_candidate_count": len(eligible),
            "brightness_dark_cluster_count": len(dark_pool),
            "brightness_bright_cluster_count": len(bright_pool),
            "brightness_dark_cluster_center_raw": dark_center,
            "brightness_bright_cluster_center_raw": bright_center,
            "brightness_threshold_raw": threshold_raw,
            "brightness_threshold_normalized": threshold_normalized,
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **merge_diagnostics,
        })
        return [], rows, summary

    dark_pool = sorted(
        dark_pool,
        key=lambda row: (
            float(row["brightness_core_mean_raw"]),
            -float(row.get("brightness_dark_probability", 0.0)),
        ),
    )[: max(
        fixed.min_candidate_trenches,
        int(fixed.brightness_candidate_pool),
    )]

    dark_pool = sorted(
        dark_pool,
        key=lambda row: float(row["candidate_center_x_px"]),
    )

    selected_count = min(
        fixed.preferred_trenches,
        len(dark_pool),
    )

    image_center_x = (
        float(fixed.center_x_px)
        if fixed.center_x_px is not None
        else (measurement_image.shape[1] - 1) / 2.0
    )

    best_group: list[dict[str, Any]] | None = None
    best_cost = float("inf")

    for combination in itertools.combinations(
        dark_pool,
        selected_count,
    ):
        cost = _group_cost(
            combination,
            image_center_x,
        )

        if cost < best_cost:
            best_cost = cost
            best_group = list(combination)

    if best_group is None or not np.isfinite(best_cost):
        summary.update({
            "detection_success": False,
            "reason": (
                "没有找到互不重叠且周期一致的真trench组合"
            ),
            "brightness_filter_enabled": True,
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **merge_diagnostics,
        })
        return [], rows, summary

    selected_ids = {id(row) for row in best_group}

    for row in rows:
        selected = id(row) in selected_ids
        row["selected"] = selected
        row["brightness_selected"] = selected

    selected_rows = sorted(
        best_group,
        key=lambda row: float(row["candidate_center_x_px"]),
    )

    pitches = np.diff([
        float(row["candidate_center_x_px"])
        for row in selected_rows
    ])

    selected_brightness = np.asarray([
        float(row["brightness_core_mean_raw"])
        for row in selected_rows
    ])
    selected_widths = np.asarray([
        float(row["estimated_width_px"])
        for row in selected_rows
    ])

    selected_widths_nm = (
        selected_widths * fixed.pixel_size_nm
    ).tolist()

    brightness_scale = _mad(
        brightness_values,
        floor=max(
            abs(float(np.mean(brightness_values))) * 1e-7,
            1e-9,
        ),
    )
    cluster_separation = (
        bright_center - dark_center
    ) / brightness_scale

    summary.update({
        "detection_success": True,
        "reason": "",
        "brightness_filter_enabled": True,
        "adaptive_width_candidate_count": len(geometry_rows),
        "adaptive_width_valid_count": sum(
            bool(row.get("adaptive_width_valid", False))
            for row in geometry_rows
        ),
        "adaptive_structure_gap_px": (
            structure_gap
            if np.isfinite(structure_gap)
            else np.nan
        ),
        "brightness_valid_candidate_count": len(eligible),
        "brightness_dark_cluster_count": len(dark_pool),
        "brightness_bright_cluster_count": len(bright_pool),
        "brightness_dark_cluster_center_raw": dark_center,
        "brightness_bright_cluster_center_raw": bright_center,
        "brightness_threshold_raw": threshold_raw,
        "brightness_threshold_normalized": threshold_normalized,
        "brightness_cluster_gap_raw": bright_center - dark_center,
        "brightness_cluster_separation_mad": cluster_separation,
        "brightness_kmeans_sse": brightness_sse,
        "brightness_selected_count": len(selected_rows),
        "brightness_selected_mean_raw": float(
            np.mean(selected_brightness)
        ),
        "adaptive_selected_width_median_px": float(
            np.median(selected_widths)
        ),
        "adaptive_selected_width_min_px": float(
            np.min(selected_widths)
        ),
        "adaptive_selected_width_max_px": float(
            np.max(selected_widths)
        ),
        "brightness_group_cost": best_cost,
        "selected_count": len(selected_rows),
        "selected_target_count": selected_count,
        "selected_centers_px": [
            float(row["candidate_center_x_px"])
            for row in selected_rows
        ],
        "selected_estimated_widths_nm": selected_widths_nm,
        "estimated_width_median_nm": float(
            np.median(selected_widths_nm)
        ),
        "pitch_mean_px": (
            float(np.mean(pitches)) if pitches.size else np.nan
        ),
        "pitch_cv": (
            float(np.std(pitches) / max(np.mean(pitches), EPS))
            if pitches.size else np.nan
        ),
        "pitch_ratio": (
            float(np.max(pitches) / max(np.min(pitches), EPS))
            if pitches.size else np.nan
        ),
        "edge_mode": (
            "adaptive_dark_basin_width_then_brightness_clustering"
        ),
        **profile_diagnostics,
        **merge_diagnostics,
    })

    return selected_rows, rows, summary


# ============================================================
# V1.14 OVERRIDE
# 高亮分隔带切分独立暗盆地 + 平均亮度逐级放宽
# ============================================================


def kmeans_1d_general(
    values: Sequence[float],
    cluster_count: int,
    restarts: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, float]:
    """通用一维K-means，输出中心按从暗到亮排序。"""
    data = np.asarray(values, dtype=float)
    cluster_count = int(cluster_count)

    if data.ndim != 1:
        raise ValueError("kmeans_1d_general输入必须是一维")
    if len(data) < cluster_count:
        raise ValueError(
            f"至少需要{cluster_count}个数据，实际{len(data)}"
        )
    if not np.all(np.isfinite(data)):
        raise ValueError("K-means输入包含非有限值")

    if float(np.max(data) - np.min(data)) <= EPS:
        labels = np.arange(len(data), dtype=int) % cluster_count
        centers = np.full(cluster_count, float(data[0]))
        return labels, centers, 0.0

    rng = np.random.default_rng(seed)
    quantiles = np.linspace(
        0, 100, cluster_count + 2
    )[1:-1]

    initial_sets: list[np.ndarray] = [
        np.percentile(data, quantiles).astype(float),
        np.linspace(
            float(np.min(data)),
            float(np.max(data)),
            cluster_count,
        ),
    ]

    for _ in range(max(0, int(restarts) - len(initial_sets))):
        indices = rng.choice(
            len(data),
            size=cluster_count,
            replace=False,
        )
        initial_sets.append(
            np.sort(data[indices].astype(float))
        )

    best_labels: np.ndarray | None = None
    best_centers: np.ndarray | None = None
    best_sse = float("inf")

    for initial in initial_sets:
        centers = np.asarray(initial, dtype=float).copy()
        labels = np.zeros(len(data), dtype=int)

        for _ in range(150):
            distances = np.abs(
                data[:, None] - centers[None, :]
            )
            new_labels = np.argmin(distances, axis=1)

            new_centers = centers.copy()
            valid = True
            for cluster in range(cluster_count):
                members = data[new_labels == cluster]
                if members.size == 0:
                    valid = False
                    break
                new_centers[cluster] = float(np.mean(members))

            if not valid:
                break

            converged = (
                np.array_equal(new_labels, labels)
                and np.max(np.abs(new_centers - centers)) < 1e-9
            )
            labels = new_labels
            centers = new_centers

            if converged:
                break

        counts = np.bincount(labels, minlength=cluster_count)
        if np.any(counts == 0):
            continue

        sse = float(np.sum((data - centers[labels]) ** 2))
        if sse < best_sse:
            best_sse = sse
            best_labels = labels.copy()
            best_centers = centers.copy()

    if best_labels is None or best_centers is None:
        order = np.argsort(data)
        split_groups = np.array_split(order, cluster_count)
        best_labels = np.zeros(len(data), dtype=int)

        for cluster, indices in enumerate(split_groups):
            best_labels[indices] = cluster

        best_centers = np.asarray([
            float(np.mean(data[best_labels == cluster]))
            for cluster in range(cluster_count)
        ])
        best_sse = float(np.sum(
            (data - best_centers[best_labels]) ** 2
        ))

    center_order = np.argsort(best_centers)
    remap = np.empty(cluster_count, dtype=int)
    for new_label, old_label in enumerate(center_order):
        remap[old_label] = new_label

    return (
        remap[best_labels],
        best_centers[center_order],
        best_sse,
    )


def _fill_short_false_runs_v114(
    mask: np.ndarray,
    maximum_gap: int,
) -> np.ndarray:
    output = np.asarray(mask, dtype=bool).copy()
    maximum_gap = max(0, int(maximum_gap))
    index = 0

    while index < len(output):
        if output[index]:
            index += 1
            continue

        start = index
        while index < len(output) and not output[index]:
            index += 1
        end = index

        if (
            end - start <= maximum_gap
            and start > 0
            and end < len(output)
            and output[start - 1]
            and output[end]
        ):
            output[start:end] = True

    return output


def _remove_short_true_runs_v114(
    mask: np.ndarray,
    minimum_run: int,
) -> np.ndarray:
    output = np.asarray(mask, dtype=bool).copy()
    minimum_run = max(1, int(minimum_run))
    index = 0

    while index < len(output):
        if not output[index]:
            index += 1
            continue

        start = index
        while index < len(output) and output[index]:
            index += 1
        end = index

        if end - start < minimum_run:
            output[start:end] = False

    return output


def _nonbright_runs_v114(
    bright_mask: np.ndarray,
) -> list[tuple[int, int]]:
    mask = np.asarray(bright_mask, dtype=bool)
    runs: list[tuple[int, int]] = []
    index = 0

    while index < len(mask):
        if mask[index]:
            index += 1
            continue

        start = index
        while index < len(mask) and not mask[index]:
            index += 1
        runs.append((start, index))

    return runs


def _nearest_basin_v114(
    basins: list[tuple[int, int]],
    x: float,
) -> tuple[int | None, float]:
    if not basins:
        return None, float("inf")

    best_index: int | None = None
    best_distance = float("inf")
    position = float(x)

    for index, (start, end) in enumerate(basins):
        if start <= position < end:
            return index, 0.0

        if position < start:
            distance = start - position
        else:
            distance = position - (end - 1)

        if distance < best_distance:
            best_index = index
            best_distance = distance

    return best_index, float(best_distance)


def segment_bright_separators_v114(
    smooth_profile: np.ndarray,
    initial_widths: Sequence[float],
    fixed: Any,
) -> tuple[
    np.ndarray,
    list[tuple[int, int]],
    dict[str, Any],
]:
    """
    代表profile做三簇：
    低亮、中亮、高亮。
    中亮/高亮中心中点作为本图高亮分隔阈值。
    """
    profile = np.asarray(smooth_profile, dtype=float)

    _, centers, sse = kmeans_1d_general(
        profile,
        cluster_count=3,
        restarts=max(
            6,
            int(fixed.separator_kmeans_restarts),
        ),
        seed=int(fixed.random_seed),
    )

    low_center = float(centers[0])
    middle_center = float(centers[1])
    high_center = float(centers[2])
    bright_threshold = 0.5 * (
        middle_center + high_center
    )

    bright_mask = profile >= bright_threshold

    valid_widths = _finite(initial_widths)
    typical_width = (
        float(np.median(valid_widths))
        if valid_widths.size
        else 50.0
    )

    minimum_run = max(
        2,
        int(round(
            typical_width
            * float(fixed.separator_min_run_fraction)
        )),
    )
    close_gap = max(
        1,
        int(round(
            typical_width
            * float(fixed.separator_close_gap_fraction)
        )),
    )

    bright_mask = _fill_short_false_runs_v114(
        bright_mask,
        maximum_gap=close_gap,
    )
    bright_mask = _remove_short_true_runs_v114(
        bright_mask,
        minimum_run=minimum_run,
    )

    basins = _nonbright_runs_v114(bright_mask)

    diagnostics = {
        "separator_low_center_raw": low_center,
        "separator_middle_center_raw": middle_center,
        "separator_high_center_raw": high_center,
        "separator_bright_threshold_raw": bright_threshold,
        "separator_kmeans_sse": float(sse),
        "separator_minimum_run_px": minimum_run,
        "separator_close_gap_px": close_gap,
        "separator_basin_count": len(basins),
    }

    return bright_mask, basins, diagnostics


def map_candidates_to_basins_v114(
    candidate_rows: list[dict[str, Any]],
    basins: list[tuple[int, int]],
    raw_profile: np.ndarray,
    fixed: Any,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """
    候选按中心映射到由亮边切开的非亮暗盆地。

    同一盆地内的候选合并；
    不同盆地永远不会合并。
    """
    geometry_rows = [
        row for row in candidate_rows
        if (
            np.isfinite(float(
                row.get("candidate_center_x_px", np.nan)
            ))
            and np.isfinite(float(
                row.get("estimated_width_px", np.nan)
            ))
            and float(
                row.get("estimated_width_px", 0.0)
            ) >= 3.0
        )
    ]

    groups: dict[int, list[dict[str, Any]]] = {}

    for row in geometry_rows:
        center = float(row["candidate_center_x_px"])
        basin_index, distance = _nearest_basin_v114(
            basins,
            center,
        )

        if basin_index is None:
            row["basin_valid"] = False
            row["basin_invalid_reason"] = "no_basin"
            continue

        max_distance = max(
            3.0,
            float(row["estimated_width_px"])
            * float(fixed.basin_mapping_distance_fraction),
        )

        if distance > max_distance:
            row["basin_valid"] = False
            row["basin_invalid_reason"] = (
                "candidate_too_far_from_basin"
            )
            continue

        left, right = basins[basin_index]
        basin_width = float(right - left)
        basin_center = 0.5 * (left + right - 1)

        row["basin_valid"] = True
        row["basin_invalid_reason"] = ""
        row["basin_sequence_index"] = int(basin_index)
        row["basin_left_x_px"] = float(left)
        row["basin_right_x_px"] = float(right)
        row["basin_center_x_px"] = float(basin_center)
        row["basin_width_px"] = basin_width

        groups.setdefault(basin_index, []).append(row)

    representatives: list[dict[str, Any]] = []
    duplicate_count = 0

    for basin_index in sorted(groups):
        group = groups[basin_index]
        left, right = basins[basin_index]
        basin_width = float(right - left)
        basin_center = 0.5 * (left + right - 1)

        representative = max(
            group,
            key=lambda row: float(
                row.get("candidate_score", 0.0)
            ),
        )

        source_centers = [
            float(row["candidate_center_x_px"])
            for row in group
        ]
        source_widths = [
            float(row["estimated_width_px"])
            for row in group
        ]

        for row in group:
            is_representative = row is representative

            # 兼容V1.13标注和统计字段
            row["adaptive_merge_group_id"] = int(basin_index)
            row["adaptive_merge_group_size"] = len(group)
            row["adaptive_merge_representative"] = (
                is_representative
            )
            row["adaptive_duplicate_merged"] = (
                not is_representative
            )
            row["adaptive_merge_source_centers_px"] = ",".join(
                f"{value:.3f}" for value in source_centers
            )
            row["adaptive_merge_source_widths_px"] = ",".join(
                f"{value:.3f}" for value in source_widths
            )

            # V1.14字段
            row["basin_group_size"] = len(group)
            row["basin_representative"] = is_representative
            row["basin_duplicate_merged"] = (
                not is_representative
            )
            row["basin_source_centers_px"] = ",".join(
                f"{value:.3f}" for value in source_centers
            )

        initial_width = float(np.median(source_widths))

        representative["candidate_center_x_px"] = basin_center
        representative["estimated_width_px"] = basin_width
        representative["estimated_width_nm"] = (
            basin_width * fixed.pixel_size_nm
        )

        representative["adaptive_initial_center_x_px"] = float(
            np.median(source_centers)
        )
        representative["adaptive_initial_width_px"] = initial_width
        representative["adaptive_left_x_px"] = float(left)
        representative["adaptive_right_x_px"] = float(right)
        representative["adaptive_center_x_px"] = basin_center
        representative["adaptive_width_px"] = basin_width
        representative["adaptive_width_ratio"] = (
            basin_width / max(initial_width, EPS)
        )
        representative["adaptive_width_valid"] = True
        representative["adaptive_width_invalid_reason"] = ""
        representative["adaptive_profile_mean_raw"] = float(
            np.mean(raw_profile[left:right])
        )

        representatives.append(representative)
        duplicate_count += max(0, len(group) - 1)

    diagnostics = {
        "basin_mapped_candidate_count": sum(
            len(group) for group in groups.values()
        ),
        "basin_unique_candidate_count": len(representatives),
        "basin_duplicate_merged_count": duplicate_count,
        "basin_largest_group_size": max(
            (len(group) for group in groups.values()),
            default=0,
        ),
    }

    return representatives, diagnostics


def _pattern_group_cost_v114(
    combination: Sequence[dict[str, Any]],
    image_center_x: float,
    preferred_basin_gap: int,
) -> float:
    ordered = sorted(
        combination,
        key=lambda row: float(
            row["candidate_center_x_px"]
        ),
    )

    positions = np.asarray([
        float(row["candidate_center_x_px"])
        for row in ordered
    ])
    widths = np.asarray([
        float(row["estimated_width_px"])
        for row in ordered
    ])
    basin_indices = np.asarray([
        int(row["basin_sequence_index"])
        for row in ordered
    ])

    basin_gaps = np.diff(basin_indices)

    # 真trench中间至少有一个伪暗盆地
    if np.any(basin_gaps < 2):
        return float("inf")

    pitches = np.diff(positions)
    if pitches.size == 0 or np.min(pitches) <= 0:
        return float("inf")

    pitch_mean = float(np.mean(pitches))
    pitch_cv = float(
        np.std(pitches) / max(pitch_mean, EPS)
    )
    pitch_ratio = float(
        np.max(pitches) / max(np.min(pitches), EPS)
    )
    width_cv = float(
        np.std(widths) / max(np.mean(widths), EPS)
    )
    center_offset = abs(
        float(np.median(positions)) - image_center_x
    )
    pattern_penalty = float(np.mean(
        np.abs(
            basin_gaps - int(preferred_basin_gap)
        )
    ))
    darkness_rank = np.asarray([
        float(row["brightness_darkness_rank"])
        for row in ordered
    ])

    return float(
        2.25 * pitch_cv
        + 0.75 * max(0.0, pitch_ratio - 1.0)
        + 0.25 * width_cv
        + 0.50 * center_offset / max(pitch_mean, 1.0)
        + 0.42 * pattern_penalty
        - 0.90 * float(np.mean(darkness_rank))
    )


def find_best_pattern_group_v114(
    pool: list[dict[str, Any]],
    preferred_count: int,
    minimum_count: int,
    image_center_x: float,
    preferred_basin_gap: int,
) -> tuple[list[dict[str, Any]] | None, float]:
    best_group: list[dict[str, Any]] | None = None
    best_cost = float("inf")

    maximum_count = min(
        int(preferred_count),
        len(pool),
    )

    for count in range(
        maximum_count,
        int(minimum_count) - 1,
        -1,
    ):
        for combination in itertools.combinations(pool, count):
            cost = _pattern_group_cost_v114(
                combination,
                image_center_x,
                preferred_basin_gap,
            )

            if cost < best_cost:
                best_cost = cost
                best_group = list(combination)

        if best_group is not None:
            break

    return best_group, best_cost


def select_with_brightness_relaxation_v114(
    candidates: list[dict[str, Any]],
    initial_threshold: float,
    fixed: Any,
    image_center_x: float,
) -> tuple[
    list[dict[str, Any]] | None,
    float,
    int,
    int,
    float,
]:
    """
    先使用K-means初始分界。

    若找不到至少3条并满足真—假—真盆地间隔模式，
    则按当前图片候选平均灰度由暗到亮逐条提高上限。
    """
    unique_brightness = np.sort(np.unique([
        float(row["brightness_core_mean_raw"])
        for row in candidates
    ]))

    threshold_sequence = [float(initial_threshold)]
    threshold_sequence.extend([
        float(value)
        for value in unique_brightness
        if value > initial_threshold + EPS
    ])
    threshold_sequence = sorted(set(threshold_sequence))

    initial_pool_count = sum(
        float(row["brightness_core_mean_raw"])
        <= initial_threshold + EPS
        for row in candidates
    )

    for step, threshold in enumerate(threshold_sequence):
        pool = [
            row for row in candidates
            if float(row["brightness_core_mean_raw"])
            <= threshold + EPS
        ]

        if len(pool) < fixed.min_candidate_trenches:
            continue

        pool = sorted(
            pool,
            key=lambda row: float(
                row["brightness_core_mean_raw"]
            ),
        )[: max(
            fixed.min_candidate_trenches,
            int(fixed.brightness_candidate_pool),
        )]

        group, cost = find_best_pattern_group_v114(
            pool,
            preferred_count=fixed.preferred_trenches,
            minimum_count=fixed.min_candidate_trenches,
            image_center_x=image_center_x,
            preferred_basin_gap=int(
                fixed.pattern_preferred_basin_gap
            ),
        )

        if group is not None:
            return (
                group,
                float(threshold),
                step,
                initial_pool_count,
                float(cost),
            )

    return (
        None,
        float(threshold_sequence[-1]),
        max(0, len(threshold_sequence) - 1),
        initial_pool_count,
        float("inf"),
    )


def select_pattern_brightness_trenches(
    measurement_image: np.ndarray,
    stage1_candidates: list[dict[str, Any]],
    candidate_rows: list[dict[str, Any]],
    detection_summary: dict[str, Any],
    fixed: Any,
    block_profile_fn: Callable[
        [np.ndarray, float, int],
        np.ndarray,
    ],
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    dict[str, Any],
]:
    """
    V1.14主入口。
    """
    rows = [dict(row) for row in candidate_rows]
    summary = dict(detection_summary)

    if not fixed.brightness_filter_enabled:
        return stage1_candidates, rows, summary

    for row in rows:
        row["selected_before_v114"] = bool(
            row.get("selected", False)
        )
        row["selected"] = False
        row["brightness_selected"] = False
        row["brightness_true_trench"] = False
        row["adaptive_duplicate_merged"] = False
        row["adaptive_merge_representative"] = False
        row["basin_duplicate_merged"] = False
        row["basin_representative"] = False

    raw_profile, smooth_profile, profile_diagnostics = (
        build_representative_profile(
            measurement_image,
            fixed,
            summary,
            block_profile_fn,
        )
    )

    geometry_rows = [
        row for row in rows
        if (
            np.isfinite(float(
                row.get("candidate_center_x_px", np.nan)
            ))
            and np.isfinite(float(
                row.get("estimated_width_px", np.nan)
            ))
            and float(
                row.get("estimated_width_px", 0.0)
            ) >= 3.0
        )
    ]

    _, basins, separator_diagnostics = (
        segment_bright_separators_v114(
            smooth_profile,
            [
                float(row["estimated_width_px"])
                for row in geometry_rows
            ],
            fixed,
        )
    )

    representatives, basin_diagnostics = (
        map_candidates_to_basins_v114(
            geometry_rows,
            basins,
            raw_profile,
            fixed,
        )
    )

    if len(representatives) < fixed.min_candidate_trenches:
        summary.update({
            "detection_success": False,
            "reason": (
                f"亮分隔带去重后候选不足"
                f"{fixed.min_candidate_trenches}条"
                f"（实际{len(representatives)}条）"
            ),
            "brightness_filter_enabled": True,
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **separator_diagnostics,
            **basin_diagnostics,
        })
        return [], rows, summary

    eligible: list[dict[str, Any]] = []

    for row in representatives:
        metrics = candidate_average_brightness(
            measurement_image,
            row,
            fixed,
            summary,
            block_profile_fn,
        )
        row.update(metrics)

        if bool(row.get("brightness_valid", False)):
            eligible.append(row)

    if len(eligible) < fixed.min_candidate_trenches:
        summary.update({
            "detection_success": False,
            "reason": (
                f"暗盆地亮度有效不足"
                f"{fixed.min_candidate_trenches}条"
                f"（实际{len(eligible)}条）"
            ),
            "brightness_filter_enabled": True,
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **separator_diagnostics,
            **basin_diagnostics,
        })
        return [], rows, summary

    brightness_values = np.asarray([
        float(row["brightness_core_mean_raw"])
        for row in eligible
    ])

    labels, centers, brightness_sse = kmeans_1d_general(
        brightness_values,
        cluster_count=2,
        restarts=max(
            6,
            int(fixed.brightness_kmeans_restarts),
        ),
        seed=int(fixed.random_seed),
    )

    dark_center = float(centers[0])
    bright_center = float(centers[1])
    initial_threshold = 0.5 * (
        dark_center + bright_center
    )

    probabilities = _dark_cluster_probability(
        brightness_values,
        centers,
        dark_label=0,
    )
    darkness_ranks = _rank01(
        brightness_values,
        higher_is_better=False,
    )

    for index, row in enumerate(eligible):
        row["brightness_cluster_label"] = int(labels[index])
        row["brightness_dark_cluster_label"] = 0
        row["brightness_bright_cluster_label"] = 1
        row["brightness_initial_true_trench"] = bool(
            labels[index] == 0
        )
        row["brightness_dark_probability"] = float(
            probabilities[index]
        )
        row["brightness_darkness_rank"] = float(
            darkness_ranks[index]
        )
        row["brightness_initial_threshold_raw"] = (
            initial_threshold
        )
        row["brightness_dark_cluster_center_raw"] = (
            dark_center
        )
        row["brightness_bright_cluster_center_raw"] = (
            bright_center
        )
        row["brightness_cluster_gap_raw"] = (
            bright_center - dark_center
        )
        row["brightness_kmeans_sse"] = float(
            brightness_sse
        )

    image_center_x = (
        float(fixed.center_x_px)
        if fixed.center_x_px is not None
        else (measurement_image.shape[1] - 1) / 2.0
    )

    (
        best_group,
        final_threshold,
        relaxation_steps,
        initial_pool_count,
        group_cost,
    ) = select_with_brightness_relaxation_v114(
        eligible,
        initial_threshold,
        fixed,
        image_center_x,
    )

    if best_group is None:
        summary.update({
            "detection_success": False,
            "reason": (
                "逐级放宽平均亮度后仍没有满足"
                "真—假—真盆地模式的组合"
            ),
            "brightness_filter_enabled": True,
            "brightness_initial_threshold_raw": (
                initial_threshold
            ),
            "brightness_final_threshold_raw": (
                final_threshold
            ),
            "brightness_relaxation_steps": (
                relaxation_steps
            ),
            "brightness_initial_pool_count": (
                initial_pool_count
            ),
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **separator_diagnostics,
            **basin_diagnostics,
        })
        return [], rows, summary

    selected_ids = {id(row) for row in best_group}
    relaxed = bool(
        final_threshold > initial_threshold + EPS
    )

    for row in eligible:
        row["brightness_final_threshold_raw"] = (
            final_threshold
        )
        row["brightness_threshold_relaxed"] = relaxed
        row["brightness_relaxation_steps"] = (
            relaxation_steps
        )
        row["brightness_true_trench"] = bool(
            float(row["brightness_core_mean_raw"])
            <= final_threshold + EPS
        )
        row["brightness_selected"] = (
            id(row) in selected_ids
        )
        row["selected"] = row["brightness_selected"]

    selected_rows = sorted(
        best_group,
        key=lambda row: float(
            row["candidate_center_x_px"]
        ),
    )

    selected_brightness = np.asarray([
        float(row["brightness_core_mean_raw"])
        for row in selected_rows
    ])
    selected_widths = np.asarray([
        float(row["estimated_width_px"])
        for row in selected_rows
    ])
    selected_basin_indices = np.asarray([
        int(row["basin_sequence_index"])
        for row in selected_rows
    ])
    positions = np.asarray([
        float(row["candidate_center_x_px"])
        for row in selected_rows
    ])
    pitches = np.diff(positions)

    image_values = _finite(measurement_image)
    image_p05, image_p95 = np.percentile(
        image_values,
        [5, 95],
    )
    image_dynamic = max(
        float(image_p95 - image_p05),
        1e-9,
    )

    selected_widths_nm = (
        selected_widths * fixed.pixel_size_nm
    ).tolist()

    summary.update({
        "detection_success": True,
        "reason": "",
        "brightness_filter_enabled": True,
        "brightness_valid_candidate_count": len(eligible),
        "brightness_dark_cluster_center_raw": dark_center,
        "brightness_bright_cluster_center_raw": bright_center,
        "brightness_cluster_gap_raw": (
            bright_center - dark_center
        ),
        "brightness_initial_threshold_raw": (
            initial_threshold
        ),
        "brightness_final_threshold_raw": (
            final_threshold
        ),
        "brightness_initial_threshold_normalized": (
            initial_threshold - float(image_p05)
        ) / image_dynamic,
        "brightness_final_threshold_normalized": (
            final_threshold - float(image_p05)
        ) / image_dynamic,
        "brightness_threshold_relaxed": relaxed,
        "brightness_relaxation_steps": relaxation_steps,
        "brightness_initial_pool_count": initial_pool_count,
        "brightness_final_pool_count": sum(
            float(row["brightness_core_mean_raw"])
            <= final_threshold + EPS
            for row in eligible
        ),
        "brightness_selected_count": len(selected_rows),
        "brightness_selected_mean_raw": float(
            np.mean(selected_brightness)
        ),
        "brightness_selected_median_raw": float(
            np.median(selected_brightness)
        ),
        "pattern_selected_basin_indices": ",".join(
            str(value) for value in selected_basin_indices
        ),
        "pattern_selected_basin_gaps": ",".join(
            str(value)
            for value in np.diff(selected_basin_indices)
        ),
        "pattern_group_cost": float(group_cost),
        "adaptive_selected_width_median_px": float(
            np.median(selected_widths)
        ),
        "adaptive_selected_width_min_px": float(
            np.min(selected_widths)
        ),
        "adaptive_selected_width_max_px": float(
            np.max(selected_widths)
        ),
        "selected_count": len(selected_rows),
        "selected_target_count": len(selected_rows),
        "selected_centers_px": positions.tolist(),
        "selected_estimated_widths_nm": selected_widths_nm,
        "estimated_width_median_nm": float(
            np.median(selected_widths_nm)
        ),
        "pitch_mean_px": (
            float(np.mean(pitches))
            if pitches.size
            else np.nan
        ),
        "pitch_cv": (
            float(np.std(pitches) / max(np.mean(pitches), EPS))
            if pitches.size
            else np.nan
        ),
        "pitch_ratio": (
            float(np.max(pitches) / max(np.min(pitches), EPS))
            if pitches.size
            else np.nan
        ),
        "edge_mode": (
            "bright_separator_basin_dedup_"
            "plus_adaptive_brightness_relaxation"
        ),
        **profile_diagnostics,
        **separator_diagnostics,
        **basin_diagnostics,
    })

    return selected_rows, rows, summary
