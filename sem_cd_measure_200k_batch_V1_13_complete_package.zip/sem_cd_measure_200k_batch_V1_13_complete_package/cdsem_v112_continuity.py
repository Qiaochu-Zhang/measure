"""V1.12 monotone, auditable gap recovery. Existing accepted samples are immutable."""
from dataclasses import replace
import math
import numpy as np


def _anchors(y, left, right, candidate, width):
    good = np.isfinite(left) & np.isfinite(right) & (right > left)
    if good.any():
        return (np.interp(y, y[good], left[good]),
                np.interp(y, y[good], right[good]))
    l, r = float(candidate.global_left_edge_px), float(candidate.global_right_edge_px)
    if not (np.isfinite(l) and np.isfinite(r) and 0 <= l < r <= width-1):
        return None
    return np.full(len(y), l), np.full(len(y), r)


def extend_threshold_search(engine, profile, edge, candidate, params, al, ar, t):
    """Recover a same-threshold crossing just OUTSIDE the selected gradient peak.

    V1.10 searches from peak inward only. V13's plateau threshold can lie
    slightly outside that peak. Extend the allowed side progressively without
    changing the requested threshold percentage or its intensity references.
    """
    if getattr(edge, 'failure_reason', '') not in (
        'left_threshold_crossing_not_found','right_threshold_crossing_not_found'):
        return None
    peak_l, peak_r = edge.left_peak_x, edge.right_peak_x
    if not np.all(np.isfinite([peak_l,peak_r,edge.left_threshold,edge.right_threshold])):
        return None
    extension = min(12., .25*(ar-al))*t
    def crossing(threshold, side, peak, anchor):
        picks=[]
        for j in range(len(profile)-1):
            v0,v1=profile[j],profile[j+1]
            correct = (v0 >= threshold >= v1 and v0>v1) if side=='left' else (v0 <= threshold <= v1 and v1>v0)
            if not correct:
                continue
            pos=j+(threshold-v0)/(v1-v0)
            allowed=(peak-extension <= pos < candidate.center_x_px) if side=='left' else (candidate.center_x_px < pos <= peak+extension)
            if allowed:picks.append(pos)
        return min(picks,key=lambda pos:abs(pos-anchor)) if picks else None
    l=crossing(edge.left_threshold,'left',peak_l,al)
    r=crossing(edge.right_threshold,'right',peak_r,ar)
    if l is None or r is None or not 0<=l<candidate.center_x_px<r<=len(profile)-1:
        return None
    cd=r-l;target=params.target_cd_nm/params.pixel_size_nm
    if not params.valid_cd_min_factor*target <= cd <= params.valid_cd_max_factor*target:
        return None
    if (abs(l-al)>params.tracking_max_edge_jump_px or abs(r-ar)>params.tracking_max_edge_jump_px
        or abs((l+r-al-ar)/2)>params.tracking_max_center_shift_px
        or abs(cd-(ar-al))>params.tracking_max_cd_change_fraction*max(ar-al,target)):
        return None
    lo,li=engine.edge_topology_levels(profile,l,'left',params.topology_band_px,params.topology_gap_px)
    ro,ri=engine.edge_topology_levels(profile,r,'right',params.topology_band_px,params.topology_gap_px)
    if not np.all(np.isfinite([lo,li,ro,ri])) or min(lo-li,ro-ri)<params.topology_min_contrast_8bit:
        return None
    return replace(edge,valid=True,failure_reason='',left_edge_x=l,right_edge_x=r,local_cd_px=cd,
                   left_outside_level=lo,left_inside_level=li,right_outside_level=ro,right_inside_level=ri)


def restore_edges(engine, image, candidate, params, y, left, right, cd_nm,
                  rows, rejected, left_tol, right_tol, cd_tol):
    """Called after V1.10's FINAL postfilter and before every downstream statistic.

    Integer strengths use the same prefix of 1..100 recovery attempts. Anchors
    are frozen from the baseline so a higher strength cannot discard a recovery
    accepted at a lower strength. Force fill exists ONLY at strength 100.
    """
    strength = int(params.edge_continuity)
    original_valid = np.isfinite(left) & np.isfinite(right) & (right > left)
    for i, row in enumerate(rows):
        row.update(continuity_original_valid=bool(original_valid[i]),
                   continuity_original_left_x=float(left[i]),
                   continuity_original_right_x=float(right[i]),
                   continuity_original_failure_reason=row.get('failure_reason', ''),
                   continuity_original_postfilter_rejected=bool(rejected[i]),
                   continuity_source='baseline' if original_valid[i] else 'missing',
                   continuity_strength_used=0, continuity_synthetic=False, continuity_method='original')
    if strength == 0 or original_valid.all():
        return
    anchor = _anchors(y, left, right, candidate, image.shape[1])
    if anchor is None:
        # No valid coarse geometry: never invent a trench outside the image.
        return
    anchor_l, anchor_r = anchor
    profiles = {}
    for i in np.flatnonzero(~original_valid):
        raw, _, _, actual = engine.average_rows_profile(image, float(y[i]), params.average_range_px)
        if raw is not None:
            profiles[int(i)] = (engine.moving_average_reflect(raw, params.smoothing_pixel), actual)

    for level in range(1, strength+1):
        missing = np.flatnonzero(~(np.isfinite(left) & np.isfinite(right)))
        if not len(missing):
            break
        t = level / 100.0
        relaxed = replace(params,
            peak_min_contrast_8bit=params.peak_min_contrast_8bit*(1-0.9*t),
            peak_mad_multiplier=params.peak_mad_multiplier*(1-0.9*t),
            topology_min_contrast_8bit=params.topology_min_contrast_8bit*(1-0.95*t),
            tracking_max_edge_jump_px=params.tracking_max_edge_jump_px*(1+2*t),
            tracking_max_center_shift_px=params.tracking_max_center_shift_px*(1+2*t),
            tracking_max_cd_change_fraction=params.tracking_max_cd_change_fraction*(1+2*t),
            valid_cd_min_factor=params.valid_cd_min_factor*(1-0.5*t),
            valid_cd_max_factor=params.valid_cd_max_factor*(1+0.5*t))
        for i in missing:
            item = profiles.get(int(i))
            if item is None:
                continue
            profile, actual = item
            if actual < params.minimum_average_range_fraction*params.average_range_px*(1-0.6*t):
                continue
            al, ar = float(anchor_l[i]), float(anchor_r[i])
            # Half-CD ceiling prevents the expanded search from freely crossing
            # adjacent trenches; anchor proximity below provides another gate.
            radius = min(params.tracking_retry_radius_px*(1+t), max(3., 0.6*(ar-al)))
            edge = engine.detect_edge_pair(profile, candidate.center_x_px, relaxed,
                anchor_left_x=al, anchor_right_x=ar, search_radius_px=radius,
                strict_tracking=True)
            method = 'relaxed_checks'
            if not edge.valid:
                extended = extend_threshold_search(engine,profile,edge,candidate,relaxed,al,ar,t)
                if extended is None:
                    continue
                edge = extended
                method = 'extended_threshold_search'
            l, r = float(edge.left_edge_x), float(edge.right_edge_x)
            if not (0 <= l < r <= image.shape[1]-1):
                continue
            # Relax baseline robust tolerances around frozen local anchors.
            if (abs(l-al) > max(params.postfilter_min_edge_tolerance_px, left_tol)*(1+3*t)
                or abs(r-ar) > max(params.postfilter_min_edge_tolerance_px, right_tol)*(1+3*t)
                or abs((r-l)-(ar-al)) > max(params.postfilter_min_cd_tolerance_px, cd_tol)*(1+3*t)):
                continue
            if getattr(params, 'viterbi_enabled', 0):
                good = np.flatnonzero(np.isfinite(left) & np.isfinite(right))
                before, after = good[good<i], good[good>i]
                neighbors = ([before[-1]] if len(before) else []) + ([after[0]] if len(after) else [])
                if any(max(abs(l-left[j]),abs(r-right[j])) > params.viterbi_max_jump_px*abs(i-j) for j in neighbors):
                    continue
            left[i], right[i], cd_nm[i] = l, r, (r-l)*params.pixel_size_nm
            engine.update_sample_row_from_edge(rows[i], edge, cd_nm[i])
            rows[i].update(valid=True, failure_reason='', postfilter_rejected=False,
                continuity_source='relaxed_redetect', continuity_strength_used=level, continuity_method=method,
                tracking_anchor_source='continuity_frozen_baseline',
                cd_out_of_recommended_range=not (
                    params.valid_cd_min_factor*params.target_cd_nm <= cd_nm[i]
                    <= params.valid_cd_max_factor*params.target_cd_nm))
            rejected[i] = False

    if strength == 100:
        remaining = ~(np.isfinite(left) & np.isfinite(right))
        if remaining.any():
            detected = ~remaining
            filled_l, filled_r = _anchors(y, left, right, candidate, image.shape[1])
            # np.interp: interior linear interpolation, endpoint nearest hold;
            # if nothing detected, use coarse global pair, explicitly labelled.
            for i in np.flatnonzero(remaining):
                left[i], right[i] = float(filled_l[i]), float(filled_r[i])
                cd_nm[i] = (right[i]-left[i])*params.pixel_size_nm
                source = ('forced_interpolation' if detected.any() else 'forced_global_anchor')
                rows[i].update(valid=True, failure_reason='', postfilter_rejected=False,
                    left_edge_x=float(left[i]), right_edge_x=float(right[i]),
                    local_cd_nm=float(cd_nm[i]), continuity_source=source,
                    continuity_strength_used=100, continuity_synthetic=True, continuity_method=source,
                    tracking_anchor_source=source)
                rejected[i] = False


def draw_overlay(ax, annotation, strength):
    """Join consecutive valid samples; NaN gaps remain gaps below strength 100."""
    if not strength:
        return
    y = annotation['y_values']
    sources = np.asarray(annotation.get('continuity_sources', ['baseline']*len(y)))
    for values in (annotation['left_edges'], annotation['right_edges']):
        ax.plot(values, y, '-', color='deepskyblue', alpha=.45, linewidth=.65)
        relaxed = (sources == 'relaxed_redetect') & np.isfinite(values)
        forced = np.char.startswith(sources.astype(str), 'forced_') & np.isfinite(values)
        if relaxed.any():
            ax.plot(values[relaxed], y[relaxed], 'D', markersize=3, fillstyle='none',
                    color='darkorange', label='continuity redetected')
        if forced.any():
            ax.plot(values[forced], y[forced], 's', markersize=3, fillstyle='none',
                    color='magenta', label='synthetic fill')
