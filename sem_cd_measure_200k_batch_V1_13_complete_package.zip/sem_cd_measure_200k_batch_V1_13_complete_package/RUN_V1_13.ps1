﻿param(
    [Parameter(Mandatory=$true)][string]$Root,
    [ValidateSet("trench","line","via")][string]$Pattern = "trench",
    [double]$PixelSize = 1.3181,
    [int]$MaxNumber = 3,
    [ValidateSet(0,1)][int]$Viterbi = 0,
    [ValidateSet(0,1)][int]$ErfFit = 0,
    [ValidateRange(0,100)][int]$Continuity = 0,
    [string]$Output = ""
)
$ScriptPath = Join-Path $PSScriptRoot "sem_cd_measure_200k_batch_V1_13.py"
$CliArguments = @($ScriptPath, "--root", $Root, "--pattern", $Pattern, "--pixel-size", $PixelSize.ToString([cultureinfo]::InvariantCulture))
if ($Output) { $CliArguments += @("--output", $Output) }
if ($Pattern -eq "via") {
    if ($Viterbi -ne 0 -or $ErfFit -ne 0 -or $Continuity -ne 0 -or $PSBoundParameters.ContainsKey("MaxNumber")) {
        throw "Via does not support MaxNumber, Viterbi, ErfFit or Continuity. Use the trench/line mode."
    }
} else {
    $CliArguments += @("--max-number", $MaxNumber, "--viterbi", $Viterbi, "--erf-fit", $ErfFit, "--edge-continuity", $Continuity)
}
& python @CliArguments
exit $LASTEXITCODE
