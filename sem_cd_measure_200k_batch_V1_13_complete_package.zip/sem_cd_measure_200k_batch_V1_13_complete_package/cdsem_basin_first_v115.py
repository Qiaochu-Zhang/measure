#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CD-SEM V1.15：Basin-First 真假暗区识别
========================================

V1.15 的核心变化
-----------------
V1.14 的主路径是：
    Stage-1 先产生多个暗区候选
    -> 高亮分隔带划分暗盆地
    -> 将候选映射到盆地
    -> 同一盆地候选合并
    -> 盆地亮度与周期拓扑选择真 trench

V1.15 改为：
    多Y位置稳健代表 profile
    -> 当前图像自适应高亮分隔带
    -> 亮带之间的非高亮连续区直接建立 Basin 对象
    -> Basin 多Y存在性/边界稳定性 QC
    -> Basin 核心亮度真/伪分群
    -> 盆地序号、pitch、宽度、中心和质量联合选组
    -> 初始阈值无法形成合理组合时，按亮度逐级放宽
    -> 选中 Basin 直接作为下游边缘引擎的中心和宽度初值（本模块不实现Viterbi/ERF）

也就是说，V1.15 不再把“先找暗候选再同盆地合并”作为正常路径。
Stage-1 只应由主程序在 V1.15 失败时作为可选 fallback 调用。

兼容性
------
本模块返回的 candidate 字典保留 V1.14/V1.7 下游所需字段：
    candidate_center_x_px
    estimated_width_px
    estimated_width_nm
    adaptive_left_x_px / adaptive_right_x_px
    selected

本模块复用 cdsem_pattern_brightness_v114.py 中经过验证的一维 K-means、
代表 profile 和盆地核心亮度统计工具，但不调用 V1.14 的 Stage-1 候选映射/合并。
"""

from __future__ import annotations

import itertools
import math
from typing import Any, Callable, Sequence

import numpy as np
from scipy.ndimage import gaussian_filter1d

import cdsem_pattern_brightness_v114 as v114


EPS = 1e-12


def _finite(values: Sequence[float] | np.ndarray) -> np.ndarray:
    data = np.asarray(values, dtype=float)
    return data[np.isfinite(data)]


def _mad(values: Sequence[float] | np.ndarray, floor: float = 1e-9) -> float:
    data = _finite(values)
    if data.size == 0:
        return float(floor)
    median = float(np.median(data))
    value = 1.4826 * float(np.median(np.abs(data - median)))
    if not np.isfinite(value) or value < floor:
        q25, q75 = np.percentile(data, [25, 75])
        value = float((q75 - q25) / 1.349)
    if not np.isfinite(value) or value < floor:
        value = float(np.std(data))
    return float(max(value, floor))


def _true_runs(mask: np.ndarray) -> list[tuple[int, int]]:
    data = np.asarray(mask, dtype=bool)
    runs: list[tuple[int, int]] = []
    i = 0
    while i < len(data):
        if not data[i]:
            i += 1
            continue
        start = i
        while i < len(data) and data[i]:
            i += 1
        runs.append((start, i))
    return runs


def _false_runs(mask: np.ndarray) -> list[tuple[int, int]]:
    data = np.asarray(mask, dtype=bool)
    runs: list[tuple[int, int]] = []
    i = 0
    while i < len(data):
        if data[i]:
            i += 1
            continue
        start = i
        while i < len(data) and not data[i]:
            i += 1
        runs.append((start, i))
    return runs


def _fill_short_false_runs(mask: np.ndarray, maximum_gap: int) -> np.ndarray:
    output = np.asarray(mask, dtype=bool).copy()
    maximum_gap = max(0, int(maximum_gap))
    if maximum_gap <= 0:
        return output
    for start, end in _false_runs(output):
        if (
            end - start <= maximum_gap
            and start > 0
            and end < len(output)
            and output[start - 1]
            and output[end]
        ):
            output[start:end] = True
    return output


def _remove_short_true_runs(mask: np.ndarray, minimum_run: int) -> np.ndarray:
    output = np.asarray(mask, dtype=bool).copy()
    minimum_run = max(1, int(minimum_run))
    for start, end in _true_runs(output):
        if end - start < minimum_run:
            output[start:end] = False
    return output


def _nearest_false_index(mask: np.ndarray, x: int, radius: int) -> int | None:
    """在中心附近寻找最近的非高亮像素。"""
    data = np.asarray(mask, dtype=bool)
    if len(data) == 0:
        return None
    x = int(np.clip(x, 0, len(data) - 1))
    if not data[x]:
        return x
    for distance in range(1, max(1, int(radius)) + 1):
        left = x - distance
        right = x + distance
        if left >= 0 and not data[left]:
            return left
        if right < len(data) and not data[right]:
            return right
    return None


def _false_run_containing(mask: np.ndarray, x: int) -> tuple[int, int] | None:
    data = np.asarray(mask, dtype=bool)
    if x < 0 or x >= len(data) or data[x]:
        return None
    left = x
    while left > 0 and not data[left - 1]:
        left -= 1
    right = x + 1
    while right < len(data) and not data[right]:
        right += 1
    return left, right


def _interval_iou(first: tuple[float, float], second: tuple[float, float]) -> float:
    a0, a1 = first
    b0, b1 = second
    intersection = max(0.0, min(a1, b1) - max(a0, b0))
    union = max(a1, b1) - min(a0, b0)
    return float(intersection / max(union, EPS))


def _measurement_y_range(image: np.ndarray, fixed: Any) -> tuple[int, int]:
    height = int(image.shape[0])
    center_y = (
        float(fixed.center_y_px)
        if fixed.center_y_px is not None
        else (height - 1) / 2.0
    )
    half_extend = min(
        float(fixed.extend_length_nm) / float(fixed.pixel_size_nm) / 2.0,
        center_y - 3.0,
        height - 4.0 - center_y,
    )
    y0 = max(0, int(round(center_y - half_extend)))
    y1 = min(height, int(round(center_y + half_extend)))
    if y1 <= y0:
        y0, y1 = 0, height
    return int(y0), int(y1)


def _default_typical_width_px(fixed: Any) -> float:
    min_px = float(fixed.adaptive_min_width_nm) / float(fixed.pixel_size_nm)
    max_px = float(fixed.adaptive_max_width_nm) / float(fixed.pixel_size_nm)
    return float(math.sqrt(max(min_px, 3.0) * max(max_px, min_px + 1.0)))


def segment_bright_separators_v115(
    smooth_profile: np.ndarray,
    fixed: Any,
) -> tuple[
    np.ndarray,
    list[tuple[int, int]],
    list[tuple[int, int]],
    dict[str, Any],
]:
    """直接由同图代表 profile 得到高亮带和非高亮 Basin。

    与 V1.14 不同：不再需要 Stage-1 候选宽度作为尺度。
    第一次使用物理安全宽度的几何均值做轻量清洗；再从初步 Basin 宽度
    估计本图尺度，执行第二次自适应清洗。
    """
    profile = np.asarray(smooth_profile, dtype=float)
    if profile.ndim != 1 or profile.size < 16:
        raise ValueError("代表profile无效或过短")

    _, centers, sse = v114.kmeans_1d_general(
        profile,
        cluster_count=3,
        restarts=max(6, int(fixed.separator_kmeans_restarts)),
        seed=int(fixed.random_seed),
    )
    low_center = float(centers[0])
    middle_center = float(centers[1])
    high_center = float(centers[2])
    bright_threshold = 0.5 * (middle_center + high_center)

    raw_bright_mask = profile >= bright_threshold
    default_width = _default_typical_width_px(fixed)

    # 初次轻量清洗，避免用尚未存在的暗候选作为尺度。
    first_min_run = max(
        int(getattr(fixed, "separator_min_run_px", 2)),
        int(round(default_width * float(fixed.separator_min_run_fraction))),
    )
    first_close_gap = max(
        int(getattr(fixed, "separator_close_gap_px", 1)),
        int(round(default_width * float(fixed.separator_close_gap_fraction))),
    )
    first_mask = _fill_short_false_runs(raw_bright_mask, first_close_gap)
    first_mask = _remove_short_true_runs(first_mask, first_min_run)
    first_basins = _false_runs(first_mask)

    min_safe_px = float(fixed.adaptive_min_width_nm) / float(fixed.pixel_size_nm)
    max_safe_px = float(fixed.adaptive_max_width_nm) / float(fixed.pixel_size_nm)
    provisional_widths = np.asarray(
        [
            end - start
            for start, end in first_basins
            if start > 0
            and end < len(profile)
            and 0.45 * min_safe_px <= end - start <= 1.60 * max_safe_px
        ],
        dtype=float,
    )
    typical_width = (
        float(np.median(provisional_widths))
        if provisional_widths.size >= 3
        else default_width
    )

    minimum_run = max(
        int(getattr(fixed, "separator_min_run_px", 2)),
        int(round(typical_width * float(fixed.separator_min_run_fraction))),
    )
    close_gap = max(
        int(getattr(fixed, "separator_close_gap_px", 1)),
        int(round(typical_width * float(fixed.separator_close_gap_fraction))),
    )

    bright_mask = _fill_short_false_runs(raw_bright_mask, close_gap)
    bright_mask = _remove_short_true_runs(bright_mask, minimum_run)
    bright_runs = _true_runs(bright_mask)
    basins = _false_runs(bright_mask)

    diagnostics = {
        "separator_low_center_raw": low_center,
        "separator_middle_center_raw": middle_center,
        "separator_high_center_raw": high_center,
        "separator_bright_threshold_raw": float(bright_threshold),
        "separator_kmeans_sse": float(sse),
        "separator_raw_bright_fraction": float(np.mean(raw_bright_mask)),
        "separator_clean_bright_fraction": float(np.mean(bright_mask)),
        "separator_first_minimum_run_px": int(first_min_run),
        "separator_first_close_gap_px": int(first_close_gap),
        "separator_minimum_run_px": int(minimum_run),
        "separator_close_gap_px": int(close_gap),
        "separator_typical_basin_width_px": float(typical_width),
        "separator_bright_run_count": len(bright_runs),
        "separator_basin_count": len(basins),
    }
    return bright_mask, bright_runs, basins, diagnostics


def validate_basin_across_y_v115(
    measurement_image: np.ndarray,
    basin: tuple[int, int],
    raw_representative_profile: np.ndarray,
    bright_threshold: float,
    fixed: Any,
    block_profile_fn: Callable[[np.ndarray, float, int], np.ndarray],
) -> dict[str, Any]:
    """检查 Basin 是否沿 Y 方向持续存在并且边界稳定。

    代表 profile 只负责生成 Basin；本函数回到多个真实 Y 位置验证：
    - Basin 中心附近是否仍存在非高亮连续区；
    - 左右名义分隔位置附近是否仍有高亮信号；
    - 局部 Basin 与名义 Basin 的重叠；
    - 中心漂移和宽度变化。
    """
    image = np.asarray(measurement_image, dtype=np.float64)
    height, width = image.shape
    left_nominal, right_nominal = map(int, basin)
    nominal_width = float(right_nominal - left_nominal)
    nominal_center = 0.5 * (left_nominal + right_nominal - 1)

    y0, y1 = _measurement_y_range(image, fixed)
    sample_count = max(9, int(getattr(fixed, "basin_validation_samples", 17)))
    block_height = max(1, int(getattr(fixed, "basin_validation_block_height_px", 5)))
    sigma = max(0.0, float(getattr(fixed, "basin_validation_sigma_px", 1.0)))

    half_block = max(0.5, block_height / 2.0)
    safe_y0 = min(max(y0 + half_block, 0.0), height - 1.0)
    safe_y1 = max(min(y1 - half_block, height - 1.0), safe_y0)
    y_positions = np.linspace(safe_y0, safe_y1, sample_count)

    representative_median = float(np.median(raw_representative_profile))
    center_values: list[float] = []
    width_values: list[float] = []
    core_values: list[float] = []
    left_separator_hits = 0
    right_separator_hits = 0
    overlap_hits = 0
    valid_profiles = 0

    separator_window = max(2, int(round(0.12 * nominal_width)))
    center_search_radius = max(2, int(round(0.15 * nominal_width)))
    core_fraction = float(np.clip(fixed.brightness_core_fraction, 0.30, 0.90))

    for y in y_positions:
        profile = np.asarray(
            block_profile_fn(image, float(y), block_height),
            dtype=float,
        )
        if profile.ndim != 1 or profile.size != width or not np.all(np.isfinite(profile)):
            continue
        valid_profiles += 1
        smooth = gaussian_filter1d(profile, sigma, mode="nearest") if sigma > 0 else profile

        # 对每个Y位置只校正整体灰度偏移，不重新自由选择阈值，避免局部K-means抖动。
        local_threshold = float(bright_threshold + np.median(smooth) - representative_median)
        local_bright = smooth >= local_threshold

        left0 = max(0, left_nominal - separator_window)
        left1 = min(width, left_nominal + separator_window + 1)
        right0 = max(0, right_nominal - separator_window)
        right1 = min(width, right_nominal + separator_window + 1)
        if left1 > left0 and np.mean(local_bright[left0:left1]) >= 0.18:
            left_separator_hits += 1
        if right1 > right0 and np.mean(local_bright[right0:right1]) >= 0.18:
            right_separator_hits += 1

        anchor = _nearest_false_index(
            local_bright,
            int(round(nominal_center)),
            center_search_radius,
        )
        if anchor is None:
            continue
        run = _false_run_containing(local_bright, anchor)
        if run is None:
            continue
        local_left, local_right = run
        local_width = float(local_right - local_left)
        if local_width < 3.0:
            continue

        iou = _interval_iou(
            (float(left_nominal), float(right_nominal)),
            (float(local_left), float(local_right)),
        )
        if iou < float(getattr(fixed, "basin_validation_min_iou", 0.25)):
            continue
        overlap_hits += 1
        center_values.append(0.5 * (local_left + local_right - 1))
        width_values.append(local_width)

        local_center = center_values[-1]
        core_half = max(1.5, 0.5 * local_width * core_fraction)
        core0 = int(np.clip(math.floor(local_center - core_half), 0, width))
        core1 = int(np.clip(math.ceil(local_center + core_half) + 1, 0, width))
        if core1 - core0 >= 3:
            core_values.append(float(np.mean(profile[core0:core1])))

    denominator = max(valid_profiles, 1)
    center_array = np.asarray(center_values, dtype=float)
    width_array = np.asarray(width_values, dtype=float)
    core_array = np.asarray(core_values, dtype=float)

    presence_fraction = len(width_array) / denominator
    left_presence = left_separator_hits / denominator
    right_presence = right_separator_hits / denominator
    overlap_fraction = overlap_hits / denominator
    center_median = float(np.median(center_array)) if center_array.size else nominal_center
    width_median = float(np.median(width_array)) if width_array.size else nominal_width
    center_mad = _mad(center_array, floor=0.0) if center_array.size >= 2 else float("inf")
    width_mad = _mad(width_array, floor=0.0) if width_array.size >= 2 else float("inf")
    width_cv = (
        float(width_mad / max(width_median, EPS))
        if np.isfinite(width_mad)
        else float("inf")
    )

    image_values = _finite(image)
    image_dynamic = max(float(np.percentile(image_values, 95) - np.percentile(image_values, 5)), 1e-9)
    core_relative_variation = (
        float(_mad(core_array, floor=0.0) / image_dynamic)
        if core_array.size >= 2
        else float("inf")
    )

    return {
        "basin_validation_requested_samples": sample_count,
        "basin_validation_valid_profiles": valid_profiles,
        "basin_vertical_presence_fraction": float(presence_fraction),
        "basin_overlap_presence_fraction": float(overlap_fraction),
        "basin_left_separator_presence_fraction": float(left_presence),
        "basin_right_separator_presence_fraction": float(right_presence),
        "basin_center_median_px": float(center_median),
        "basin_width_median_px": float(width_median),
        "basin_center_mad_px": float(center_mad),
        "basin_width_mad_px": float(width_mad),
        "basin_width_cv_robust": float(width_cv),
        "basin_core_y_relative_variation": float(core_relative_variation),
    }


def build_direct_basin_candidates_v115(
    measurement_image: np.ndarray,
    raw_profile: np.ndarray,
    bright_mask: np.ndarray,
    basins: list[tuple[int, int]],
    bright_threshold: float,
    fixed: Any,
    block_profile_fn: Callable[[np.ndarray, float, int], np.ndarray],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """每个非高亮连续区直接建立一个候选 Basin，不经过暗候选合并。"""
    image_width = int(measurement_image.shape[1])
    min_width_px = (
        float(fixed.adaptive_min_width_nm)
        / float(fixed.pixel_size_nm)
        * float(getattr(fixed, "basin_width_min_factor", 0.45))
    )
    max_width_px = (
        float(fixed.adaptive_max_width_nm)
        / float(fixed.pixel_size_nm)
        * float(getattr(fixed, "basin_width_max_factor", 1.45))
    )
    reject_edge = bool(getattr(fixed, "basin_reject_edge_basins", True))

    rows: list[dict[str, Any]] = []
    valid_count = 0
    invalid_reason_counts: dict[str, int] = {}

    for basin_index, (left, right) in enumerate(basins):
        nominal_width = float(right - left)
        nominal_center = 0.5 * (left + right - 1)
        bounded_left = left > 0 and bool(bright_mask[left - 1])
        bounded_right = right < image_width and bool(bright_mask[right])

        row: dict[str, Any] = {
            "candidate_id": int(basin_index),
            "basin_sequence_index": int(basin_index),
            "basin_left_x_px": float(left),
            "basin_right_x_px": float(right),
            "basin_center_x_px": float(nominal_center),
            "basin_width_px": float(nominal_width),
            "basin_left_bounded_by_separator": bool(bounded_left),
            "basin_right_bounded_by_separator": bool(bounded_right),
            "basin_edge_clipped": bool(not (bounded_left and bounded_right)),
            "basin_direct_candidate": True,
            "basin_group_size": 1,
            "basin_duplicate_merged": False,
            "basin_source_centers_px": f"{nominal_center:.3f}",
            "adaptive_duplicate_merged": False,
            "adaptive_merge_representative": True,
            "adaptive_merge_group_id": int(basin_index),
            "adaptive_merge_group_size": 1,
            "adaptive_merge_source_centers_px": f"{nominal_center:.3f}",
            "adaptive_merge_source_widths_px": f"{nominal_width:.3f}",
            "adaptive_initial_center_x_px": float(nominal_center),
            "adaptive_initial_width_px": float(nominal_width),
            "adaptive_left_x_px": float(left),
            "adaptive_right_x_px": float(right),
            "adaptive_center_x_px": float(nominal_center),
            "adaptive_width_px": float(nominal_width),
            "adaptive_width_ratio": 1.0,
            "adaptive_width_valid": True,
            "candidate_center_x_px": float(nominal_center),
            "estimated_width_px": float(nominal_width),
            "estimated_width_nm": float(nominal_width * fixed.pixel_size_nm),
            "selected": False,
            "brightness_selected": False,
            "brightness_true_trench": False,
        }

        validation = validate_basin_across_y_v115(
            measurement_image,
            (left, right),
            raw_profile,
            bright_threshold,
            fixed,
            block_profile_fn,
        )
        row.update(validation)

        # 使用多Y中位几何作为下游边缘搜索初值，但不越过代表profile盆地边界太远。
        if np.isfinite(float(validation.get("basin_center_median_px", np.nan))):
            robust_center = float(validation["basin_center_median_px"])
            if abs(robust_center - nominal_center) <= max(4.0, 0.25 * nominal_width):
                row["candidate_center_x_px"] = robust_center
                row["adaptive_center_x_px"] = robust_center
        if np.isfinite(float(validation.get("basin_width_median_px", np.nan))):
            robust_width = float(validation["basin_width_median_px"])
            if 0.55 * nominal_width <= robust_width <= 1.55 * nominal_width:
                row["estimated_width_px"] = robust_width
                row["estimated_width_nm"] = robust_width * fixed.pixel_size_nm
                row["adaptive_width_px"] = robust_width

        reasons: list[str] = []
        if reject_edge and row["basin_edge_clipped"]:
            reasons.append("edge_clipped_basin")
        if nominal_width < min_width_px:
            reasons.append("basin_too_narrow")
        if nominal_width > max_width_px:
            reasons.append("basin_too_wide")

        presence = float(validation["basin_vertical_presence_fraction"])
        left_presence = float(validation["basin_left_separator_presence_fraction"])
        right_presence = float(validation["basin_right_separator_presence_fraction"])
        center_mad = float(validation["basin_center_mad_px"])
        width_cv = float(validation["basin_width_cv_robust"])

        min_presence = float(getattr(fixed, "basin_min_vertical_presence", 0.45))
        min_separator_presence = float(getattr(fixed, "basin_min_separator_presence", 0.35))
        max_center_jitter = max(
            float(getattr(fixed, "basin_max_center_jitter_px", 8.0)),
            float(getattr(fixed, "basin_max_center_jitter_fraction", 0.22)) * nominal_width,
        )
        max_width_cv = float(getattr(fixed, "basin_max_width_cv", 0.40))

        if presence < min_presence:
            reasons.append("basin_vertical_presence_low")
        if min(left_presence, right_presence) < min_separator_presence:
            reasons.append("separator_presence_low")
        if not np.isfinite(center_mad) or center_mad > max_center_jitter:
            reasons.append("basin_center_jitter_high")
        if not np.isfinite(width_cv) or width_cv > max_width_cv:
            reasons.append("basin_width_variation_high")

        width_center = math.sqrt(max(min_width_px, 1.0) * max(max_width_px, min_width_px + 1.0))
        width_log_distance = abs(math.log(max(nominal_width, 1.0) / width_center))
        width_score = math.exp(-width_log_distance)
        jitter_score = math.exp(-max(center_mad, 0.0) / max(0.18 * nominal_width, 2.0)) if np.isfinite(center_mad) else 0.0
        width_stability_score = math.exp(-max(width_cv, 0.0) / 0.25) if np.isfinite(width_cv) else 0.0
        separator_score = min(left_presence, right_presence)
        quality_score = float(np.clip(
            0.30 * presence
            + 0.20 * separator_score
            + 0.18 * width_score
            + 0.16 * jitter_score
            + 0.16 * width_stability_score,
            0.0,
            1.0,
        ))

        basin_valid = len(reasons) == 0
        row.update({
            "basin_valid": basin_valid,
            "basin_invalid_reason": ";".join(reasons),
            "basin_quality_score": quality_score,
            "candidate_score": quality_score,
            "precheck_structure_score": quality_score,
            "adaptive_eligible": basin_valid,
            "eligible": basin_valid,
        })
        if basin_valid:
            valid_count += 1
        else:
            for reason in reasons:
                invalid_reason_counts[reason] = invalid_reason_counts.get(reason, 0) + 1
        rows.append(row)

    diagnostics = {
        "basin_direct_candidate_count": len(rows),
        "basin_valid_candidate_count": valid_count,
        "basin_invalid_candidate_count": len(rows) - valid_count,
        "basin_invalid_reason_counts": ";".join(
            f"{key}:{value}" for key, value in sorted(invalid_reason_counts.items())
        ),
        "basin_width_min_allowed_px": float(min_width_px),
        "basin_width_max_allowed_px": float(max_width_px),
        # 兼容V1.14汇总字段；V1.15正常路径不存在合并。
        "basin_unique_candidate_count": len(rows),
        "basin_duplicate_merged_count": 0,
        "eligible_count": valid_count,
    }
    return rows, diagnostics


def _pattern_group_cost_v115(
    combination: Sequence[dict[str, Any]],
    image_center_x: float,
    preferred_basin_gap: int,
) -> float:
    ordered = sorted(combination, key=lambda row: float(row["candidate_center_x_px"]))
    positions = np.asarray([float(row["candidate_center_x_px"]) for row in ordered])
    widths = np.asarray([float(row["estimated_width_px"]) for row in ordered])
    basin_indices = np.asarray([int(row["basin_sequence_index"]) for row in ordered])
    basin_gaps = np.diff(basin_indices)
    if np.any(basin_gaps < 2):
        return float("inf")

    pitches = np.diff(positions)
    if pitches.size == 0 or np.min(pitches) <= 0:
        return float("inf")

    pitch_mean = float(np.mean(pitches))
    pitch_cv = float(np.std(pitches) / max(pitch_mean, EPS))
    pitch_ratio = float(np.max(pitches) / max(np.min(pitches), EPS))
    width_cv = float(np.std(widths) / max(np.mean(widths), EPS))
    center_offset = abs(float(np.median(positions)) - image_center_x)
    pattern_penalty = float(np.mean(np.abs(basin_gaps - int(preferred_basin_gap))))
    darkness_rank = np.asarray([float(row["brightness_darkness_rank"]) for row in ordered])
    quality = np.asarray([float(row.get("basin_quality_score", 0.0)) for row in ordered])
    vertical_presence = np.asarray([
        float(row.get("basin_vertical_presence_fraction", 0.0)) for row in ordered
    ])

    return float(
        2.25 * pitch_cv
        + 0.75 * max(0.0, pitch_ratio - 1.0)
        + 0.25 * width_cv
        + 0.50 * center_offset / max(pitch_mean, 1.0)
        + 0.42 * pattern_penalty
        - 0.82 * float(np.mean(darkness_rank))
        - 0.42 * float(np.mean(quality))
        - 0.20 * float(np.mean(vertical_presence))
    )


def find_best_pattern_group_v115(
    pool: list[dict[str, Any]],
    preferred_count: int,
    minimum_count: int,
    image_center_x: float,
    preferred_basin_gap: int,
) -> tuple[list[dict[str, Any]] | None, float]:
    best_group: list[dict[str, Any]] | None = None
    best_cost = float("inf")
    maximum_count = min(int(preferred_count), len(pool))
    for count in range(maximum_count, int(minimum_count) - 1, -1):
        for combination in itertools.combinations(pool, count):
            cost = _pattern_group_cost_v115(
                combination,
                image_center_x,
                preferred_basin_gap,
            )
            if cost < best_cost:
                best_cost = cost
                best_group = list(combination)
        if best_group is not None:
            break
    return best_group, best_cost


def select_with_brightness_relaxation_v115(
    candidates: list[dict[str, Any]],
    initial_threshold: float,
    fixed: Any,
    image_center_x: float,
) -> tuple[list[dict[str, Any]] | None, float, int, int, float]:
    """按盆地亮度逐级提高上限，首次形成结构可行组合时停止。"""
    unique_brightness = np.sort(np.unique([
        float(row["brightness_core_mean_raw"]) for row in candidates
    ]))
    threshold_sequence = [float(initial_threshold)]
    threshold_sequence.extend([
        float(value) for value in unique_brightness if value > initial_threshold + EPS
    ])
    threshold_sequence = sorted(set(threshold_sequence))
    initial_pool_count = sum(
        float(row["brightness_core_mean_raw"]) <= initial_threshold + EPS
        for row in candidates
    )

    for step, threshold in enumerate(threshold_sequence):
        pool = [
            row for row in candidates
            if float(row["brightness_core_mean_raw"]) <= threshold + EPS
        ]
        if len(pool) < fixed.min_candidate_trenches:
            continue
        pool = sorted(
            pool,
            key=lambda row: (
                float(row["brightness_core_mean_raw"]),
                -float(row.get("basin_quality_score", 0.0)),
            ),
        )[: max(fixed.min_candidate_trenches, int(fixed.brightness_candidate_pool))]
        group, cost = find_best_pattern_group_v115(
            pool,
            preferred_count=fixed.preferred_trenches,
            minimum_count=fixed.min_candidate_trenches,
            image_center_x=image_center_x,
            preferred_basin_gap=int(fixed.pattern_preferred_basin_gap),
        )
        if group is not None:
            return group, float(threshold), int(step), int(initial_pool_count), float(cost)

    return (
        None,
        float(threshold_sequence[-1]),
        max(0, len(threshold_sequence) - 1),
        int(initial_pool_count),
        float("inf"),
    )


def select_basin_first_trenches(
    measurement_image: np.ndarray,
    detection_summary: dict[str, Any] | None,
    fixed: Any,
    block_profile_fn: Callable[[np.ndarray, float, int], np.ndarray],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    """V1.15 Basin-First 主入口。"""
    image = np.asarray(measurement_image, dtype=np.float64)
    if image.ndim != 2:
        raise ValueError("V1.15只支持二维灰度SEM图像")

    summary = dict(detection_summary or {})
    y0, y1 = _measurement_y_range(image, fixed)
    summary.setdefault("y_start", y0)
    summary.setdefault("y_end", y1)
    summary["basin_first_enabled"] = True
    summary["basin_first_fallback_used"] = False
    summary["edge_mode"] = "v115_basin_first"

    if not bool(getattr(fixed, "basin_first_enabled", True)):
        return [], [], {
            **summary,
            "detection_success": False,
            "reason": "basin_first_disabled",
        }

    raw_profile, smooth_profile, profile_diagnostics = v114.build_representative_profile(
        image,
        fixed,
        summary,
        block_profile_fn,
    )
    bright_mask, bright_runs, basins, separator_diagnostics = segment_bright_separators_v115(
        smooth_profile,
        fixed,
    )
    bright_threshold = float(separator_diagnostics["separator_bright_threshold_raw"])

    rows, basin_diagnostics = build_direct_basin_candidates_v115(
        image,
        raw_profile,
        bright_mask,
        basins,
        bright_threshold,
        fixed,
        block_profile_fn,
    )

    eligible = [row for row in rows if bool(row.get("basin_valid", False))]
    if len(eligible) < fixed.min_candidate_trenches:
        summary.update({
            "detection_success": False,
            "reason": (
                f"Basin-First有效盆地不足{fixed.min_candidate_trenches}条"
                f"（实际{len(eligible)}条）"
            ),
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **separator_diagnostics,
            **basin_diagnostics,
        })
        return [], rows, summary

    brightness_eligible: list[dict[str, Any]] = []
    for row in eligible:
        metrics = v114.candidate_average_brightness(
            image,
            row,
            fixed,
            summary,
            block_profile_fn,
        )
        row.update(metrics)
        if bool(row.get("brightness_valid", False)):
            brightness_eligible.append(row)

    if len(brightness_eligible) < fixed.min_candidate_trenches:
        summary.update({
            "detection_success": False,
            "reason": (
                f"Basin-First亮度有效盆地不足{fixed.min_candidate_trenches}条"
                f"（实际{len(brightness_eligible)}条）"
            ),
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **separator_diagnostics,
            **basin_diagnostics,
        })
        return [], rows, summary

    brightness_values = np.asarray([
        float(row["brightness_core_mean_raw"]) for row in brightness_eligible
    ])
    labels, centers, brightness_sse = v114.kmeans_1d_general(
        brightness_values,
        cluster_count=2,
        restarts=max(6, int(fixed.brightness_kmeans_restarts)),
        seed=int(fixed.random_seed),
    )
    dark_center = float(centers[0])
    bright_center = float(centers[1])
    initial_threshold = 0.5 * (dark_center + bright_center)
    probabilities = v114._dark_cluster_probability(
        brightness_values,
        centers,
        dark_label=0,
    )
    darkness_ranks = v114._rank01(
        brightness_values,
        higher_is_better=False,
    )

    for index, row in enumerate(brightness_eligible):
        row.update({
            "brightness_cluster_label": int(labels[index]),
            "brightness_dark_cluster_label": 0,
            "brightness_bright_cluster_label": 1,
            "brightness_initial_true_trench": bool(labels[index] == 0),
            "brightness_dark_probability": float(probabilities[index]),
            "brightness_darkness_rank": float(darkness_ranks[index]),
            "brightness_initial_threshold_raw": float(initial_threshold),
            "brightness_dark_cluster_center_raw": dark_center,
            "brightness_bright_cluster_center_raw": bright_center,
            "brightness_cluster_gap_raw": bright_center - dark_center,
            "brightness_kmeans_sse": float(brightness_sse),
        })

    image_center_x = (
        float(fixed.center_x_px)
        if fixed.center_x_px is not None
        else (image.shape[1] - 1) / 2.0
    )
    best_group, final_threshold, relaxation_steps, initial_pool_count, group_cost = (
        select_with_brightness_relaxation_v115(
            brightness_eligible,
            initial_threshold,
            fixed,
            image_center_x,
        )
    )

    if best_group is None:
        summary.update({
            "detection_success": False,
            "reason": "Basin-First逐级放宽后仍没有满足拓扑/周期约束的组合",
            "brightness_initial_threshold_raw": initial_threshold,
            "brightness_final_threshold_raw": final_threshold,
            "brightness_relaxation_steps": relaxation_steps,
            "brightness_initial_pool_count": initial_pool_count,
            "brightness_selected_count": 0,
            **profile_diagnostics,
            **separator_diagnostics,
            **basin_diagnostics,
        })
        return [], rows, summary

    selected_ids = {id(row) for row in best_group}
    relaxed = bool(final_threshold > initial_threshold + EPS)
    for row in brightness_eligible:
        row["brightness_final_threshold_raw"] = float(final_threshold)
        row["brightness_threshold_raw"] = float(final_threshold)
        row["brightness_threshold_relaxed"] = relaxed
        row["brightness_relaxation_steps"] = int(relaxation_steps)
        row["brightness_true_trench"] = bool(
            float(row["brightness_core_mean_raw"]) <= final_threshold + EPS
        )
        row["brightness_selected"] = id(row) in selected_ids
        row["selected"] = row["brightness_selected"]

    selected_rows = sorted(best_group, key=lambda row: float(row["candidate_center_x_px"]))
    positions = np.asarray([float(row["candidate_center_x_px"]) for row in selected_rows])
    selected_widths = np.asarray([float(row["estimated_width_px"]) for row in selected_rows])
    selected_brightness = np.asarray([
        float(row["brightness_core_mean_raw"]) for row in selected_rows
    ])
    selected_basin_indices = np.asarray([
        int(row["basin_sequence_index"]) for row in selected_rows
    ])
    pitches = np.diff(positions)

    image_values = _finite(image)
    image_p05, image_p95 = np.percentile(image_values, [5, 95])
    image_dynamic = max(float(image_p95 - image_p05), 1e-9)

    summary.update({
        "detection_success": True,
        "reason": "",
        "basin_first_enabled": True,
        "basin_first_fallback_used": False,
        "brightness_filter_enabled": True,
        "brightness_valid_candidate_count": len(brightness_eligible),
        "brightness_dark_cluster_center_raw": dark_center,
        "brightness_bright_cluster_center_raw": bright_center,
        "brightness_cluster_gap_raw": bright_center - dark_center,
        "brightness_initial_threshold_raw": float(initial_threshold),
        "brightness_final_threshold_raw": float(final_threshold),
        "brightness_initial_threshold_normalized": (
            initial_threshold - float(image_p05)
        ) / image_dynamic,
        "brightness_final_threshold_normalized": (
            final_threshold - float(image_p05)
        ) / image_dynamic,
        "brightness_threshold_relaxed": relaxed,
        "brightness_relaxation_steps": int(relaxation_steps),
        "brightness_initial_pool_count": int(initial_pool_count),
        "brightness_final_pool_count": sum(
            float(row["brightness_core_mean_raw"]) <= final_threshold + EPS
            for row in brightness_eligible
        ),
        "brightness_selected_count": len(selected_rows),
        "brightness_selected_mean_raw": float(np.mean(selected_brightness)),
        "brightness_selected_median_raw": float(np.median(selected_brightness)),
        "pattern_selected_basin_indices": ",".join(str(v) for v in selected_basin_indices),
        "pattern_selected_basin_gaps": ",".join(
            str(v) for v in np.diff(selected_basin_indices)
        ),
        "pattern_group_cost": float(group_cost),
        "selected_count": len(selected_rows),
        "selected_target_count": len(selected_rows),
        "selected_centers_px": positions.tolist(),
        "selected_estimated_widths_nm": (
            selected_widths * float(fixed.pixel_size_nm)
        ).tolist(),
        "estimated_width_median_nm": float(
            np.median(selected_widths) * fixed.pixel_size_nm
        ),
        "pitch_mean_px": float(np.mean(pitches)) if pitches.size else np.nan,
        "pitch_cv": (
            float(np.std(pitches) / max(np.mean(pitches), EPS))
            if pitches.size else np.nan
        ),
        "pitch_ratio": (
            float(np.max(pitches) / max(np.min(pitches), EPS))
            if pitches.size else np.nan
        ),
        "edge_mode": "v115_basin_first_direct_regions",
        **profile_diagnostics,
        **separator_diagnostics,
        **basin_diagnostics,
    })
    return selected_rows, rows, summary


def synthetic_self_test() -> dict[str, Any]:
    """无需外部SEM文件的轻量自检，用于确认 Basin-First 主逻辑可运行。"""
    height, width = 512, 1024
    rng = np.random.default_rng(42)
    x = np.arange(width)
    profile = np.full(width, 150.0)

    # 交替构造：真暗盆地(70) / 伪暗盆地(104)，由窄高亮带(210)分隔。
    basin_starts = [70, 170, 270, 370, 470, 570, 670, 770, 870]
    basin_width = 60
    true_indices = {0, 2, 4, 6, 8}
    for index, start in enumerate(basin_starts):
        profile[start:start + basin_width] = 72.0 if index in true_indices else 106.0
        if start - 8 >= 0:
            profile[start - 8:start] = 215.0
        if start + basin_width + 8 <= width:
            profile[start + basin_width:start + basin_width + 8] = 215.0
    image = np.tile(profile, (height, 1))
    image += rng.normal(0.0, 3.0, size=image.shape)
    # 轻微纵向漂移，验证多Y稳定性不是只看同一行。
    for y in range(height):
        image[y] += 0.8 * math.sin(2 * math.pi * y / 91.0)

    class Fixed:
        pixel_size_nm = 0.87890625
        center_x_px = None
        center_y_px = None
        extend_length_nm = 350.0
        preferred_trenches = 4
        min_candidate_trenches = 3
        adaptive_min_width_nm = 30.0
        adaptive_max_width_nm = 100.0
        random_seed = 42
        brightness_samples = 19
        brightness_block_height_px = 5
        brightness_core_fraction = 0.76
        brightness_trim_fraction = 0.10
        brightness_candidate_pool = 24
        brightness_kmeans_restarts = 16
        width_profile_samples = 41
        width_profile_block_height_px = 5
        width_profile_trim_fraction = 0.10
        width_profile_sigma_px = 1.50
        separator_kmeans_restarts = 16
        separator_min_run_fraction = 0.05
        separator_close_gap_fraction = 0.03
        separator_min_run_px = 2
        separator_close_gap_px = 1
        pattern_preferred_basin_gap = 2
        basin_first_enabled = True
        basin_width_min_factor = 0.45
        basin_width_max_factor = 1.45
        basin_reject_edge_basins = True
        basin_validation_samples = 17
        basin_validation_block_height_px = 5
        basin_validation_sigma_px = 1.0
        basin_validation_min_iou = 0.25
        basin_min_vertical_presence = 0.45
        basin_min_separator_presence = 0.35
        basin_max_center_jitter_px = 8.0
        basin_max_center_jitter_fraction = 0.22
        basin_max_width_cv = 0.40

    def block_profile(data: np.ndarray, y: float, block_height: int) -> np.ndarray:
        y0 = max(0, int(round(y - block_height / 2)))
        y1 = min(data.shape[0], y0 + block_height)
        return np.mean(data[y0:y1], axis=0)

    selected, rows, summary = select_basin_first_trenches(
        image,
        {},
        Fixed(),
        block_profile,
    )
    if not summary.get("detection_success", False):
        raise AssertionError(f"V1.15 synthetic self-test失败：{summary.get('reason')}")
    if len(selected) < 3:
        raise AssertionError(f"选中数量异常：{len(selected)}")
    selected_indices = [int(row["basin_sequence_index"]) for row in selected]
    return {
        "success": True,
        "selected_count": len(selected),
        "selected_basin_indices": selected_indices,
        "all_basin_count": len(rows),
        "summary": summary,
    }


if __name__ == "__main__":
    result = synthetic_self_test()
    print("V1.15 Basin-First self-test PASS")
    print({
        "selected_count": result["selected_count"],
        "selected_basin_indices": result["selected_basin_indices"],
        "all_basin_count": result["all_basin_count"],
    })
