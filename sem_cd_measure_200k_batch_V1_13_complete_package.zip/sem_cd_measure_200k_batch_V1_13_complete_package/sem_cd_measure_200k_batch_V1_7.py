#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SEM PNG 批量 CD 统计：Via 圆孔 + Trench/Space（V1.7 整目录指定图案版）
========================================================

适用目录结构：

ROOT/
  任意子文件夹1/*.png
  任意子文件夹2/*.png
  任意子文件夹3/*.png
  任意子文件夹4/*.png

输入规则：
  1) 递归扫描 ROOT 下所有层级的 .png 文件（扩展名大小写不敏感）；
  2) 不按根目录名、子文件夹名或 PNG 文件名过滤；
  3) 必须通过 --pattern via 或 --pattern trench 指定整棵输入目录的图案类型；
  4) root 及所有子文件夹中的 PNG 均按同一种图案类型处理；
  5) 自动从图像估计 Via 直径或 Trench/Space 宽度，作为检测尺度先验；
  6) 自动排除输出目录，防止重复处理 annotated/plots。

自动估计值是检测参考尺度，并非版图设计值；结果以 image_estimated 标记。
如果已知统一参考尺寸，可用命令行参数显式指定，仍不依赖文件名。

默认像素尺寸：1.3181 nm/pixel。

Via 主要输出：
  - 每个合格圆孔的面积等效直径、X/Y 跨度、椭圆长短轴、4πA/P² 圆形度、
    短轴/长轴圆整度、solidity、ellipse IoU、radial CV、识别置信度。
  - 每张图和每个子文件夹下，参考 CD 与实测 CD 的偏差。

Trench 主要输出：
  - 每条合格暗 trench 的平均宽度、标准差、3σ LWR、有效采样比例、倾斜角。
  - 相邻 trench 之间每条亮 space 的平均宽度、标准差和 3σ 波动。
  - 每张图和每个子文件夹下，参考 W/S 与实测 W/S 的偏差。

输出目录（默认 ROOT/CD_measure_output_200K_V1_7）：
  annotated/<原相对子文件夹>/*.png（保留原文件名和扩展名）
  plots/*.png（包含 Via 圆形度逐图图与总体分布图）
  CD_measurement_200K_results.xlsx
  image_summary.csv
  condition_summary.csv
  all_objects_long.csv
  via_objects.csv
  trench_objects.csv
  space_objects.csv
  processing_errors.csv
  settings.json

安装依赖：
  pip install numpy pandas scipy opencv-python matplotlib openpyxl

运行示例：
  python sem_cd_measure_200k_batch_V1_7.py --pattern via

或：
  python sem_cd_measure_200k_batch_V1_7.py --root "C:\\Users\\z00027644\\Downloads\\CD measure\\CD measure" --pattern trench

说明：
  - Via 使用自动估计或命令行指定尺寸作为“找圆孔的尺度先验”，但最终直径来自图像中的真实外边缘，
    不是直接把设计值写回结果。
  - Trench 使用自动估计或命令行指定 W/S 作为候选间距和边缘搜索先验，最终 W/S 均由逐行边缘测得。
  - 自动放宽只用于严格条件完全找不到或规则阵列中的弱图案补全；结果会标记为 REVIEW。
  - 保留 V1.2 的全部硬终检：
      1) 贴近图像边缘且缺少左右两个亮边的截断 trench 舍弃；
      2) 一条 trench 的有效宽度 max/min >= 2 时舍弃；
      3) trench 沿 Y 方向由暗变亮，且亮端接近相邻 space 灰度时舍弃；
      4) Via 只有在“偏离可靠方形点阵”且“边缘异常圆滑”同时成立时才舍弃。
  - V1.6 调整 Via 流程顺序：严格模式得到初始 Via 后，必须先清洗不合理 Via，再允许点阵
    预测和放宽恢复新 Via。前置清洗包含：
      A) 方阵外且边缘异常圆滑的对象舍弃；
      B) 实际空间邻孔过近筛选：先计算初始 Via 点阵 X/Y 方向平均间距；对每个 Via 与图案上
         实际相邻近的全部 Via 检查。若某邻孔对主方向间距小于平均值的 0.60，则一次性舍弃
         该过近对中可靠性较低的对象；
      C) 轴向邻孔存在性筛选：在 B 完成后的 Via 集合上固定一次邻接关系。若某 Via 在左/右
         方向约一倍平均 X 间距处两侧都找不到水平邻孔，或在上/下方向约一倍平均 Y 间距处
         两侧都找不到垂直邻孔，则一次性舍弃。左右只需至少一侧存在、上下只需至少一侧存在。
      B/C 都只执行一轮，不会因删除对象而重算均值、重建邻接关系或递归执行。完成 A/B/C 后，
      才用清洗后的 Via 重新估计点阵，进行规则位置放宽候选和点阵缺失位置恢复。
      若初始严格 Via 非零但被前置清洗删光，不会再启用全图放宽把这些对象重新捞回；只有
      “初始严格结果本来就是 0”时才保留原有 zero-result fallback。
  - Annotated 图保留 V/T/S 编号，并对每个成功纳入统计的 Via、Trench、Space 标注实测 CD。
  - plots 额外输出 Via 圆形度逐图统计图和总体分布图。
  - 所有阈值集中在 GeneralConfig / ViaConfig / TrenchConfig，可按样本继续 tuning。

参考思路：
  - cdsem_batch_v2.py：全局暗槽候选、50% 灰度边缘、逐行跟踪、鲁棒飞点剔除。
  - sem_before_after_compare_V25_auto_fallback.py：物理尺寸匹配的 via 中心检测、
    外侧持续暗到亮跃迁、连通暗区辅助、形貌 QC、零结果自动回退。
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
import traceback
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence

try:
    import cv2
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from scipy.signal import find_peaks
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "缺少依赖。请先运行：\n"
        "  pip install numpy pandas scipy opencv-python matplotlib openpyxl\n"
        f"原始错误：{exc}"
    ) from exc


SCRIPT_VERSION = "2026-09-02-V1.7-ALL-PNG-FOLDER-PATTERN-AUTO-SCALE"
EPS = 1e-9
DEFAULT_ROOT = Path(r"C:\Users\z00027644\Downloads\CD measure\CD measure")
NUMBER_PATTERN = r"\d+(?:\.\d+)?"

VIA_NAME_RE = re.compile(
    rf"^(?P<pretreatment>{NUMBER_PATTERN})NM_"
    rf"(?P<dose>{NUMBER_PATTERN})MJ_"
    rf"CD(?P<design_cd>{NUMBER_PATTERN})_"
    rf"(?P<sample>[^_]+)_200K$",
    flags=re.IGNORECASE,
)

# 兼容示例 W25S40_200K，也兼容以后可能出现的 W25S40_6_200K。
TRENCH_NAME_RE = re.compile(
    rf"^(?P<pretreatment>{NUMBER_PATTERN})NM_"
    rf"(?P<dose>{NUMBER_PATTERN})MJ_"
    rf"W(?P<design_w>{NUMBER_PATTERN})S(?P<design_s>{NUMBER_PATTERN})"
    rf"(?:_(?P<sample>[^_]+))?_200K$",
    flags=re.IGNORECASE,
)


# ============================================================
# 1. 参数
# ============================================================
@dataclass
class GeneralConfig:
    root_dir: Path = DEFAULT_ROOT
    output_dir: Optional[Path] = None
    pixel_size_nm: float = 1.3181
    magnification_token: str = "200K"
    image_suffix: str = ".png"
    force_pattern: Optional[str] = None
    via_reference_nm: Optional[float] = None
    trench_reference_nm: Optional[float] = None
    space_reference_nm: Optional[float] = None
    save_debug_masks: bool = False
    overwrite_output: bool = True
    continue_on_error: bool = True
    # 排除非常靠近图像边界、容易被截断的结构。相对设计尺寸再取更大值。
    absolute_border_margin_px: int = 3

    def resolved_output_dir(self) -> Path:
        if self.output_dir is not None:
            return self.output_dir
        return self.root_dir / "CD_measure_output_200K_V1_7"

    def validate(self) -> None:
        if self.pixel_size_nm <= 0:
            raise ValueError("pixel_size_nm 必须大于 0")
        if not self.root_dir.exists():
            raise FileNotFoundError(f"输入根目录不存在：{self.root_dir}")
        if not self.root_dir.is_dir():
            raise NotADirectoryError(f"输入路径不是文件夹：{self.root_dir}")
        if (self.force_pattern or "").casefold() not in {"via", "trench", "line"}:
            raise ValueError("必须通过 pattern 指定整个输入目录为 via、trench 或 line")
        for name, value in (
            ("via_reference_nm", self.via_reference_nm),
            ("trench_reference_nm", self.trench_reference_nm),
            ("space_reference_nm", self.space_reference_nm),
        ):
            if value is not None and value <= 0:
                raise ValueError(f"{name} 必须大于 0")


@dataclass
class ViaConfig:
    # 多尺度暗圆 + 外圈匹配。设计尺寸只作为尺度先验。
    scale_ratios: tuple[float, ...] = (0.72, 0.82, 0.92, 1.00, 1.10, 1.22, 1.35)
    inner_radius_diam_frac: float = 0.30
    ring_inner_diam_frac: float = 0.56
    ring_outer_diam_frac: float = 0.82
    local_dark_weight: float = 0.12

    max_candidates: int = 500
    strict_peak_score_min: float = 0.25
    relaxed_peak_score_min: float = 0.17
    strict_raw_floor_factor: float = 1.00
    relaxed_raw_floor_factor: float = 0.55
    nms_diameter_frac: float = 0.50
    center_dedup_diameter_frac: float = 0.34
    center_refine_diameter_frac: float = 0.30
    border_diameter_frac: float = 0.62

    # 外边缘径向追踪。
    radial_angles: int = 144
    radial_samples_per_px: float = 4.0
    max_radius_factor_R: float = 1.65
    min_edge_radius_factor_R: float = 0.52
    radius_spike_limit_R: float = 0.25
    connected_component_close_diam_frac: float = 0.075
    connected_component_min_core_overlap: float = 0.12

    # 严格 QC；尺寸范围故意比参考程序稍宽，避免把真实工艺偏差当成噪声删掉。
    strict_min_design_factor: float = 0.55
    strict_max_design_factor: float = 1.75
    strict_min_circularity: float = 0.68
    strict_min_solidity: float = 0.80
    strict_max_axis_ratio: float = 1.60
    strict_min_ellipse_iou: float = 0.50
    strict_max_radial_cv: float = 0.30
    strict_min_good_ray_fraction: float = 0.54
    strict_max_outer_dark_leak: float = 0.38

    # 放宽条件仍保留尺寸、闭合形貌和圆整度要求；输出会标 REVIEW。
    relaxed_min_design_factor: float = 0.45
    relaxed_max_design_factor: float = 1.95
    relaxed_min_circularity: float = 0.72
    relaxed_min_solidity: float = 0.70
    relaxed_max_axis_ratio: float = 1.52
    relaxed_min_ellipse_iou: float = 0.38
    relaxed_max_radial_cv: float = 0.40
    relaxed_min_good_ray_fraction: float = 0.38
    relaxed_max_outer_dark_leak: float = 0.48

    # 规则阵列辅助：严格识别后，允许补回被两个以上邻居共同预测的弱圆孔。
    enable_grid_recovery: bool = True
    grid_min_seed_count: int = 4
    grid_pitch_min_design_factor: float = 1.10
    grid_pitch_max_design_factor: float = 8.0
    grid_neighbor_distance_tolerance: float = 0.32
    grid_angle_tolerance_deg: float = 20.0
    grid_prediction_cluster_diam_frac: float = 0.34
    grid_min_prediction_votes: int = 2
    grid_recovery_rounds: int = 2

    # 方形点阵前置清洗：只有“偏离可靠点阵”且“边缘异常圆滑”同时成立才舍弃。
    # V1.6 将该规则移到点阵放宽候选和缺失位置恢复之前，避免假圆参与后续点阵预测。
    enable_offgrid_smooth_rejection: bool = True
    grid_membership_min_seed_count: int = 6
    grid_core_min_neighbor_support: int = 1
    grid_phase_fit_tolerance_pitch_fraction: float = 0.18
    grid_membership_max_residual_pitch_fraction: float = 0.22
    grid_membership_min_inlier_fraction: float = 0.55
    offgrid_smooth_min_circularity: float = 0.94
    offgrid_smooth_min_axis_roundness: float = 0.93
    offgrid_smooth_min_solidity: float = 0.96
    offgrid_smooth_min_ellipse_iou: float = 0.88
    offgrid_smooth_max_radial_cv: float = 0.050
    offgrid_smooth_max_highfreq_roughness_cv: float = 0.022

    # V1.6 Via 前置一次性实际空间邻孔间距清洗。
    # 仅对“严格模式初始 Via”在点阵预测/放宽恢复之前运行一轮；先建立实际空间邻接对，
    # 再一次性决定删除对象，不因删除对象而重建邻接关系或递归执行。
    enable_adjacent_spacing_rejection: bool = True
    adjacent_spacing_min_seed_count: int = 3
    adjacent_spacing_reject_ratio: float = 0.60
    adjacent_spacing_reference_min_pitch_fraction: float = 0.55
    adjacent_spacing_reference_max_pitch_fraction: float = 1.45
    adjacent_spacing_orthogonal_gate_pitch_fraction: float = 0.35
    adjacent_spacing_min_reference_pairs: int = 2
    adjacent_spacing_robust_band_fraction: float = 0.25
    # “实际相邻近”定义：两圆心距离不超过约 1.60 个点阵 pitch。
    # 该范围覆盖方形点阵的上下左右邻孔和对角邻孔，同时排除跨越两个以上 pitch 的远孔。
    adjacent_spacing_actual_neighbor_max_pitch_fraction: float = 1.60

    # V1.6 Via 前置一次性轴向邻孔存在性清洗。
    # 对“前置过近筛选后的严格 Via 集合”在点阵预测/放宽恢复之前只执行一轮，不递归。
    # 水平方向：在“约 1.0 * 平均 X 间距”处，且 Y 偏移足够小的对象视为左/右邻孔；
    # 垂直方向：在“约 1.0 * 平均 Y 间距”处，且 X 偏移足够小的对象视为上/下邻孔。
    # 这里使用 ±25% 的间距容差，而不是简单写成 <= 平均间距；否则规则点阵中略大于均值
    # 的正常邻孔会被误判不存在。左右至少有一侧、上下至少有一侧即可。
    enable_axis_neighbor_presence_rejection: bool = True
    axis_neighbor_presence_min_seed_count: int = 3
    axis_neighbor_presence_spacing_tolerance_ratio: float = 0.25
    axis_neighbor_presence_orthogonal_gate_ratio: float = 0.35


@dataclass
class TrenchConfig:
    # 全局候选。
    global_y_margin_fraction: float = 0.08
    smoothing_px: int = 3
    basin_window_width_factor: float = 0.48
    valley_min_distance_pitch_factor: float = 0.52
    valley_min_prominence_gray: float = 0.35
    candidate_center_dedup_width_factor: float = 0.45
    candidate_search_radius_width_factor: float = 0.60
    candidate_min_contrast_gray: float = 1.8
    candidate_min_width_factor: float = 0.45
    candidate_max_width_factor: float = 1.80

    # 一维规则阵列拟合与补全。
    lattice_pitch_min_factor: float = 0.75
    lattice_pitch_max_factor: float = 1.25
    lattice_residual_pitch_fraction: float = 0.22
    lattice_min_support: int = 3
    lattice_recovery_margin_width_factor: float = 0.70

    # 逐行测量。
    sample_number: int = 80
    average_rows_px: int = 7
    local_search_radius_width_factor: float = 0.38
    retry_search_radius_width_factor: float = 0.62
    tracking_max_jump_width_factor: float = 0.28
    tracking_max_width_change_fraction: float = 0.34
    threshold_fraction: float = 0.50
    minimum_valid_fraction: float = 0.60
    postfilter_window: int = 9
    postfilter_mad_multiplier: float = 6.0
    postfilter_min_edge_tolerance_px: float = 2.2
    postfilter_min_width_tolerance_px: float = 3.0

    # Trench 完整性与形貌终检。
    # 1) 靠近图像左右边界时，必须能在左右两侧都看到足够亮的边；
    # 2) 有效测量点 max(width)/min(width) >= 2 时舍弃；
    # 3) trench 沿 Y 方向由暗变亮并接近相邻 space 灰度时舍弃。
    reject_border_incomplete_trench: bool = True
    edge_bright_band_space_factor: float = 0.20
    edge_bright_band_width_factor: float = 0.30
    edge_bright_gap_px: float = 1.0
    edge_border_extra_px: float = 1.5
    edge_complete_min_bright_contrast_gray: float = 1.5
    edge_complete_min_global_contrast_fraction: float = 0.25
    edge_complete_min_side_fraction: float = 0.45
    edge_complete_min_both_fraction: float = 0.40

    max_to_min_width_ratio_limit: float = 2.0

    reject_dark_to_space_transition: bool = True
    intensity_inner_margin_fraction: float = 0.20
    intensity_smooth_window: int = 7
    intensity_dark_reference_percentile: float = 75.0
    intensity_min_reference_contrast_gray: float = 3.0
    intensity_bright_like_max_contrast_fraction: float = 0.22
    intensity_dark_like_min_contrast_fraction: float = 0.60
    intensity_min_bright_run_fraction: float = 0.10
    intensity_min_dark_run_fraction: float = 0.15
    intensity_min_run_separation_fraction: float = 0.12
    intensity_min_gray_change: float = 2.0
    intensity_min_change_reference_fraction: float = 0.30

    # Space 合格条件。
    space_min_design_factor: float = 0.40
    space_max_design_factor: float = 2.00
    space_min_valid_fraction: float = 0.50
    # 若中间某条 trench 被硬 QC 舍弃，不能把跨过该 trench 的大间隔当成一个 Space。
    space_pair_min_pitch_factor: float = 0.65
    space_pair_max_pitch_factor: float = 1.40


@dataclass
class ParsedImage:
    path: Path
    pattern: str
    folder_name: str
    folder_nominal_nm: float
    pretreatment_nm: float
    dose_mj: float
    sample_id: str
    design_via_nm: float = math.nan
    design_trench_nm: float = math.nan
    design_space_nm: float = math.nan
    metadata_source: str = "image_estimated"
    # 为兼容 V1.6 的输出表结构保留；V1.7 不做逐图自动分类，因此恒为 NaN。
    auto_pattern_score: float = math.nan
    auto_gradient_x_to_y_ratio: float = math.nan


@dataclass
class ViaCandidate:
    center: np.ndarray
    score: float
    raw_contrast: float
    detect_diameter_px: float
    source: str


@dataclass
class ViaMeasured:
    center: np.ndarray
    contour: np.ndarray
    metrics: dict[str, float]
    edge_meta: dict[str, float]
    candidate: ViaCandidate
    selection_mode: str
    confidence_flag: str
    grid_support: int = 0


@dataclass
class TrenchCandidate:
    center_x: float
    global_left_x: float
    global_right_x: float
    global_width_px: float
    basin_mean: float
    contrast: float
    score: float
    source: str
    lattice_index: Optional[int] = None


@dataclass
class TrenchTrack:
    candidate: TrenchCandidate
    y_values: np.ndarray
    left_edges: np.ndarray
    right_edges: np.ndarray
    valid_mask: np.ndarray
    mean_width_nm: float
    median_width_nm: float
    std_width_nm: float
    lwr_3sigma_nm: float
    valid_count: int
    valid_fraction: float
    centerline_tilt_deg: float
    left_fit_slope_px_per_px: float
    right_fit_slope_px_per_px: float
    confidence_flag: str
    quality_metrics: dict[str, Any] = field(default_factory=dict)


@dataclass
class DarkBandEdge:
    valid: bool
    reason: str = ""
    left_x: float = math.nan
    right_x: float = math.nan
    width_px: float = math.nan
    center_x: float = math.nan
    left_peak_x: float = math.nan
    right_peak_x: float = math.nan
    contrast_left: float = math.nan
    contrast_right: float = math.nan
    dark_level: float = math.nan


# ============================================================
# 2. 通用工具
# ============================================================
def finite_float(value: Any, default: float = math.nan) -> float:
    try:
        x = float(value)
        return x if np.isfinite(x) else default
    except Exception:
        return default


def robust_mad(values: np.ndarray) -> float:
    a = np.asarray(values, dtype=np.float64)
    a = a[np.isfinite(a)]
    if a.size == 0:
        return 0.0
    med = float(np.median(a))
    return float(np.median(np.abs(a - med)))


def robust_normalize_01(arr: np.ndarray, lo_q: float = 5.0, hi_q: float = 97.0) -> np.ndarray:
    a = np.asarray(arr, dtype=np.float32)
    if a.size == 0:
        return np.zeros_like(a, dtype=np.float32)
    lo, hi = np.percentile(a, [lo_q, hi_q])
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo + 1e-6:
        lo, hi = float(np.min(a)), float(np.max(a))
    if hi <= lo + 1e-6:
        return np.zeros_like(a, dtype=np.float32)
    return np.clip((a - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)


def moving_average_reflect(profile: np.ndarray, window: int) -> np.ndarray:
    p = np.asarray(profile, dtype=np.float64)
    w = max(1, int(window))
    if w <= 1:
        return p.copy()
    if w % 2 == 0:
        w += 1
    pad = w // 2
    padded = np.pad(p, (pad, pad), mode="reflect")
    kernel = np.ones(w, dtype=np.float64) / float(w)
    return np.convolve(padded, kernel, mode="valid")


def central_difference(profile: np.ndarray) -> np.ndarray:
    p = np.asarray(profile, dtype=np.float64)
    if p.size < 2:
        return np.zeros_like(p)
    g = np.empty_like(p)
    g[0] = p[1] - p[0]
    g[-1] = p[-1] - p[-2]
    if p.size > 2:
        g[1:-1] = 0.5 * (p[2:] - p[:-2])
    return g


def rolling_median_reference(values: np.ndarray, window: int) -> np.ndarray:
    a = np.asarray(values, dtype=np.float64)
    n = len(a)
    out = np.full(n, np.nan, dtype=np.float64)
    finite_global = a[np.isfinite(a)]
    global_med = float(np.median(finite_global)) if finite_global.size else math.nan
    radius = max(1, int(window) // 2)
    for i in range(n):
        s = max(0, i - radius)
        e = min(n, i + radius + 1)
        local = a[s:e]
        local = local[np.isfinite(local)]
        out[i] = float(np.median(local)) if local.size else global_med
    return out


def robust_series_outliers(
    values: np.ndarray,
    window: int,
    mad_multiplier: float,
    minimum_tolerance: float,
) -> tuple[np.ndarray, np.ndarray, float]:
    ref = rolling_median_reference(values, window)
    residual = np.asarray(values, dtype=float) - ref
    finite = residual[np.isfinite(residual)]
    sigma = 1.4826 * robust_mad(finite) if finite.size else 0.0
    tol = max(float(minimum_tolerance), float(mad_multiplier) * sigma)
    bad = np.isfinite(values) & np.isfinite(ref) & (np.abs(residual) > tol)
    return bad, ref, tol


def unicode_imread(path: Path) -> np.ndarray:
    try:
        raw = np.fromfile(str(path), dtype=np.uint8)
        img = cv2.imdecode(raw, cv2.IMREAD_UNCHANGED)
    except Exception as exc:
        raise RuntimeError(f"读取图像失败：{path}；{type(exc).__name__}: {exc}") from exc
    if img is None:
        raise RuntimeError(f"OpenCV 无法解码图像：{path}")
    return img


def normalize_gray_uint8(image: np.ndarray) -> np.ndarray:
    img = np.asarray(image)
    if img.ndim == 3:
        if img.shape[2] == 4:
            img = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
        else:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if img.ndim != 2:
        raise ValueError(f"期望二维灰度图，实际 shape={img.shape}")
    f = img.astype(np.float32)
    finite = np.isfinite(f)
    if not np.any(finite):
        raise ValueError("图像中没有有限灰度值")
    if not np.all(finite):
        f = np.where(finite, f, float(np.median(f[finite])))
    lo, hi = np.percentile(f, [1.0, 99.0])
    if hi <= lo + 1e-6:
        lo, hi = float(np.min(f)), float(np.max(f))
    if hi <= lo + 1e-6:
        raise ValueError("图像近似常数，无法测量边缘")
    return np.clip((f - lo) * 255.0 / (hi - lo), 0, 255).astype(np.uint8)


def read_gray_png(path: Path) -> np.ndarray:
    return normalize_gray_uint8(unicode_imread(path))


def unicode_imwrite(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower() or ".png"
    ok, buf = cv2.imencode(suffix, image)
    if not ok:
        raise RuntimeError(f"无法编码输出图像：{path}")
    buf.tofile(str(path))


def to_color(gray: np.ndarray) -> np.ndarray:
    if gray.ndim == 2:
        return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    return gray.copy()


def put_text_with_outline(
    image: np.ndarray,
    text: str,
    origin: tuple[int, int],
    font_scale: float,
    color: tuple[int, int, int],
    thickness: int = 1,
) -> None:
    """Draw a compact label with a thin black halo for both bright and dark SEM regions."""
    cv2.putText(
        image,
        text,
        origin,
        cv2.FONT_HERSHEY_SIMPLEX,
        font_scale,
        (0, 0, 0),
        max(2, thickness + 1),
        cv2.LINE_AA,
    )
    cv2.putText(
        image,
        text,
        origin,
        cv2.FONT_HERSHEY_SIMPLEX,
        font_scale,
        color,
        thickness,
        cv2.LINE_AA,
    )


def safe_mean(values: Iterable[float]) -> float:
    a = np.asarray(list(values), dtype=np.float64)
    a = a[np.isfinite(a)]
    return float(np.mean(a)) if a.size else math.nan


def safe_std(values: Iterable[float], ddof: int = 1) -> float:
    a = np.asarray(list(values), dtype=np.float64)
    a = a[np.isfinite(a)]
    if a.size <= ddof:
        return math.nan
    return float(np.std(a, ddof=ddof))


def safe_pct_bias(actual: float, design: float) -> float:
    if not np.isfinite(actual) or not np.isfinite(design) or abs(design) < EPS:
        return math.nan
    return 100.0 * (actual - design) / design


def contour_center(contour: np.ndarray) -> np.ndarray:
    c = np.asarray(contour)
    m = cv2.moments(c.astype(np.float32))
    if abs(m.get("m00", 0.0)) > 1e-9:
        return np.array([m["m10"] / m["m00"], m["m01"] / m["m00"]], dtype=float)
    return c.reshape(-1, 2).astype(float).mean(axis=0)


def ellipse_iou(contour: np.ndarray) -> float:
    c = np.asarray(contour, dtype=np.int32)
    if len(c) < 5:
        return 0.0
    try:
        ell = cv2.fitEllipse(c.astype(np.float32))
    except Exception:
        return 0.0
    pts = c.reshape(-1, 2)
    x0, y0 = np.floor(pts.min(axis=0) - 3).astype(int)
    x1, y1 = np.ceil(pts.max(axis=0) + 3).astype(int)
    w = max(8, int(x1 - x0 + 1))
    h = max(8, int(y1 - y0 + 1))
    shift = np.array([[[x0, y0]]], dtype=np.int32)
    cc = c - shift
    m1 = np.zeros((h, w), dtype=np.uint8)
    m2 = np.zeros_like(m1)
    cv2.drawContours(m1, [cc], -1, 255, -1)
    (ecx, ecy), axes, angle = ell
    center = (int(round(ecx - x0)), int(round(ecy - y0)))
    ax = (max(1, int(round(axes[0] / 2.0))), max(1, int(round(axes[1] / 2.0))))
    cv2.ellipse(m2, center, ax, float(angle), 0, 360, 255, -1)
    inter = int(np.count_nonzero((m1 > 0) & (m2 > 0)))
    union = int(np.count_nonzero((m1 > 0) | (m2 > 0)))
    return float(inter / union) if union else 0.0


def parse_folder_nominal_nm(name: str) -> float:
    m = re.search(rf"(?P<n>{NUMBER_PATTERN})\s*NM", name, flags=re.IGNORECASE)
    return float(m.group("n")) if m else math.nan


def is_png(path: Path) -> bool:
    """只检查文件类型；不检查文件名、倍率字段或所在文件夹名称。"""
    return path.is_file() and path.suffix.casefold() == ".png"


def _binary_run_lengths(mask: np.ndarray) -> list[tuple[bool, int, int, int]]:
    values = np.asarray(mask, dtype=bool).ravel()
    if values.size == 0:
        return []
    changes = np.flatnonzero(values[1:] != values[:-1]) + 1
    bounds = np.concatenate(([0], changes, [values.size]))
    return [
        (bool(values[start]), int(end - start), int(start), int(end))
        for start, end in zip(bounds[:-1], bounds[1:])
    ]


def estimate_via_reference_nm(gray: np.ndarray, pixel_size_nm: float) -> float:
    """从暗圆连通区域估计 Via 尺度；失败时回退到 40 nm。"""
    H, W = gray.shape
    blur = cv2.GaussianBlur(gray, (0, 0), 1.4)
    otsu_value, _ = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    thresholds = sorted({
        float(otsu_value),
        float(np.percentile(blur, 22.0)),
        float(np.percentile(blur, 30.0)),
        float(np.percentile(blur, 38.0)),
    })
    best: Optional[tuple[float, float]] = None
    image_area = float(H * W)
    min_reference_diameter_px = max(8.0, 15.0 / pixel_size_nm)
    min_reference_area_px = math.pi * (0.5 * min_reference_diameter_px) ** 2
    for threshold in thresholds:
        dark = (blur <= threshold).astype(np.uint8)
        dark = cv2.morphologyEx(dark, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        count, _, stats, _ = cv2.connectedComponentsWithStats(dark, connectivity=8)
        diameters: list[float] = []
        for i in range(1, count):
            x, y, width, height, area = [int(v) for v in stats[i]]
            if x <= 0 or y <= 0 or x + width >= W or y + height >= H:
                continue
            if area < max(min_reference_area_px, 0.00002 * image_area) or area > 0.025 * image_area:
                continue
            aspect = width / max(height, 1)
            if not 0.45 <= aspect <= 2.20:
                continue
            diameters.append(2.0 * math.sqrt(area / math.pi))
        if len(diameters) < 2:
            continue
        values = np.asarray(diameters, dtype=float)
        median = float(np.median(values))
        mad_fraction = 1.4826 * robust_mad(values) / max(median, EPS)
        score = min(len(values), 60) / 60.0 - 0.65 * mad_fraction
        if best is None or score > best[0]:
            best = (score, median)
    reference_px = best[1] if best is not None else 40.0 / pixel_size_nm
    reference_px = float(np.clip(reference_px, 6.0, max(8.0, 0.20 * min(H, W))))
    return reference_px * pixel_size_nm


def estimate_trench_references_nm(gray: np.ndarray, pixel_size_nm: float) -> tuple[float, float]:
    """从全高列均值的暗/亮游程估计 Trench 宽度和 Space 宽度。"""
    W = gray.shape[1]
    profile = gray.mean(axis=0).astype(np.float32)
    smooth_window = max(3, min(21, int(round(W / 120))))
    if smooth_window % 2 == 0:
        smooth_window += 1
    smooth = moving_average_reflect(profile, smooth_window).astype(np.float32)
    normalized = cv2.normalize(smooth.reshape(1, -1), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    threshold, _ = cv2.threshold(normalized, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    dark_mask = normalized.ravel() <= threshold
    runs = _binary_run_lengths(dark_mask)
    dark_widths = [
        length for is_dark, length, start, end in runs
        if is_dark and start > 0 and end < W and 3 <= length <= 0.30 * W
    ]
    bright_widths = [
        length for is_dark, length, start, end in runs
        if (not is_dark) and start > 0 and end < W and 3 <= length <= 0.45 * W
    ]
    trench_px = float(np.median(dark_widths)) if dark_widths else 30.0 / pixel_size_nm
    space_px = float(np.median(bright_widths)) if bright_widths else 70.0 / pixel_size_nm
    trench_px = float(np.clip(trench_px, 4.0, max(6.0, 0.25 * W)))
    space_px = float(np.clip(space_px, 3.0, max(5.0, 0.45 * W)))
    return trench_px * pixel_size_nm, space_px * pixel_size_nm


def parse_image_from_content(
    path: Path,
    folder_name: str,
    gray: np.ndarray,
    config: GeneralConfig,
) -> ParsedImage:
    # V1.7：图案类型只由调用参数决定，并统一应用于 root 及全部子文件夹。
    # 不再依据单张图内容、文件名或文件夹名改变 Via/Trench 类型。
    pattern = (config.force_pattern or "").casefold()
    folder_nm = parse_folder_nominal_nm(folder_name)
    common = dict(
        path=path,
        pattern=pattern,
        folder_name=folder_name,
        folder_nominal_nm=folder_nm,
        pretreatment_nm=math.nan,
        dose_mj=math.nan,
        sample_id=path.stem,
        auto_pattern_score=math.nan,
        auto_gradient_x_to_y_ratio=math.nan,
    )
    if pattern == "via":
        reference = (
            float(config.via_reference_nm)
            if config.via_reference_nm is not None
            else estimate_via_reference_nm(gray, config.pixel_size_nm)
        )
        return ParsedImage(
            **common,
            design_via_nm=reference,
            metadata_source="cli_reference" if config.via_reference_nm is not None else "image_estimated",
        )
    work_gray = 255.0-gray if pattern == "line" else gray
    trench_nm, space_nm = estimate_trench_references_nm(work_gray, config.pixel_size_nm)
    if config.trench_reference_nm is not None:
        trench_nm = float(config.trench_reference_nm)
    if config.space_reference_nm is not None:
        space_nm = float(config.space_reference_nm)
    if config.trench_reference_nm is not None and config.space_reference_nm is not None:
        source = "cli_reference"
    elif config.trench_reference_nm is not None or config.space_reference_nm is not None:
        source = "image_estimated_or_partial_cli"
    else:
        source = "image_estimated"
    return ParsedImage(
        **common,
        design_trench_nm=trench_nm,
        design_space_nm=space_nm,
        metadata_source=source,
    )


def discover_images(config: GeneralConfig) -> tuple[list[ParsedImage], list[dict[str, Any]]]:
    records: list[ParsedImage] = []
    errors: list[dict[str, Any]] = []
    root = config.root_dir
    out_dir = config.resolved_output_dir().resolve()

    paths = sorted((p for p in root.rglob("*") if is_png(p)), key=lambda p: str(p).casefold())
    for path in paths:
        try:
            resolved = path.resolve()
            if resolved == out_dir or out_dir in resolved.parents:
                continue
        except Exception:
            pass
        try:
            relative_parent = path.parent.relative_to(root)
            # 保存原始相对目录；根目录中的图片使用 "."，便于输出镜像输入目录树。
            folder_name = relative_parent.as_posix() if relative_parent.parts else "."
            gray = read_gray_png(path)
            records.append(parse_image_from_content(path, folder_name, gray, config))
        except Exception as exc:
            errors.append({
                "image": path.name,
                "path": str(path),
                "pattern": config.force_pattern,
                "stage": "content_scale_estimation",
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            })
    return records, errors


# ============================================================
# 3. Via：尺度匹配候选 + 真实外边缘 + 圆形 QC + 阵列补全
# ============================================================
def disk_annulus_kernel(diam_px: float, cfg: ViaConfig) -> np.ndarray:
    d = max(6.0, float(diam_px))
    r0 = max(1.5, cfg.inner_radius_diam_frac * d)
    r1 = max(r0 + 1.0, cfg.ring_inner_diam_frac * d)
    r2 = max(r1 + 1.0, cfg.ring_outer_diam_frac * d)
    half = int(math.ceil(r2)) + 1
    yy, xx = np.mgrid[-half:half + 1, -half:half + 1]
    rr = np.sqrt(xx.astype(np.float64) ** 2 + yy.astype(np.float64) ** 2)
    inner = rr <= r0
    ring = (rr >= r1) & (rr <= r2)
    k = np.zeros(rr.shape, dtype=np.float32)
    ni = int(np.count_nonzero(inner))
    nr = int(np.count_nonzero(ring))
    if ni:
        k[inner] = -1.0 / ni
    if nr:
        k[ring] = 1.0 / nr
    return k


def via_scale_response(
    gray: np.ndarray,
    nominal_diam_px: float,
    cfg: ViaConfig,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, float]]:
    g = gray.astype(np.float32)
    sigma = max(0.65, min(1.65, 0.025 * nominal_diam_px))
    gs = cv2.GaussianBlur(g, (0, 0), sigmaX=sigma, sigmaY=sigma)

    norm_responses: list[np.ndarray] = []
    raw_responses: list[np.ndarray] = []
    scale_diams: list[float] = []
    for ratio in cfg.scale_ratios:
        d = max(6.0, nominal_diam_px * ratio)
        raw = cv2.filter2D(gs, cv2.CV_32F, disk_annulus_kernel(d, cfg), borderType=cv2.BORDER_REFLECT_101)
        raw = np.maximum(raw, 0.0)
        norm = robust_normalize_01(raw, 25.0, 99.65)
        raw_responses.append(raw)
        norm_responses.append(norm)
        scale_diams.append(d)

    stack = np.stack(norm_responses, axis=0)
    winner = np.argmax(stack, axis=0)
    best = np.max(stack, axis=0)
    raw_stack = np.stack(raw_responses, axis=0)
    best_raw = np.take_along_axis(raw_stack, winner[None, ...], axis=0)[0]
    dvals = np.asarray(scale_diams, dtype=np.float32)
    best_diam = dvals[winner]

    bg_sigma = max(3.0, 0.70 * nominal_diam_px)
    local_bg = cv2.GaussianBlur(gs, (0, 0), sigmaX=bg_sigma, sigmaY=bg_sigma)
    local_dark = robust_normalize_01(np.maximum(local_bg - gs, 0.0), 20.0, 99.3)
    score = (1.0 - cfg.local_dark_weight) * best + cfg.local_dark_weight * local_dark
    score = cv2.GaussianBlur(score.astype(np.float32), (0, 0), sigmaX=0.65, sigmaY=0.65)
    score = np.clip(score, 0.0, 1.0)

    lo, hi = np.percentile(g, [5.0, 95.0])
    robust_range = max(1.0, float(hi - lo))
    raw_floor = max(0.35, 0.008 * robust_range)
    return score, best_raw, best_diam, {
        "response_smoothing_sigma_px": float(sigma),
        "robust_gray_range": float(robust_range),
        "raw_contrast_floor": float(raw_floor),
    }


def peak_components(mask: np.ndarray, score: np.ndarray) -> list[tuple[float, int, int]]:
    n, labels = cv2.connectedComponents(mask.astype(np.uint8), connectivity=8)
    out: list[tuple[float, int, int]] = []
    for lab in range(1, n):
        ys, xs = np.where(labels == lab)
        if len(xs) == 0:
            continue
        vals = score[ys, xs]
        k = int(np.argmax(vals))
        out.append((float(vals[k]), int(xs[k]), int(ys[k])))
    out.sort(key=lambda z: z[0], reverse=True)
    return out


def segmentation_center_candidates(
    gray: np.ndarray,
    score: np.ndarray,
    raw: np.ndarray,
    nominal_diam_px: float,
    raw_floor: float,
    cfg: ViaConfig,
) -> list[ViaCandidate]:
    """补充中心候选。只用轮廓找中心，最终边界仍由径向外边缘测量。"""
    D = max(6.0, nominal_diam_px)
    R = 0.5 * D
    H, W = gray.shape
    clahe = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8)).apply(gray)
    blur = cv2.GaussianBlur(clahe, (0, 0), sigmaX=max(0.7, 0.018 * D))
    masks: list[np.ndarray] = []
    _thr, otsu = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    masks.append(otsu)
    for q in (18.0, 24.0, 30.0, 36.0, 42.0):
        t = float(np.percentile(blur, q))
        masks.append((blur <= t).astype(np.uint8) * 255)

    k = max(3, int(round(0.08 * D)))
    if k % 2 == 0:
        k += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    min_area = math.pi * (0.22 * D) ** 2
    max_area = math.pi * (1.05 * D) ** 2
    margin = max(3, int(math.ceil(cfg.border_diameter_frac * D)))
    out: list[ViaCandidate] = []

    for mask in masks:
        work = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
        contours, _ = cv2.findContours(work, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            area = float(cv2.contourArea(c))
            if not (min_area <= area <= max_area):
                continue
            x, y, w, h = cv2.boundingRect(c)
            if min(w, h) < 0.32 * D or max(w, h) > 2.05 * D:
                continue
            cc = contour_center(c)
            cx, cy = cc
            if cx <= margin or cy <= margin or cx >= W - 1 - margin or cy >= H - 1 - margin:
                continue
            xi = int(np.clip(round(cx), 0, W - 1))
            yi = int(np.clip(round(cy), 0, H - 1))
            sc = float(score[yi, xi])
            rw = float(raw[yi, xi])
            if sc < 0.10 or rw < 0.28 * raw_floor:
                continue
            eqd = math.sqrt(4.0 * area / math.pi)
            out.append(ViaCandidate(cc, sc, rw, eqd, "multi_threshold_component"))
    return out


def via_candidate_centers(
    gray: np.ndarray,
    score: np.ndarray,
    raw: np.ndarray,
    best_diam: np.ndarray,
    nominal_diam_px: float,
    raw_floor: float,
    cfg: ViaConfig,
) -> list[ViaCandidate]:
    H, W = gray.shape
    D = max(6.0, nominal_diam_px)
    k = int(max(3, round(cfg.nms_diameter_frac * D)))
    if k % 2 == 0:
        k += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    dil = cv2.dilate(score, kernel)
    margin = max(3, int(math.ceil(cfg.border_diameter_frac * D)))

    candidates: list[ViaCandidate] = []
    for mode, score_min, raw_factor in (
        ("strict_scale_peak", cfg.strict_peak_score_min, cfg.strict_raw_floor_factor),
        ("relaxed_scale_peak", cfg.relaxed_peak_score_min, cfg.relaxed_raw_floor_factor),
    ):
        maxima = (score >= dil - 1e-6) & (score >= score_min) & (raw >= raw_factor * raw_floor)
        maxima[:margin, :] = False
        maxima[-margin:, :] = False
        maxima[:, :margin] = False
        maxima[:, -margin:] = False
        for sc, x, y in peak_components(maxima, score)[: cfg.max_candidates]:
            dd = float(best_diam[y, x]) if np.isfinite(best_diam[y, x]) else D
            candidates.append(ViaCandidate(np.array([x, y], dtype=float), sc, float(raw[y, x]), dd, mode))

    candidates.extend(segmentation_center_candidates(gray, score, raw, D, raw_floor, cfg))

    # 中心去重：优先 scale score 高，其次 raw contrast 高。
    candidates.sort(key=lambda c: (c.score, c.raw_contrast), reverse=True)
    tol = max(2.5, cfg.center_dedup_diameter_frac * D)
    unique: list[ViaCandidate] = []
    for c in candidates:
        hit = next((i for i, e in enumerate(unique) if np.linalg.norm(c.center - e.center) <= tol), None)
        if hit is None:
            unique.append(c)
        elif (c.score, c.raw_contrast) > (unique[hit].score, unique[hit].raw_contrast):
            unique[hit] = c
    return unique[: cfg.max_candidates]


def refine_via_center(
    gray: np.ndarray,
    score: np.ndarray,
    raw: np.ndarray,
    center: np.ndarray,
    nominal_diam_px: float,
    nearest_pitch: float,
    cfg: ViaConfig,
) -> tuple[np.ndarray, float, float]:
    H, W = gray.shape
    D = max(6.0, nominal_diam_px)
    r = max(2.0, cfg.center_refine_diameter_frac * D)
    if np.isfinite(nearest_pitch) and nearest_pitch > 0:
        r = min(r, 0.22 * nearest_pitch)
    cx, cy = map(float, center)
    x0 = max(0, int(math.floor(cx - r)))
    x1 = min(W, int(math.ceil(cx + r + 1)))
    y0 = max(0, int(math.floor(cy - r)))
    y1 = min(H, int(math.ceil(cy + r + 1)))
    if x1 <= x0 or y1 <= y0:
        return np.asarray(center, dtype=float), 0.0, 0.0

    sub = score[y0:y1, x0:x1]
    yy, xx = np.mgrid[y0:y1, x0:x1]
    inside = (xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2
    masked = np.where(inside, sub, -np.inf)
    iy, ix = np.unravel_index(int(np.argmax(masked)), masked.shape)
    peak_xy = np.array([x0 + ix, y0 + iy], dtype=float)

    # 暗区质心仅作小幅修正；防止被单个最暗像素拉偏。
    R = 0.5 * D
    half = int(math.ceil(0.75 * D))
    px, py = peak_xy
    ax0 = max(0, int(px - half)); ax1 = min(W, int(px + half + 1))
    ay0 = max(0, int(py - half)); ay1 = min(H, int(py + half + 1))
    loc = gray[ay0:ay1, ax0:ax1].astype(np.float32)
    yyl, xxl = np.mgrid[ay0:ay1, ax0:ax1]
    rr = np.sqrt((xxl - px) ** 2 + (yyl - py) ** 2)
    core = rr <= 0.42 * R
    ring = (rr >= 1.10 * R) & (rr <= 1.55 * R)
    refined = peak_xy.copy()
    if np.count_nonzero(core) >= 4 and np.count_nonzero(ring) >= 8:
        dark = float(np.median(loc[core]))
        bg = float(np.percentile(loc[ring], 70.0))
        if bg - dark > 1.0:
            dmask = (loc <= dark + 0.35 * (bg - dark)) & (rr <= 0.62 * D)
            if np.count_nonzero(dmask) >= 5:
                weights = np.clip(bg - loc[dmask], 0.0, None) + 1e-3
                dc = np.array([
                    float(np.average(xxl[dmask], weights=weights)),
                    float(np.average(yyl[dmask], weights=weights)),
                ])
                if np.linalg.norm(dc - peak_xy) <= 0.26 * D:
                    refined = 0.72 * peak_xy + 0.28 * dc

    xi = int(np.clip(round(refined[0]), 0, W - 1))
    yi = int(np.clip(round(refined[1]), 0, H - 1))
    return refined, float(score[yi, xi]), float(raw[yi, xi])


def via_processing_image(gray: np.ndarray, nominal_diam_px: float, relaxed: bool) -> tuple[np.ndarray, float]:
    D = max(7.0, nominal_diam_px)
    src = gray.astype(np.float32)
    if relaxed or D < 24:
        med = cv2.medianBlur(np.clip(src, 0, 255).astype(np.uint8), 3).astype(np.float32)
        sigma = max(0.85, min(1.65, 0.032 * D))
        sm = cv2.GaussianBlur(med, (0, 0), sigmaX=sigma, sigmaY=sigma)
    else:
        sigma = max(0.68, min(1.35, 0.022 * D))
        sm = cv2.GaussianBlur(src, (0, 0), sigmaX=sigma, sigmaY=sigma)
    return sm.astype(np.float32), float(sigma)


def circular_median(values: np.ndarray, half_window: int = 2) -> np.ndarray:
    a = np.asarray(values, dtype=np.float64)
    if len(a) < 3 or half_window <= 0:
        return a.copy()
    stack = [np.roll(a, k) for k in range(-half_window, half_window + 1)]
    return np.nanmedian(np.vstack(stack), axis=0)


def smooth_1d_profile(profile: np.ndarray, sigma_samples: float = 1.0) -> np.ndarray:
    p = np.asarray(profile, dtype=np.float32).reshape(1, -1)
    if p.shape[1] < 5:
        return p.ravel().astype(np.float64)
    return cv2.GaussianBlur(p, (0, 0), sigmaX=max(0.35, sigma_samples)).ravel().astype(np.float64)


def connected_component_radii(
    sm: np.ndarray,
    center: np.ndarray,
    R: float,
    rmax: float,
    bg: float,
    contrast: float,
    darkness_threshold: float,
    angles: np.ndarray,
    rr_sample: np.ndarray,
    relaxed: bool,
    cfg: ViaConfig,
) -> tuple[np.ndarray, dict[str, float]]:
    H, W = sm.shape
    c = np.asarray(center, dtype=float)
    half = int(math.ceil(rmax + 3.0))
    x0 = max(0, int(math.floor(c[0] - half)))
    x1 = min(W, int(math.ceil(c[0] + half + 1)))
    y0 = max(0, int(math.floor(c[1] - half)))
    y1 = min(H, int(math.ceil(c[1] + half + 1)))
    if x1 - x0 < 5 or y1 - y0 < 5:
        return np.full(len(angles), np.nan), {"component_used": 0.0}
    yy, xx = np.mgrid[y0:y1, x0:x1]
    radial = np.sqrt((xx - c[0]) ** 2 + (yy - c[1]) ** 2)
    loc = sm[y0:y1, x0:x1]
    darkness = np.clip((bg - loc) / max(contrast, 1e-6), -0.5, 2.0)
    mask = ((darkness >= darkness_threshold) & (radial <= rmax)).astype(np.uint8)
    k = max(3, int(round(cfg.connected_component_close_diam_frac * (2.0 * R))))
    if k % 2 == 0:
        k += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
    if not relaxed:
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)),
            iterations=1,
        )
    n, labels = cv2.connectedComponents(mask, connectivity=8)
    if n <= 1:
        return np.full(len(angles), np.nan), {"component_used": 0.0}

    core = radial <= 0.42 * R
    core_n = max(1, int(np.count_nonzero(core)))
    best_lab = 0
    best_score = -1.0
    best_overlap = 0.0
    for lab in range(1, n):
        comp = labels == lab
        overlap = float(np.count_nonzero(comp & core)) / core_n
        area = float(np.count_nonzero(comp))
        q = 4.0 * overlap + min(area / (math.pi * R * R + 1e-6), 1.5)
        if q > best_score:
            best_score = q
            best_lab = lab
            best_overlap = overlap
    if best_lab <= 0 or best_overlap < cfg.connected_component_min_core_overlap:
        return np.full(len(angles), np.nan), {
            "component_used": 0.0,
            "component_core_overlap": best_overlap,
        }

    comp = (labels == best_lab).astype(np.float32)
    xs = (c[0] + np.outer(np.cos(angles), rr_sample)).astype(np.float32)
    ys = (c[1] + np.outer(np.sin(angles), rr_sample)).astype(np.float32)
    vals = cv2.remap(
        comp,
        (xs - x0).astype(np.float32),
        (ys - y0).astype(np.float32),
        cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )
    radii = np.full(len(angles), np.nan, dtype=float)
    hit_bound = 0
    for i, row in enumerate(vals):
        idx = np.where(row > 0.5)[0]
        if len(idx):
            j = int(idx[-1])
            radii[i] = float(rr_sample[j])
            if radii[i] >= rmax - 0.6:
                hit_bound += 1
    return radii, {
        "component_used": 1.0,
        "component_core_overlap": float(best_overlap),
        "component_bound_fraction": float(hit_bound / max(1, len(angles))),
        "component_area_px": float(np.count_nonzero(comp)),
    }


def trace_via_outer_edge(
    gray: np.ndarray,
    center: np.ndarray,
    nominal_diam_px: float,
    nearest_pitch: float,
    cfg: ViaConfig,
    relaxed: bool,
) -> tuple[Optional[np.ndarray], dict[str, float]]:
    """沿径向寻找最外侧、持续的暗到亮跃迁，并与中心连通暗区合并。"""
    H, W = gray.shape
    D = max(7.0, float(nominal_diam_px))
    R = 0.5 * D
    c = np.asarray(center, dtype=float)
    sm, sigma = via_processing_image(gray, D, relaxed)

    rmax = cfg.max_radius_factor_R * R
    if np.isfinite(nearest_pitch) and nearest_pitch > 0 and 0.46 * nearest_pitch > 1.20 * R:
        rmax = min(rmax, 0.46 * nearest_pitch)
    rmin = max(1.0, 0.08 * R)
    rmin_edge = cfg.min_edge_radius_factor_R * R
    if rmax <= rmin_edge + 2.0:
        return None, {"good_ray_fraction": 0.0, "failure": "radius_window_too_small"}

    half = int(math.ceil(rmax + 3.0))
    x0 = max(0, int(math.floor(c[0] - half)))
    x1 = min(W, int(math.ceil(c[0] + half + 1)))
    y0 = max(0, int(math.floor(c[1] - half)))
    y1 = min(H, int(math.ceil(c[1] + half + 1)))
    if x1 - x0 < 8 or y1 - y0 < 8:
        return None, {"good_ray_fraction": 0.0, "failure": "near_image_boundary"}

    yy, xx = np.mgrid[y0:y1, x0:x1]
    radial = np.sqrt((xx - c[0]) ** 2 + (yy - c[1]) ** 2)
    loc = sm[y0:y1, x0:x1]
    core = radial <= 0.40 * R
    shoulder = (radial >= 0.55 * R) & (radial <= 0.96 * R)
    outer = (radial >= max(1.18 * R, 0.78 * rmax)) & (radial <= rmax)
    if min(np.count_nonzero(core), np.count_nonzero(shoulder), np.count_nonzero(outer)) < 8:
        return None, {"good_ray_fraction": 0.0, "failure": "insufficient_radial_samples"}

    bg_global = float(np.percentile(loc[outer], 72.0))
    dark_global = float(np.median(loc[core]))
    shoulder_gray = float(np.median(loc[shoulder]))
    contrast_global = bg_global - dark_global
    shoulder_contrast = bg_global - shoulder_gray
    robust_range = max(1.0, float(np.percentile(sm, 95) - np.percentile(sm, 5)))
    contrast_min = max(1.0 if relaxed else 2.0, (0.015 if relaxed else 0.025) * robust_range)
    shoulder_min = max(0.45 if relaxed else 0.75, (0.035 if relaxed else 0.055) * max(contrast_global, 0.0))
    broad_cut = bg_global - (0.06 if relaxed else 0.08) * max(contrast_global, 1e-6)
    shoulder_dark_fraction = float(np.mean(loc[shoulder] <= broad_cut))
    shoulder_frac_min = 0.15 if relaxed else 0.24

    if contrast_global < contrast_min or shoulder_contrast < shoulder_min or shoulder_dark_fraction < shoulder_frac_min:
        return None, {
            "good_ray_fraction": 0.0,
            "failure": "insufficient_broad_dark_support",
            "core_contrast_gray": contrast_global,
            "shoulder_contrast_gray": shoulder_contrast,
            "shoulder_dark_fraction": shoulder_dark_fraction,
            "smooth_sigma_px": sigma,
        }

    shoulder_ratio = shoulder_contrast / max(contrast_global, 1e-6)
    qfloor = 0.055 if relaxed else 0.075
    qthr = float(np.clip(0.56 * shoulder_ratio, qfloor, 0.34))

    nr = max(80, int(math.ceil((rmax - rmin) * cfg.radial_samples_per_px)))
    rr = np.linspace(rmin, rmax, nr, dtype=np.float32)
    angles = np.linspace(0.0, 2.0 * math.pi, cfg.radial_angles, endpoint=False)
    radii = np.full(len(angles), np.nan, dtype=float)
    strengths = np.zeros(len(angles), dtype=float)
    contrasts = np.zeros(len(angles), dtype=float)

    for ia, angle in enumerate(angles):
        xs = (c[0] + rr * math.cos(angle)).astype(np.float32)
        ys = (c[1] + rr * math.sin(angle)).astype(np.float32)
        if xs.min() < 1 or ys.min() < 1 or xs.max() > W - 2 or ys.max() > H - 2:
            continue
        prof = cv2.remap(
            sm,
            xs.reshape(1, -1),
            ys.reshape(1, -1),
            cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REFLECT_101,
        ).ravel().astype(np.float64)
        prof = smooth_1d_profile(prof, 1.05 if relaxed else 0.95)
        core_mask = rr <= 0.42 * R
        bg_mask = rr >= max(1.16 * R, 0.78 * rmax)
        if np.count_nonzero(core_mask) < 4 or np.count_nonzero(bg_mask) < 4:
            continue
        dark = float(np.median(prof[core_mask]))
        bg = float(np.percentile(prof[bg_mask], 68.0))
        contrast = bg - dark
        if contrast < max(0.7, 0.35 * contrast_min):
            continue
        q = np.clip((bg - prof) / max(contrast, 1e-6), -0.5, 2.0)
        ray_sh = (rr >= 0.55 * R) & (rr <= 0.96 * R)
        ray_sh_q = float(np.median(q[ray_sh])) if np.count_nonzero(ray_sh) >= 3 else 2.0 * qthr
        qthr_ray = float(np.clip(0.65 * (0.56 * ray_sh_q) + 0.35 * qthr, qfloor, 0.36))

        win = max(3, int(round(0.045 * D * cfg.radial_samples_per_px)))
        if win % 2 == 0:
            win += 1
        qsm = np.convolve(q, np.ones(win, dtype=float) / win, mode="same")
        search = np.where((rr >= rmin_edge) & (rr <= rmax))[0]
        if len(search) < 8:
            continue
        in_n = max(3, int(round(0.055 * R * cfg.radial_samples_per_px)))
        out_n = max(3, int(round(0.070 * R * cfg.radial_samples_per_px)))
        grad = np.gradient(prof, rr.astype(np.float64))
        chosen: Optional[int] = None
        chosen_grad = 0.0
        for j in search[-2:1:-1]:
            if j + out_n >= len(qsm) or j - in_n < 0:
                continue
            if not (qsm[j] >= qthr_ray and qsm[j + 1] < qthr_ray):
                continue
            inside_med = float(np.median(qsm[j - in_n + 1:j + 1]))
            outside_med = float(np.median(qsm[j + 1:j + 1 + out_n]))
            g = float(np.max(grad[max(0, j - 1):min(len(grad), j + 3)]))
            if inside_med >= 0.88 * qthr_ray and outside_med <= 1.10 * qthr_ray and g >= max(0.03, 0.010 * contrast):
                chosen = int(j)
                chosen_grad = g
                break

        if chosen is None:
            binary = (qsm >= qthr_ray).astype(np.uint8)
            kk = max(3, int(round(0.035 * D * cfg.radial_samples_per_px)))
            if kk % 2 == 0:
                kk += 1
            binary = cv2.morphologyEx(binary.reshape(1, -1), cv2.MORPH_CLOSE, np.ones((1, kk), np.uint8), iterations=1).ravel()
            starts = np.where((rr <= 0.48 * R) & (binary > 0))[0]
            if len(starts):
                j = int(starts[-1])
                last = j
                gap = 0
                for qidx in range(j + 1, len(binary)):
                    if binary[qidx] > 0:
                        last = qidx
                        gap = 0
                    else:
                        gap += 1
                        if gap > max(2, out_n // 2):
                            break
                if rr[last] >= rmin_edge and last < len(rr) - 1:
                    chosen = int(last)
                    chosen_grad = float(max(0.0, grad[min(last, len(grad) - 1)]))
        if chosen is None:
            continue

        j = int(chosen)
        if j + 1 < len(rr) and abs(qsm[j] - qsm[j + 1]) > 1e-9:
            frac = float(np.clip((qsm[j] - qthr_ray) / (qsm[j] - qsm[j + 1]), 0.0, 1.0))
            radius = float(rr[j] + frac * (rr[j + 1] - rr[j]))
        else:
            radius = float(rr[j])
        radii[ia] = radius
        strengths[ia] = chosen_grad
        contrasts[ia] = contrast

    comp_r, comp_meta = connected_component_radii(
        sm, c, R, rmax, bg_global, contrast_global, qthr, angles, rr, relaxed, cfg
    )
    comp_ok = bool(
        comp_meta.get("component_used", 0.0) > 0.5
        and comp_meta.get("component_bound_fraction", 1.0) <= (0.20 if relaxed else 0.16)
    )
    if comp_ok:
        for i in range(len(radii)):
            cr = comp_r[i]
            if not np.isfinite(cr):
                continue
            if not np.isfinite(radii[i]):
                radii[i] = cr
            elif cr > radii[i]:
                radii[i] = min(cr, radii[i] + (0.38 if relaxed else 0.34) * R)

    good = np.isfinite(radii)
    good_fraction = float(np.mean(good)) if len(good) else 0.0
    min_good = cfg.relaxed_min_good_ray_fraction if relaxed else cfg.strict_min_good_ray_fraction
    if good_fraction < min_good or np.count_nonzero(good) < 8:
        return None, {
            "good_ray_fraction": good_fraction,
            "failure": "too_few_reliable_rays",
            "core_contrast_gray": contrast_global,
            "shoulder_contrast_gray": shoulder_contrast,
            "shoulder_dark_fraction": shoulder_dark_fraction,
            "smooth_sigma_px": sigma,
            **comp_meta,
        }

    idx = np.where(good)[0]
    xg = np.r_[idx - len(radii), idx, idx + len(radii)]
    yg = np.r_[radii[idx], radii[idx], radii[idx]]
    miss = np.where(~good)[0]
    if len(miss):
        radii[miss] = np.interp(miss, xg, yg)

    med = circular_median(radii, 3 if relaxed else 2)
    lim = cfg.radius_spike_limit_R * R
    radii = np.clip(radii, med - lim, med + lim)
    passes = 3 if relaxed else 2
    for _ in range(passes):
        radii = (
            0.16 * np.roll(radii, 2)
            + 0.20 * np.roll(radii, 1)
            + 0.28 * radii
            + 0.20 * np.roll(radii, -1)
            + 0.16 * np.roll(radii, -2)
        )

    pts = np.column_stack([c[0] + radii * np.cos(angles), c[1] + radii * np.sin(angles)])
    # 保留亚像素轮廓用于面积、周长和圆形度；仅在绘图/掩膜时再取整。
    # 这样理想圆的 4πA/P² 会接近 1，不会被 144 个径向点的像素取整锯齿人为压低。
    contour = np.asarray(pts, dtype=np.float32).reshape(-1, 1, 2)

    leak_vals: list[float] = []
    dr = max(1.0, 0.075 * R)
    for ia, angle in enumerate(angles):
        rtest = np.array([radii[ia] + dr, radii[ia] + 2.0 * dr], dtype=np.float32)
        xs = (c[0] + rtest * math.cos(angle)).astype(np.float32)
        ys = (c[1] + rtest * math.sin(angle)).astype(np.float32)
        if xs.min() < 0 or ys.min() < 0 or xs.max() > W - 1 or ys.max() > H - 1:
            continue
        values = cv2.remap(
            sm,
            xs.reshape(1, -1),
            ys.reshape(1, -1),
            cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REFLECT_101,
        ).ravel()
        leak_vals.append(float(np.mean((bg_global - values) / max(contrast_global, 1e-6) >= 0.80 * qthr)))
    leak = float(np.mean(leak_vals)) if leak_vals else 1.0

    return contour, {
        "good_ray_fraction": good_fraction,
        "median_edge_radius_px": float(np.median(radii)),
        "median_ray_contrast_gray": float(np.median(contrasts[good])) if np.any(good) else math.nan,
        "median_ray_edge_gradient": float(np.median(strengths[good])) if np.any(good) else math.nan,
        "smooth_sigma_px": sigma,
        "smooth_passes": float(passes),
        "core_contrast_gray": contrast_global,
        "shoulder_contrast_gray": shoulder_contrast,
        "shoulder_dark_fraction": shoulder_dark_fraction,
        "outer_dark_leak_fraction": leak,
        "darkness_threshold": qthr,
        **comp_meta,
    }


def via_shape_metrics(contour: np.ndarray) -> dict[str, float]:
    # 面积/周长使用亚像素轮廓；ellipse IoU 内部会单独栅格化为整数掩膜。
    c = np.asarray(contour, dtype=np.float32)
    area = float(cv2.contourArea(c))
    perimeter = float(cv2.arcLength(c, True))
    if area <= 0 or perimeter <= 0:
        return {
            "area_px2": 0.0,
            "perimeter_px": 0.0,
            "equivalent_diameter_px": 0.0,
            "circularity": 0.0,
            "solidity": 0.0,
            "axis_ratio": math.inf,
            "axis_roundness": 0.0,
            "ellipse_iou": 0.0,
            "radial_cv": math.inf,
            "edge_highfreq_roughness_rms_px": math.inf,
            "edge_highfreq_roughness_cv": math.inf,
            "ellipse_major_px": math.nan,
            "ellipse_minor_px": math.nan,
            "x_span_px": 0.0,
            "y_span_px": 0.0,
        }
    hull = cv2.convexHull(c)
    hull_area = float(cv2.contourArea(hull))
    solidity = area / max(hull_area, EPS)
    circularity = 4.0 * math.pi * area / max(perimeter * perimeter, EPS)
    pts = c.reshape(-1, 2).astype(float)
    x_span = float(pts[:, 0].max() - pts[:, 0].min())
    y_span = float(pts[:, 1].max() - pts[:, 1].min())

    if len(c) >= 5:
        try:
            _center, axes, _angle = cv2.fitEllipse(c)
            minor = float(min(axes))
            major = float(max(axes))
        except Exception:
            rect = cv2.minAreaRect(c)
            minor = float(min(rect[1]))
            major = float(max(rect[1]))
    else:
        rect = cv2.minAreaRect(c)
        minor = float(min(rect[1]))
        major = float(max(rect[1]))
    axis_ratio = major / max(minor, EPS)
    axis_roundness = minor / max(major, EPS)

    cc = contour_center(c)
    rr = np.linalg.norm(pts - cc, axis=1)
    radial_cv = float(np.std(rr) / max(np.mean(rr), EPS)) if len(rr) else math.inf

    # 高频边缘粗糙度：先按极角排序，再用环形局部中位数去除整体椭圆度和
    # 低频形变，仅保留局部边缘起伏。该指标只用于“离开方阵且过度圆滑”的
    # 联合假阳性筛选，不参与正常 Via 的基础 QC。
    if len(rr) >= 12:
        angles = np.arctan2(pts[:, 1] - cc[1], pts[:, 0] - cc[0])
        rr_ordered = rr[np.argsort(angles)]
        half_window = max(2, min(10, len(rr_ordered) // 24))
        baseline = circular_median(rr_ordered, half_window=half_window)
        residual = rr_ordered - baseline
        edge_rough_rms = float(np.sqrt(np.mean(residual * residual)))
        edge_rough_cv = edge_rough_rms / max(float(np.mean(rr_ordered)), EPS)
    else:
        edge_rough_rms = math.inf
        edge_rough_cv = math.inf

    eqd = math.sqrt(4.0 * area / math.pi)
    return {
        "area_px2": area,
        "perimeter_px": perimeter,
        "equivalent_diameter_px": float(eqd),
        "circularity": float(circularity),
        "solidity": float(solidity),
        "axis_ratio": float(axis_ratio),
        "axis_roundness": float(axis_roundness),
        "ellipse_iou": float(ellipse_iou(c)),
        "radial_cv": float(radial_cv),
        "edge_highfreq_roughness_rms_px": float(edge_rough_rms),
        "edge_highfreq_roughness_cv": float(edge_rough_cv),
        "ellipse_major_px": float(major),
        "ellipse_minor_px": float(minor),
        "x_span_px": x_span,
        "y_span_px": y_span,
    }


def via_shape_qc(
    metrics: dict[str, float],
    edge_meta: dict[str, float],
    nominal_diam_px: float,
    cfg: ViaConfig,
    relaxed: bool,
) -> tuple[bool, list[str]]:
    D = max(1e-9, nominal_diam_px)
    if relaxed:
        min_factor = cfg.relaxed_min_design_factor
        max_factor = cfg.relaxed_max_design_factor
        circ_min = cfg.relaxed_min_circularity
        sol_min = cfg.relaxed_min_solidity
        ar_max = cfg.relaxed_max_axis_ratio
        iou_min = cfg.relaxed_min_ellipse_iou
        rcv_max = cfg.relaxed_max_radial_cv
        good_min = cfg.relaxed_min_good_ray_fraction
        leak_max = cfg.relaxed_max_outer_dark_leak
    else:
        min_factor = cfg.strict_min_design_factor
        max_factor = cfg.strict_max_design_factor
        circ_min = cfg.strict_min_circularity
        sol_min = cfg.strict_min_solidity
        ar_max = cfg.strict_max_axis_ratio
        iou_min = cfg.strict_min_ellipse_iou
        rcv_max = cfg.strict_max_radial_cv
        good_min = cfg.strict_min_good_ray_fraction
        leak_max = cfg.strict_max_outer_dark_leak

    reasons: list[str] = []
    eqd = metrics["equivalent_diameter_px"]
    if eqd < min_factor * D:
        reasons.append("equivalent_diameter_too_small")
    if eqd > max_factor * D:
        reasons.append("equivalent_diameter_too_large")
    if metrics["circularity"] < circ_min:
        reasons.append("circularity_too_low")
    if metrics["solidity"] < sol_min:
        reasons.append("solidity_too_low")
    if metrics["axis_ratio"] > ar_max:
        reasons.append("axis_ratio_too_large")
    if metrics["ellipse_iou"] < iou_min:
        reasons.append("ellipse_iou_too_low")
    if metrics["radial_cv"] > rcv_max:
        reasons.append("radial_cv_too_large")
    if edge_meta.get("good_ray_fraction", 0.0) < good_min:
        reasons.append("too_few_good_rays")
    if edge_meta.get("outer_dark_leak_fraction", 1.0) > leak_max:
        reasons.append("outer_edge_likely_inward")
    return len(reasons) == 0, reasons


def evaluate_via_candidate(
    gray: np.ndarray,
    score: np.ndarray,
    raw: np.ndarray,
    candidate: ViaCandidate,
    nominal_diam_px: float,
    nearest_pitch: float,
    raw_floor: float,
    cfg: ViaConfig,
    relaxed: bool,
) -> Optional[ViaMeasured]:
    center, sc, rw = refine_via_center(gray, score, raw, candidate.center, nominal_diam_px, nearest_pitch, cfg)
    if relaxed:
        if sc < cfg.relaxed_peak_score_min or rw < cfg.relaxed_raw_floor_factor * raw_floor:
            return None
    else:
        if sc < cfg.strict_peak_score_min * 0.80 or rw < cfg.strict_raw_floor_factor * 0.72 * raw_floor:
            return None

    centers = [center, np.asarray(candidate.center, dtype=float), 0.5 * (center + candidate.center)]
    unique_centers: list[np.ndarray] = []
    for c in centers:
        if not any(np.linalg.norm(c - old) < 0.5 for old in unique_centers):
            unique_centers.append(c)

    options: list[tuple[float, np.ndarray, dict[str, float], dict[str, float], np.ndarray]] = []
    for c in unique_centers:
        contour, edge_meta = trace_via_outer_edge(gray, c, nominal_diam_px, nearest_pitch, cfg, relaxed)
        if contour is None:
            continue
        metrics = via_shape_metrics(contour)
        ok, _reasons = via_shape_qc(metrics, edge_meta, nominal_diam_px, cfg, relaxed)
        if not ok:
            continue
        leak = edge_meta.get("outer_dark_leak_fraction", 1.0)
        q = (
            2.1 * edge_meta.get("good_ray_fraction", 0.0)
            + 0.60 * min(metrics["equivalent_diameter_px"] / max(nominal_diam_px, EPS), 1.40)
            + 0.35 * metrics["solidity"]
            + 0.25 * metrics["ellipse_iou"]
            + 0.20 * metrics["circularity"]
            - 1.20 * max(0.0, leak - (cfg.relaxed_max_outer_dark_leak if relaxed else cfg.strict_max_outer_dark_leak))
        )
        options.append((float(q), contour, edge_meta, metrics, c))

    if not options:
        return None
    options.sort(key=lambda z: z[0], reverse=True)
    _q, contour, edge_meta, metrics, used_center = options[0]
    final_center = contour_center(contour)
    final_candidate = ViaCandidate(
        center=final_center,
        score=float(sc),
        raw_contrast=float(rw),
        detect_diameter_px=float(candidate.detect_diameter_px),
        source=candidate.source,
    )
    edge_meta = dict(edge_meta)
    edge_meta["used_edge_center_x_px"] = float(used_center[0])
    edge_meta["used_edge_center_y_px"] = float(used_center[1])
    return ViaMeasured(
        center=final_center,
        contour=contour,
        metrics=metrics,
        edge_meta=edge_meta,
        candidate=final_candidate,
        selection_mode="RELAXED_FALLBACK" if relaxed else "STRICT",
        confidence_flag="RELAXED_REVIEW" if relaxed else "NORMAL",
    )


def dedup_measured_vias(items: Sequence[ViaMeasured], nominal_diam_px: float) -> list[ViaMeasured]:
    ranked = sorted(
        items,
        key=lambda m: (
            m.selection_mode == "STRICT",
            m.edge_meta.get("good_ray_fraction", 0.0),
            m.metrics.get("circularity", 0.0),
            m.candidate.score,
        ),
        reverse=True,
    )
    tol = max(2.5, 0.52 * nominal_diam_px)
    out: list[ViaMeasured] = []
    for m in ranked:
        if any(np.linalg.norm(m.center - old.center) <= tol for old in out):
            continue
        out.append(m)
    out.sort(key=lambda m: (float(m.center[1]), float(m.center[0])))
    return out


def estimate_pitch_and_axes(points: np.ndarray, nominal_diam_px: float, cfg: ViaConfig) -> tuple[float, np.ndarray, np.ndarray]:
    pts = np.asarray(points, dtype=float)
    if len(pts) < 3:
        return math.nan, np.array([1.0, 0.0]), np.array([0.0, 1.0])
    diffs: list[tuple[float, float]] = []
    nearest: list[float] = []
    for i in range(len(pts)):
        ds = []
        for j in range(len(pts)):
            if i == j:
                continue
            v = pts[j] - pts[i]
            d = float(np.linalg.norm(v))
            if cfg.grid_pitch_min_design_factor * nominal_diam_px <= d <= cfg.grid_pitch_max_design_factor * nominal_diam_px:
                ds.append(d)
        if ds:
            nearest.append(min(ds))
    if not nearest:
        return math.nan, np.array([1.0, 0.0]), np.array([0.0, 1.0])
    pitch = float(np.median(nearest))

    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            v = pts[j] - pts[i]
            d = float(np.linalg.norm(v))
            if abs(d - pitch) <= cfg.grid_neighbor_distance_tolerance * pitch:
                ang = math.atan2(v[1], v[0]) % math.pi
                diffs.append((ang, d))
    if not diffs:
        return pitch, np.array([1.0, 0.0]), np.array([0.0, 1.0])

    angles = np.array([a for a, _d in diffs], dtype=float)
    bins = np.linspace(0.0, math.pi, 37)
    hist, edges = np.histogram(angles, bins=bins)
    idx1 = int(np.argmax(hist))
    a1 = 0.5 * (edges[idx1] + edges[idx1 + 1])

    def angular_diff_pi(a: float, b: float) -> float:
        d = abs(a - b) % math.pi
        return min(d, math.pi - d)

    candidates2 = []
    for idx, count in enumerate(hist):
        a = 0.5 * (edges[idx] + edges[idx + 1])
        sep = angular_diff_pi(a, a1)
        if math.radians(45.0) <= sep <= math.radians(135.0):
            candidates2.append((int(count), a))
    a2 = max(candidates2)[1] if candidates2 else (a1 + math.pi / 2.0) % math.pi

    tol = math.radians(cfg.grid_angle_tolerance_deg)
    for which, a0 in ((1, a1), (2, a2)):
        near = np.array([a for a in angles if angular_diff_pi(a, a0) <= tol])
        if len(near):
            # 方向是模 π 的，使用 double-angle 平均。
            refined = 0.5 * math.atan2(float(np.mean(np.sin(2 * near))), float(np.mean(np.cos(2 * near))))
            if refined < 0:
                refined += math.pi
            if which == 1:
                a1 = refined
            else:
                a2 = refined

    u = np.array([math.cos(a1), math.sin(a1)], dtype=float)
    v = np.array([math.cos(a2), math.sin(a2)], dtype=float)
    # 若第二轴不可靠，强制取第一轴的垂线。
    sep = angular_diff_pi(a1, a2)
    if not (math.radians(45.0) <= sep <= math.radians(135.0)):
        v = np.array([-u[1], u[0]], dtype=float)
    return pitch, u, v


def grid_support_count(
    center: np.ndarray,
    existing: Sequence[ViaMeasured],
    pitch: float,
    u: np.ndarray,
    v: np.ndarray,
    cfg: ViaConfig,
) -> int:
    if not np.isfinite(pitch) or pitch <= 0:
        return 0
    tol_d = cfg.grid_neighbor_distance_tolerance * pitch
    tol_a = math.radians(cfg.grid_angle_tolerance_deg)
    axes = [u / (np.linalg.norm(u) + EPS), v / (np.linalg.norm(v) + EPS)]
    count = 0
    for m in existing:
        vec = np.asarray(m.center) - np.asarray(center)
        d = float(np.linalg.norm(vec))
        if abs(d - pitch) > tol_d or d <= EPS:
            continue
        uv = vec / d
        ok = False
        for axis in axes:
            cosv = abs(float(np.dot(uv, axis)))
            angle = math.acos(float(np.clip(cosv, -1.0, 1.0)))
            if angle <= tol_a:
                ok = True
                break
        if ok:
            count += 1
    return count


def orthonormal_grid_axes(u: np.ndarray, v: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Convert approximate grid directions to a stable orthonormal square-grid basis."""
    au = np.asarray(u, dtype=float)
    av = np.asarray(v, dtype=float)
    if not np.all(np.isfinite(au)) or np.linalg.norm(au) <= EPS:
        au = np.array([1.0, 0.0], dtype=float)
    au = au / (np.linalg.norm(au) + EPS)
    if not np.all(np.isfinite(av)) or np.linalg.norm(av) <= EPS:
        av = np.array([-au[1], au[0]], dtype=float)
    av = av - float(np.dot(av, au)) * au
    if np.linalg.norm(av) <= 1e-6:
        av = np.array([-au[1], au[0]], dtype=float)
    av = av / (np.linalg.norm(av) + EPS)
    if np.linalg.det(np.column_stack([au, av])) < 0:
        av = -av
    return au, av


def wrapped_lattice_residual(values: np.ndarray, phase: float, pitch: float) -> np.ndarray:
    """Absolute distance to the nearest phase + k*pitch lattice line."""
    values = np.asarray(values, dtype=float)
    return np.abs(((values - phase + 0.5 * pitch) % pitch) - 0.5 * pitch)


def fit_lattice_phase(values: np.ndarray, pitch: float, tolerance_px: float) -> float:
    """Fit one lattice phase modulo pitch by maximum inlier consensus."""
    a = np.asarray(values, dtype=float)
    a = a[np.isfinite(a)]
    if len(a) == 0 or not np.isfinite(pitch) or pitch <= EPS:
        return math.nan
    phases = np.mod(a, pitch)
    best_phase = float(phases[0])
    best_key: tuple[int, float, float] = (-1, -math.inf, -math.inf)
    for phase in phases:
        residual = wrapped_lattice_residual(a, float(phase), pitch)
        inlier = residual <= tolerance_px
        count = int(np.count_nonzero(inlier))
        med = float(np.median(residual[inlier])) if count else math.inf
        mean = float(np.mean(residual[inlier])) if count else math.inf
        key = (count, -med, -mean)
        if key > best_key:
            best_key = key
            best_phase = float(phase)

    # Circular-mean refinement avoids the phase=0 / phase=pitch wrap problem.
    for _ in range(2):
        residual = wrapped_lattice_residual(a, best_phase, pitch)
        inlier = residual <= tolerance_px
        if np.count_nonzero(inlier) < 2:
            break
        angles = 2.0 * math.pi * a[inlier] / pitch
        z = complex(float(np.mean(np.cos(angles))), float(np.mean(np.sin(angles))))
        if abs(z) <= 1e-8:
            break
        best_phase = float((math.atan2(z.imag, z.real) % (2.0 * math.pi)) * pitch / (2.0 * math.pi))
    return best_phase


def via_is_overly_smooth(m: ViaMeasured, cfg: ViaConfig) -> bool:
    """Conservative smooth-circle flag, used only together with off-grid status."""
    met = m.metrics
    return bool(
        met.get("circularity", 0.0) >= cfg.offgrid_smooth_min_circularity
        and met.get("axis_roundness", 0.0) >= cfg.offgrid_smooth_min_axis_roundness
        and met.get("solidity", 0.0) >= cfg.offgrid_smooth_min_solidity
        and met.get("ellipse_iou", 0.0) >= cfg.offgrid_smooth_min_ellipse_iou
        and met.get("radial_cv", math.inf) <= cfg.offgrid_smooth_max_radial_cv
        and met.get("edge_highfreq_roughness_cv", math.inf)
        <= cfg.offgrid_smooth_max_highfreq_roughness_cv
    )


def filter_offgrid_overly_smooth_vias(
    items: Sequence[ViaMeasured],
    nominal_diam_px: float,
    cfg: ViaConfig,
) -> tuple[list[ViaMeasured], dict[int, dict[str, Any]], dict[str, Any]]:
    """Reject only Via objects that are both off a reliable square lattice and overly smooth."""
    result = list(items)
    metrics_by_id: dict[int, dict[str, Any]] = {}
    meta: dict[str, Any] = {
        "via_square_grid_qc_used": False,
        "via_offgrid_smooth_rejected_count": 0,
        "via_square_grid_pitch_px": math.nan,
        "via_square_grid_phase_u_px": math.nan,
        "via_square_grid_phase_v_px": math.nan,
        "via_square_grid_core_count": 0,
        "via_square_grid_inlier_count": 0,
        "via_square_grid_inlier_fraction": 0.0,
    }

    def fill_no_model() -> None:
        for m in result:
            metrics_by_id[id(m)] = {
                "grid_model_used": False,
                "grid_on_square_lattice": math.nan,
                "grid_residual_px": math.nan,
                "grid_residual_pitch_fraction": math.nan,
                "grid_axis_u_residual_px": math.nan,
                "grid_axis_v_residual_px": math.nan,
                "offgrid_smooth_shape": via_is_overly_smooth(m, cfg),
            }

    if not cfg.enable_offgrid_smooth_rejection or len(result) < cfg.grid_membership_min_seed_count:
        fill_no_model()
        return result, metrics_by_id, meta

    centers = np.asarray([m.center for m in result], dtype=float)
    pitch0, u0, v0 = estimate_pitch_and_axes(centers, nominal_diam_px, cfg)
    if not np.isfinite(pitch0) or pitch0 <= EPS:
        fill_no_model()
        return result, metrics_by_id, meta

    support0 = np.asarray(
        [
            grid_support_count(m.center, [x for x in result if x is not m], pitch0, u0, v0, cfg)
            for m in result
        ],
        dtype=int,
    )
    core_idx = np.flatnonzero(support0 >= cfg.grid_core_min_neighbor_support)
    if len(core_idx) < cfg.grid_membership_min_seed_count:
        core_idx = np.arange(len(result), dtype=int)
    core_centers = centers[core_idx]
    pitch, u, v = estimate_pitch_and_axes(core_centers, nominal_diam_px, cfg)
    if not np.isfinite(pitch) or pitch <= EPS:
        pitch, u, v = pitch0, u0, v0
    au, av = orthonormal_grid_axes(u, v)

    fit_tol = cfg.grid_phase_fit_tolerance_pitch_fraction * pitch
    phase_u = fit_lattice_phase(core_centers @ au, pitch, fit_tol)
    phase_v = fit_lattice_phase(core_centers @ av, pitch, fit_tol)
    if not np.isfinite(phase_u) or not np.isfinite(phase_v):
        fill_no_model()
        return result, metrics_by_id, meta

    proj_u = centers @ au
    proj_v = centers @ av
    res_u = wrapped_lattice_residual(proj_u, phase_u, pitch)
    res_v = wrapped_lattice_residual(proj_v, phase_v, pitch)
    residual = np.hypot(res_u, res_v)
    on_grid = residual <= cfg.grid_membership_max_residual_pitch_fraction * pitch
    inlier_count = int(np.count_nonzero(on_grid))
    inlier_fraction = inlier_count / float(len(result))
    model_used = bool(
        inlier_count >= cfg.grid_membership_min_seed_count
        and inlier_fraction >= cfg.grid_membership_min_inlier_fraction
    )
    if not model_used:
        fill_no_model()
        meta.update({
            "via_square_grid_pitch_px": float(pitch),
            "via_square_grid_core_count": int(len(core_idx)),
            "via_square_grid_inlier_count": inlier_count,
            "via_square_grid_inlier_fraction": float(inlier_fraction),
        })
        return result, metrics_by_id, meta

    kept: list[ViaMeasured] = []
    rejected = 0
    for i, m in enumerate(result):
        smooth = via_is_overly_smooth(m, cfg)
        reject = bool((not on_grid[i]) and smooth)
        metrics_by_id[id(m)] = {
            "grid_model_used": True,
            "grid_on_square_lattice": bool(on_grid[i]),
            "grid_residual_px": float(residual[i]),
            "grid_residual_pitch_fraction": float(residual[i] / max(pitch, EPS)),
            "grid_axis_u_residual_px": float(res_u[i]),
            "grid_axis_v_residual_px": float(res_v[i]),
            "offgrid_smooth_shape": bool(smooth),
            "offgrid_smooth_rejected": bool(reject),
        }
        if reject:
            rejected += 1
        else:
            kept.append(m)

    meta.update({
        "via_square_grid_qc_used": True,
        "via_offgrid_smooth_rejected_count": int(rejected),
        "via_square_grid_pitch_px": float(pitch),
        "via_square_grid_phase_u_px": float(phase_u),
        "via_square_grid_phase_v_px": float(phase_v),
        "via_square_grid_core_count": int(len(core_idx)),
        "via_square_grid_inlier_count": inlier_count,
        "via_square_grid_inlier_fraction": float(inlier_fraction),
    })
    return kept, metrics_by_id, meta


def sort_vias_spatially(
    items: Sequence[ViaMeasured],
    pitch: float,
    u: np.ndarray,
    v: np.ndarray,
) -> list[ViaMeasured]:
    """Assign stable top-to-bottom / left-to-right object order.

    For a regular tilted array, use the fitted lattice axes.  For a sparse or
    non-grid image, fall back to ordinary image Y then X ordering.
    """
    result = list(items)
    if len(result) <= 1:
        return result
    centers = np.asarray([m.center for m in result], dtype=float)
    if not np.isfinite(pitch) or pitch <= 0 or not np.all(np.isfinite(u)) or not np.all(np.isfinite(v)):
        return [result[i] for i in np.lexsort((centers[:, 0], centers[:, 1]))]

    au = np.asarray(u, dtype=float) / (np.linalg.norm(u) + EPS)
    av = np.asarray(v, dtype=float) / (np.linalg.norm(v) + EPS)
    if abs(au[0]) >= abs(av[0]):
        h_axis, v_axis = au, av
    else:
        h_axis, v_axis = av, au
    if h_axis[0] < 0:
        h_axis = -h_axis
    if v_axis[1] < 0:
        v_axis = -v_axis
    hp = centers @ h_axis
    vp = centers @ v_axis
    row_index = np.rint((vp - np.min(vp)) / max(pitch, EPS)).astype(int)
    order = np.lexsort((hp, row_index))
    return [result[int(i)] for i in order]



def horizontal_vertical_grid_axes(u: np.ndarray, v: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return stable grid axes whose dominant image directions are X and Y.

    The fitted Via lattice may be slightly tilted.  This helper keeps the fitted
    directions, but consistently names the direction with the larger absolute
    X component as the horizontal axis and the other as the vertical axis.
    """
    au, av = orthonormal_grid_axes(u, v)
    if abs(float(au[0])) >= abs(float(av[0])):
        h_axis, v_axis = au, av
    else:
        h_axis, v_axis = av, au
    if h_axis[0] < 0:
        h_axis = -h_axis
    if v_axis[1] < 0:
        v_axis = -v_axis
    return h_axis, v_axis


def robust_arithmetic_mean_spacing(values: Sequence[float], cfg: ViaConfig) -> float:
    """Arithmetic mean after a median-centred outlier trim.

    The user requested an average spacing.  A short false-positive separation
    must not pull that reference downward, so the final arithmetic mean is
    calculated only from values within a configurable band around the median.
    """
    a = np.asarray(list(values), dtype=float)
    a = a[np.isfinite(a) & (a > EPS)]
    if len(a) < cfg.adjacent_spacing_min_reference_pairs:
        return math.nan
    med = float(np.median(a))
    band = max(0.0, float(cfg.adjacent_spacing_robust_band_fraction))
    lo = max(EPS, (1.0 - band) * med)
    hi = (1.0 + band) * med
    trimmed = a[(a >= lo) & (a <= hi)]
    if len(trimmed) < cfg.adjacent_spacing_min_reference_pairs:
        trimmed = a
    return float(np.mean(trimmed)) if len(trimmed) else math.nan


def estimate_via_average_xy_spacings(
    items: Sequence[ViaMeasured],
    pitch: float,
    u: np.ndarray,
    v: np.ndarray,
    nominal_diam_px: float,
    cfg: ViaConfig,
) -> tuple[float, float, int, int]:
    """Estimate average nearest-grid spacing in image X and Y components.

    Horizontal/vertical neighbour pairs are identified using the fitted lattice
    axes.  The returned X spacing is the arithmetic mean of |delta x| for
    horizontal one-pitch pairs; the Y spacing is the arithmetic mean of
    |delta y| for vertical one-pitch pairs.  Very short pairs are deliberately
    excluded from the reference calculation so that the suspected false Via
    does not redefine the threshold used to reject itself.
    """
    result = list(items)
    if len(result) < cfg.adjacent_spacing_min_seed_count:
        return math.nan, math.nan, 0, 0
    centers = np.asarray([m.center for m in result], dtype=float)
    if not np.isfinite(pitch) or pitch <= EPS:
        pitch, u, v = estimate_pitch_and_axes(centers, nominal_diam_px, cfg)
    if not np.isfinite(pitch) or pitch <= EPS:
        return math.nan, math.nan, 0, 0

    h_axis, v_axis = horizontal_vertical_grid_axes(u, v)
    min_step = cfg.adjacent_spacing_reference_min_pitch_fraction * pitch
    max_step = cfg.adjacent_spacing_reference_max_pitch_fraction * pitch
    orth_gate = cfg.adjacent_spacing_orthogonal_gate_pitch_fraction * pitch

    horizontal_dx: list[float] = []
    vertical_dy: list[float] = []
    for i in range(len(centers)):
        for j in range(i + 1, len(centers)):
            delta = centers[j] - centers[i]
            dh = abs(float(np.dot(delta, h_axis)))
            dv = abs(float(np.dot(delta, v_axis)))
            if dv <= orth_gate and min_step <= dh <= max_step:
                horizontal_dx.append(abs(float(delta[0])))
            if dh <= orth_gate and min_step <= dv <= max_step:
                vertical_dy.append(abs(float(delta[1])))

    avg_x = robust_arithmetic_mean_spacing(horizontal_dx, cfg)
    avg_y = robust_arithmetic_mean_spacing(vertical_dy, cfg)
    return avg_x, avg_y, len(horizontal_dx), len(vertical_dy)


def via_keep_quality_key(m: ViaMeasured, grid_qc: dict[str, Any]) -> tuple[float, ...]:
    """Higher tuple means the Via is the safer member of a too-close pair."""
    on_grid = grid_qc.get("grid_on_square_lattice", math.nan)
    if isinstance(on_grid, (bool, np.bool_)):
        grid_rank = 2.0 if bool(on_grid) else 0.0
    else:
        grid_rank = 1.0
    residual = finite_float(grid_qc.get("grid_residual_pitch_fraction", math.nan))
    residual_score = -residual if np.isfinite(residual) else -0.50
    confidence_score = 1.0 if m.confidence_flag == "NORMAL" else 0.0
    good_ray = finite_float(m.edge_meta.get("good_ray_fraction", math.nan))
    if not np.isfinite(good_ray):
        good_ray = -1.0
    score = finite_float(m.candidate.score)
    if not np.isfinite(score):
        score = -math.inf
    raw_contrast = finite_float(m.candidate.raw_contrast)
    if not np.isfinite(raw_contrast):
        raw_contrast = -math.inf
    return (
        grid_rank,
        residual_score,
        float(m.grid_support),
        confidence_score,
        good_ray,
        score,
        raw_contrast,
    )


def find_actual_spatial_via_neighbor_pairs(
    items: Sequence[ViaMeasured],
    pitch: float,
    u: np.ndarray,
    v: np.ndarray,
    avg_x: float,
    avg_y: float,
    nominal_diam_px: float,
    cfg: ViaConfig,
) -> list[tuple[int, int]]:
    """Return all physically adjacent Via pairs from the pre-QC object set.

    This is deliberately independent of temporary Via numbering.  A pair is
    considered spatially adjacent when the two centres lie within one local
    square-lattice neighbourhood.  With a valid fitted pitch, the default gate
    is 1.60 pitch, which includes the four cardinal neighbours and the four
    diagonal neighbours of a square array, but excludes sites two pitches away.

    If a reliable pitch cannot be fitted, the function falls back to the
    already calculated X/Y average spacings and uses the same normalized local
    neighbourhood idea.  The result is calculated once from the original Via
    list and is never rebuilt after any deletion.
    """
    result = list(items)
    n = len(result)
    if n < 2:
        return []

    centers = np.asarray([m.center for m in result], dtype=float)
    effective_pitch = finite_float(pitch)
    if not np.isfinite(effective_pitch) or effective_pitch <= EPS:
        effective_pitch, u, v = estimate_pitch_and_axes(centers, nominal_diam_px, cfg)

    usable_pitch = np.isfinite(effective_pitch) and effective_pitch > EPS
    usable_x = np.isfinite(avg_x) and avg_x > EPS
    usable_y = np.isfinite(avg_y) and avg_y > EPS
    max_local_step = max(1.0, float(cfg.adjacent_spacing_actual_neighbor_max_pitch_fraction))

    pairs: list[tuple[int, int]] = []
    for i in range(n):
        for j in range(i + 1, n):
            delta = centers[j] - centers[i]
            dx = abs(float(delta[0]))
            dy = abs(float(delta[1]))
            euclidean = float(np.hypot(dx, dy))

            if usable_pitch:
                # Euclidean distance is rotation-independent.  For a square
                # point array, 1.0 pitch is a row/column neighbour and sqrt(2)
                # pitch is a diagonal neighbour.
                local_step = euclidean / effective_pitch
            elif usable_x and usable_y:
                # Chebyshev-normalized distance keeps a normal same-row pair
                # (dy≈0) and a normal same-column pair (dx≈0) at step≈1.
                local_step = max(dx / avg_x, dy / avg_y)
            elif usable_x:
                local_step = dx / avg_x
            elif usable_y:
                local_step = dy / avg_y
            else:
                continue

            if np.isfinite(local_step) and EPS < local_step <= max_local_step:
                pairs.append((i, j))

    return pairs


def filter_actual_spatial_neighbor_too_close_vias_once(
    ordered_items: Sequence[ViaMeasured],
    pitch: float,
    u: np.ndarray,
    v: np.ndarray,
    nominal_diam_px: float,
    grid_qc_by_id: dict[int, dict[str, Any]],
    cfg: ViaConfig,
) -> tuple[list[ViaMeasured], dict[int, dict[str, Any]], dict[str, Any]]:
    """One non-recursive pass over all actual spatial-neighbour Via pairs.

    Temporary Via numbering is retained only for deterministic reporting.  It
    no longer decides which objects are compared.  The function first computes
    the average X/Y lattice spacings from every previously accepted Via, then
    builds all physically adjacent pairs from their centre coordinates.

    All neighbour pairs, quality comparisons and reject decisions are based on
    the same original list.  Objects are removed simultaneously at the end; the
    neighbour graph, averages and decisions are never recalculated after a
    deletion, so this remains exactly one non-recursive pass.

    A normal horizontal grid pair has delta-y near zero, and a normal vertical
    pair has delta-x near zero.  Therefore testing ``dx < 0.6*avg_x OR
    dy < 0.6*avg_y`` literally would delete every valid row/column pair.  As in
    V1.3, the pair is judged along its dominant normalized movement axis: X for
    a row-like pair and Y for a column-like pair.  Only that meaningful ratio
    is compared with the configured 0.60 threshold.
    """
    result = list(ordered_items)
    metrics_by_id: dict[int, dict[str, Any]] = {}
    meta: dict[str, Any] = {
        "via_adjacent_spacing_qc_used": False,
        "via_adjacent_spacing_neighbor_definition": "all_actual_spatial_neighbors",
        "via_adjacent_spacing_rejected_count": 0,
        "via_adjacent_spacing_too_close_pair_count": 0,
        "via_adjacent_spacing_tested_pair_count": 0,
        "via_adjacent_spacing_average_x_px": math.nan,
        "via_adjacent_spacing_average_y_px": math.nan,
        "via_adjacent_spacing_reference_pair_count_x": 0,
        "via_adjacent_spacing_reference_pair_count_y": 0,
        "via_adjacent_spacing_reject_ratio": float(cfg.adjacent_spacing_reject_ratio),
        "via_adjacent_spacing_actual_neighbor_max_pitch_fraction": float(
            cfg.adjacent_spacing_actual_neighbor_max_pitch_fraction
        ),
        "via_adjacent_spacing_too_close_pair_preorders": "",
        "via_adjacent_spacing_rejected_preorders": "",
    }

    for order, m in enumerate(result, start=1):
        metrics_by_id[id(m)] = {
            "pre_adjacent_spacing_qc_order": int(order),
            "adjacent_spacing_qc_used": False,
            "adjacent_spacing_average_x_px": math.nan,
            "adjacent_spacing_average_y_px": math.nan,
            "adjacent_spacing_actual_neighbor_count": 0,
            "adjacent_spacing_min_pair_ratio": math.nan,
            "adjacent_spacing_too_close_pair_count": 0,
            "adjacent_spacing_rejected": False,
            "adjacent_spacing_reject_partner_preorder": "",
        }

    if (
        not cfg.enable_adjacent_spacing_rejection
        or len(result) < cfg.adjacent_spacing_min_seed_count
    ):
        return result, metrics_by_id, meta

    avg_x, avg_y, pair_count_x, pair_count_y = estimate_via_average_xy_spacings(
        result, pitch, u, v, nominal_diam_px, cfg
    )
    usable_x = np.isfinite(avg_x) and avg_x > EPS
    usable_y = np.isfinite(avg_y) and avg_y > EPS
    meta.update({
        "via_adjacent_spacing_average_x_px": float(avg_x) if usable_x else math.nan,
        "via_adjacent_spacing_average_y_px": float(avg_y) if usable_y else math.nan,
        "via_adjacent_spacing_reference_pair_count_x": int(pair_count_x),
        "via_adjacent_spacing_reference_pair_count_y": int(pair_count_y),
    })
    if not (usable_x or usable_y):
        return result, metrics_by_id, meta

    neighbor_pairs = find_actual_spatial_via_neighbor_pairs(
        result,
        pitch,
        u,
        v,
        avg_x,
        avg_y,
        nominal_diam_px,
        cfg,
    )
    meta["via_adjacent_spacing_tested_pair_count"] = int(len(neighbor_pairs))
    meta["via_adjacent_spacing_qc_used"] = True

    reject_indices: set[int] = set()
    reject_partners: dict[int, set[int]] = defaultdict(set)
    too_close_pair_orders: list[str] = []
    too_close_pairs = 0

    # Count every actual spatial neighbour before making any deletion decision.
    for i, j in neighbor_pairs:
        metrics_by_id[id(result[i])]["adjacent_spacing_actual_neighbor_count"] += 1
        metrics_by_id[id(result[j])]["adjacent_spacing_actual_neighbor_count"] += 1

    for i, j in neighbor_pairs:
        delta = np.asarray(result[j].center, dtype=float) - np.asarray(result[i].center, dtype=float)
        dx = abs(float(delta[0]))
        dy = abs(float(delta[1]))
        rx = dx / avg_x if usable_x else math.nan
        ry = dy / avg_y if usable_y else math.nan

        if usable_x and usable_y:
            if rx >= ry:
                dominant_axis = "x"
                ratio = rx
            else:
                dominant_axis = "y"
                ratio = ry
        elif usable_x:
            dominant_axis = "x"
            ratio = rx
        else:
            dominant_axis = "y"
            ratio = ry

        for idx in (i, j):
            info = metrics_by_id[id(result[idx])]
            previous = finite_float(info.get("adjacent_spacing_min_pair_ratio", math.nan))
            if not np.isfinite(previous) or ratio < previous:
                info["adjacent_spacing_min_pair_ratio"] = float(ratio)
                info["adjacent_spacing_min_pair_axis"] = dominant_axis
                info["adjacent_spacing_min_pair_delta_x_px"] = float(dx)
                info["adjacent_spacing_min_pair_delta_y_px"] = float(dy)

        if not np.isfinite(ratio) or ratio >= cfg.adjacent_spacing_reject_ratio:
            continue

        too_close_pairs += 1
        too_close_pair_orders.append(f"{i + 1}-{j + 1}")
        metrics_by_id[id(result[i])]["adjacent_spacing_too_close_pair_count"] += 1
        metrics_by_id[id(result[j])]["adjacent_spacing_too_close_pair_count"] += 1

        key_i = via_keep_quality_key(result[i], grid_qc_by_id.get(id(result[i]), {}))
        key_j = via_keep_quality_key(result[j], grid_qc_by_id.get(id(result[j]), {}))
        if key_i < key_j:
            loser = i
            partner = j
        elif key_j < key_i:
            loser = j
            partner = i
        else:
            # 完全并列时舍弃临时编号较后的对象，保证结果可重复。
            loser = j
            partner = i
        reject_indices.add(loser)
        reject_partners[loser].add(partner + 1)

    for idx, m in enumerate(result):
        info = metrics_by_id[id(m)]
        info["adjacent_spacing_qc_used"] = True
        info["adjacent_spacing_average_x_px"] = float(avg_x) if usable_x else math.nan
        info["adjacent_spacing_average_y_px"] = float(avg_y) if usable_y else math.nan
        if idx in reject_indices:
            info["adjacent_spacing_rejected"] = True
            info["adjacent_spacing_reject_partner_preorder"] = ",".join(
                str(value) for value in sorted(reject_partners.get(idx, set()))
            )

    kept = [m for idx, m in enumerate(result) if idx not in reject_indices]
    meta.update({
        "via_adjacent_spacing_rejected_count": int(len(reject_indices)),
        "via_adjacent_spacing_too_close_pair_count": int(too_close_pairs),
        "via_adjacent_spacing_too_close_pair_preorders": ",".join(too_close_pair_orders),
        "via_adjacent_spacing_rejected_preorders": ",".join(
            str(index + 1) for index in sorted(reject_indices)
        ),
    })
    return kept, metrics_by_id, meta



def filter_vias_without_axis_neighbors_once(
    ordered_items: Sequence[ViaMeasured],
    avg_x: float,
    avg_y: float,
    cfg: ViaConfig,
) -> tuple[list[ViaMeasured], dict[int, dict[str, Any]], dict[str, Any]]:
    """One non-recursive pass rejecting Via objects isolated along X or Y.

    In V1.6 this rule is deliberately applied *before* any grid-relaxed
    candidate recovery or predicted-site recovery, and immediately after the
    too-close-pair rejection.  It uses the previously calculated average X/Y
    grid spacings as fixed references and evaluates the current strict-seed Via
    set exactly once.

    For each Via, a horizontal neighbour exists when another selected Via lies
    near ``1.0 * average_x_spacing`` in |dx| (default ±25%) while its |dy| stays inside a
    narrow orthogonal gate.  Likewise, a vertical neighbour exists when |dy|
    is near ``1.0 * average_y_spacing`` (default ±25%) and |dx| stays inside the gate.

    "Left/right have no Via" means neither side provides a horizontal neighbour;
    it does NOT require both left and right to be present.  The same applies to
    up/down.  Therefore a valid Via on the image-array boundary can survive as
    long as it has at least one horizontal and at least one vertical neighbour.

    All neighbour flags and all reject decisions are made from the same input
    list.  Rejected objects are removed simultaneously at the end.  No spacing
    is recalculated, no neighbour relationship is rebuilt and the operation is
    never recursively repeated.
    """
    result = list(ordered_items)
    metrics_by_id: dict[int, dict[str, Any]] = {}
    meta: dict[str, Any] = {
        "via_axis_neighbor_qc_used": False,
        "via_axis_neighbor_rejected_count": 0,
        "via_axis_neighbor_rejected_preorders": "",
        "via_axis_neighbor_average_x_px": float(avg_x) if np.isfinite(avg_x) else math.nan,
        "via_axis_neighbor_average_y_px": float(avg_y) if np.isfinite(avg_y) else math.nan,
        "via_axis_neighbor_spacing_tolerance_ratio": float(cfg.axis_neighbor_presence_spacing_tolerance_ratio),
        "via_axis_neighbor_orthogonal_gate_ratio": float(cfg.axis_neighbor_presence_orthogonal_gate_ratio),
        "via_axis_neighbor_definition": "at_least_one_horizontal_AND_at_least_one_vertical",
    }

    for order, m in enumerate(result, start=1):
        metrics_by_id[id(m)] = {
            "pre_axis_neighbor_qc_order": int(order),
            "axis_neighbor_qc_used": False,
            "axis_neighbor_has_left": False,
            "axis_neighbor_has_right": False,
            "axis_neighbor_has_up": False,
            "axis_neighbor_has_down": False,
            "axis_neighbor_has_horizontal": False,
            "axis_neighbor_has_vertical": False,
            "axis_neighbor_horizontal_count": 0,
            "axis_neighbor_vertical_count": 0,
            "axis_neighbor_rejected": False,
            "axis_neighbor_reject_reason": "",
        }

    if (
        not cfg.enable_axis_neighbor_presence_rejection
        or len(result) < cfg.axis_neighbor_presence_min_seed_count
    ):
        return result, metrics_by_id, meta

    usable_x = np.isfinite(avg_x) and avg_x > EPS
    usable_y = np.isfinite(avg_y) and avg_y > EPS
    # The requested rule needs both reference spacings.  If one axis could not
    # be estimated reliably, skip this QC instead of making a one-axis guess.
    if not (usable_x and usable_y):
        return result, metrics_by_id, meta

    centers = np.asarray([m.center for m in result], dtype=float)
    spacing_tol = max(0.0, float(cfg.axis_neighbor_presence_spacing_tolerance_ratio))
    min_dx = max(EPS, (1.0 - spacing_tol) * float(avg_x))
    max_dx = (1.0 + spacing_tol) * float(avg_x)
    min_dy = max(EPS, (1.0 - spacing_tol) * float(avg_y))
    max_dy = (1.0 + spacing_tol) * float(avg_y)
    orth_y = float(cfg.axis_neighbor_presence_orthogonal_gate_ratio) * float(avg_y)
    orth_x = float(cfg.axis_neighbor_presence_orthogonal_gate_ratio) * float(avg_x)

    # Freeze all neighbour relationships from the original pre-deletion set.
    for i in range(len(result)):
        for j in range(i + 1, len(result)):
            delta = centers[j] - centers[i]
            dx_signed = float(delta[0])
            dy_signed = float(delta[1])
            dx = abs(dx_signed)
            dy = abs(dy_signed)

            # Horizontal neighbour: approximately same row and approximately
            # one average X spacing away (default 0.75x--1.25x).
            if min_dx - EPS <= dx <= max_dx + EPS and dy <= orth_y + EPS:
                info_i = metrics_by_id[id(result[i])]
                info_j = metrics_by_id[id(result[j])]
                info_i["axis_neighbor_horizontal_count"] += 1
                info_j["axis_neighbor_horizontal_count"] += 1
                if dx_signed > 0:
                    info_i["axis_neighbor_has_right"] = True
                    info_j["axis_neighbor_has_left"] = True
                else:
                    info_i["axis_neighbor_has_left"] = True
                    info_j["axis_neighbor_has_right"] = True

            # Vertical neighbour: approximately same column and approximately
            # one average Y spacing away (default 0.75x--1.25x).
            if min_dy - EPS <= dy <= max_dy + EPS and dx <= orth_x + EPS:
                info_i = metrics_by_id[id(result[i])]
                info_j = metrics_by_id[id(result[j])]
                info_i["axis_neighbor_vertical_count"] += 1
                info_j["axis_neighbor_vertical_count"] += 1
                if dy_signed > 0:  # image coordinates: positive Y is downward
                    info_i["axis_neighbor_has_down"] = True
                    info_j["axis_neighbor_has_up"] = True
                else:
                    info_i["axis_neighbor_has_up"] = True
                    info_j["axis_neighbor_has_down"] = True

    reject_indices: set[int] = set()
    for idx, m in enumerate(result):
        info = metrics_by_id[id(m)]
        info["axis_neighbor_qc_used"] = True
        has_horizontal = bool(info["axis_neighbor_has_left"] or info["axis_neighbor_has_right"])
        has_vertical = bool(info["axis_neighbor_has_up"] or info["axis_neighbor_has_down"])
        info["axis_neighbor_has_horizontal"] = has_horizontal
        info["axis_neighbor_has_vertical"] = has_vertical

        reasons: list[str] = []
        if not has_horizontal:
            reasons.append("no_left_or_right_neighbor_near_1x_avg_x")
        if not has_vertical:
            reasons.append("no_up_or_down_neighbor_near_1x_avg_y")
        if reasons:
            reject_indices.add(idx)
            info["axis_neighbor_rejected"] = True
            info["axis_neighbor_reject_reason"] = ";".join(reasons)

    kept = [m for idx, m in enumerate(result) if idx not in reject_indices]
    meta.update({
        "via_axis_neighbor_qc_used": True,
        "via_axis_neighbor_rejected_count": int(len(reject_indices)),
        "via_axis_neighbor_rejected_preorders": ",".join(
            str(index + 1) for index in sorted(reject_indices)
        ),
    })
    return kept, metrics_by_id, meta


def predicted_grid_sites(
    existing: Sequence[ViaMeasured],
    pitch: float,
    u: np.ndarray,
    v: np.ndarray,
    nominal_diam_px: float,
    image_shape: tuple[int, int],
    cfg: ViaConfig,
) -> list[tuple[np.ndarray, int]]:
    if len(existing) < cfg.grid_min_seed_count or not np.isfinite(pitch) or pitch <= 0:
        return []
    H, W = image_shape
    margin = cfg.border_diameter_frac * nominal_diam_px
    raw_preds: list[np.ndarray] = []
    for m in existing:
        c = np.asarray(m.center, dtype=float)
        for axis in (u, v):
            axis = axis / (np.linalg.norm(axis) + EPS)
            for sign in (-1.0, 1.0):
                p = c + sign * pitch * axis
                if margin < p[0] < W - 1 - margin and margin < p[1] < H - 1 - margin:
                    if not any(np.linalg.norm(p - e.center) <= 0.45 * nominal_diam_px for e in existing):
                        raw_preds.append(p)

    clusters: list[list[np.ndarray]] = []
    tol = max(2.5, cfg.grid_prediction_cluster_diam_frac * nominal_diam_px)
    for p in raw_preds:
        placed = False
        for cluster in clusters:
            center = np.mean(cluster, axis=0)
            if np.linalg.norm(p - center) <= tol:
                cluster.append(p)
                placed = True
                break
        if not placed:
            clusters.append([p])
    out = []
    for cluster in clusters:
        votes = len(cluster)
        if votes >= cfg.grid_min_prediction_votes:
            out.append((np.mean(cluster, axis=0), votes))
    return out


def measure_via_image(
    parsed: ParsedImage,
    gray: np.ndarray,
    general: GeneralConfig,
    cfg: ViaConfig,
) -> tuple[list[dict[str, Any]], dict[str, Any], np.ndarray, dict[str, np.ndarray]]:
    px_nm = general.pixel_size_nm
    design_nm = parsed.design_via_nm
    D = max(6.0, design_nm / px_nm)
    score, raw, best_diam, response_meta = via_scale_response(gray, D, cfg)
    raw_floor = float(response_meta["raw_contrast_floor"])
    candidates = via_candidate_centers(gray, score, raw, best_diam, D, raw_floor, cfg)

    strict: list[ViaMeasured] = []
    for c in candidates:
        m = evaluate_via_candidate(gray, score, raw, c, D, math.nan, raw_floor, cfg, relaxed=False)
        if m is not None:
            strict.append(m)
    accepted = dedup_measured_vias(strict, D)
    strict_initial_count = len(accepted)
    strict_initial_empty = strict_initial_count == 0

    # ========================================================
    # V1.6 Via 前置清洗：必须早于任何“点阵预判 + 放宽要求”。
    # ========================================================
    # 先只用严格模式原始 Via 建立点阵与邻居支持。随后依次执行：
    #   1) 方阵外 + 异常圆滑对象剔除；
    #   2) 实际空间邻孔过近一次性剔除；
    #   3) 左右/上下轴向邻孔存在性一次性剔除。
    # 这里所有删除都发生在规则位置放宽候选和 predicted-grid recovery 之前。
    pitch, u, v = estimate_pitch_and_axes(np.array([m.center for m in accepted]), D, cfg)
    for m in accepted:
        m.grid_support = max(
            m.grid_support,
            grid_support_count(m.center, [x for x in accepted if x is not m], pitch, u, v, cfg),
        )

    # A. 先去除“方阵外且边缘异常圆滑”的假圆，避免它们污染平均 pitch/点阵相位。
    accepted, grid_qc_by_id, grid_qc_meta = filter_offgrid_overly_smooth_vias(accepted, D, cfg)
    pre_qc_after_offgrid_count = len(accepted)

    # B. 对清洗后的严格 Via 重新估计点阵，并做一次“实际空间邻孔过近”筛选。
    #    只执行这一轮，不递归。
    pitch, u, v = estimate_pitch_and_axes(np.array([m.center for m in accepted]), D, cfg)
    for m in accepted:
        m.grid_support = max(
            m.grid_support,
            grid_support_count(m.center, [x for x in accepted if x is not m], pitch, u, v, cfg),
        )
    accepted = sort_vias_spatially(accepted, pitch, u, v)
    accepted, spacing_qc_by_id, spacing_qc_meta = filter_actual_spatial_neighbor_too_close_vias_once(
        accepted,
        pitch,
        u,
        v,
        D,
        grid_qc_by_id,
        cfg,
    )
    pre_qc_after_spacing_count = len(accepted)

    # C. 使用 B 中固定算出的 X/Y 平均间距，做一次轴向邻孔存在性筛选。
    #    左右至少一侧存在约 1x avg-X 邻孔，且上下至少一侧存在约 1x avg-Y 邻孔。
    #    本轮所有邻接关系先冻结，再同时删除；不递归、不重算。
    axis_ref_avg_x = finite_float(spacing_qc_meta.get("via_adjacent_spacing_average_x_px", math.nan))
    axis_ref_avg_y = finite_float(spacing_qc_meta.get("via_adjacent_spacing_average_y_px", math.nan))
    accepted, axis_neighbor_qc_by_id, axis_neighbor_qc_meta = filter_vias_without_axis_neighbors_once(
        accepted,
        axis_ref_avg_x,
        axis_ref_avg_y,
        cfg,
    )
    pre_qc_after_axis_count = len(accepted)

    # 记录哪些对象是真正通过“点阵恢复前清洗”的 seed。后面新增的 relaxed/recovered Via
    # 不再重新接受 B/C 两轮删除，从而严格满足“先删一次，再预测一次”的流程要求。
    pre_recovery_seed_ids = {id(m) for m in accepted}
    pre_recovery_qc_meta: dict[str, Any] = {
        "via_pre_recovery_qc_stage_used": bool(strict_initial_count > 0),
        "via_strict_initial_count": int(strict_initial_count),
        "via_pre_recovery_after_offgrid_count": int(pre_qc_after_offgrid_count),
        "via_pre_recovery_after_spacing_count": int(pre_qc_after_spacing_count),
        "via_pre_recovery_after_axis_neighbor_count": int(pre_qc_after_axis_count),
        "via_pre_recovery_removed_total": int(max(0, strict_initial_count - pre_qc_after_axis_count)),
        "via_grid_relaxation_seed_count": int(pre_qc_after_axis_count),
        "via_zero_result_fallback_eligible": bool(strict_initial_empty),
        "via_qc_order": (
            "STRICT->OFFGRID_SMOOTH_QC->TOO_CLOSE_QC_ONCE->AXIS_NEIGHBOR_QC_ONCE"
            "->GRID_RELAXED_CANDIDATE->GRID_PREDICTED_RECOVERY"
        ),
    }

    # ========================================================
    # 只有完成上述前置删除之后，才允许点阵预判和放宽要求。
    # ========================================================
    pitch, u, v = estimate_pitch_and_axes(np.array([m.center for m in accepted]), D, cfg)

    # 对“清洗后的严格阵列”中的弱候选做规则位置放宽。
    if len(accepted) >= cfg.grid_min_seed_count and np.isfinite(pitch):
        relaxed_extra: list[ViaMeasured] = []
        for c in candidates:
            if any(np.linalg.norm(c.center - m.center) <= 0.45 * D for m in accepted):
                continue
            support = grid_support_count(c.center, accepted, pitch, u, v, cfg)
            if support < cfg.grid_min_prediction_votes:
                continue
            m = evaluate_via_candidate(gray, score, raw, c, D, pitch, raw_floor, cfg, relaxed=True)
            if m is not None:
                m.selection_mode = "GRID_RELAXED_CANDIDATE"
                m.confidence_flag = "RELAXED_REVIEW"
                m.grid_support = support
                relaxed_extra.append(m)
        accepted = dedup_measured_vias(accepted + relaxed_extra, D)

    # 再由“已经清洗后的点阵”向缺失位置预测；必须至少两个邻居投票。
    if cfg.enable_grid_recovery and len(accepted) >= cfg.grid_min_seed_count:
        for _round in range(cfg.grid_recovery_rounds):
            pitch, u, v = estimate_pitch_and_axes(np.array([m.center for m in accepted]), D, cfg)
            if not np.isfinite(pitch):
                break
            recovered: list[ViaMeasured] = []
            for pred, votes in predicted_grid_sites(accepted, pitch, u, v, D, gray.shape, cfg):
                center, sc, rw = refine_via_center(gray, score, raw, pred, D, pitch, cfg)
                if sc < cfg.relaxed_peak_score_min or rw < cfg.relaxed_raw_floor_factor * raw_floor:
                    continue
                c = ViaCandidate(center, sc, rw, D, "grid_predicted_site")
                m = evaluate_via_candidate(gray, score, raw, c, D, pitch, raw_floor, cfg, relaxed=True)
                if m is not None:
                    m.selection_mode = "GRID_PREDICTED_RECOVERY"
                    m.confidence_flag = "RELAXED_REVIEW"
                    m.grid_support = votes
                    recovered.append(m)
            before = len(accepted)
            accepted = dedup_measured_vias(accepted + recovered, D)
            if len(accepted) == before:
                break

    # V25 风格 zero-result fallback 只允许用于“初始严格结果本来就是 0”的情况。
    # 如果严格模式曾经找到 Via，但它们被 V1.6 前置清洗全部删除，绝不通过全图放宽重新捞回。
    fallback_used = False
    if strict_initial_empty and not accepted:
        fallback_used = True
        relaxed_all: list[ViaMeasured] = []
        for c in candidates:
            m = evaluate_via_candidate(gray, score, raw, c, D, math.nan, raw_floor, cfg, relaxed=True)
            if m is not None:
                m.selection_mode = "ZERO_RESULT_FALLBACK"
                m.confidence_flag = "RELAXED_FALLBACK_REVIEW"
                relaxed_all.append(m)
        accepted = dedup_measured_vias(relaxed_all, D)

    # 预测/放宽结束后只重新估计最终点阵参数、邻居支持和编号；
    # 不再次执行过近筛选或轴向邻孔筛选，避免递归/二次删除。
    pitch, u, v = estimate_pitch_and_axes(np.array([m.center for m in accepted]), D, cfg)
    for m in accepted:
        m.grid_support = max(
            m.grid_support,
            grid_support_count(m.center, [x for x in accepted if x is not m], pitch, u, v, cfg),
        )
    accepted = sort_vias_spatially(accepted, pitch, u, v)

    rows: list[dict[str, Any]] = []
    for i, m in enumerate(accepted, start=1):
        met = m.metrics
        edge = m.edge_meta
        grid_qc = grid_qc_by_id.get(id(m), {})
        spacing_qc = spacing_qc_by_id.get(id(m), {})
        axis_qc = axis_neighbor_qc_by_id.get(id(m), {})
        was_pre_recovery_seed = id(m) in pre_recovery_seed_ids
        eq_nm = met["equivalent_diameter_px"] * px_nm
        major_nm = met["ellipse_major_px"] * px_nm
        minor_nm = met["ellipse_minor_px"] * px_nm
        x_nm = met["x_span_px"] * px_nm
        y_nm = met["y_span_px"] * px_nm
        rows.append({
            "folder_name": parsed.folder_name,
            "folder_nominal_nm": parsed.folder_nominal_nm,
            "pretreatment_nm": parsed.pretreatment_nm,
            "dose_mj": parsed.dose_mj,
            "sample_id": parsed.sample_id,
            "metadata_source": parsed.metadata_source,
            "auto_pattern_score": parsed.auto_pattern_score,
            "auto_gradient_x_to_y_ratio": parsed.auto_gradient_x_to_y_ratio,
            "image": parsed.path.name,
            "path": str(parsed.path),
            "pattern": "via",
            "magnification": general.magnification_token,
            "pixel_size_nm": px_nm,
            "design_cd_nm": design_nm,
            "via_id": i,
            "center_x_px": float(m.center[0]),
            "center_y_px": float(m.center[1]),
            "diameter_nm": eq_nm,
            "diameter_px": met["equivalent_diameter_px"],
            "diameter_bias_nm": eq_nm - design_nm,
            "diameter_bias_pct": safe_pct_bias(eq_nm, design_nm),
            "x_span_nm": x_nm,
            "y_span_nm": y_nm,
            "ellipse_major_nm": major_nm,
            "ellipse_minor_nm": minor_nm,
            "ellipse_mean_diameter_nm": 0.5 * (major_nm + minor_nm),
            "area_px2": met["area_px2"],
            "area_nm2": met["area_px2"] * px_nm * px_nm,
            "perimeter_px": met["perimeter_px"],
            "circularity_4piA_P2": met["circularity"],
            "axis_roundness_minor_over_major": met["axis_roundness"],
            "axis_ratio_major_over_minor": met["axis_ratio"],
            "solidity": met["solidity"],
            "ellipse_iou": met["ellipse_iou"],
            "radial_cv": met["radial_cv"],
            "edge_highfreq_roughness_rms_px": met["edge_highfreq_roughness_rms_px"],
            "edge_highfreq_roughness_cv": met["edge_highfreq_roughness_cv"],
            "scale_match_score": m.candidate.score,
            "raw_annulus_inner_contrast_gray": m.candidate.raw_contrast,
            "detected_scale_diameter_px": m.candidate.detect_diameter_px,
            "good_ray_fraction": edge.get("good_ray_fraction", math.nan),
            "core_contrast_gray": edge.get("core_contrast_gray", math.nan),
            "shoulder_contrast_gray": edge.get("shoulder_contrast_gray", math.nan),
            "shoulder_dark_fraction": edge.get("shoulder_dark_fraction", math.nan),
            "outer_dark_leak_fraction": edge.get("outer_dark_leak_fraction", math.nan),
            "component_used": edge.get("component_used", math.nan),
            "estimated_pitch_px": pitch,
            "grid_support_neighbors": m.grid_support,
            "grid_model_used": grid_qc.get("grid_model_used", False),
            "grid_on_square_lattice": grid_qc.get("grid_on_square_lattice", math.nan),
            "grid_residual_px": grid_qc.get("grid_residual_px", math.nan),
            "grid_residual_pitch_fraction": grid_qc.get("grid_residual_pitch_fraction", math.nan),
            "grid_axis_u_residual_px": grid_qc.get("grid_axis_u_residual_px", math.nan),
            "grid_axis_v_residual_px": grid_qc.get("grid_axis_v_residual_px", math.nan),
            "offgrid_smooth_shape": grid_qc.get("offgrid_smooth_shape", False),
            "pre_adjacent_spacing_qc_order": spacing_qc.get("pre_adjacent_spacing_qc_order", math.nan),
            "adjacent_spacing_qc_used": spacing_qc.get("adjacent_spacing_qc_used", False),
            "adjacent_spacing_average_x_px": spacing_qc.get("adjacent_spacing_average_x_px", math.nan),
            "adjacent_spacing_average_y_px": spacing_qc.get("adjacent_spacing_average_y_px", math.nan),
            "adjacent_spacing_average_x_nm": finite_float(spacing_qc.get("adjacent_spacing_average_x_px", math.nan)) * px_nm,
            "adjacent_spacing_average_y_nm": finite_float(spacing_qc.get("adjacent_spacing_average_y_px", math.nan)) * px_nm,
            "adjacent_spacing_actual_neighbor_count": spacing_qc.get("adjacent_spacing_actual_neighbor_count", 0),
            "adjacent_spacing_min_pair_ratio": spacing_qc.get("adjacent_spacing_min_pair_ratio", math.nan),
            "adjacent_spacing_min_pair_axis": spacing_qc.get("adjacent_spacing_min_pair_axis", ""),
            "adjacent_spacing_min_pair_delta_x_px": spacing_qc.get("adjacent_spacing_min_pair_delta_x_px", math.nan),
            "adjacent_spacing_min_pair_delta_y_px": spacing_qc.get("adjacent_spacing_min_pair_delta_y_px", math.nan),
            "adjacent_spacing_too_close_pair_count": spacing_qc.get("adjacent_spacing_too_close_pair_count", 0),
            "pre_axis_neighbor_qc_order": axis_qc.get("pre_axis_neighbor_qc_order", math.nan),
            "axis_neighbor_qc_used": axis_qc.get("axis_neighbor_qc_used", False),
            "axis_neighbor_has_left": axis_qc.get("axis_neighbor_has_left", False),
            "axis_neighbor_has_right": axis_qc.get("axis_neighbor_has_right", False),
            "axis_neighbor_has_up": axis_qc.get("axis_neighbor_has_up", False),
            "axis_neighbor_has_down": axis_qc.get("axis_neighbor_has_down", False),
            "axis_neighbor_has_horizontal": axis_qc.get("axis_neighbor_has_horizontal", False),
            "axis_neighbor_has_vertical": axis_qc.get("axis_neighbor_has_vertical", False),
            "axis_neighbor_horizontal_count": axis_qc.get("axis_neighbor_horizontal_count", 0),
            "axis_neighbor_vertical_count": axis_qc.get("axis_neighbor_vertical_count", 0),
            "pre_recovery_clean_seed": bool(was_pre_recovery_seed),
            "added_after_pre_recovery_qc": bool(not was_pre_recovery_seed),
            "selection_source": m.candidate.source,
            "selection_mode": m.selection_mode,
            "confidence_flag": m.confidence_flag,
            "used_for_statistics": True,
        })

    annotated = annotate_vias(gray, accepted, rows, design_nm, fallback_used)
    debug = {
        "via_scale_score": np.clip(score * 255.0, 0, 255).astype(np.uint8),
        "via_raw_response": np.clip(robust_normalize_01(raw, 1, 99.5) * 255.0, 0, 255).astype(np.uint8),
    }
    summary_meta = dict(response_meta)
    summary_meta.update(pre_recovery_qc_meta)
    summary_meta.update(grid_qc_meta)
    spacing_qc_meta = dict(spacing_qc_meta)
    spacing_qc_meta["via_adjacent_spacing_average_x_nm"] = (
        finite_float(spacing_qc_meta.get("via_adjacent_spacing_average_x_px", math.nan)) * px_nm
    )
    spacing_qc_meta["via_adjacent_spacing_average_y_nm"] = (
        finite_float(spacing_qc_meta.get("via_adjacent_spacing_average_y_px", math.nan)) * px_nm
    )
    summary_meta.update(spacing_qc_meta)
    axis_neighbor_qc_meta = dict(axis_neighbor_qc_meta)
    axis_neighbor_qc_meta["via_axis_neighbor_average_x_nm"] = (
        finite_float(axis_neighbor_qc_meta.get("via_axis_neighbor_average_x_px", math.nan)) * px_nm
    )
    axis_neighbor_qc_meta["via_axis_neighbor_average_y_nm"] = (
        finite_float(axis_neighbor_qc_meta.get("via_axis_neighbor_average_y_px", math.nan)) * px_nm
    )
    summary_meta.update(axis_neighbor_qc_meta)
    summary = summarize_via_image(parsed, rows, len(candidates), fallback_used, pitch, summary_meta, gray.shape)
    return rows, summary, annotated, debug


def annotate_vias(
    gray: np.ndarray,
    accepted: Sequence[ViaMeasured],
    rows: Sequence[dict[str, Any]],
    design_nm: float,
    fallback_used: bool,
) -> np.ndarray:
    out = to_color(gray)
    value_color = (255, 0, 255)  # BGR：紫红色，用于每个对象的实测 CD。
    for m, row in zip(accepted, rows):
        relaxed = row["confidence_flag"] != "NORMAL"
        color = (0, 215, 255) if relaxed else (0, 220, 0)
        cv2.drawContours(out, [m.contour.astype(np.int32)], -1, color, 2)
        c = tuple(np.round(m.center).astype(int))
        cv2.circle(out, c, 2, color, -1)
        # 图案编号沿用原字体大小和置信度颜色。
        label = f"V{row['via_id']}"
        text_size, _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.32, 1)
        x = int(np.clip(c[0] - text_size[0] / 2, 2, max(2, out.shape[1] - text_size[0] - 2)))
        y = int(np.clip(c[1] + text_size[1] / 2, 13, out.shape[0] - 3))
        put_text_with_outline(out, label, (x, y), 0.32, color, 1)

        # 每个成功 Via 的实测 CD；字号与 V 编号相同，颜色不同。
        # Unit is nm; keep the per-object label compact enough for dense arrays.
        value = f"CD{row['diameter_nm']:.1f}"
        value_size, _ = cv2.getTextSize(value, cv2.FONT_HERSHEY_SIMPLEX, 0.32, 1)
        radius_px = 0.5 * max(float(row["x_span_nm"]), float(row["y_span_nm"])) / max(float(row["pixel_size_nm"]), EPS)
        vx = int(np.clip(c[0] - value_size[0] / 2, 2, max(2, out.shape[1] - value_size[0] - 2)))
        vy_below = int(round(c[1] + radius_px + value_size[1] + 3))
        vy_above = int(round(c[1] - radius_px - 4))
        vy = vy_below if vy_below < out.shape[0] - 3 else max(12, vy_above)
        put_text_with_outline(out, value, (vx, vy), 0.32, value_color, 1)

    mean_d = safe_mean(row["diameter_nm"] for row in rows)
    mean_c = safe_mean(row["circularity_4piA_P2"] for row in rows)
    banner = f"VIA used={len(rows)} design={design_nm:.1f}nm mean={mean_d:.2f}nm circ={mean_c:.3f}"
    if fallback_used:
        banner += "  AUTO FALLBACK REVIEW"
    cv2.rectangle(out, (3, 3), (min(out.shape[1] - 4, 760), 29), (0, 0, 0), -1)
    cv2.putText(out, banner, (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.47, (255, 255, 255), 1, cv2.LINE_AA)
    return out


def summarize_via_image(
    parsed: ParsedImage,
    rows: Sequence[dict[str, Any]],
    candidate_count: int,
    fallback_used: bool,
    pitch_px: float,
    response_meta: dict[str, float],
    image_shape: tuple[int, int],
) -> dict[str, Any]:
    diameters = [r["diameter_nm"] for r in rows]
    mean_d = safe_mean(diameters)
    return {
        "folder_name": parsed.folder_name,
        "folder_nominal_nm": parsed.folder_nominal_nm,
        "pretreatment_nm": parsed.pretreatment_nm,
        "dose_mj": parsed.dose_mj,
        "sample_id": parsed.sample_id,
        "metadata_source": parsed.metadata_source,
        "auto_pattern_score": parsed.auto_pattern_score,
        "auto_gradient_x_to_y_ratio": parsed.auto_gradient_x_to_y_ratio,
        "image": parsed.path.name,
        "path": str(parsed.path),
        "pattern": "via",
        "status": "OK" if rows else "NO_VALID_OBJECT",
        "image_height_px": image_shape[0],
        "image_width_px": image_shape[1],
        "design_via_nm": parsed.design_via_nm,
        "design_trench_nm": math.nan,
        "design_space_nm": math.nan,
        "via_count": len(rows),
        "via_candidate_count": candidate_count,
        "via_mean_nm": mean_d,
        "via_median_nm": float(np.median(diameters)) if diameters else math.nan,
        "via_between_object_std_nm": safe_std(diameters),
        "via_min_nm": float(np.min(diameters)) if diameters else math.nan,
        "via_max_nm": float(np.max(diameters)) if diameters else math.nan,
        "via_bias_nm": mean_d - parsed.design_via_nm if np.isfinite(mean_d) else math.nan,
        "via_bias_pct": safe_pct_bias(mean_d, parsed.design_via_nm),
        "via_mean_circularity": safe_mean(r["circularity_4piA_P2"] for r in rows),
        "via_mean_axis_roundness": safe_mean(r["axis_roundness_minor_over_major"] for r in rows),
        "via_mean_solidity": safe_mean(r["solidity"] for r in rows),
        "via_relaxed_count": int(sum(r["confidence_flag"] != "NORMAL" for r in rows)),
        "via_zero_result_fallback_used": fallback_used,
        "estimated_pitch_px": pitch_px,
        "trench_count": 0,
        "space_count": 0,
        "trench_mean_nm": math.nan,
        "trench_bias_nm": math.nan,
        "trench_bias_pct": math.nan,
        "space_mean_nm": math.nan,
        "space_bias_nm": math.nan,
        "space_bias_pct": math.nan,
        **response_meta,
    }


# ============================================================
# 4. Trench：全部暗条逐行测量 + 相邻亮 space
# ============================================================
def safe_segment_mean(profile: np.ndarray, start: float, end: float) -> float:
    n = len(profile)
    s = max(0, min(n, int(math.floor(start))))
    e = max(0, min(n, int(math.ceil(end))))
    if e <= s:
        return math.nan
    return float(np.mean(profile[s:e]))


def threshold_crossing_left(profile: np.ndarray, threshold: float, peak_x: int, center_x: float) -> Optional[float]:
    """Return the bright-to-dark 50% crossing nearest the left gradient peak.

    The discrete central-difference maximum can fall one pixel to either side of
    the actual threshold crossing.  Searching only from the peak toward the dark
    trench therefore loses otherwise valid rows.  Search the whole physically
    valid left half and select the crossing nearest the detected peak instead.
    """
    stop = min(len(profile) - 1, int(math.ceil(center_x)))
    crossings: list[float] = []
    for x in range(0, stop):
        p0 = float(profile[x]); p1 = float(profile[x + 1])
        if p0 >= threshold and p1 < threshold:
            denom = p1 - p0
            if abs(denom) > EPS:
                crossings.append(float(x + (threshold - p0) / denom))
    if not crossings:
        return None
    return min(crossings, key=lambda z: abs(z - float(peak_x)))


def threshold_crossing_right(profile: np.ndarray, threshold: float, peak_x: int, center_x: float) -> Optional[float]:
    """Return the dark-to-bright 50% crossing nearest the right gradient peak."""
    start = max(0, int(math.floor(center_x)))
    crossings: list[float] = []
    for x in range(start, len(profile) - 1):
        p0 = float(profile[x]); p1 = float(profile[x + 1])
        if p0 < threshold and p1 >= threshold:
            denom = p1 - p0
            if abs(denom) > EPS:
                crossings.append(float(x + (threshold - p0) / denom))
    if not crossings:
        return None
    return min(crossings, key=lambda z: abs(z - float(peak_x)))


def detect_dark_band_edges(
    profile: np.ndarray,
    center_x: float,
    expected_width_px: float,
    cfg: TrenchConfig,
    anchor_left: Optional[float] = None,
    anchor_right: Optional[float] = None,
    search_radius_px: Optional[float] = None,
    strict_tracking: bool = False,
) -> DarkBandEdge:
    p = moving_average_reflect(profile, cfg.smoothing_px)
    n = len(p)
    W = max(4.0, expected_width_px)
    pred_left = float(anchor_left) if anchor_left is not None and np.isfinite(anchor_left) else center_x - 0.5 * W
    pred_right = float(anchor_right) if anchor_right is not None and np.isfinite(anchor_right) else center_x + 0.5 * W
    if pred_right <= pred_left:
        return DarkBandEdge(False, "invalid_anchors")
    radius = search_radius_px if search_radius_px is not None else max(4.0, cfg.candidate_search_radius_width_factor * W)
    grad = central_difference(p)

    def choose_peak(anchor: float, side: str) -> Optional[int]:
        s = max(1, int(math.floor(anchor - radius)))
        e = min(n - 1, int(math.ceil(anchor + radius + 1)))
        if e - s < 3:
            return None
        idx = np.arange(s, e)
        if side == "left":
            sign_strength = -grad[idx]
            direction_ok = idx < center_x
        else:
            sign_strength = grad[idx]
            direction_ok = idx > center_x
        valid = direction_ok & (sign_strength > 0)
        if not np.any(valid):
            return None
        candidates = idx[valid]
        strengths = sign_strength[valid]
        # 先筛掉明显弱梯度，再综合锚点距离和拓扑。
        baseline = float(np.median(np.abs(grad[s:e])))
        mad = robust_mad(np.abs(grad[s:e]))
        min_strength = max(1e-6, baseline + 0.6 * mad)
        scored: list[tuple[float, int]] = []
        band = max(2, int(round(0.16 * W)))
        gap = 1
        for q, strength in zip(candidates, strengths):
            if strength < min_strength:
                continue
            if side == "left":
                outside = safe_segment_mean(p, q - gap - band, q - gap)
                inside = safe_segment_mean(p, q + gap, q + gap + band)
            else:
                inside = safe_segment_mean(p, q - gap - band, q - gap)
                outside = safe_segment_mean(p, q + gap, q + gap + band)
            contrast = outside - inside
            if not np.isfinite(contrast) or contrast < 0.55 * cfg.candidate_min_contrast_gray:
                continue
            proximity = math.exp(-abs(float(q) - anchor) / max(radius, 1.0))
            scored.append((float(strength + 0.35 * contrast + 0.25 * min_strength * proximity), int(q)))
        if not scored:
            return None
        scored.sort(reverse=True)
        # 多个峰强度相近时，优先靠近预期锚点。
        top_strength = scored[0][0]
        near_top = [q for sc, q in scored if sc >= 0.80 * top_strength]
        return min(near_top, key=lambda q: abs(float(q) - anchor))

    left_peak = choose_peak(pred_left, "left")
    right_peak = choose_peak(pred_right, "right")
    if left_peak is None or right_peak is None:
        return DarkBandEdge(False, "edge_peak_missing")

    dark_start = pred_left + 0.28 * (pred_right - pred_left)
    dark_end = pred_right - 0.28 * (pred_right - pred_left)
    dark = safe_segment_mean(p, dark_start, dark_end)
    band = max(3, int(round(0.18 * W)))
    left_bright = safe_segment_mean(p, left_peak - band, left_peak - 1)
    right_bright = safe_segment_mean(p, right_peak + 1, right_peak + band)
    if not all(np.isfinite(v) for v in (dark, left_bright, right_bright)):
        return DarkBandEdge(False, "invalid_intensity_levels")
    contrast_left = left_bright - dark
    contrast_right = right_bright - dark
    if min(contrast_left, contrast_right) < cfg.candidate_min_contrast_gray:
        return DarkBandEdge(False, "insufficient_bright_dark_contrast")

    left_thr = dark + cfg.threshold_fraction * contrast_left
    right_thr = dark + cfg.threshold_fraction * contrast_right
    left = threshold_crossing_left(p, left_thr, left_peak, center_x)
    right = threshold_crossing_right(p, right_thr, right_peak, center_x)
    if left is None or right is None or right <= left:
        return DarkBandEdge(False, "threshold_crossing_missing")
    width = float(right - left)
    if not (cfg.candidate_min_width_factor * W <= width <= cfg.candidate_max_width_factor * W):
        return DarkBandEdge(False, "width_outside_hard_range")
    mid = 0.5 * (left + right)
    if not (left < center_x < right) and abs(mid - center_x) > 0.35 * W:
        return DarkBandEdge(False, "candidate_center_not_inside_band")

    if strict_tracking:
        anchor_width = pred_right - pred_left
        max_jump = max(2.0, cfg.tracking_max_jump_width_factor * W)
        if abs(left - pred_left) > max_jump or abs(right - pred_right) > max_jump:
            return DarkBandEdge(False, "tracking_edge_jump")
        if abs(width - anchor_width) > cfg.tracking_max_width_change_fraction * max(W, anchor_width):
            return DarkBandEdge(False, "tracking_width_jump")

    return DarkBandEdge(
        True,
        "",
        left_x=float(left),
        right_x=float(right),
        width_px=width,
        center_x=float(mid),
        left_peak_x=float(left_peak),
        right_peak_x=float(right_peak),
        contrast_left=float(contrast_left),
        contrast_right=float(contrast_right),
        dark_level=float(dark),
    )


def fit_1d_lattice(
    centers: Sequence[float],
    scores: Sequence[float],
    expected_pitch_px: float,
    cfg: TrenchConfig,
) -> dict[str, Any]:
    x = np.asarray(centers, dtype=float)
    q = np.asarray(scores, dtype=float)
    if len(x) < cfg.lattice_min_support:
        return {"used": False, "pitch_px": expected_pitch_px, "origin_px": math.nan, "supported": np.ones(len(x), dtype=bool)}

    pitch_candidates: list[float] = [expected_pitch_px * f for f in np.linspace(cfg.lattice_pitch_min_factor, cfg.lattice_pitch_max_factor, 13)]
    for i in range(len(x)):
        for j in range(i + 1, len(x)):
            d = abs(float(x[j] - x[i]))
            for k in range(1, 6):
                p = d / k
                if cfg.lattice_pitch_min_factor * expected_pitch_px <= p <= cfg.lattice_pitch_max_factor * expected_pitch_px:
                    pitch_candidates.append(p)

    best: Optional[dict[str, Any]] = None
    for p in pitch_candidates:
        tol = cfg.lattice_residual_pitch_fraction * p
        for origin in x:
            idx = np.rint((x - origin) / p)
            pred = origin + idx * p
            residual = np.abs(x - pred)
            supported = residual <= tol
            count = int(np.count_nonzero(supported))
            if count == 0:
                continue
            quality = float(np.sum(q[supported]))
            mean_res = float(np.mean(residual[supported]))
            objective = count + 0.25 * quality - 0.35 * mean_res / max(tol, EPS) - 0.10 * abs(p / expected_pitch_px - 1.0)
            if best is None or objective > best["objective"]:
                best = {
                    "used": count >= cfg.lattice_min_support,
                    "pitch_px": float(p),
                    "origin_px": float(origin),
                    "indices": idx.astype(int),
                    "residual_px": residual,
                    "supported": supported,
                    "support_count": count,
                    "objective": objective,
                }
    if best is None:
        return {"used": False, "pitch_px": expected_pitch_px, "origin_px": math.nan, "supported": np.ones(len(x), dtype=bool)}
    return best


def detect_trench_candidates(
    gray: np.ndarray,
    expected_width_px: float,
    expected_space_px: float,
    cfg: TrenchConfig,
) -> tuple[list[TrenchCandidate], dict[str, Any], np.ndarray]:
    H, Wimg = gray.shape
    y0 = int(round(cfg.global_y_margin_fraction * H))
    y1 = int(round((1.0 - cfg.global_y_margin_fraction) * H))
    if y1 - y0 < max(10, cfg.average_rows_px):
        y0, y1 = 0, H
    raw_profile = gray[y0:y1, :].mean(axis=0)
    profile = moving_average_reflect(raw_profile, cfg.smoothing_px)
    pitch_expected = expected_width_px + expected_space_px
    basin_window = max(3, int(round(cfg.basin_window_width_factor * expected_width_px)))
    if basin_window % 2 == 0:
        basin_window += 1
    basin = moving_average_reflect(profile, basin_window)
    diff_mad = robust_mad(np.diff(basin))
    prominence = max(cfg.valley_min_prominence_gray, 0.75 * diff_mad)
    min_distance = max(3, int(round(cfg.valley_min_distance_pitch_factor * pitch_expected)))
    valleys, _ = find_peaks(-basin, distance=min_distance, prominence=prominence)

    proposed: list[tuple[float, str]] = [(float(v), "global_valley") for v in valleys]
    # 重叠窗口暗点作为召回补充。
    block = max(8, int(round(0.80 * pitch_expected)))
    step = max(4, block // 2)
    for start in range(0, Wimg, step):
        end = min(Wimg, start + block)
        if end - start >= 3:
            proposed.append((float(start + int(np.argmin(basin[start:end]))), "block_dark_minimum"))

    proposed.sort(key=lambda z: float(basin[int(np.clip(round(z[0]), 0, Wimg - 1))]))
    seed_tol = max(3.0, cfg.candidate_center_dedup_width_factor * expected_width_px)
    seeds: list[tuple[float, str]] = []
    for c, src in proposed:
        if c < 0.45 * expected_width_px or c > Wimg - 1 - 0.45 * expected_width_px:
            continue
        if any(abs(c - old[0]) < seed_tol for old in seeds):
            continue
        seeds.append((c, src))

    candidates: list[TrenchCandidate] = []
    for seed, src in seeds:
        edge = detect_dark_band_edges(profile, seed, expected_width_px, cfg)
        if not edge.valid:
            continue
        edge2 = detect_dark_band_edges(
            profile,
            edge.center_x,
            expected_width_px,
            cfg,
            anchor_left=edge.left_x,
            anchor_right=edge.right_x,
            search_radius_px=max(4.0, 0.45 * expected_width_px),
        )
        if edge2.valid:
            edge = edge2
        width_score = math.exp(-abs(edge.width_px - expected_width_px) / max(expected_width_px, EPS))
        contrast = min(edge.contrast_left, edge.contrast_right)
        dynamic = max(1.0, float(np.percentile(profile, 95) - np.percentile(profile, 5)))
        contrast_score = float(np.clip(contrast / dynamic, 0.0, 1.0))
        darkness = 1.0 - float(np.clip((edge.dark_level - np.percentile(profile, 5)) / dynamic, 0.0, 1.0))
        score = 0.40 * width_score + 0.35 * contrast_score + 0.25 * darkness
        basin_mean = safe_segment_mean(profile, edge.left_x + 0.15 * edge.width_px, edge.right_x - 0.15 * edge.width_px)
        candidates.append(TrenchCandidate(
            center_x=edge.center_x,
            global_left_x=edge.left_x,
            global_right_x=edge.right_x,
            global_width_px=edge.width_px,
            basin_mean=basin_mean,
            contrast=contrast,
            score=float(score),
            source=src,
        ))

    # 以实测中心再次去重。
    candidates.sort(key=lambda c: (c.score, c.contrast, -c.basin_mean), reverse=True)
    unique: list[TrenchCandidate] = []
    for c in candidates:
        if any(abs(c.center_x - old.center_x) < seed_tol for old in unique):
            continue
        unique.append(c)
    unique.sort(key=lambda c: c.center_x)

    lattice = fit_1d_lattice(
        [c.center_x for c in unique],
        [c.score for c in unique],
        pitch_expected,
        cfg,
    )
    if lattice.get("used", False):
        support = np.asarray(lattice["supported"], dtype=bool)
        filtered = [c for c, ok in zip(unique, support) if ok]
        # 规则位置之间缺失的 trench 直接在全局 profile 上补测。
        if filtered:
            p = float(lattice["pitch_px"])
            origin = float(lattice["origin_px"])
            idx_existing = [int(round((c.center_x - origin) / p)) for c in filtered]
            imin = int(math.ceil((0.5 * expected_width_px - origin) / p))
            imax = int(math.floor((Wimg - 1 - 0.5 * expected_width_px - origin) / p))
            recovered: list[TrenchCandidate] = []
            for idx in range(imin, imax + 1):
                pred = origin + idx * p
                if any(abs(pred - c.center_x) <= 0.45 * expected_width_px for c in filtered):
                    continue
                edge = detect_dark_band_edges(
                    profile,
                    pred,
                    expected_width_px,
                    cfg,
                    anchor_left=pred - 0.5 * expected_width_px,
                    anchor_right=pred + 0.5 * expected_width_px,
                    search_radius_px=max(4.0, cfg.lattice_recovery_margin_width_factor * expected_width_px),
                )
                if not edge.valid:
                    continue
                contrast = min(edge.contrast_left, edge.contrast_right)
                if contrast < 0.80 * cfg.candidate_min_contrast_gray:
                    continue
                recovered.append(TrenchCandidate(
                    center_x=edge.center_x,
                    global_left_x=edge.left_x,
                    global_right_x=edge.right_x,
                    global_width_px=edge.width_px,
                    basin_mean=safe_segment_mean(profile, edge.left_x + 0.15 * edge.width_px, edge.right_x - 0.15 * edge.width_px),
                    contrast=contrast,
                    score=0.5,
                    source="lattice_recovery",
                    lattice_index=idx,
                ))
            filtered.extend(recovered)
            unique = filtered
            for c in unique:
                if c.lattice_index is None:
                    c.lattice_index = int(round((c.center_x - origin) / p))
            unique.sort(key=lambda c: c.center_x)

    # 亮度和宽度的鲁棒最终筛选，避免亮 line 中的小暗斑。
    if unique:
        widths = np.array([c.global_width_px for c in unique], dtype=float)
        basins = np.array([c.basin_mean for c in unique], dtype=float)
        contrasts = np.array([c.contrast for c in unique], dtype=float)
        med_w = float(np.median(widths))
        med_b = float(np.median(basins))
        med_c = float(np.median(contrasts))
        w_tol = max(0.45 * expected_width_px, 5.0 * 1.4826 * robust_mad(widths))
        b_tol = max(8.0, 5.0 * 1.4826 * robust_mad(basins))
        final = []
        for c in unique:
            if abs(c.global_width_px - med_w) > w_tol:
                continue
            if c.basin_mean > med_b + b_tol:
                continue
            if c.contrast < max(0.65 * cfg.candidate_min_contrast_gray, 0.35 * med_c):
                continue
            final.append(c)
        unique = final

    meta = {
        "global_profile_y0": y0,
        "global_profile_y1": y1,
        "candidate_seed_count": len(seeds),
        "candidate_final_count": len(unique),
        "candidate_prominence": prominence,
        "candidate_basin_window_px": basin_window,
        "expected_pitch_px": pitch_expected,
        "lattice_used": bool(lattice.get("used", False)),
        "lattice_pitch_px": finite_float(lattice.get("pitch_px")),
        "lattice_support_count": int(lattice.get("support_count", 0)),
    }
    return unique, meta, profile


def sample_row_profile(gray: np.ndarray, y: float, average_rows: int) -> tuple[Optional[np.ndarray], int, int]:
    H = gray.shape[0]
    half = max(0, average_rows // 2)
    y0 = max(0, int(round(y)) - half)
    y1 = min(H, y0 + max(1, average_rows))
    if y1 <= y0:
        return None, y0, y1
    return gray[y0:y1, :].mean(axis=0), y0, y1


def nearest_valid_anchor(
    idx: int,
    y_values: np.ndarray,
    left: np.ndarray,
    right: np.ndarray,
    candidate: TrenchCandidate,
) -> tuple[float, float]:
    valid = np.flatnonzero(np.isfinite(left) & np.isfinite(right))
    if len(valid):
        j = int(valid[np.argmin(np.abs(y_values[valid] - y_values[idx]))])
        return float(left[j]), float(right[j])
    return candidate.global_left_x, candidate.global_right_x


def longest_true_run(mask: np.ndarray) -> tuple[int, int, int]:
    """Return ``(length, start, end_exclusive)`` for the longest True run."""
    values = np.asarray(mask, dtype=bool)
    best_len = best_start = best_end = 0
    start: Optional[int] = None
    for i, value in enumerate(values):
        if value and start is None:
            start = i
        if (not value or i == len(values) - 1) and start is not None:
            end = i + 1 if value and i == len(values) - 1 else i
            length = end - start
            if length > best_len:
                best_len, best_start, best_end = length, start, end
            start = None
    return int(best_len), int(best_start), int(best_end)


def trench_track_quality_metrics(
    gray: np.ndarray,
    y_values: np.ndarray,
    left: np.ndarray,
    right: np.ndarray,
    valid: np.ndarray,
    expected_width_px: float,
    expected_space_px: float,
    candidate_global_contrast: float,
    cfg: TrenchConfig,
) -> dict[str, Any]:
    """Calculate V1.2 hard-QC metrics after edge tracking.

    The three rejection rules are deliberately evaluated after robust edge
    tracking, so a single obvious fly point does not condemn a whole trench:

    1. a border-adjacent trench must retain visible bright material on both
       sides of the dark band;
    2. max(valid width) / min(valid width) must be smaller than the configured
       limit (2.0 by default);
    3. a contiguous Y-section whose trench contrast collapses to the local
       space level, while another section remains genuinely dark, is rejected.
    """
    _H, image_width = gray.shape
    valid_idx = np.flatnonzero(valid)
    widths = right - left
    valid_widths = widths[valid_idx]
    min_width_px = float(np.min(valid_widths)) if len(valid_widths) else math.nan
    max_width_px = float(np.max(valid_widths)) if len(valid_widths) else math.nan
    max_min_ratio = (
        max_width_px / max(min_width_px, EPS)
        if np.isfinite(min_width_px) and np.isfinite(max_width_px)
        else math.nan
    )

    # Width of the local bright reference band on each side.  It is capped by
    # both design-space and trench-width priors so it does not cross into the
    # next structure on dense patterns.
    side_band = max(
        2.0,
        min(
            cfg.edge_bright_band_space_factor * max(expected_space_px, 1.0),
            cfg.edge_bright_band_width_factor * max(expected_width_px, 1.0),
        ),
    )
    gap = max(0.0, cfg.edge_bright_gap_px)
    min_side_contrast = max(
        cfg.edge_complete_min_bright_contrast_gray,
        cfg.edge_complete_min_global_contrast_fraction * max(candidate_global_contrast, 0.0),
    )

    sample_count = len(y_values)
    trench_gray = np.full(sample_count, np.nan, dtype=float)
    local_space_gray = np.full(sample_count, np.nan, dtype=float)
    left_space_gray = np.full(sample_count, np.nan, dtype=float)
    right_space_gray = np.full(sample_count, np.nan, dtype=float)
    left_bright = np.zeros(sample_count, dtype=bool)
    right_bright = np.zeros(sample_count, dtype=bool)
    left_available = np.zeros(sample_count, dtype=bool)
    right_available = np.zeros(sample_count, dtype=bool)

    # A disappearing/brightening trench may cause tracking to fail exactly in
    # its bright section.  Interpolate the trusted edge positions along Y and
    # inspect intensity at every sampling height rather than only valid rows.
    sample_index = np.arange(sample_count, dtype=float)
    if len(valid_idx):
        left_for_intensity = np.interp(sample_index, valid_idx.astype(float), left[valid_idx])
        right_for_intensity = np.interp(sample_index, valid_idx.astype(float), right[valid_idx])
    else:
        left_for_intensity = np.full(sample_count, np.nan, dtype=float)
        right_for_intensity = np.full(sample_count, np.nan, dtype=float)

    for idx in range(sample_count):
        profile, _y0, _y1 = sample_row_profile(gray, y_values[idx], cfg.average_rows_px)
        if profile is None:
            continue
        l = float(left_for_intensity[idx])
        r = float(right_for_intensity[idx])
        width = r - l
        if not np.isfinite(width) or width <= 2.0:
            continue

        inner_margin = min(
            0.40 * width,
            max(1.0, cfg.intensity_inner_margin_fraction * width),
        )
        tg = safe_segment_mean(profile, l + inner_margin, r - inner_margin)
        if not np.isfinite(tg):
            tg = safe_segment_mean(profile, l + 0.15 * width, r - 0.15 * width)
        trench_gray[idx] = tg

        if l - gap - side_band >= 0:
            left_available[idx] = True
            left_space_gray[idx] = safe_segment_mean(
                profile,
                l - gap - side_band,
                l - gap,
            )
        if r + gap + side_band <= image_width:
            right_available[idx] = True
            right_space_gray[idx] = safe_segment_mean(
                profile,
                r + gap,
                r + gap + side_band,
            )

        if np.isfinite(tg) and np.isfinite(left_space_gray[idx]):
            left_bright[idx] = (left_space_gray[idx] - tg) >= min_side_contrast
        if np.isfinite(tg) and np.isfinite(right_space_gray[idx]):
            right_bright[idx] = (right_space_gray[idx] - tg) >= min_side_contrast

        side_values = [
            value
            for value in (left_space_gray[idx], right_space_gray[idx])
            if np.isfinite(value)
        ]
        if side_values:
            local_space_gray[idx] = float(np.median(side_values))

    # Border completeness is calculated on rows whose two edges were actually
    # trusted.  A trench in the middle of the image is not rejected merely
    # because local texture weakens one side; this rule is only hard near X edge.
    denominator = max(1, len(valid_idx))
    left_available_fraction = float(np.count_nonzero(left_available & valid) / denominator)
    right_available_fraction = float(np.count_nonzero(right_available & valid) / denominator)
    left_bright_fraction = float(np.count_nonzero(left_bright & valid) / denominator)
    right_bright_fraction = float(np.count_nonzero(right_bright & valid) / denominator)
    both_bright_fraction = float(
        np.count_nonzero(left_bright & right_bright & valid) / denominator
    )

    median_left = float(np.nanmedian(left[valid])) if np.any(valid) else math.nan
    median_right = float(np.nanmedian(right[valid])) if np.any(valid) else math.nan
    median_center = (
        0.5 * (median_left + median_right)
        if np.isfinite(median_left) and np.isfinite(median_right)
        else math.nan
    )
    expected_left = (
        median_center - 0.5 * expected_width_px
        if np.isfinite(median_center)
        else math.nan
    )
    expected_right = (
        median_center + 0.5 * expected_width_px
        if np.isfinite(median_center)
        else math.nan
    )
    border_guard = side_band + gap + cfg.edge_border_extra_px
    near_left_border = bool(
        (np.isfinite(median_left) and median_left < border_guard)
        or (np.isfinite(expected_left) and expected_left < border_guard)
    )
    near_right_border = bool(
        (np.isfinite(median_right) and median_right > (image_width - 1 - border_guard))
        or (
            np.isfinite(expected_right)
            and expected_right > (image_width - 1 - border_guard)
        )
    )
    near_border = near_left_border or near_right_border
    both_sides_complete = bool(
        left_available_fraction >= cfg.edge_complete_min_side_fraction
        and right_available_fraction >= cfg.edge_complete_min_side_fraction
        and left_bright_fraction >= cfg.edge_complete_min_side_fraction
        and right_bright_fraction >= cfg.edge_complete_min_side_fraction
        and both_bright_fraction >= cfg.edge_complete_min_both_fraction
    )
    border_incomplete = bool(
        cfg.reject_border_incomplete_trench
        and near_border
        and not both_sides_complete
    )

    # Local contrast is robust against a global illumination gradient because
    # it always compares trench interior with its own two neighboring spaces.
    contrast = local_space_gray - trench_gray
    finite_intensity = (
        np.isfinite(contrast)
        & np.isfinite(trench_gray)
        & np.isfinite(local_space_gray)
    )
    intensity_idx = np.flatnonzero(finite_intensity)
    dark_reference = math.nan
    min_norm_contrast = math.nan
    bright_fraction = math.nan
    dark_fraction = math.nan
    bright_run_len = dark_run_len = 0
    bright_run_start = bright_run_end = -1
    dark_run_start = dark_run_end = -1
    run_separation_fraction = math.nan
    trench_gray_change = math.nan
    transition_detected = False

    if len(intensity_idx) >= 6:
        contrast_values = contrast[intensity_idx]
        positive = contrast_values[
            np.isfinite(contrast_values) & (contrast_values > 0)
        ]
        if len(positive):
            dark_reference = float(
                np.percentile(positive, cfg.intensity_dark_reference_percentile)
            )

        if (
            np.isfinite(dark_reference)
            and dark_reference >= cfg.intensity_min_reference_contrast_gray
        ):
            smooth_contrast = rolling_median_reference(
                contrast_values,
                cfg.intensity_smooth_window,
            )
            norm = smooth_contrast / max(dark_reference, EPS)
            bright_like = norm <= cfg.intensity_bright_like_max_contrast_fraction
            dark_like = norm >= cfg.intensity_dark_like_min_contrast_fraction
            bright_fraction = float(np.mean(bright_like))
            dark_fraction = float(np.mean(dark_like))
            min_norm_contrast = float(np.min(norm)) if len(norm) else math.nan

            bright_run_len, bright_run_start, bright_run_end = longest_true_run(bright_like)
            dark_run_len, dark_run_start, dark_run_end = longest_true_run(dark_like)
            if bright_run_len and dark_run_len:
                bright_center = 0.5 * (bright_run_start + bright_run_end - 1)
                dark_center = 0.5 * (dark_run_start + dark_run_end - 1)
                run_separation_fraction = abs(bright_center - dark_center) / max(
                    1.0,
                    len(norm) - 1.0,
                )
                bright_positions = np.arange(len(norm))[bright_like]
                dark_positions = np.arange(len(norm))[dark_like]
                tg_values = trench_gray[intensity_idx]
                if len(bright_positions) and len(dark_positions):
                    trench_gray_change = float(
                        np.median(tg_values[bright_positions])
                        - np.median(tg_values[dark_positions])
                    )

            min_bright_run = max(
                2,
                int(math.ceil(cfg.intensity_min_bright_run_fraction * len(norm))),
            )
            min_dark_run = max(
                2,
                int(math.ceil(cfg.intensity_min_dark_run_fraction * len(norm))),
            )
            min_gray_change = max(
                cfg.intensity_min_gray_change,
                cfg.intensity_min_change_reference_fraction * dark_reference,
            )
            transition_detected = bool(
                cfg.reject_dark_to_space_transition
                and bright_run_len >= min_bright_run
                and dark_run_len >= min_dark_run
                and np.isfinite(run_separation_fraction)
                and run_separation_fraction >= cfg.intensity_min_run_separation_fraction
                and np.isfinite(trench_gray_change)
                and trench_gray_change >= min_gray_change
            )

    return {
        "min_width_px": min_width_px,
        "max_width_px": max_width_px,
        "max_min_width_ratio": max_min_ratio,
        "width_ratio_rejected": bool(
            np.isfinite(max_min_ratio)
            and max_min_ratio >= cfg.max_to_min_width_ratio_limit
        ),
        "side_bright_band_px": float(side_band),
        "near_left_image_border": near_left_border,
        "near_right_image_border": near_right_border,
        "near_image_border": near_border,
        "left_space_available_fraction": left_available_fraction,
        "right_space_available_fraction": right_available_fraction,
        "left_bright_edge_fraction": left_bright_fraction,
        "right_bright_edge_fraction": right_bright_fraction,
        "both_bright_edges_fraction": both_bright_fraction,
        "both_bright_edges_complete": both_sides_complete,
        "border_incomplete_rejected": border_incomplete,
        "median_trench_gray": (
            float(np.nanmedian(trench_gray[finite_intensity]))
            if np.any(finite_intensity)
            else math.nan
        ),
        "median_local_space_gray": (
            float(np.nanmedian(local_space_gray[finite_intensity]))
            if np.any(finite_intensity)
            else math.nan
        ),
        "dark_reference_contrast_gray": dark_reference,
        "minimum_smoothed_contrast_fraction_of_dark_reference": min_norm_contrast,
        "bright_like_space_fraction_along_y": bright_fraction,
        "dark_like_fraction_along_y": dark_fraction,
        "longest_bright_like_run_samples": int(bright_run_len),
        "longest_bright_like_run_start_index": int(bright_run_start),
        "longest_bright_like_run_end_index_exclusive": int(bright_run_end),
        "longest_dark_like_run_samples": int(dark_run_len),
        "longest_dark_like_run_start_index": int(dark_run_start),
        "longest_dark_like_run_end_index_exclusive": int(dark_run_end),
        "dark_bright_run_separation_fraction": run_separation_fraction,
        "trench_gray_bright_minus_dark": trench_gray_change,
        "dark_to_space_transition_rejected": transition_detected,
    }


def track_one_trench(
    gray: np.ndarray,
    candidate: TrenchCandidate,
    expected_width_px: float,
    expected_space_px: float,
    pixel_size_nm: float,
    cfg: TrenchConfig,
    relaxed: bool = False,
) -> Optional[TrenchTrack]:
    H = gray.shape[0]
    margin = int(round(cfg.global_y_margin_fraction * H))
    y_start = max(0, margin)
    y_end = min(H - 1, H - 1 - margin)
    if y_end <= y_start:
        y_start, y_end = 0, H - 1
    y_values = np.linspace(y_start, y_end, cfg.sample_number)
    left = np.full(cfg.sample_number, np.nan, dtype=float)
    right = np.full(cfg.sample_number, np.nan, dtype=float)

    order = sorted(range(cfg.sample_number), key=lambda i: (abs(y_values[i] - 0.5 * (y_start + y_end)), i))
    for idx in order:
        profile, _y0, _y1 = sample_row_profile(gray, y_values[idx], cfg.average_rows_px)
        if profile is None:
            continue
        al, ar = nearest_valid_anchor(idx, y_values, left, right, candidate)
        edge = detect_dark_band_edges(
            profile,
            candidate.center_x,
            expected_width_px,
            cfg,
            anchor_left=al,
            anchor_right=ar,
            search_radius_px=max(4.0, cfg.local_search_radius_width_factor * expected_width_px),
            strict_tracking=True,
        )
        if not edge.valid:
            edge = detect_dark_band_edges(
                profile,
                candidate.center_x,
                expected_width_px,
                cfg,
                anchor_left=candidate.global_left_x,
                anchor_right=candidate.global_right_x,
                search_radius_px=max(5.0, cfg.retry_search_radius_width_factor * expected_width_px),
                strict_tracking=False,
            )
        if edge.valid:
            left[idx] = edge.left_x
            right[idx] = edge.right_x

    widths = right - left
    left_bad, _left_ref, _ = robust_series_outliers(
        left, cfg.postfilter_window, cfg.postfilter_mad_multiplier, cfg.postfilter_min_edge_tolerance_px
    )
    right_bad, _right_ref, _ = robust_series_outliers(
        right, cfg.postfilter_window, cfg.postfilter_mad_multiplier, cfg.postfilter_min_edge_tolerance_px
    )
    width_bad, _width_ref, _ = robust_series_outliers(
        widths, cfg.postfilter_window, cfg.postfilter_mad_multiplier, cfg.postfilter_min_width_tolerance_px
    )
    bad = left_bad | right_bad | width_bad
    left[bad] = np.nan
    right[bad] = np.nan
    widths = right - left

    hard_min = (0.35 if relaxed else cfg.candidate_min_width_factor) * expected_width_px
    hard_max = (2.00 if relaxed else cfg.candidate_max_width_factor) * expected_width_px
    invalid_size = np.isfinite(widths) & ((widths < hard_min) | (widths > hard_max))
    left[invalid_size] = np.nan
    right[invalid_size] = np.nan
    widths = right - left
    valid = np.isfinite(left) & np.isfinite(right) & np.isfinite(widths)
    count = int(np.count_nonzero(valid))
    fraction = count / float(cfg.sample_number)
    min_fraction = 0.42 if relaxed else cfg.minimum_valid_fraction
    if count < 4 or fraction < min_fraction:
        return None

    quality = trench_track_quality_metrics(
        gray=gray,
        y_values=y_values,
        left=left,
        right=right,
        valid=valid,
        expected_width_px=expected_width_px,
        expected_space_px=expected_space_px,
        candidate_global_contrast=candidate.contrast,
        cfg=cfg,
    )
    # These are hard rejection rules.  The zero-result relaxed fallback may
    # loosen the original detector, but cannot bypass physical completeness.
    if quality.get("border_incomplete_rejected", False):
        return None
    if quality.get("width_ratio_rejected", False):
        return None
    if quality.get("dark_to_space_transition_rejected", False):
        return None

    width_nm = widths[valid] * pixel_size_nm
    mean_nm = float(np.mean(width_nm))
    median_nm = float(np.median(width_nm))
    std_nm = float(np.std(width_nm, ddof=1)) if len(width_nm) > 1 else 0.0
    lwr = 3.0 * float(np.std(width_nm, ddof=0))

    yv = y_values[valid]
    lc = left[valid]
    rc = right[valid]
    centers = 0.5 * (lc + rc)
    if len(yv) >= 3 and np.ptp(yv) > 0:
        slope_center, _intercept = np.polyfit(yv, centers, 1)
        slope_l, _ = np.polyfit(yv, lc, 1)
        slope_r, _ = np.polyfit(yv, rc, 1)
        tilt = math.degrees(math.atan(float(slope_center)))
    else:
        slope_l = slope_r = tilt = math.nan

    return TrenchTrack(
        candidate=candidate,
        y_values=y_values,
        left_edges=left,
        right_edges=right,
        valid_mask=valid,
        mean_width_nm=mean_nm,
        median_width_nm=median_nm,
        std_width_nm=std_nm,
        lwr_3sigma_nm=lwr,
        valid_count=count,
        valid_fraction=fraction,
        centerline_tilt_deg=float(tilt),
        left_fit_slope_px_per_px=float(slope_l),
        right_fit_slope_px_per_px=float(slope_r),
        confidence_flag="RELAXED_FALLBACK_REVIEW" if relaxed else "NORMAL",
        quality_metrics=quality,
    )


def measure_spaces_between_tracks(
    tracks: Sequence[TrenchTrack],
    design_trench_nm: float,
    design_space_nm: float,
    pixel_size_nm: float,
    cfg: TrenchConfig,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if len(tracks) < 2:
        return rows
    sorted_tracks = sorted(tracks, key=lambda t: t.candidate.center_x)
    expected_pitch_px = (design_trench_nm + design_space_nm) / max(pixel_size_nm, EPS)
    for i in range(len(sorted_tracks) - 1):
        left_trench = sorted_tracks[i]
        right_trench = sorted_tracks[i + 1]

        # Never bridge over a trench that was rejected by hard QC.  Prefer the
        # fitted lattice index when available, then apply a broad design-pitch
        # guard as an independent safety net.
        left_index = left_trench.candidate.lattice_index
        right_index = right_trench.candidate.lattice_index
        if left_index is not None and right_index is not None:
            if int(right_index) - int(left_index) != 1:
                continue
        center_distance_px = float(
            right_trench.candidate.center_x - left_trench.candidate.center_x
        )
        if np.isfinite(expected_pitch_px) and expected_pitch_px > EPS:
            if center_distance_px < cfg.space_pair_min_pitch_factor * expected_pitch_px:
                continue
            if center_distance_px > cfg.space_pair_max_pitch_factor * expected_pitch_px:
                continue

        valid = (
            np.isfinite(left_trench.right_edges)
            & np.isfinite(right_trench.left_edges)
        )
        space_px = right_trench.left_edges - left_trench.right_edges
        min_px = cfg.space_min_design_factor * design_space_nm / pixel_size_nm
        max_px = cfg.space_max_design_factor * design_space_nm / pixel_size_nm
        valid &= np.isfinite(space_px) & (space_px >= min_px) & (space_px <= max_px)
        values = space_px[valid] * pixel_size_nm
        fraction = int(np.count_nonzero(valid)) / float(len(valid))
        if len(values) < 4 or fraction < cfg.space_min_valid_fraction:
            continue
        rows.append({
            "left_track_index": i,
            "right_track_index": i + 1,
            "valid_mask": valid,
            "space_widths_nm": values,
            "mean_space_nm": float(np.mean(values)),
            "median_space_nm": float(np.median(values)),
            "std_space_nm": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
            "space_3sigma_nm": 3.0 * float(np.std(values, ddof=0)),
            "valid_count": int(len(values)),
            "valid_fraction": float(fraction),
            "trench_center_pitch_px": center_distance_px,
            "trench_center_pitch_nm": center_distance_px * pixel_size_nm,
            "trench_center_pitch_over_design": (
                center_distance_px / expected_pitch_px
                if expected_pitch_px > EPS
                else math.nan
            ),
        })
    return rows


def measure_trench_image(
    parsed: ParsedImage,
    gray: np.ndarray,
    general: GeneralConfig,
    cfg: TrenchConfig,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any], np.ndarray, dict[str, np.ndarray]]:
    px_nm = general.pixel_size_nm
    design_w = parsed.design_trench_nm
    design_s = parsed.design_space_nm
    Wpx = max(4.0, design_w / px_nm)
    Spx = max(3.0, design_s / px_nm)
    candidates, meta, global_profile = detect_trench_candidates(gray, Wpx, Spx, cfg)

    tracks: list[TrenchTrack] = []
    for c in candidates:
        t = track_one_trench(gray, c, Wpx, Spx, px_nm, cfg, relaxed=False)
        if t is not None:
            tracks.append(t)

    fallback_used = False
    if not tracks and candidates:
        fallback_used = True
        for c in candidates:
            t = track_one_trench(gray, c, Wpx, Spx, px_nm, cfg, relaxed=True)
            if t is not None:
                tracks.append(t)

    tracks.sort(key=lambda t: t.candidate.center_x)
    # 轨迹去重，保留有效比例高的。
    deduped: list[TrenchTrack] = []
    for t in sorted(tracks, key=lambda x: x.valid_fraction, reverse=True):
        if any(abs(t.candidate.center_x - old.candidate.center_x) < 0.45 * Wpx for old in deduped):
            continue
        deduped.append(t)
    tracks = sorted(deduped, key=lambda t: t.candidate.center_x)

    trench_rows: list[dict[str, Any]] = []
    for i, t in enumerate(tracks, start=1):
        trench_rows.append({
            "folder_name": parsed.folder_name,
            "folder_nominal_nm": parsed.folder_nominal_nm,
            "pretreatment_nm": parsed.pretreatment_nm,
            "dose_mj": parsed.dose_mj,
            "sample_id": parsed.sample_id,
            "metadata_source": parsed.metadata_source,
            "auto_pattern_score": parsed.auto_pattern_score,
            "auto_gradient_x_to_y_ratio": parsed.auto_gradient_x_to_y_ratio,
            "image": parsed.path.name,
            "path": str(parsed.path),
            "pattern": "trench",
            "magnification": general.magnification_token,
            "pixel_size_nm": px_nm,
            "design_trench_nm": design_w,
            "design_space_nm": design_s,
            "trench_id": i,
            "center_x_global_px": t.candidate.center_x,
            "global_width_px": t.candidate.global_width_px,
            "mean_width_nm": t.mean_width_nm,
            "median_width_nm": t.median_width_nm,
            "std_width_nm": t.std_width_nm,
            "lwr_3sigma_nm": t.lwr_3sigma_nm,
            "width_bias_nm": t.mean_width_nm - design_w,
            "width_bias_pct": safe_pct_bias(t.mean_width_nm, design_w),
            "valid_sample_count": t.valid_count,
            "valid_fraction": t.valid_fraction,
            "centerline_tilt_deg_from_vertical": t.centerline_tilt_deg,
            "left_edge_slope_dx_dy": t.left_fit_slope_px_per_px,
            "right_edge_slope_dx_dy": t.right_fit_slope_px_per_px,
            "minimum_width_nm": finite_float(t.quality_metrics.get("min_width_px")) * px_nm,
            "maximum_width_nm": finite_float(t.quality_metrics.get("max_width_px")) * px_nm,
            "max_min_width_ratio": t.quality_metrics.get("max_min_width_ratio", math.nan),
            "near_left_image_border": t.quality_metrics.get("near_left_image_border", False),
            "near_right_image_border": t.quality_metrics.get("near_right_image_border", False),
            "near_image_border": t.quality_metrics.get("near_image_border", False),
            "left_space_available_fraction": t.quality_metrics.get("left_space_available_fraction", math.nan),
            "right_space_available_fraction": t.quality_metrics.get("right_space_available_fraction", math.nan),
            "left_bright_edge_fraction": t.quality_metrics.get("left_bright_edge_fraction", math.nan),
            "right_bright_edge_fraction": t.quality_metrics.get("right_bright_edge_fraction", math.nan),
            "both_bright_edges_fraction": t.quality_metrics.get("both_bright_edges_fraction", math.nan),
            "both_bright_edges_complete": t.quality_metrics.get("both_bright_edges_complete", False),
            "median_trench_gray": t.quality_metrics.get("median_trench_gray", math.nan),
            "median_local_space_gray": t.quality_metrics.get("median_local_space_gray", math.nan),
            "dark_reference_contrast_gray": t.quality_metrics.get("dark_reference_contrast_gray", math.nan),
            "minimum_smoothed_contrast_fraction_of_dark_reference": t.quality_metrics.get(
                "minimum_smoothed_contrast_fraction_of_dark_reference",
                math.nan,
            ),
            "bright_like_space_fraction_along_y": t.quality_metrics.get(
                "bright_like_space_fraction_along_y",
                math.nan,
            ),
            "dark_like_fraction_along_y": t.quality_metrics.get("dark_like_fraction_along_y", math.nan),
            "longest_bright_like_run_samples": t.quality_metrics.get("longest_bright_like_run_samples", 0),
            "longest_bright_like_run_start_index": t.quality_metrics.get(
                "longest_bright_like_run_start_index",
                -1,
            ),
            "longest_bright_like_run_end_index_exclusive": t.quality_metrics.get(
                "longest_bright_like_run_end_index_exclusive",
                -1,
            ),
            "longest_dark_like_run_samples": t.quality_metrics.get("longest_dark_like_run_samples", 0),
            "longest_dark_like_run_start_index": t.quality_metrics.get(
                "longest_dark_like_run_start_index",
                -1,
            ),
            "longest_dark_like_run_end_index_exclusive": t.quality_metrics.get(
                "longest_dark_like_run_end_index_exclusive",
                -1,
            ),
            "dark_bright_run_separation_fraction": t.quality_metrics.get(
                "dark_bright_run_separation_fraction",
                math.nan,
            ),
            "trench_gray_bright_minus_dark": t.quality_metrics.get(
                "trench_gray_bright_minus_dark",
                math.nan,
            ),
            "global_basin_mean_gray": t.candidate.basin_mean,
            "global_line_to_trench_contrast_gray": t.candidate.contrast,
            "candidate_score": t.candidate.score,
            "selection_source": t.candidate.source,
            "lattice_index": t.candidate.lattice_index,
            "confidence_flag": t.confidence_flag,
            "used_for_statistics": True,
        })

    raw_spaces = measure_spaces_between_tracks(tracks, design_w, design_s, px_nm, cfg)
    space_rows: list[dict[str, Any]] = []
    for i, s in enumerate(raw_spaces, start=1):
        lt = tracks[int(s["left_track_index"])]
        rt = tracks[int(s["right_track_index"])]
        space_rows.append({
            "folder_name": parsed.folder_name,
            "folder_nominal_nm": parsed.folder_nominal_nm,
            "pretreatment_nm": parsed.pretreatment_nm,
            "dose_mj": parsed.dose_mj,
            "sample_id": parsed.sample_id,
            "metadata_source": parsed.metadata_source,
            "auto_pattern_score": parsed.auto_pattern_score,
            "auto_gradient_x_to_y_ratio": parsed.auto_gradient_x_to_y_ratio,
            "image": parsed.path.name,
            "path": str(parsed.path),
            "pattern": "space",
            "magnification": general.magnification_token,
            "pixel_size_nm": px_nm,
            "design_trench_nm": design_w,
            "design_space_nm": design_s,
            "space_id": i,
            "left_trench_id": int(s["left_track_index"]) + 1,
            "right_trench_id": int(s["right_track_index"]) + 1,
            "center_x_px": 0.5 * (lt.candidate.center_x + rt.candidate.center_x),
            "mean_width_nm": s["mean_space_nm"],
            "median_width_nm": s["median_space_nm"],
            "std_width_nm": s["std_space_nm"],
            "width_3sigma_nm": s["space_3sigma_nm"],
            "width_bias_nm": s["mean_space_nm"] - design_s,
            "width_bias_pct": safe_pct_bias(s["mean_space_nm"], design_s),
            "valid_sample_count": s["valid_count"],
            "valid_fraction": s["valid_fraction"],
            "trench_center_pitch_px": s["trench_center_pitch_px"],
            "trench_center_pitch_nm": s["trench_center_pitch_nm"],
            "trench_center_pitch_over_design": s["trench_center_pitch_over_design"],
            "confidence_flag": "RELAXED_FALLBACK_REVIEW" if fallback_used else "NORMAL",
            "used_for_statistics": True,
        })

    annotated = annotate_trenches(gray, tracks, trench_rows, raw_spaces, design_w, design_s, fallback_used)
    debug_profile = np.tile(np.clip(global_profile, 0, 255).astype(np.uint8), (120, 1))
    debug = {"trench_global_profile": debug_profile}
    summary = summarize_trench_image(parsed, trench_rows, space_rows, len(candidates), fallback_used, meta, gray.shape)
    return trench_rows, space_rows, summary, annotated, debug


def polyline_points(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    valid = np.isfinite(y) & np.isfinite(x)
    pts = np.column_stack([x[valid], y[valid]])
    return np.asarray(np.rint(pts), dtype=np.int32).reshape(-1, 1, 2)


def annotate_trenches(
    gray: np.ndarray,
    tracks: Sequence[TrenchTrack],
    trench_rows: Sequence[dict[str, Any]],
    spaces: Sequence[dict[str, Any]],
    design_w: float,
    design_s: float,
    fallback_used: bool,
) -> np.ndarray:
    out = to_color(gray)
    H, W = gray.shape
    value_color = (255, 0, 255)  # BGR：实测 CD 统一使用紫红色。
    for t, row in zip(tracks, trench_rows):
        relaxed = row["confidence_flag"] != "NORMAL"
        color = (0, 215, 255) if relaxed else (0, 220, 0)
        lp = polyline_points(t.y_values, t.left_edges)
        rp = polyline_points(t.y_values, t.right_edges)
        if len(lp) >= 2:
            cv2.polylines(out, [lp], False, color, 1, cv2.LINE_AA)
        if len(rp) >= 2:
            cv2.polylines(out, [rp], False, color, 1, cv2.LINE_AA)
        valid_idx = np.flatnonzero(t.valid_mask)
        if len(valid_idx):
            j = int(valid_idx[len(valid_idx) // 2])
            c = (int(round(0.5 * (t.left_edges[j] + t.right_edges[j]))), int(round(t.y_values[j])))
        else:
            c = (int(round(t.candidate.center_x)), H // 2)
        label = f"T{row['trench_id']}"
        # 放在图像上方并交错高度，避免多条 trench 的文字挤成一团。
        x = int(np.clip(c[0] - 8, 2, max(2, W - 28)))
        y = 43 + 14 * ((int(row['trench_id']) - 1) % 3)
        y = min(max(13, y), H - 4)
        put_text_with_outline(out, label, (x, y), 0.34, color, 1)

        # 每条成功 Trench 的平均 CD；与 T 编号同字号、不同颜色。
        # Unit is nm.  Four staggered lanes reduce overlap between dense lines.
        value = f"W{row['mean_width_nm']:.1f}"
        value_size, _ = cv2.getTextSize(
            value,
            cv2.FONT_HERSHEY_SIMPLEX,
            0.34,
            1,
        )
        value_x = int(
            np.clip(
                c[0] - value_size[0] / 2,
                2,
                max(2, W - value_size[0] - 2),
            )
        )
        value_y = int(
            np.clip(
                0.43 * H + 14 * ((int(row["trench_id"]) - 1) % 4),
                45,
                H - 4,
            )
        )
        put_text_with_outline(
            out,
            value,
            (value_x, value_y),
            0.34,
            value_color,
            1,
        )

    # 在中间高度标注每条合格 space。
    for i, s in enumerate(spaces, start=1):
        lt = tracks[int(s["left_track_index"])]
        rt = tracks[int(s["right_track_index"])]
        common = np.flatnonzero(np.isfinite(lt.right_edges) & np.isfinite(rt.left_edges))
        if not len(common):
            continue
        j = int(common[len(common) // 2])
        y = int(round(lt.y_values[j]))
        x1 = int(round(lt.right_edges[j]))
        x2 = int(round(rt.left_edges[j]))
        if x2 <= x1:
            continue
        cv2.arrowedLine(out, (x1, y), (x2, y), (255, 255, 0), 1, cv2.LINE_AA, tipLength=0.08)
        cv2.arrowedLine(out, (x2, y), (x1, y), (255, 255, 0), 1, cv2.LINE_AA, tipLength=0.08)
        text = f"S{i}"
        ty = int(np.clip(y - 5 - 12 * ((i - 1) % 3), 12, H - 3))
        put_text_with_outline(
            out,
            text,
            (max(2, (x1 + x2) // 2 - 8), ty),
            0.31,
            (255, 255, 0),
            1,
        )

        # 每条成功 Space 的平均 CD；与 S 编号同字号、不同颜色。
        value = f"S{float(s['mean_space_nm']):.1f}"
        value_size, _ = cv2.getTextSize(
            value,
            cv2.FONT_HERSHEY_SIMPLEX,
            0.31,
            1,
        )
        value_x = int(
            np.clip(
                0.5 * (x1 + x2) - value_size[0] / 2,
                2,
                max(2, W - value_size[0] - 2),
            )
        )
        value_y = int(
            np.clip(
                0.62 * H + 14 * ((i - 1) % 4),
                45,
                H - 3,
            )
        )
        put_text_with_outline(
            out,
            value,
            (value_x, value_y),
            0.31,
            value_color,
            1,
        )

    mean_w = safe_mean(r["mean_width_nm"] for r in trench_rows)
    mean_s = safe_mean(s["mean_space_nm"] for s in spaces)
    banner = (
        f"TRENCH used={len(trench_rows)} Wdesign={design_w:.1f} mean={mean_w:.2f}nm  "
        f"SPACE used={len(spaces)} Sdesign={design_s:.1f} mean={mean_s:.2f}nm"
    )
    if fallback_used:
        banner += "  AUTO FALLBACK REVIEW"
    cv2.rectangle(out, (3, 3), (min(W - 4, 920), 29), (0, 0, 0), -1)
    cv2.putText(out, banner, (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.44, (255, 255, 255), 1, cv2.LINE_AA)
    return out


def summarize_trench_image(
    parsed: ParsedImage,
    trench_rows: Sequence[dict[str, Any]],
    space_rows: Sequence[dict[str, Any]],
    candidate_count: int,
    fallback_used: bool,
    meta: dict[str, Any],
    image_shape: tuple[int, int],
) -> dict[str, Any]:
    widths = [r["mean_width_nm"] for r in trench_rows]
    spaces = [r["mean_width_nm"] for r in space_rows]
    mean_w = safe_mean(widths)
    mean_s = safe_mean(spaces)
    return {
        "folder_name": parsed.folder_name,
        "folder_nominal_nm": parsed.folder_nominal_nm,
        "pretreatment_nm": parsed.pretreatment_nm,
        "dose_mj": parsed.dose_mj,
        "sample_id": parsed.sample_id,
        "metadata_source": parsed.metadata_source,
        "auto_pattern_score": parsed.auto_pattern_score,
        "auto_gradient_x_to_y_ratio": parsed.auto_gradient_x_to_y_ratio,
        "image": parsed.path.name,
        "path": str(parsed.path),
        "pattern": "trench",
        "status": "OK" if trench_rows else "NO_VALID_OBJECT",
        "image_height_px": image_shape[0],
        "image_width_px": image_shape[1],
        "design_via_nm": math.nan,
        "design_trench_nm": parsed.design_trench_nm,
        "design_space_nm": parsed.design_space_nm,
        "via_count": 0,
        "via_candidate_count": 0,
        "via_mean_nm": math.nan,
        "via_median_nm": math.nan,
        "via_between_object_std_nm": math.nan,
        "via_min_nm": math.nan,
        "via_max_nm": math.nan,
        "via_bias_nm": math.nan,
        "via_bias_pct": math.nan,
        "via_mean_circularity": math.nan,
        "via_mean_axis_roundness": math.nan,
        "via_mean_solidity": math.nan,
        "via_relaxed_count": 0,
        "via_zero_result_fallback_used": False,
        "trench_count": len(trench_rows),
        "trench_candidate_count": candidate_count,
        "trench_mean_nm": mean_w,
        "trench_median_nm": float(np.median(widths)) if widths else math.nan,
        "trench_between_object_std_nm": safe_std(widths),
        "trench_bias_nm": mean_w - parsed.design_trench_nm if np.isfinite(mean_w) else math.nan,
        "trench_bias_pct": safe_pct_bias(mean_w, parsed.design_trench_nm),
        "trench_mean_lwr_3sigma_nm": safe_mean(r["lwr_3sigma_nm"] for r in trench_rows),
        "trench_mean_valid_fraction": safe_mean(r["valid_fraction"] for r in trench_rows),
        "space_count": len(space_rows),
        "space_mean_nm": mean_s,
        "space_median_nm": float(np.median(spaces)) if spaces else math.nan,
        "space_between_object_std_nm": safe_std(spaces),
        "space_bias_nm": mean_s - parsed.design_space_nm if np.isfinite(mean_s) else math.nan,
        "space_bias_pct": safe_pct_bias(mean_s, parsed.design_space_nm),
        "space_mean_3sigma_nm": safe_mean(r["width_3sigma_nm"] for r in space_rows),
        "trench_zero_result_fallback_used": fallback_used,
        **meta,
    }


# ============================================================
# 5. 汇总、Excel 与图
# ============================================================
def build_long_image_metrics(image_df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    if image_df.empty:
        return pd.DataFrame()
    common_cols = [
        "folder_name", "folder_nominal_nm", "pretreatment_nm", "dose_mj", "sample_id",
        "metadata_source", "auto_pattern_score", "auto_gradient_x_to_y_ratio", "image", "path",
    ]
    for _, r in image_df.iterrows():
        common = {c: r.get(c, math.nan) for c in common_cols}
        if r.get("pattern") == "via" and np.isfinite(finite_float(r.get("via_mean_nm"))):
            rows.append({
                **common,
                "metric": "via_diameter",
                "design_nm": r.get("design_via_nm"),
                "actual_image_mean_nm": r.get("via_mean_nm"),
                "object_count": r.get("via_count", 0),
                "bias_nm": r.get("via_bias_nm"),
                "bias_pct": r.get("via_bias_pct"),
                "via_image_mean_circularity": r.get("via_mean_circularity"),
                "via_image_mean_axis_roundness": r.get("via_mean_axis_roundness"),
                "via_image_mean_solidity": r.get("via_mean_solidity"),
                "trench_image_mean_lwr_3sigma_nm": math.nan,
                "trench_image_mean_valid_fraction": math.nan,
                "space_image_mean_3sigma_nm": math.nan,
            })
        if r.get("pattern") == "trench":
            if np.isfinite(finite_float(r.get("trench_mean_nm"))):
                rows.append({
                    **common,
                    "metric": "trench_width",
                    "design_nm": r.get("design_trench_nm"),
                    "actual_image_mean_nm": r.get("trench_mean_nm"),
                    "object_count": r.get("trench_count", 0),
                    "bias_nm": r.get("trench_bias_nm"),
                    "bias_pct": r.get("trench_bias_pct"),
                    "via_image_mean_circularity": math.nan,
                    "via_image_mean_axis_roundness": math.nan,
                    "via_image_mean_solidity": math.nan,
                    "trench_image_mean_lwr_3sigma_nm": r.get("trench_mean_lwr_3sigma_nm"),
                    "trench_image_mean_valid_fraction": r.get("trench_mean_valid_fraction"),
                    "space_image_mean_3sigma_nm": math.nan,
                })
            if np.isfinite(finite_float(r.get("space_mean_nm"))):
                rows.append({
                    **common,
                    "metric": "space_width",
                    "design_nm": r.get("design_space_nm"),
                    "actual_image_mean_nm": r.get("space_mean_nm"),
                    "object_count": r.get("space_count", 0),
                    "bias_nm": r.get("space_bias_nm"),
                    "bias_pct": r.get("space_bias_pct"),
                    "via_image_mean_circularity": math.nan,
                    "via_image_mean_axis_roundness": math.nan,
                    "via_image_mean_solidity": math.nan,
                    "trench_image_mean_lwr_3sigma_nm": math.nan,
                    "trench_image_mean_valid_fraction": math.nan,
                    "space_image_mean_3sigma_nm": r.get("space_mean_3sigma_nm"),
                })
    return pd.DataFrame(rows)


def build_long_object_metrics(
    via_df: pd.DataFrame,
    trench_df: pd.DataFrame,
    space_df: pd.DataFrame,
) -> pd.DataFrame:
    """Combine every accepted Via/Trench/Space object into one long table."""
    rows: list[dict[str, Any]] = []

    def accepted_records(df: pd.DataFrame) -> Iterable[pd.Series]:
        if df.empty:
            return []
        if "used_for_statistics" not in df.columns:
            return [row for _, row in df.iterrows()]
        used = df["used_for_statistics"].fillna(False).astype(bool)
        return [row for _, row in df.loc[used].iterrows()]

    common_cols = [
        "folder_name",
        "folder_nominal_nm",
        "pretreatment_nm",
        "dose_mj",
        "sample_id",
        "metadata_source",
        "auto_pattern_score",
        "auto_gradient_x_to_y_ratio",
        "image",
        "path",
        "confidence_flag",
    ]

    for row in accepted_records(via_df):
        measured = finite_float(row.get("diameter_nm"))
        design = finite_float(row.get("design_cd_nm"))
        if not (np.isfinite(measured) and np.isfinite(design)):
            continue
        rows.append({
            **{column: row.get(column, math.nan) for column in common_cols},
            "metric": "via_diameter",
            "object_id": f"V{row.get('via_id', '')}",
            "design_nm": design,
            "measured_object_nm": measured,
            "bias_nm": measured - design,
            "bias_pct": safe_pct_bias(measured, design),
            "via_circularity_4piA_P2": finite_float(row.get("circularity_4piA_P2")),
        })

    for row in accepted_records(trench_df):
        measured = finite_float(row.get("mean_width_nm"))
        design = finite_float(row.get("design_trench_nm"))
        if not (np.isfinite(measured) and np.isfinite(design)):
            continue
        rows.append({
            **{column: row.get(column, math.nan) for column in common_cols},
            "metric": "trench_width",
            "object_id": f"T{row.get('trench_id', '')}",
            "design_nm": design,
            "measured_object_nm": measured,
            "bias_nm": measured - design,
            "bias_pct": safe_pct_bias(measured, design),
            "via_circularity_4piA_P2": math.nan,
        })

    for row in accepted_records(space_df):
        measured = finite_float(row.get("mean_width_nm"))
        design = finite_float(row.get("design_space_nm"))
        if not (np.isfinite(measured) and np.isfinite(design)):
            continue
        rows.append({
            **{column: row.get(column, math.nan) for column in common_cols},
            "metric": "space_width",
            "object_id": f"S{row.get('space_id', '')}",
            "design_nm": design,
            "measured_object_nm": measured,
            "bias_nm": measured - design,
            "bias_pct": safe_pct_bias(measured, design),
            "via_circularity_4piA_P2": math.nan,
        })

    return pd.DataFrame(rows)


def build_condition_summary(image_df: pd.DataFrame) -> pd.DataFrame:
    long_df = build_long_image_metrics(image_df)
    if long_df.empty:
        return pd.DataFrame(columns=[
            "folder_name", "folder_nominal_nm", "pretreatment_nm", "dose_mj", "metric", "design_nm",
            "image_count", "total_object_count", "image_mean_average_nm", "image_mean_std_nm",
            "image_mean_sem_nm", "image_mean_ci95_half_width_nm", "bias_nm", "bias_pct",
        ])
    group_cols = ["folder_name", "folder_nominal_nm", "pretreatment_nm", "dose_mj", "metric", "design_nm"]
    rows = []
    for keys, g in long_df.groupby(group_cols, dropna=False):
        values = pd.to_numeric(g["actual_image_mean_nm"], errors="coerce").dropna().to_numpy(float)
        n = len(values)
        mean = float(np.mean(values)) if n else math.nan
        std = float(np.std(values, ddof=1)) if n > 1 else math.nan
        sem = std / math.sqrt(n) if n > 1 and np.isfinite(std) else math.nan
        design = float(keys[-1])
        def group_numeric_mean(column: str) -> float:
            if column not in g.columns:
                return math.nan
            a = pd.to_numeric(g[column], errors="coerce").dropna().to_numpy(float)
            return float(np.mean(a)) if len(a) else math.nan

        rows.append({
            **dict(zip(group_cols, keys)),
            "image_count": n,
            "total_object_count": int(pd.to_numeric(g["object_count"], errors="coerce").fillna(0).sum()),
            "image_mean_average_nm": mean,
            "image_mean_median_nm": float(np.median(values)) if n else math.nan,
            "image_mean_std_nm": std,
            "image_mean_sem_nm": sem,
            "image_mean_ci95_half_width_nm": 1.96 * sem if np.isfinite(sem) else math.nan,
            "bias_nm": mean - design if np.isfinite(mean) else math.nan,
            "bias_pct": safe_pct_bias(mean, design),
            "mean_absolute_bias_nm": float(np.mean(np.abs(values - design))) if n else math.nan,
            "mean_absolute_percentage_error_pct": float(np.mean(np.abs(values - design) / design) * 100.0) if n and abs(design) > EPS else math.nan,
            "mean_via_circularity_4piA_P2": group_numeric_mean("via_image_mean_circularity"),
            "mean_via_axis_roundness_minor_over_major": group_numeric_mean("via_image_mean_axis_roundness"),
            "mean_via_solidity": group_numeric_mean("via_image_mean_solidity"),
            "mean_trench_lwr_3sigma_nm": group_numeric_mean("trench_image_mean_lwr_3sigma_nm"),
            "mean_trench_valid_fraction": group_numeric_mean("trench_image_mean_valid_fraction"),
            "mean_space_width_3sigma_nm": group_numeric_mean("space_image_mean_3sigma_nm"),
        })
    return pd.DataFrame(rows).sort_values(group_cols).reset_index(drop=True)


def save_design_actual_plot(long_df: pd.DataFrame, metric: str, output_path: Path) -> None:
    if long_df.empty or "metric" not in long_df.columns:
        return
    g = long_df[long_df["metric"] == metric].copy()
    if g.empty:
        return
    x = pd.to_numeric(g["design_nm"], errors="coerce").to_numpy(float)
    y = pd.to_numeric(g["actual_image_mean_nm"], errors="coerce").to_numpy(float)
    finite = np.isfinite(x) & np.isfinite(y)
    if not np.any(finite):
        return
    x = x[finite]; y = y[finite]
    lo = float(min(np.min(x), np.min(y)))
    hi = float(max(np.max(x), np.max(y)))
    pad = max(1.0, 0.08 * (hi - lo if hi > lo else hi if hi > 0 else 1.0))
    fig, ax = plt.subplots(figsize=(7.2, 6.0))
    ax.scatter(x, y, alpha=0.75)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], linestyle="--", linewidth=1.2, label="actual = design")
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(lo - pad, hi + pad)
    titles = {
        "via_diameter": "Via: design CD vs measured diameter",
        "trench_width": "Trench: design W vs measured W",
        "space_width": "Space: design S vs measured S",
    }
    ax.set_title(titles.get(metric, metric))
    ax.set_xlabel("Design (nm)")
    ax.set_ylabel("Measured image mean (nm)")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def save_bias_plot(long_df: pd.DataFrame, metric: str, output_path: Path) -> None:
    if long_df.empty or "metric" not in long_df.columns:
        return
    g = long_df[long_df["metric"] == metric].copy()
    if g.empty:
        return
    g = g.sort_values(["pretreatment_nm", "dose_mj", "design_nm", "image"])
    y = pd.to_numeric(g["bias_nm"], errors="coerce").to_numpy(float)
    finite = np.isfinite(y)
    if not np.any(finite):
        return
    labels = [
        f"{r.pretreatment_nm:g}nm/{r.dose_mj:g}mj/{r.design_nm:g}"
        for r in g.itertuples()
    ]
    x = np.arange(len(g))
    fig, ax = plt.subplots(figsize=(max(8.0, 0.32 * len(g)), 5.5))
    ax.axhline(0.0, linewidth=1.0)
    ax.scatter(x[finite], y[finite])
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=70, ha="right", fontsize=8)
    ax.set_ylabel("Measured - design (nm)")
    ax.set_title(f"{metric}: per-image bias")
    ax.grid(True, axis="y", alpha=0.25)
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=180)
    plt.close(fig)



def accepted_via_rows(via_df: pd.DataFrame) -> pd.DataFrame:
    if via_df.empty:
        return via_df.copy()
    result = via_df.copy()
    if "used_for_statistics" in result.columns:
        used = result["used_for_statistics"].fillna(False).astype(bool)
        result = result.loc[used].copy()
    return result


def save_via_circularity_per_image_plot(via_df: pd.DataFrame, output_path: Path) -> None:
    """Show every accepted Via circularity and per-image mean ± object SD."""
    g = accepted_via_rows(via_df)
    if g.empty or "circularity_4piA_P2" not in g.columns:
        return
    g["_circ"] = pd.to_numeric(g["circularity_4piA_P2"], errors="coerce")
    g = g[np.isfinite(g["_circ"].to_numpy(float))].copy()
    if g.empty:
        return

    sort_cols = [
        column for column in
        ("pretreatment_nm", "dose_mj", "design_cd_nm", "sample_id", "image")
        if column in g.columns
    ]
    if sort_cols:
        g = g.sort_values(sort_cols)
    key_column = "path" if "path" in g.columns else "image"
    image_order = list(dict.fromkeys(g[key_column].astype(str).tolist()))
    groups = [g[g[key_column].astype(str) == image_key] for image_key in image_order]
    labels: list[str] = []

    fig, ax = plt.subplots(figsize=(max(9.0, 0.42 * len(groups)), 6.0))
    means: list[float] = []
    stds: list[float] = []
    x_positions = np.arange(len(groups), dtype=float)
    for idx, group in enumerate(groups):
        values = group["_circ"].to_numpy(float)
        jitter = np.linspace(-0.16, 0.16, len(values)) if len(values) > 1 else np.array([0.0])
        ax.scatter(np.full(len(values), x_positions[idx]) + jitter, values, alpha=0.35, s=18)
        means.append(float(np.mean(values)))
        stds.append(float(np.std(values, ddof=1)) if len(values) > 1 else 0.0)
        first = group.iloc[0]
        sample = str(first.get("sample_id", ""))
        labels.append(
            f"{finite_float(first.get('pretreatment_nm')):g}nm/"
            f"{finite_float(first.get('dose_mj')):g}mj/"
            f"CD{finite_float(first.get('design_cd_nm')):g}/#{sample}"
        )

    ax.errorbar(
        x_positions,
        np.asarray(means),
        yerr=np.asarray(stds),
        fmt="o",
        capsize=3,
        linewidth=1.0,
        label="image mean ± object SD",
    )
    ax.set_xticks(x_positions)
    ax.set_xticklabels(labels, rotation=70, ha="right", fontsize=8)
    ax.set_ylabel("Circularity 4πA/P²")
    ax.set_title("Via circularity by image")
    all_values = g["_circ"].to_numpy(float)
    lo = max(0.0, float(np.min(all_values)) - 0.04)
    hi = min(1.05, max(1.0, float(np.max(all_values)) + 0.03))
    if hi > lo:
        ax.set_ylim(lo, hi)
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def save_via_circularity_distribution_plot(via_df: pd.DataFrame, output_path: Path) -> None:
    """Histogram of circularity for all accepted Via objects."""
    g = accepted_via_rows(via_df)
    if g.empty or "circularity_4piA_P2" not in g.columns:
        return
    values = pd.to_numeric(g["circularity_4piA_P2"], errors="coerce").to_numpy(float)
    values = values[np.isfinite(values)]
    if len(values) == 0:
        return
    bins = int(np.clip(round(2.0 * math.sqrt(len(values))), 8, 30))
    mean_value = float(np.mean(values))
    median_value = float(np.median(values))

    fig, ax = plt.subplots(figsize=(7.4, 5.6))
    ax.hist(values, bins=bins, alpha=0.75, edgecolor="black")
    ax.axvline(mean_value, linestyle="--", linewidth=1.2, label=f"mean={mean_value:.4f}")
    ax.axvline(median_value, linestyle=":", linewidth=1.2, label=f"median={median_value:.4f}")
    ax.set_xlabel("Circularity 4πA/P²")
    ax.set_ylabel("Accepted Via count")
    ax.set_title("Via circularity distribution")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


METRIC_DISPLAY_NAMES = {
    "via_diameter": "Via CD",
    "trench_width": "Trench CD",
    "space_width": "Space CD",
}

METRIC_MARKERS = {
    "via_diameter": "o",
    "trench_width": "s",
    "space_width": "^",
}


def save_combined_design_actual_plot(
    data: pd.DataFrame,
    measured_column: str,
    output_path: Path,
    title: str,
    y_label: str,
) -> None:
    """Plot Via, Trench and Space together without dropping any metric type."""
    if data.empty or measured_column not in data.columns:
        return
    finite_groups: list[tuple[np.ndarray, np.ndarray]] = []
    fig, ax = plt.subplots(figsize=(7.6, 6.2))
    for metric in ("via_diameter", "trench_width", "space_width"):
        group = data[data["metric"] == metric]
        if group.empty:
            continue
        x = pd.to_numeric(group["design_nm"], errors="coerce").to_numpy(float)
        y = pd.to_numeric(group[measured_column], errors="coerce").to_numpy(float)
        finite = np.isfinite(x) & np.isfinite(y)
        if not np.any(finite):
            continue
        x = x[finite]
        y = y[finite]
        finite_groups.append((x, y))
        ax.scatter(
            x,
            y,
            alpha=0.72,
            marker=METRIC_MARKERS[metric],
            label=METRIC_DISPLAY_NAMES[metric],
        )
    if not finite_groups:
        plt.close(fig)
        return
    all_x = np.concatenate([values[0] for values in finite_groups])
    all_y = np.concatenate([values[1] for values in finite_groups])
    lo = float(min(np.min(all_x), np.min(all_y)))
    hi = float(max(np.max(all_x), np.max(all_y)))
    pad = max(1.0, 0.08 * (hi - lo if hi > lo else hi if hi > 0 else 1.0))
    ax.plot(
        [lo - pad, hi + pad],
        [lo - pad, hi + pad],
        linestyle="--",
        linewidth=1.2,
        label="measured = design",
    )
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_title(title)
    ax.set_xlabel("Design (nm)")
    ax.set_ylabel(y_label)
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def save_combined_bias_vs_design_plot(
    data: pd.DataFrame,
    output_path: Path,
    title: str,
) -> None:
    if data.empty or "bias_nm" not in data.columns:
        return
    fig, ax = plt.subplots(figsize=(8.0, 5.8))
    plotted = False
    for metric in ("via_diameter", "trench_width", "space_width"):
        group = data[data["metric"] == metric]
        if group.empty:
            continue
        x = pd.to_numeric(group["design_nm"], errors="coerce").to_numpy(float)
        y = pd.to_numeric(group["bias_nm"], errors="coerce").to_numpy(float)
        finite = np.isfinite(x) & np.isfinite(y)
        if not np.any(finite):
            continue
        plotted = True
        ax.scatter(
            x[finite],
            y[finite],
            alpha=0.72,
            marker=METRIC_MARKERS[metric],
            label=METRIC_DISPLAY_NAMES[metric],
        )
    if not plotted:
        plt.close(fig)
        return
    ax.axhline(0.0, linewidth=1.0)
    ax.set_title(title)
    ax.set_xlabel("Design (nm)")
    ax.set_ylabel("Measured - design (nm)")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def dataframe_or_empty(rows: Sequence[dict[str, Any]]) -> pd.DataFrame:
    return pd.DataFrame(list(rows)) if rows else pd.DataFrame()


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")


def autofit_worksheet(ws, max_width: int = 48) -> None:
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for col_idx, column_cells in enumerate(ws.iter_cols(1, ws.max_column), start=1):
        length = 0
        for cell in column_cells[: min(ws.max_row, 300)]:
            value = "" if cell.value is None else str(cell.value)
            length = max(length, len(value))
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max(10, length + 2), max_width)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, float):
                cell.number_format = "0.0000"
            cell.alignment = Alignment(vertical="top")


def write_excel(
    output_path: Path,
    image_df: pd.DataFrame,
    condition_df: pd.DataFrame,
    object_long_df: pd.DataFrame,
    via_df: pd.DataFrame,
    trench_df: pd.DataFrame,
    space_df: pd.DataFrame,
    errors_df: pd.DataFrame,
    settings_df: pd.DataFrame,
) -> None:
    sheets = {
        "image_summary": image_df,
        "condition_summary": condition_df,
        "all_objects_long": object_long_df,
        "via_objects": via_df,
        "trench_objects": trench_df,
        "space_objects": space_df,
        "processing_errors": errors_df,
        "settings": settings_df,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for name, df in sheets.items():
            safe_df = df.copy()
            if safe_df.empty and len(safe_df.columns) == 0:
                safe_df = pd.DataFrame({"note": ["No records"]})
            safe_df.to_excel(writer, sheet_name=name[:31], index=False)
        for ws in writer.book.worksheets:
            autofit_worksheet(ws)


def settings_table(general: GeneralConfig, via: ViaConfig, trench: TrenchConfig) -> pd.DataFrame:
    rows = []
    for section, obj in (("general", general), ("via", via), ("trench", trench)):
        for k, v in asdict(obj).items():
            rows.append({"section": section, "parameter": k, "value": str(v)})
    rows.insert(0, {"section": "script", "parameter": "version", "value": SCRIPT_VERSION})
    return pd.DataFrame(rows)


def jsonable_config(obj: Any) -> Any:
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, tuple):
        return list(obj)
    if isinstance(obj, dict):
        return {k: jsonable_config(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [jsonable_config(v) for v in obj]
    return obj


# ============================================================
# 6. 批处理主流程
# ============================================================
def annotation_path(output_dir: Path, parsed: ParsedImage) -> Path:
    # 镜像输入目录结构，并完整保留原 PNG 文件名（包括大小写扩展名）。
    return output_dir / "annotated" / parsed.folder_name / parsed.path.name


def debug_path(output_dir: Path, parsed: ParsedImage, name: str) -> Path:
    kind = "Via" if parsed.pattern == "via" else "Trench"
    return output_dir / "debug" / parsed.folder_name / kind / f"{parsed.path.stem}_{name}.png"


def process_all(general: GeneralConfig, via_cfg: ViaConfig, trench_cfg: TrenchConfig) -> dict[str, Path]:
    general.validate()
    out_dir = general.resolved_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)

    parsed_images, discovery_errors = discover_images(general)
    if not parsed_images:
        raise RuntimeError(
            "没有找到可处理的 PNG。程序会递归扫描 root，并自动排除输出目录。"
        )

    print(f"脚本版本：{SCRIPT_VERSION}")
    print(f"输入目录：{general.root_dir}")
    print(f"输出目录：{out_dir}")
    print(f"整目录图案类型：{(general.force_pattern or '').upper()}")
    print(f"找到 {len(parsed_images)} 张 PNG（未按文件夹名或文件名过滤）。")

    via_rows: list[dict[str, Any]] = []
    trench_rows: list[dict[str, Any]] = []
    space_rows: list[dict[str, Any]] = []
    image_rows: list[dict[str, Any]] = []
    errors = list(discovery_errors)

    for idx, parsed in enumerate(parsed_images, start=1):
        print(f"[{idx}/{len(parsed_images)}] {parsed.pattern.upper():7s} {parsed.path.name}", flush=True)
        try:
            gray = read_gray_png(parsed.path)
            if parsed.pattern == "via":
                rows, summary, annotated, debug = measure_via_image(parsed, gray, general, via_cfg)
                via_rows.extend(rows)
            else:
                trows, srows, summary, annotated, debug = measure_trench_image(parsed, gray, general, trench_cfg)
                trench_rows.extend(trows)
                space_rows.extend(srows)
            # 文件夹标称值与文件名第一字段不一致时，仅警告，不停止。
            mismatch = (
                np.isfinite(parsed.folder_nominal_nm)
                and abs(parsed.folder_nominal_nm - parsed.pretreatment_nm) > 1e-6
            )
            summary["folder_filename_pretreatment_mismatch"] = bool(mismatch)
            image_rows.append(summary)
            unicode_imwrite(annotation_path(out_dir, parsed), annotated)
            if general.save_debug_masks:
                for name, img in debug.items():
                    unicode_imwrite(debug_path(out_dir, parsed, name), img)
        except Exception as exc:
            errors.append({
                "image": parsed.path.name,
                "path": str(parsed.path),
                "pattern": parsed.pattern,
                "stage": "measurement",
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "traceback": traceback.format_exc(),
            })
            image_rows.append({
                "folder_name": parsed.folder_name,
                "folder_nominal_nm": parsed.folder_nominal_nm,
                "pretreatment_nm": parsed.pretreatment_nm,
                "dose_mj": parsed.dose_mj,
                "sample_id": parsed.sample_id,
                "metadata_source": parsed.metadata_source,
                "auto_pattern_score": parsed.auto_pattern_score,
                "auto_gradient_x_to_y_ratio": parsed.auto_gradient_x_to_y_ratio,
                "image": parsed.path.name,
                "path": str(parsed.path),
                "pattern": parsed.pattern,
                "status": "ERROR",
                "design_via_nm": parsed.design_via_nm,
                "design_trench_nm": parsed.design_trench_nm,
                "design_space_nm": parsed.design_space_nm,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            })
            print(f"  ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
            if not general.continue_on_error:
                raise

    image_df = dataframe_or_empty(image_rows)
    via_df = dataframe_or_empty(via_rows)
    trench_df = dataframe_or_empty(trench_rows)
    space_df = dataframe_or_empty(space_rows)
    errors_df = dataframe_or_empty(errors)
    condition_df = build_condition_summary(image_df)
    object_long_df = build_long_object_metrics(via_df, trench_df, space_df)
    settings_df = settings_table(general, via_cfg, trench_cfg)

    outputs = {
        "excel": out_dir / "CD_measurement_200K_results.xlsx",
        "image_summary": out_dir / "image_summary.csv",
        "condition_summary": out_dir / "condition_summary.csv",
        "all_objects_long": out_dir / "all_objects_long.csv",
        "via_objects": out_dir / "via_objects.csv",
        "trench_objects": out_dir / "trench_objects.csv",
        "space_objects": out_dir / "space_objects.csv",
        "errors": out_dir / "processing_errors.csv",
        "settings": out_dir / "settings.json",
    }

    write_csv(image_df, outputs["image_summary"])
    write_csv(condition_df, outputs["condition_summary"])
    write_csv(object_long_df, outputs["all_objects_long"])
    write_csv(via_df, outputs["via_objects"])
    write_csv(trench_df, outputs["trench_objects"])
    write_csv(space_df, outputs["space_objects"])
    write_csv(errors_df, outputs["errors"])
    write_excel(
        outputs["excel"],
        image_df,
        condition_df,
        object_long_df,
        via_df,
        trench_df,
        space_df,
        errors_df,
        settings_df,
    )

    settings_payload = {
        "script_version": SCRIPT_VERSION,
        "general": jsonable_config(asdict(general)),
        "via": jsonable_config(asdict(via_cfg)),
        "trench": jsonable_config(asdict(trench_cfg)),
        "processed_image_count": len(parsed_images),
        "successful_image_count": int((image_df.get("status", pd.Series(dtype=str)) == "OK").sum()) if not image_df.empty else 0,
        "via_object_count": len(via_df),
        "trench_object_count": len(trench_df),
        "space_object_count": len(space_df),
        "all_object_measurement_count": len(object_long_df),
        "error_count": len(errors_df),
    }
    outputs["settings"].write_text(json.dumps(settings_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    long_df = build_long_image_metrics(image_df)
    plot_dir = out_dir / "plots"
    for metric in ("via_diameter", "trench_width", "space_width"):
        save_design_actual_plot(long_df, metric, plot_dir / f"{metric}_design_vs_measured.png")
        save_bias_plot(long_df, metric, plot_dir / f"{metric}_per_image_bias.png")

    save_via_circularity_per_image_plot(
        via_df,
        plot_dir / "via_circularity_per_image.png",
    )
    save_via_circularity_distribution_plot(
        via_df,
        plot_dir / "via_circularity_distribution.png",
    )

    # Three-metric overview at both image-mean and accepted-object levels.
    save_combined_design_actual_plot(
        long_df,
        "actual_image_mean_nm",
        plot_dir / "all_metrics_image_mean_design_vs_measured.png",
        "Via / Trench / Space: image means vs design",
        "Measured image mean (nm)",
    )
    save_combined_bias_vs_design_plot(
        long_df,
        plot_dir / "all_metrics_image_mean_bias_vs_design.png",
        "Via / Trench / Space: image-mean bias",
    )
    save_combined_design_actual_plot(
        object_long_df,
        "measured_object_nm",
        plot_dir / "all_metrics_object_design_vs_measured.png",
        "Via / Trench / Space: every accepted object vs design",
        "Measured object CD (nm)",
    )
    save_combined_bias_vs_design_plot(
        object_long_df,
        plot_dir / "all_metrics_object_bias_vs_design.png",
        "Via / Trench / Space: every accepted object bias",
    )

    print("\n处理完成：")
    print(f"  图像：{len(parsed_images)}")
    print(f"  Via 圆孔：{len(via_df)}")
    print(f"  Trench：{len(trench_df)}")
    print(f"  Space：{len(space_df)}")
    print(f"  错误/警告记录：{len(errors_df)}")
    print(f"  Excel：{outputs['excel']}")
    print(f"  Annotated：{out_dir / 'annotated'}")
    return outputs


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "递归处理 root 下所有 SEM PNG：不按目录名/文件名过滤，由 --pattern 指定整目录为 Via/Trench，"
            "并统计 Via/Trench/Space 与 Via 圆形度。"
        )
    )
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT, help=f"输入根目录；默认：{DEFAULT_ROOT}")
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="输出目录；默认在 root 下创建 CD_measure_output_200K_V1_7",
    )
    parser.add_argument("--pixel-size", type=float, default=1.3181, help="nm/pixel；默认 1.3181")
    parser.add_argument(
        "--pattern",
        type=str.casefold,
        choices=("via", "trench"),
        required=True,
        help="必填：整个 root（含所有子文件夹）的统一图案类型",
    )
    parser.add_argument("--via-reference-nm", type=float, default=None, help="可选：统一 Via 检测参考直径")
    parser.add_argument("--trench-reference-nm", type=float, default=None, help="可选：统一 Trench 检测参考宽度")
    parser.add_argument("--space-reference-nm", type=float, default=None, help="可选：统一 Space 检测参考宽度")
    parser.add_argument("--save-debug-masks", action="store_true", help="额外保存 via response / trench profile 调试图")
    parser.add_argument("--stop-on-error", action="store_true", help="任一图出错后立即停止；默认记录错误后继续")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    general = GeneralConfig(
        root_dir=args.root,
        output_dir=args.output,
        pixel_size_nm=args.pixel_size,
        force_pattern=args.pattern,
        via_reference_nm=args.via_reference_nm,
        trench_reference_nm=args.trench_reference_nm,
        space_reference_nm=args.space_reference_nm,
        save_debug_masks=bool(args.save_debug_masks),
        continue_on_error=not bool(args.stop_on_error),
    )
    via_cfg = ViaConfig()
    trench_cfg = TrenchConfig()
    try:
        process_all(general, via_cfg, trench_cfg)
        return 0
    except KeyboardInterrupt:
        print("用户中断。", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"程序失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
