#!/usr/bin/env python3
"""Portable V1.13 numerical and complete CLI validation checks (no SEM data needed)."""
from pathlib import Path
from types import SimpleNamespace
from itertools import product
import argparse
import json
import math
import numpy as np
from scipy.special import erf, erfinv
import sem_cd_measure_200k_batch_V1_13 as entry
from cdsem_v113_parameters import validate_args
from cdsem_v113_selection import choose_objects
from cdsem_v113_path_erf import viterbi_path, fit_erf, apply_final_flyers
import cdsem_v112_psd as psd


def checked(argv):
    args=entry.build_parser().parse_args(argv)
    validate_args(args,argv)
    return args


def check_cli():
    parser=entry.build_parser();audit=[]
    custom=dict(root='input',output='output',via_reference_nm=60,trench_reference_nm=60,
        line_reference_nm=60,space_reference_nm=40,center_x=255.5,center_y=255.5,
        meas_area_width=480,meas_area_height=480,extend_length=300,min_number=2,
        candidate_dark_tolerance=15,candidate_min_contrast=3,machine_excel='reference.xlsx',
        smoothing_pixel=4,postfilter_window=8,group_size=3,max_number=5,sample_number=96,
        machine_end_row=0,machine_image_column='AA')
    for action in parser._actions:
        if action.dest=='help':continue
        flag=action.option_strings[0]
        values=list(action.choices) if action.choices else [custom.get(action.dest,action.default)]
        for value in values:
            context=['--pattern','trench']
            if action.dest=='line_reference_nm':context=['--pattern','line']
            if action.dest=='via_reference_nm':context=['--pattern','via']
            if flag.startswith('--viterbi-'):context+=['--viterbi','1']
            if flag.startswith('--erf-') and flag!='--erf-fit':context+=['--erf-fit','1']
            if flag=='--psd-max-gap':context+=['--psd-gap-mode','interpolate']
            argv=context+[flag]
            if not isinstance(action,argparse._StoreTrueAction):argv.append(str(value))
            checked(argv)
        audit.append(dict(parameter=flag,default=str(action.default),tested_values=values,status='PASS'))
    defaults=checked(['--pattern','trench'])
    assert defaults.viterbi==defaults.erf_fit==defaults.edge_continuity==0
    for n in [1,2,4,5,10]:
        a=checked(['--pattern','trench','--max-number',str(n)])
        assert a.max_number==n and a.min_number==min(3,n)
    bad=[['--max-number','0'],['--min-number','5','--max-number','4'],
         ['--pixel-size','nan'],['--smoothing-pixel','0'],['--threshold-left','100'],
         ['--minimum-valid-fraction','1.1'],['--group-size','129'],['--edge-continuity','101'],
         ['--erf-window','2','--erf-fit','1'],['--viterbi-weight','7'],
         ['--psd-method','periodogram','--psd-overlap','0.2'],
         ['--psd-max-gap','2'],['--skip-psd','--psd-axis','normal'],
         ['--machine-image-column','2'],['--pattern','via','--max-number','4'],
         ['--pattern','line','--line-reference-nm','60','--trench-reference-nm','70']]
    for extra in bad:
        try:checked(['--pattern','trench']+extra)
        except ValueError:pass
        else:raise AssertionError(f'Invalid options accepted: {extra}')
    return audit,len(bad)


def check_selection():
    rows=[dict(basin_valid=True,brightness_true_trench=True,candidate_center_x_px=x,
               brightness_core_mean_raw=20,basin_core_mean_raw=20) for x in [60,160,260,360,460,560]]
    for n in [1,2,4,5,6,10]:
        p=entry.v5.MeasurementParams(max_number=n,min_number=min(3,n))
        selected=choose_objects([],rows,260,p,lambda *a:[])
        assert len(selected)==min(n,len(rows))
        assert len({r['candidate_center_x_px'] for role,r in selected})==len(selected)
    p=entry.v5.MeasurementParams(max_number=6,candidate_dark_mean_tolerance_8bit=5)
    rows[-1]['brightness_core_mean_raw']=60
    assert len(choose_objects([],rows,260,p,lambda *a:[]))==5


def check_viterbi():
    def state(l,r,c):return dict(left=l,right=r,cost=c)
    layers=[[state(0,10,1),state(3,13,.4)],[],[state(.5,10.5,.3),state(4,14,.1)],
            [state(.8,10.8,.2),state(5,15,.2)],[state(1,11,.4)]]
    weight,jump,gapcost=2.,1.5,3.
    selected,score=viterbi_path(layers,weight,jump,gapcost)
    brute=math.inf
    for choice in product(*[range(-1,len(layer)) for layer in layers]):
        path=[(i,layers[i][k]) for i,k in enumerate(choice) if k>=0]
        cost=(len(layers)-len(path))*gapcost+sum(c['cost'] for i,c in path)
        for (j,a),(i,b) in zip(path,path[1:]):
            d=np.array([b['left']-a['left'],b['right']-a['right']]);den=jump*(i-j)
            cost+=weight*np.sum((d/den)**2) if np.max(abs(d))<=den else math.inf
        brute=min(brute,cost)
    assert np.isclose(score,brute) and 1 not in selected
    layers=[[state(0,40,1)]+([state(20,60,0)] if 4<=i<10 else []) for i in range(16)]
    chosen,_=viterbi_path(layers,5,2,6)
    assert len(chosen)==16 and all(c['left']==0 for c in chosen.values())
    chosen,_=viterbi_path([[state(0,10,0)],[],[],[state(3,13,0)]],1,1,6)
    assert set(chosen)=={0,3}  # true slot distance, not compressed distance


def check_erf():
    x=np.arange(140.);x0=60.35;sigma=1.7
    for side,sign in [('left',-1),('right',1)]:
        profile=30+180*.5*(1+sign*erf((x-x0)/(np.sqrt(2)*sigma)))
        for percent in [35,50,65]:
            expected=x0+sign*np.sqrt(2)*sigma*erfinv(2*percent/100-1)
            fitted,reason=fit_erf(profile,expected+.2,side,percent,8,2,.1)
            assert not reason and abs(fitted['x']-expected)<1e-5
            assert abs(fitted['sigma']-sigma)<1e-5
    assert fit_erf(np.ones(100),50,'left',50,8,2,.2)[0] is None


def check_windows_groups_flyers():
    a=np.arange(20.)
    for n in [1,2,3,4,8]:
        actual=entry.v5.moving_average_reflect(a,n)
        expected=np.convolve(np.pad(a,(n//2,n-1-n//2),mode='reflect'),np.ones(n)/n,mode='valid')
        assert len(actual)==len(a) and np.allclose(actual,expected)
    assert entry.v5.rolling_median_reference(a,8)[10]==9.5
    from unittest.mock import patch
    gradient=np.zeros(100);gradient[20]=-30;gradient[40]=-50
    for engine in [entry.v5,entry.v13v5]:
        with patch.object(engine,'edge_topology_levels',return_value=(220.,20.)):
            found=[]
            for order in [1,2,3,99]:
                found.append(engine.adaptive_peak_indices(np.full(100,120.),gradient,5,60,
                    'negative',order,80,3,0,1,25,50,7,1,2.5)[0])
            assert found==[20,40,None,None],found
    for n in [1,3,4,8]:
        grouped=psd.strict_group(np.arange(128.),n)
        assert len(grouped)==128//n and grouped[0]==(n-1)/2
    p=entry.v5.MeasurementParams(pixel_size_nm=1,flyer_left_offset_px=3,flyer_right_offset_px=3)
    for mode in ['reserve','remove','replace']:
        p.flyer_mode=mode;l=np.full(11,20.);r=np.full(11,60.);l[5]=30;cd=r-l
        rows=[dict(valid=True,left_edge_x=l[i],right_edge_x=r[i],local_cd_nm=cd[i]) for i in range(11)]
        apply_final_flyers(l,r,cd,rows,p,entry.v5)
        if mode=='reserve':assert l[5]==30 and cd[5]==30
        if mode=='remove':assert np.isnan(l[5]) and not rows[5]['valid']
        if mode=='replace':assert l[5]==20 and cd[5]==40 and rows[5]['continuity_synthetic']


def main():
    import self_check_V1_10 as legacy
    import self_check_V1_12 as inherited
    legacy.entry=entry;inherited.entry=entry
    legacy.check_defaults();legacy.check_source_routing();legacy.check_ideal_tilt_rotation()
    inherited.check_psd();inherited.check_continuity()
    audit,bad_count=check_cli();check_selection();check_viterbi();check_erf();check_windows_groups_flyers()
    parser=argparse.ArgumentParser();parser.add_argument('--report',type=Path);args=parser.parse_args()
    if args.report:
        args.report.write_text(json.dumps(dict(version='V1.13',parameters=audit,invalid_cases_rejected=bad_count,
            numerical_checks='PASS'),indent=2,ensure_ascii=False),encoding='utf-8')
    print(f'V1.13 SELF-CHECK PASSED: {len(audit)} CLI parameters, {bad_count} invalid combinations, '
          'unlimited candidate count, exact Viterbi objective, ERF subpixels, even windows, '
          'Flyer propagation, arbitrary grouping, hybrid routing, rotation, PSD, continuity')

if __name__=='__main__':main()
