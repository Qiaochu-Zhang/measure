$ErrorActionPreference = "Stop"

$InputDir = "C:\Users\z00027644\Downloads\CD measure\CD measure"
$Pattern = "trench"

python .\sem_cd_measure_200k_batch_V1_10.py `
  --root $InputDir `
  --pattern $Pattern `
  --pixel-size 1.3181

if ($LASTEXITCODE -ne 0) {
    throw "V1.10 pipeline failed with exit code $LASTEXITCODE"
}

Write-Host ""
Write-Host "Finished. Output:"
Write-Host "  $InputDir\CD_measure_output_200K_V1_10"
