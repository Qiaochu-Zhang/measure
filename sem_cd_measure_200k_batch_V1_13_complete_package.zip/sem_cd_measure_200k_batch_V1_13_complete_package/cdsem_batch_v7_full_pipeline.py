#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CD-SEM V7 Full Pipeline
===========================

Purpose
-------
- Keep V1.15 Basin-First only for rough trench/SPACE identity.
- Keep the V5/V2 concrete edge tracking and its raw CD/LER/LWR as the baseline.
- Do NOT apply empirical scale/offset fitting to imitate a machine result.
- Recalculate several physically plausible implementation variants after V2 has
  found a reliable edge path, so the user can compare which hidden machine detail
  best explains stable CD bias and unstable LWR/CDR bias.
- Report horizontal x-width and fitted-trench-normal/slanted width.
- Exclude five user-confirmed low-quality images before calculation and comparison.
- Automatically compare every method with Data.xlsx/v2 and rank multi-metric candidates.

The program is a simulator based on documented settings and inferred details. It
is not Oriental Crystal Source official source code.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
import traceback
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    from scipy.ndimage import gaussian_filter1d

    import cdsem_batch_v5_v115_locator_v2_measure as v5
    import select_cdsem_candidate_methods as candidate_selector
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "Missing dependency or V5/V1.15 module. Keep these files in one folder:\n"
        "  cdsem_batch_v6_physical_variants.py\n"
        "  cdsem_batch_v5_v115_locator_v2_measure.py\n"
        "  cdsem_basin_first_v115.py\n"
        "  cdsem_pattern_brightness_v114.py\n"
        "  select_cdsem_candidate_methods.py\n"
        "Install: pip install numpy pandas scipy matplotlib tifffile openpyxl\n"
        f"Original error: {exc}"
    ) from exc


EPS = 1e-12
ALGORITHM_VERSION = "V7_V115_LOCATOR_V2_EDGE_PHYSICAL_VARIANTS_MACHINE_COMPARE_SELECTION"
COMPARISON_VERSION = "MACHINE_COMPARE_DATA_XLSX_V2_WITH_SKIP"

# 用户明确指定的低质量图像：不计算，也不参与机台比较/候选筛选。
DEFAULT_SKIP_IMAGE_STEMS = (
    "S10_M0120-01MS",
    "S10_M0232-01MS",
    "S10_M0344-01MS",
    "S10_M0456-01MS",
    "S10_M0568-01MS",
)
DEFAULT_SKIP_REASON = "manual_skip_low_image_quality"


@dataclass(frozen=True)
class EdgeVariantSpec:
    name: str
    category: str
    description: str
    kind: str  # raw / reference / profile_redetect / pre_postfilter

    # Profile construction
    average_range_px: int = 32
    smoothing_mode: str = "moving_average"  # moving_average / gaussian / none
    smoothing_value: float = 3.0

    # Reference-based threshold re-crossing
    bright_scope: str = "local"  # local / global
    dark_scope: str = "local"  # local / global
    bright_stat: str = "mean"  # mean / median / percentile
    bright_percentile: float = 70.0
    dark_stat: str = "median"  # mean / median / percentile
    dark_percentile: float = 30.0
    threshold_pct: float = 50.0

    # Whether this variant is a likely implementation candidate or only a
    # sensitivity/control test.
    interpretation: str = "candidate"


@dataclass
class PhysicalVariantParams:
    reference_band_px: int = 9
    reference_gap_px: int = 2
    reference_crossing_radius_px: float = 5.0
    reference_max_shift_px: float = 3.0
    reference_min_samples: int = 24

    profile_redetect_radius_px: float = 6.0
    profile_redetect_max_shift_px: float = 4.0

    group_size: int = 4
    save_diagnostic_plots: bool = True
    save_sample_variant_edges: bool = True

    def validate(self) -> None:
        if self.reference_band_px < 2:
            raise ValueError("reference_band_px must be >= 2")
        if self.reference_gap_px < 0:
            raise ValueError("reference_gap_px must be >= 0")
        if self.reference_crossing_radius_px <= 0:
            raise ValueError("reference_crossing_radius_px must be positive")
        if self.reference_max_shift_px <= 0:
            raise ValueError("reference_max_shift_px must be positive")
        if self.reference_min_samples < 2:
            raise ValueError("reference_min_samples must be >= 2")
        if self.profile_redetect_radius_px <= 0:
            raise ValueError("profile_redetect_radius_px must be positive")
        if self.profile_redetect_max_shift_px <= 0:
            raise ValueError("profile_redetect_max_shift_px must be positive")
        if self.group_size < 1:
            raise ValueError("group_size must be >= 1")


def build_edge_variants(base_average_range: int, base_smoothing: int) -> list[EdgeVariantSpec]:
    """Fixed, non-fitted physical/control variants.

    No number below is derived by solving against the user's machine values.
    Each variant corresponds to a plausible interpretation of a UI setting or
    an implementation detail that can be checked independently.
    """
    return [
        EdgeVariantSpec(
            name="raw_v2",
            category="baseline",
            description=(
                "Frozen V5/V2 accepted edge sequence: local gradient-peak level, "
                "local central dark reference, Average Range as configured, moving average."
            ),
            kind="raw",
        ),
        EdgeVariantSpec(
            name="initial_before_recovery",
            category="point_handling",
            description=(
                "V2 edge sequence before the final robust postfilter. Diagnostic only; "
                "tests whether point rejection explains LWR differences."
            ),
            kind="pre_postfilter",
            interpretation="diagnostic",
        ),
        EdgeVariantSpec(
            name="local_plateau_mean50",
            category="threshold_reference",
            description=(
                "At each Y, use the mean of the bright line-side band and the median "
                "of the trench central 40% as the 50% threshold references."
            ),
            kind="reference",
            average_range_px=base_average_range,
            smoothing_mode="moving_average",
            smoothing_value=float(base_smoothing),
            bright_scope="local",
            dark_scope="local",
            bright_stat="mean",
            threshold_pct=50.0,
        ),
        EdgeVariantSpec(
            name="global_plateau_mean50",
            category="threshold_reference",
            description=(
                "Use one robust bright/dark plateau reference for the whole SPACE, "
                "then re-cross at 50% near the frozen V2 path. Tests reference jitter."
            ),
            kind="reference",
            average_range_px=base_average_range,
            smoothing_mode="moving_average",
            smoothing_value=float(base_smoothing),
            bright_scope="global",
            dark_scope="global",
            bright_stat="mean",
            threshold_pct=50.0,
        ),
        EdgeVariantSpec(
            name="global_plateau_p70_50",
            category="threshold_reference",
            description=(
                "Whole-SPACE robust references; bright line level is the local 70th "
                "percentile before robust Y aggregation, threshold remains 50%."
            ),
            kind="reference",
            average_range_px=base_average_range,
            smoothing_mode="moving_average",
            smoothing_value=float(base_smoothing),
            bright_scope="global",
            dark_scope="global",
            bright_stat="percentile",
            bright_percentile=70.0,
            threshold_pct=50.0,
        ),
        EdgeVariantSpec(
            name="global_bright_local_dark50",
            category="threshold_reference",
            description=(
                "Stabilize only the left/right bright-line reference across Y; keep "
                "the dark trench reference local. Isolates bright-reference jitter."
            ),
            kind="reference",
            average_range_px=base_average_range,
            smoothing_mode="moving_average",
            smoothing_value=float(base_smoothing),
            bright_scope="global",
            dark_scope="local",
            bright_stat="mean",
            threshold_pct=50.0,
        ),
        EdgeVariantSpec(
            name="local_bright_global_dark50",
            category="threshold_reference",
            description=(
                "Keep bright-line references local but stabilize the trench dark "
                "reference across Y. Isolates dark-reference jitter."
            ),
            kind="reference",
            average_range_px=base_average_range,
            smoothing_mode="moving_average",
            smoothing_value=float(base_smoothing),
            bright_scope="local",
            dark_scope="global",
            bright_stat="mean",
            threshold_pct=50.0,
        ),
        EdgeVariantSpec(
            name="global_plateau_mean45",
            category="threshold_sensitivity",
            description=(
                "Global plateau references with a 45% crossing. Sensitivity control, "
                "not a claim that the machine ignores the displayed 50%."
            ),
            kind="reference",
            average_range_px=base_average_range,
            smoothing_mode="moving_average",
            smoothing_value=float(base_smoothing),
            bright_scope="global",
            dark_scope="global",
            bright_stat="mean",
            threshold_pct=45.0,
            interpretation="sensitivity",
        ),
        EdgeVariantSpec(
            name="global_plateau_mean55",
            category="threshold_sensitivity",
            description=(
                "Global plateau references with a 55% crossing. Tests whether a "
                "different reference definition creates a higher effective threshold."
            ),
            kind="reference",
            average_range_px=base_average_range,
            smoothing_mode="moving_average",
            smoothing_value=float(base_smoothing),
            bright_scope="global",
            dark_scope="global",
            bright_stat="mean",
            threshold_pct=55.0,
            interpretation="sensitivity",
        ),
        EdgeVariantSpec(
            name="avg16_ma3_v2ref",
            category="average_range",
            description=(
                "Rebuild each profile using 16 total Y rows, then run the V2 detector "
                "only near the frozen raw edge. Tests stronger retention of local variation."
            ),
            kind="profile_redetect",
            average_range_px=16,
            smoothing_mode="moving_average",
            smoothing_value=3.0,
        ),
        EdgeVariantSpec(
            name="avg64_ma3_v2ref",
            category="average_range",
            description=(
                "Rebuild each profile using 64 total Y rows. Tests whether Average "
                "Range=32 means +/-32 rows rather than 32 rows in total."
            ),
            kind="profile_redetect",
            average_range_px=64,
            smoothing_mode="moving_average",
            smoothing_value=3.0,
        ),
        EdgeVariantSpec(
            name="avg32_gaussian1_v2ref",
            category="smoothing",
            description=(
                "Use Average Range=32 and Gaussian sigma=1 px instead of a 3-point "
                "moving average; re-detect only near the frozen V2 edge."
            ),
            kind="profile_redetect",
            average_range_px=base_average_range,
            smoothing_mode="gaussian",
            smoothing_value=1.0,
        ),
        EdgeVariantSpec(
            name="avg32_ma5_v2ref",
            category="smoothing",
            description=(
                "Use a 5-point moving average with Average Range=32; re-detect only "
                "near the frozen V2 edge. Smoothing sensitivity control."
            ),
            kind="profile_redetect",
            average_range_px=base_average_range,
            smoothing_mode="moving_average",
            smoothing_value=5.0,
            interpretation="sensitivity",
        ),
        EdgeVariantSpec(
            name="avg32_none_v2ref",
            category="smoothing",
            description=(
                "No 1D smoothing after Average Range=32; re-detect only near the "
                "frozen V2 edge. Smoothing sensitivity control."
            ),
            kind="profile_redetect",
            average_range_px=base_average_range,
            smoothing_mode="none",
            smoothing_value=1.0,
            interpretation="sensitivity",
        ),
    ]


def finite_array(values: Iterable[float]) -> np.ndarray:
    arr = np.asarray(list(values), dtype=np.float64)
    return arr[np.isfinite(arr)]


def finite_mean(values: Iterable[float]) -> float:
    arr = finite_array(values)
    return float(np.mean(arr)) if arr.size else math.nan


def three_sigma(values: np.ndarray, ddof: int = 0) -> float:
    arr = np.asarray(values, dtype=np.float64)
    arr = arr[np.isfinite(arr)]
    if arr.size <= ddof:
        return math.nan
    return 3.0 * float(np.std(arr - np.mean(arr), ddof=ddof))


def robust_location(values: np.ndarray) -> float:
    arr = np.asarray(values, dtype=np.float64)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return math.nan
    if arr.size < 8:
        return float(np.median(arr))
    q10, q90 = np.percentile(arr, [10.0, 90.0])
    trimmed = arr[(arr >= q10) & (arr <= q90)]
    return float(np.mean(trimmed)) if trimmed.size else float(np.median(arr))


def segment_values(profile: np.ndarray, start: float, end: float) -> np.ndarray:
    s, e = v5.clamp_int_window(start, end, int(profile.size))
    if e <= s:
        return np.empty(0, dtype=np.float64)
    values = np.asarray(profile[s:e], dtype=np.float64)
    return values[np.isfinite(values)]


def statistic(values: np.ndarray, mode: str, percentile: float) -> float:
    arr = np.asarray(values, dtype=np.float64)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return math.nan
    if mode == "mean":
        return float(np.mean(arr))
    if mode == "median":
        return float(np.median(arr))
    if mode == "percentile":
        return float(np.percentile(arr, percentile))
    raise ValueError(f"unknown statistic mode: {mode}")


def smooth_profile(profile: np.ndarray, mode: str, value: float) -> np.ndarray:
    data = np.asarray(profile, dtype=np.float64)
    if mode == "none":
        return data.copy()
    if mode == "moving_average":
        window = max(1, int(round(value)))
        if window % 2 == 0:
            window += 1
        return v5.moving_average_reflect(data, window)
    if mode == "gaussian":
        sigma = max(float(value), 1e-6)
        return gaussian_filter1d(data, sigma=sigma, mode="reflect")
    raise ValueError(f"unknown smoothing mode: {mode}")


def crossing_near_edge(
    profile: np.ndarray,
    threshold: float,
    edge_guess: float,
    side: str,
    radius_px: float,
) -> Optional[float]:
    if not np.isfinite(threshold) or not np.isfinite(edge_guess):
        return None
    start = max(0, int(math.floor(edge_guess - radius_px)))
    end = min(int(profile.size) - 1, int(math.ceil(edge_guess + radius_px)))
    candidates: list[float] = []
    for x in range(start, end):
        p0 = float(profile[x])
        p1 = float(profile[x + 1])
        if side == "left":
            matched = p0 >= threshold and p1 < threshold
        elif side == "right":
            matched = p0 < threshold and p1 >= threshold
        else:
            raise ValueError(f"unknown side: {side}")
        if not matched:
            continue
        denominator = p1 - p0
        if abs(denominator) <= EPS:
            continue
        candidates.append(float(x + (threshold - p0) / denominator))
    if not candidates:
        return None
    return min(candidates, key=lambda value: abs(value - edge_guess))


def build_profile_cache(
    image: np.ndarray,
    y_values: np.ndarray,
    average_range_px: int,
    smoothing_mode: str,
    smoothing_value: float,
    minimum_fraction: float,
) -> list[Optional[np.ndarray]]:
    profiles: list[Optional[np.ndarray]] = [None] * int(y_values.size)
    minimum_rows = minimum_fraction * average_range_px
    for index, y in enumerate(y_values):
        raw, _, _, actual = v5.average_rows_profile(image, float(y), average_range_px)
        if raw is None or actual < minimum_rows:
            continue
        profiles[index] = smooth_profile(raw, smoothing_mode, smoothing_value)
    return profiles


def line_side_values(
    profile: np.ndarray,
    edge_x: float,
    side: str,
    band_px: int,
    gap_px: int,
) -> np.ndarray:
    if side == "left":
        return segment_values(profile, edge_x - gap_px - band_px, edge_x - gap_px)
    if side == "right":
        return segment_values(profile, edge_x + gap_px, edge_x + gap_px + band_px)
    raise ValueError(side)


def reference_refinement(
    image: np.ndarray,
    y_values: np.ndarray,
    left_raw: np.ndarray,
    right_raw: np.ndarray,
    spec: EdgeVariantSpec,
    v5_params: v5.MeasurementParams,
    variant_params: PhysicalVariantParams,
    profile_cache: dict[tuple[int, str, float], list[Optional[np.ndarray]]],
) -> dict[str, Any]:
    cache_key = (spec.average_range_px, spec.smoothing_mode, float(spec.smoothing_value))
    if cache_key not in profile_cache:
        profile_cache[cache_key] = build_profile_cache(
            image,
            y_values,
            spec.average_range_px,
            spec.smoothing_mode,
            spec.smoothing_value,
            v5_params.minimum_average_range_fraction,
        )
    profiles = profile_cache[cache_key]

    n = int(y_values.size)
    left_new = np.asarray(left_raw, dtype=np.float64).copy()
    right_new = np.asarray(right_raw, dtype=np.float64).copy()
    local_dark = np.full(n, np.nan, dtype=np.float64)
    local_left_bright = np.full(n, np.nan, dtype=np.float64)
    local_right_bright = np.full(n, np.nan, dtype=np.float64)
    left_threshold = np.full(n, np.nan, dtype=np.float64)
    right_threshold = np.full(n, np.nan, dtype=np.float64)
    fallback = np.zeros(n, dtype=bool)
    shift_rejected = np.zeros(n, dtype=bool)

    raw_valid = (
        np.isfinite(left_raw)
        & np.isfinite(right_raw)
        & (np.asarray(right_raw) > np.asarray(left_raw))
    )

    for index in np.flatnonzero(raw_valid):
        profile = profiles[int(index)]
        if profile is None:
            continue
        left = float(left_raw[index])
        right = float(right_raw[index])
        width = right - left
        if width <= 0:
            continue
        dark_values = segment_values(profile, left + 0.30 * width, right - 0.30 * width)
        local_dark[index] = statistic(
            dark_values, spec.dark_stat, spec.dark_percentile
        )
        local_left_bright[index] = statistic(
            line_side_values(
                profile,
                left,
                "left",
                variant_params.reference_band_px,
                variant_params.reference_gap_px,
            ),
            spec.bright_stat,
            spec.bright_percentile,
        )
        local_right_bright[index] = statistic(
            line_side_values(
                profile,
                right,
                "right",
                variant_params.reference_band_px,
                variant_params.reference_gap_px,
            ),
            spec.bright_stat,
            spec.bright_percentile,
        )

    ref_mask = (
        raw_valid
        & np.isfinite(local_dark)
        & np.isfinite(local_left_bright)
        & np.isfinite(local_right_bright)
    )
    global_dark = robust_location(local_dark[ref_mask])
    global_left_bright = robust_location(local_left_bright[ref_mask])
    global_right_bright = robust_location(local_right_bright[ref_mask])
    enough_global = int(ref_mask.sum()) >= variant_params.reference_min_samples

    for index in np.flatnonzero(raw_valid):
        profile = profiles[int(index)]
        if profile is None:
            fallback[index] = True
            continue

        dark = local_dark[index]
        left_bright = local_left_bright[index]
        right_bright = local_right_bright[index]
        if spec.dark_scope == "global" and enough_global:
            dark = global_dark
        if spec.bright_scope == "global" and enough_global:
            left_bright = global_left_bright
            right_bright = global_right_bright

        if not all(np.isfinite(value) for value in (dark, left_bright, right_bright)):
            fallback[index] = True
            continue
        if left_bright <= dark or right_bright <= dark:
            fallback[index] = True
            continue

        left_t = dark + (spec.threshold_pct / 100.0) * (left_bright - dark)
        right_t = dark + (spec.threshold_pct / 100.0) * (right_bright - dark)
        left_threshold[index] = left_t
        right_threshold[index] = right_t

        candidate_left = crossing_near_edge(
            profile,
            left_t,
            float(left_raw[index]),
            "left",
            variant_params.reference_crossing_radius_px,
        )
        candidate_right = crossing_near_edge(
            profile,
            right_t,
            float(right_raw[index]),
            "right",
            variant_params.reference_crossing_radius_px,
        )
        if candidate_left is None or candidate_right is None or candidate_right <= candidate_left:
            fallback[index] = True
            continue
        if (
            abs(candidate_left - float(left_raw[index]))
            > variant_params.reference_max_shift_px
            or abs(candidate_right - float(right_raw[index]))
            > variant_params.reference_max_shift_px
        ):
            fallback[index] = True
            shift_rejected[index] = True
            continue
        left_new[index] = candidate_left
        right_new[index] = candidate_right

    return {
        "left": left_new,
        "right": right_new,
        "fallback": fallback,
        "shift_rejected": shift_rejected,
        "local_dark": local_dark,
        "local_left_bright": local_left_bright,
        "local_right_bright": local_right_bright,
        "left_threshold": left_threshold,
        "right_threshold": right_threshold,
        "global_dark": global_dark,
        "global_left_bright": global_left_bright,
        "global_right_bright": global_right_bright,
        "reference_sample_count": int(ref_mask.sum()),
        "enough_global_reference": bool(enough_global),
    }


def profile_redetect_refinement(
    image: np.ndarray,
    y_values: np.ndarray,
    left_raw: np.ndarray,
    right_raw: np.ndarray,
    candidate: v5.Candidate,
    spec: EdgeVariantSpec,
    v5_params: v5.MeasurementParams,
    variant_params: PhysicalVariantParams,
    profile_cache: dict[tuple[int, str, float], list[Optional[np.ndarray]]],
) -> dict[str, Any]:
    cache_key = (spec.average_range_px, spec.smoothing_mode, float(spec.smoothing_value))
    if cache_key not in profile_cache:
        profile_cache[cache_key] = build_profile_cache(
            image,
            y_values,
            spec.average_range_px,
            spec.smoothing_mode,
            spec.smoothing_value,
            v5_params.minimum_average_range_fraction,
        )
    profiles = profile_cache[cache_key]

    n = int(y_values.size)
    left_new = np.asarray(left_raw, dtype=np.float64).copy()
    right_new = np.asarray(right_raw, dtype=np.float64).copy()
    fallback = np.zeros(n, dtype=bool)
    shift_rejected = np.zeros(n, dtype=bool)

    raw_valid = (
        np.isfinite(left_raw)
        & np.isfinite(right_raw)
        & (np.asarray(right_raw) > np.asarray(left_raw))
    )
    local_params = replace(
        v5_params,
        average_range_px=spec.average_range_px,
        smoothing_pixel=max(1, int(round(spec.smoothing_value))),
    )
    for index in np.flatnonzero(raw_valid):
        profile = profiles[int(index)]
        if profile is None:
            fallback[index] = True
            continue
        edge = v5.detect_edge_pair(
            profile,
            candidate.center_x_px,
            local_params,
            anchor_left_x=float(left_raw[index]),
            anchor_right_x=float(right_raw[index]),
            search_radius_px=variant_params.profile_redetect_radius_px,
            strict_tracking=True,
        )
        if not edge.valid or edge.right_edge_x <= edge.left_edge_x:
            fallback[index] = True
            continue
        if (
            abs(edge.left_edge_x - float(left_raw[index]))
            > variant_params.profile_redetect_max_shift_px
            or abs(edge.right_edge_x - float(right_raw[index]))
            > variant_params.profile_redetect_max_shift_px
        ):
            fallback[index] = True
            shift_rejected[index] = True
            continue
        left_new[index] = edge.left_edge_x
        right_new[index] = edge.right_edge_x

    return {
        "left": left_new,
        "right": right_new,
        "fallback": fallback,
        "shift_rejected": shift_rejected,
        "reference_sample_count": int(raw_valid.sum()),
        "enough_global_reference": True,
    }


def group_mean(values: np.ndarray, group_size: int) -> np.ndarray:
    data = np.asarray(values, dtype=np.float64)
    output: list[float] = []
    for start in range(0, data.size, group_size):
        block = data[start : start + group_size]
        finite = block[np.isfinite(block)]
        output.append(float(np.mean(finite)) if finite.size else math.nan)
    return np.asarray(output, dtype=np.float64)


def detrend_preserve_mean(y: np.ndarray, values: np.ndarray, degree: int) -> np.ndarray:
    yy = np.asarray(y, dtype=np.float64)
    vv = np.asarray(values, dtype=np.float64)
    result = vv.copy()
    mask = np.isfinite(yy) & np.isfinite(vv)
    if int(mask.sum()) <= degree:
        return result
    coefficients = np.polyfit(yy[mask], vv[mask], degree)
    fit = np.polyval(coefficients, yy[mask])
    result[mask] = vv[mask] - fit + float(np.mean(vv[mask]))
    return result


def apply_stat_mode(
    y_values: np.ndarray,
    left_px: np.ndarray,
    right_px: np.ndarray,
    mode: str,
    v5_params: v5.MeasurementParams,
    group_size: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    y = np.asarray(y_values, dtype=np.float64)
    left = np.asarray(left_px, dtype=np.float64).copy()
    right = np.asarray(right_px, dtype=np.float64).copy()

    if mode == "all_submean":
        return y, left, right
    if mode == "group4_mean":
        return group_mean(y, group_size), group_mean(left, group_size), group_mean(right, group_size)
    if mode == "every4":
        indices = np.arange(0, y.size, group_size, dtype=int)
        return y[indices], left[indices], right[indices]
    if mode == "every2":
        indices = np.arange(0, y.size, 2, dtype=int)
        return y[indices], left[indices], right[indices]
    if mode in {"linear_detrend", "quadratic_detrend"}:
        degree = 1 if mode == "linear_detrend" else 2
        return y, detrend_preserve_mean(y, left, degree), detrend_preserve_mean(y, right, degree)

    valid = np.isfinite(left) & np.isfinite(right)
    valid_indices = np.flatnonzero(valid)
    if valid_indices.size:
        left_valid = left[valid]
        right_valid = right[valid]
        left_flyer, left_ref = v5.mark_flyers(left_valid, v5_params)
        right_flyer, right_ref = v5.mark_flyers(right_valid, v5_params)
        if mode == "flyer_remove":
            remove = left_flyer | right_flyer
            left[valid_indices[remove]] = np.nan
            right[valid_indices[remove]] = np.nan
            return y, left, right
        if mode == "flyer_replace":
            left_valid[left_flyer] = left_ref[left_flyer]
            right_valid[right_flyer] = right_ref[right_flyer]
            left[valid_indices] = left_valid
            right[valid_indices] = right_valid
            return y, left, right
    if mode in {"flyer_remove", "flyer_replace"}:
        return y, left, right
    raise ValueError(f"unknown stat mode: {mode}")


def sequence_metrics(
    y_values: np.ndarray,
    left_px: np.ndarray,
    right_px: np.ndarray,
    pixel_size_nm: float,
    normal_factor: float,
    ddof: int,
) -> dict[str, Any]:
    y = np.asarray(y_values, dtype=np.float64)
    left = np.asarray(left_px, dtype=np.float64)
    right = np.asarray(right_px, dtype=np.float64)
    valid = np.isfinite(y) & np.isfinite(left) & np.isfinite(right) & (right > left)
    cd_x = np.full(left.shape, np.nan, dtype=np.float64)
    cd_x[valid] = (right[valid] - left[valid]) * pixel_size_nm
    cd_slant = cd_x * normal_factor
    left_nm = left * pixel_size_nm
    right_nm = right * pixel_size_nm
    center_nm = 0.5 * (left_nm + right_nm)

    rho = math.nan
    sigma_left = math.nan
    sigma_right = math.nan
    covariance = math.nan
    lwr_from_components = math.nan
    if int(valid.sum()) >= 3:
        l_res = left_nm[valid] - np.mean(left_nm[valid])
        r_res = right_nm[valid] - np.mean(right_nm[valid])
        sigma_left = float(np.std(l_res, ddof=ddof))
        sigma_right = float(np.std(r_res, ddof=ddof))
        covariance = float(np.mean(l_res * r_res)) if ddof == 0 else float(np.cov(l_res, r_res, ddof=ddof)[0, 1])
        if sigma_left > EPS and sigma_right > EPS:
            rho = float(covariance / (sigma_left * sigma_right))
        width_variance = max(0.0, sigma_left**2 + sigma_right**2 - 2.0 * covariance)
        lwr_from_components = 3.0 * math.sqrt(width_variance)

    return {
        "y": y,
        "left": left,
        "right": right,
        "valid": valid,
        "cd_x": cd_x,
        "cd_slant": cd_slant,
        "mean_cd_px": finite_mean((right - left)[valid]),
        "mean_cd_x_nm": finite_mean(cd_x),
        "mean_cd_slant_nm": finite_mean(cd_slant),
        "ler_left_nm": three_sigma(left_nm, ddof=ddof),
        "ler_right_nm": three_sigma(right_nm, ddof=ddof),
        "lwr_x_nm": three_sigma(cd_x, ddof=ddof),
        "lwr_slant_nm": three_sigma(cd_slant, ddof=ddof),
        "centerline_3sigma_nm": three_sigma(center_nm, ddof=ddof),
        "rho_left_right": rho,
        "sigma_left_nm": sigma_left,
        "sigma_right_nm": sigma_right,
        "cov_left_right_nm2": covariance,
        "lwr_from_variance_components_nm": lwr_from_components,
        "valid_count": int(valid.sum()),
        "valid_fraction": float(valid.sum() / max(1, left.size)),
    }


def stat_modes_for_variant(variant_name: str) -> list[str]:
    if variant_name == "raw_v2":
        return [
            "all_submean",
            "group4_mean",
            "every4",
            "every2",
            "linear_detrend",
            "quadratic_detrend",
            "flyer_remove",
            "flyer_replace",
        ]
    if variant_name == "global_plateau_mean50":
        return ["all_submean", "group4_mean", "linear_detrend"]
    return ["all_submean"]


def choose_aggregate_space_indices(
    space_rows: list[dict[str, Any]], min_number: int
) -> list[int]:
    stable = [row for row in space_rows if bool(row.get("stable", False))]
    selected = stable if len(stable) >= min_number else [
        row
        for row in space_rows
        if np.isfinite(float(row.get("mean_cd_nm", math.nan)))
        and np.isfinite(float(row.get("lwr_nm", math.nan)))
    ]
    return [int(row["space_index"]) for row in selected]


def mean_metric(records: Sequence[dict[str, Any]], key: str) -> float:
    return finite_mean(float(record.get(key, math.nan)) for record in records)


def pooled_residual_metric(
    sequences: Sequence[dict[str, Any]], key: str, ddof: int
) -> float:
    residuals: list[np.ndarray] = []
    for sequence in sequences:
        values = np.asarray(sequence[key], dtype=np.float64)
        finite = values[np.isfinite(values)]
        if finite.size:
            residuals.append(finite - np.mean(finite))
    if not residuals:
        return math.nan
    return three_sigma(np.concatenate(residuals), ddof=ddof)


def aligned_space_sequence(
    sequences: Sequence[dict[str, Any]], key: str, reducer: str
) -> np.ndarray:
    if not sequences:
        return np.empty(0, dtype=np.float64)
    lengths = [np.asarray(sequence[key]).size for sequence in sequences]
    if len(set(lengths)) != 1:
        return np.empty(0, dtype=np.float64)
    matrix = np.vstack([np.asarray(sequence[key], dtype=np.float64) for sequence in sequences])
    all_valid = np.all(np.isfinite(matrix), axis=0)
    if not np.any(all_valid):
        return np.empty(0, dtype=np.float64)
    if reducer == "mean":
        return np.mean(matrix[:, all_valid], axis=0)
    if reducer == "median":
        return np.median(matrix[:, all_valid], axis=0)
    raise ValueError(reducer)


def image_aggregation_rows(
    image_name: str,
    result_id: str,
    edge_variant: str,
    stat_mode: str,
    per_space_records: Sequence[dict[str, Any]],
    per_space_sequences: Sequence[dict[str, Any]],
    ddof: int,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not per_space_records:
        return rows

    common = {
        "image_name": image_name,
        "result_id": result_id,
        "edge_variant": edge_variant,
        "stat_mode": stat_mode,
        "space_count": len(per_space_records),
    }
    rows.append(
        {
            **common,
            "aggregation_mode": "mean_per_space",
            "mean_cd_px": mean_metric(per_space_records, "mean_cd_px"),
            "ACD_x_nm": mean_metric(per_space_records, "mean_cd_x_nm"),
            "ACD_slant_nm": mean_metric(per_space_records, "mean_cd_slant_nm"),
            "LER_left_nm": mean_metric(per_space_records, "ler_left_nm"),
            "LER_right_nm": mean_metric(per_space_records, "ler_right_nm"),
            "LWR_x_nm": mean_metric(per_space_records, "lwr_x_nm"),
            "LWR_slant_nm": mean_metric(per_space_records, "lwr_slant_nm"),
            "rho_left_right": mean_metric(per_space_records, "rho_left_right"),
            "centerline_3sigma_nm": mean_metric(
                per_space_records, "centerline_3sigma_nm"
            ),
        }
    )

    rows.append(
        {
            **common,
            "aggregation_mode": "pooled_residual",
            "mean_cd_px": mean_metric(per_space_records, "mean_cd_px"),
            "ACD_x_nm": mean_metric(per_space_records, "mean_cd_x_nm"),
            "ACD_slant_nm": mean_metric(per_space_records, "mean_cd_slant_nm"),
            "LER_left_nm": pooled_residual_metric(per_space_sequences, "left_nm", ddof),
            "LER_right_nm": pooled_residual_metric(per_space_sequences, "right_nm", ddof),
            "LWR_x_nm": pooled_residual_metric(per_space_sequences, "cd_x", ddof),
            "LWR_slant_nm": pooled_residual_metric(
                per_space_sequences, "cd_slant", ddof
            ),
            "rho_left_right": math.nan,
            "centerline_3sigma_nm": pooled_residual_metric(
                per_space_sequences, "center_nm", ddof
            ),
        }
    )

    for reducer in ("mean", "median"):
        cd_x = aligned_space_sequence(per_space_sequences, "cd_x", reducer)
        cd_slant = aligned_space_sequence(per_space_sequences, "cd_slant", reducer)
        left_nm = aligned_space_sequence(per_space_sequences, "left_nm", reducer)
        right_nm = aligned_space_sequence(per_space_sequences, "right_nm", reducer)
        center_nm = aligned_space_sequence(per_space_sequences, "center_nm", reducer)
        rho = math.nan
        if left_nm.size >= 3 and right_nm.size == left_nm.size:
            l_res = left_nm - np.mean(left_nm)
            r_res = right_nm - np.mean(right_nm)
            if np.std(l_res) > EPS and np.std(r_res) > EPS:
                rho = float(np.corrcoef(l_res, r_res)[0, 1])
        rows.append(
            {
                **common,
                "aggregation_mode": f"{reducer}_space_sequence",
                "mean_cd_px": math.nan,
                "ACD_x_nm": finite_mean(cd_x),
                "ACD_slant_nm": finite_mean(cd_slant),
                "LER_left_nm": three_sigma(left_nm, ddof=ddof),
                "LER_right_nm": three_sigma(right_nm, ddof=ddof),
                "LWR_x_nm": three_sigma(cd_x, ddof=ddof),
                "LWR_slant_nm": three_sigma(cd_slant, ddof=ddof),
                "rho_left_right": rho,
                "centerline_3sigma_nm": three_sigma(center_nm, ddof=ddof),
            }
        )
    return rows


def process_measurement_variants(
    measurement: v5.ImageMeasurement,
    v5_params: v5.MeasurementParams,
    variant_params: PhysicalVariantParams,
    edge_specs: Sequence[EdgeVariantSpec],
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
    dict[str, Any],
]:
    image = np.asarray(measurement.annotation_payload["image"], dtype=np.float64)
    annotations = {
        int(item["space_index"]): item
        for item in measurement.annotation_payload.get("spaces", [])
    }
    sample_groups: dict[int, list[dict[str, Any]]] = {}
    for row in measurement.sample_rows:
        sample_groups.setdefault(int(row["space_index"]), []).append(row)
    for rows in sample_groups.values():
        rows.sort(key=lambda item: int(item["sample_index"]))

    base_space_rows = {int(row["space_index"]): row for row in measurement.space_rows}
    aggregate_indices = choose_aggregate_space_indices(
        measurement.space_rows, v5_params.min_number
    )

    per_space_variant_rows: list[dict[str, Any]] = []
    per_sample_rows: list[dict[str, Any]] = []
    sequences_by_result: dict[str, dict[int, dict[str, Any]]] = {}
    records_by_result: dict[str, dict[int, dict[str, Any]]] = {}

    for space_index, annotation in annotations.items():
        candidate: v5.Candidate = annotation["candidate"]
        y_values = np.asarray(annotation["y_values"], dtype=np.float64)
        raw_left = np.asarray(annotation["left_edges"], dtype=np.float64)
        raw_right = np.asarray(annotation["right_edges"], dtype=np.float64)
        initial_left = np.asarray(
            annotation.get("initial_left_edges", raw_left), dtype=np.float64
        )
        initial_right = np.asarray(
            annotation.get("initial_right_edges", raw_right), dtype=np.float64
        )
        fit = annotation.get("centerline_fit") or v5.fit_centerline_and_width_factor(
            y_values, raw_left, raw_right
        )
        normal_factor = float(fit.get("normal_width_factor", 1.0))
        angle = float(fit.get("angle_from_vertical_deg", math.nan))
        profile_cache: dict[tuple[int, str, float], list[Optional[np.ndarray]]] = {}

        edge_results: dict[str, dict[str, Any]] = {}
        for spec in edge_specs:
            if spec.kind == "raw":
                edge_results[spec.name] = {
                    "left": raw_left.copy(),
                    "right": raw_right.copy(),
                    "fallback": np.zeros(raw_left.size, dtype=bool),
                    "shift_rejected": np.zeros(raw_left.size, dtype=bool),
                    "reference_sample_count": int(
                        np.sum(np.isfinite(raw_left) & np.isfinite(raw_right))
                    ),
                }
            elif spec.kind == "pre_postfilter":
                edge_results[spec.name] = {
                    "left": initial_left.copy(),
                    "right": initial_right.copy(),
                    "fallback": np.zeros(raw_left.size, dtype=bool),
                    "shift_rejected": np.zeros(raw_left.size, dtype=bool),
                    "reference_sample_count": int(
                        np.sum(np.isfinite(initial_left) & np.isfinite(initial_right))
                    ),
                }
            elif spec.kind == "reference":
                edge_results[spec.name] = reference_refinement(
                    image,
                    y_values,
                    raw_left,
                    raw_right,
                    spec,
                    v5_params,
                    variant_params,
                    profile_cache,
                )
            elif spec.kind == "profile_redetect":
                edge_results[spec.name] = profile_redetect_refinement(
                    image,
                    y_values,
                    raw_left,
                    raw_right,
                    candidate,
                    spec,
                    v5_params,
                    variant_params,
                    profile_cache,
                )
            else:
                raise ValueError(f"unknown variant kind: {spec.kind}")

        # Per-sample output starts with the frozen V5/V2 diagnostic fields.
        source_rows = sample_groups.get(space_index, [])
        sample_output: list[dict[str, Any]] = []
        for index in range(y_values.size):
            base = dict(source_rows[index]) if index < len(source_rows) else {
                "image_name": measurement.image_row["image_name"],
                "space_index": space_index,
                "sample_index": index,
                "sample_y": float(y_values[index]),
            }
            base.update(
                {
                    "algorithm_version": ALGORITHM_VERSION,
                    "centerline_angle_from_vertical_deg": angle,
                    "normal_width_factor": normal_factor,
                }
            )
            sample_output.append(base)

        for spec in edge_specs:
            variant = edge_results[spec.name]
            left = np.asarray(variant["left"], dtype=np.float64)
            right = np.asarray(variant["right"], dtype=np.float64)
            raw_shift_left = left - raw_left
            raw_shift_right = right - raw_right
            cd_x = (right - left) * v5_params.pixel_size_nm
            cd_slant = cd_x * normal_factor
            for index, row in enumerate(sample_output):
                if variant_params.save_sample_variant_edges:
                    row[f"left_{spec.name}_px"] = (
                        float(left[index]) if np.isfinite(left[index]) else math.nan
                    )
                    row[f"right_{spec.name}_px"] = (
                        float(right[index]) if np.isfinite(right[index]) else math.nan
                    )
                row[f"cd_x_{spec.name}_nm"] = (
                    float(cd_x[index]) if np.isfinite(cd_x[index]) else math.nan
                )
                row[f"cd_slant_{spec.name}_nm"] = (
                    float(cd_slant[index]) if np.isfinite(cd_slant[index]) else math.nan
                )
                row[f"left_shift_vs_raw_{spec.name}_px"] = (
                    float(raw_shift_left[index])
                    if np.isfinite(raw_shift_left[index])
                    else math.nan
                )
                row[f"right_shift_vs_raw_{spec.name}_px"] = (
                    float(raw_shift_right[index])
                    if np.isfinite(raw_shift_right[index])
                    else math.nan
                )
                row[f"fallback_{spec.name}"] = bool(variant["fallback"][index])

            for stat_mode in stat_modes_for_variant(spec.name):
                y_stat, left_stat, right_stat = apply_stat_mode(
                    y_values,
                    left,
                    right,
                    stat_mode,
                    v5_params,
                    variant_params.group_size,
                )
                metrics = sequence_metrics(
                    y_stat,
                    left_stat,
                    right_stat,
                    v5_params.pixel_size_nm,
                    normal_factor,
                    v5_params.standard_deviation_ddof,
                )
                result_id = f"{spec.name}__{stat_mode}"
                record = {
                    "algorithm_version": ALGORITHM_VERSION,
                    "image_name": measurement.image_row["image_name"],
                    "space_index": space_index,
                    "space_role": base_space_rows.get(space_index, {}).get(
                        "space_role", ""
                    ),
                    "edge_variant": spec.name,
                    "stat_mode": stat_mode,
                    "result_id": result_id,
                    "variant_category": spec.category,
                    "variant_interpretation": spec.interpretation,
                    "centerline_angle_from_vertical_deg": angle,
                    "normal_width_factor": normal_factor,
                    "fallback_count": int(np.sum(variant["fallback"])),
                    "shift_rejected_count": int(
                        np.sum(variant["shift_rejected"])
                    ),
                    "reference_sample_count": int(
                        variant.get("reference_sample_count", 0)
                    ),
                    "mean_left_shift_vs_raw_px": finite_mean(raw_shift_left),
                    "mean_right_shift_vs_raw_px": finite_mean(raw_shift_right),
                    "mean_outward_width_change_vs_raw_nm": (
                        metrics["mean_cd_x_nm"]
                        - sequence_metrics(
                            y_values,
                            raw_left,
                            raw_right,
                            v5_params.pixel_size_nm,
                            normal_factor,
                            v5_params.standard_deviation_ddof,
                        )["mean_cd_x_nm"]
                    ),
                    **{
                        key: value
                        for key, value in metrics.items()
                        if key
                        not in {
                            "y",
                            "left",
                            "right",
                            "valid",
                            "cd_x",
                            "cd_slant",
                        }
                    },
                }
                per_space_variant_rows.append(record)
                records_by_result.setdefault(result_id, {})[space_index] = record
                sequences_by_result.setdefault(result_id, {})[space_index] = {
                    "y": metrics["y"],
                    "left_nm": metrics["left"] * v5_params.pixel_size_nm,
                    "right_nm": metrics["right"] * v5_params.pixel_size_nm,
                    "center_nm": 0.5
                    * (metrics["left"] + metrics["right"])
                    * v5_params.pixel_size_nm,
                    "cd_x": metrics["cd_x"],
                    "cd_slant": metrics["cd_slant"],
                }

        per_sample_rows.extend(sample_output)

    image_variant_rows: list[dict[str, Any]] = []
    for result_id, space_record_map in records_by_result.items():
        edge_variant, stat_mode = result_id.split("__", 1)
        selected_records = [
            space_record_map[index]
            for index in aggregate_indices
            if index in space_record_map
        ]
        sequence_map = sequences_by_result.get(result_id, {})
        selected_sequences = [
            sequence_map[index] for index in aggregate_indices if index in sequence_map
        ]
        image_variant_rows.extend(
            image_aggregation_rows(
                measurement.image_row["image_name"],
                result_id,
                edge_variant,
                stat_mode,
                selected_records,
                selected_sequences,
                v5_params.standard_deviation_ddof,
            )
        )

    # Wide image row. Compatibility fields remain frozen raw V2 mean-per-space.
    image_row = dict(measurement.image_row)
    image_row["algorithm_version"] = ALGORITHM_VERSION
    for row in image_variant_rows:
        if row["aggregation_mode"] != "mean_per_space":
            continue
        suffix = row["result_id"]
        image_row[f"ACD_x__{suffix}_nm"] = row["ACD_x_nm"]
        image_row[f"LER_left__{suffix}_nm"] = row["LER_left_nm"]
        image_row[f"LER_right__{suffix}_nm"] = row["LER_right_nm"]
        image_row[f"LWR_x__{suffix}_nm"] = row["LWR_x_nm"]
        image_row[f"ACD_slant__{suffix}_nm"] = row["ACD_slant_nm"]
        image_row[f"LWR_slant__{suffix}_nm"] = row["LWR_slant_nm"]

    for row in image_variant_rows:
        if row["result_id"] != "raw_v2__all_submean":
            continue
        aggregation = row["aggregation_mode"]
        image_row[f"LWR_x__raw_v2__{aggregation}_nm"] = row["LWR_x_nm"]
        image_row[f"LWR_slant__raw_v2__{aggregation}_nm"] = row[
            "LWR_slant_nm"
        ]
    for row in image_variant_rows:
        if row["result_id"] != "global_plateau_mean50__all_submean":
            continue
        aggregation = row["aggregation_mode"]
        image_row[
            f"LWR_x__global_plateau_mean50__{aggregation}_nm"
        ] = row["LWR_x_nm"]

    return per_space_variant_rows, image_variant_rows, per_sample_rows, image_row


def save_diagnostic_plot(
    image_name: str,
    per_sample_rows: list[dict[str, Any]],
    output_path: Path,
) -> None:
    if not per_sample_rows:
        return
    frame = pd.DataFrame(per_sample_rows)
    fig, ax = plt.subplots(figsize=(10, 6), dpi=150)
    plotted = False
    for space_index, group in frame.groupby("space_index"):
        group = group.sort_values("sample_y")
        y = group["sample_y"].to_numpy(dtype=float)
        for variant, linestyle in [
            ("raw_v2", "-"),
            ("global_plateau_mean50", "--"),
            ("avg64_ma3_v2ref", ":"),
        ]:
            column = f"cd_x_{variant}_nm"
            if column not in group:
                continue
            values = group[column].to_numpy(dtype=float)
            ax.plot(
                y,
                values,
                linestyle=linestyle,
                linewidth=0.8,
                alpha=0.8,
                label=f"SPACE {space_index} {variant}",
            )
            plotted = True
    if not plotted:
        plt.close(fig)
        return
    ax.set_xlabel("Y (pixel)")
    ax.set_ylabel("Local CD-x (nm)")
    ax.set_title(f"{image_name}: physical variant CD sequences")
    handles, labels = ax.get_legend_handles_labels()
    if handles:
        unique = dict(zip(labels, handles))
        ax.legend(unique.values(), unique.keys(), fontsize=6, ncol=2)
    ax.grid(True, alpha=0.2)
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, bbox_inches="tight")
    plt.close(fig)


def write_csv(rows: list[dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def build_variant_catalog_rows(edge_specs: Sequence[EdgeVariantSpec]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for spec in edge_specs:
        for stat_mode in stat_modes_for_variant(spec.name):
            rows.append(
                {
                    **asdict(spec),
                    "stat_mode": stat_mode,
                    "result_id": f"{spec.name}__{stat_mode}",
                    "empirical_machine_fit": False,
                }
            )
    return rows



def normalize_skip_keys(skip_image_stems: Sequence[str] | None) -> set[str]:
    """Normalize skip names using exactly the same rule as machine/TIFF matching."""
    if not skip_image_stems:
        return set()
    return {
        normalize_image_match_key(value)
        for value in skip_image_stems
        if normalize_image_match_key(value)
    }


def build_skip_measurement_report(
    all_files: Sequence[Path],
    skip_image_stems: Sequence[str],
) -> pd.DataFrame:
    skip_keys = normalize_skip_keys(skip_image_stems)
    by_key = {
        normalize_image_match_key(path.name): path
        for path in all_files
    }
    rows: list[dict[str, Any]] = []
    for requested in skip_image_stems:
        key = normalize_image_match_key(requested)
        path = by_key.get(key)
        rows.append(
            {
                "requested_skip_name": requested,
                "image_match_key": key,
                "actual_tiff_name": path.name if path is not None else "",
                "actual_tiff_path": str(path.resolve()) if path is not None else "",
                "tiff_found": path is not None,
                "calculated": False,
                "compared_with_machine": False,
                "reason": DEFAULT_SKIP_REASON,
            }
        )
    return pd.DataFrame(rows)



def run_batch(
    input_dir: Path,
    output_dir: Path,
    v5_params: v5.MeasurementParams,
    variant_params: PhysicalVariantParams,
    recursive: bool,
    save_annotations: bool,
    skip_image_stems: Sequence[str] = DEFAULT_SKIP_IMAGE_STEMS,
) -> int:
    v5_params.validate()
    variant_params.validate()
    if not input_dir.exists() or not input_dir.is_dir():
        raise FileNotFoundError(f"input folder does not exist: {input_dir}")
    all_files = v5.find_tiff_files(input_dir, recursive=recursive)
    if not all_files:
        raise FileNotFoundError(f"no .tif/.tiff files found in: {input_dir}")
    skip_keys = normalize_skip_keys(skip_image_stems)
    files = [
        path for path in all_files
        if normalize_image_match_key(path.name) not in skip_keys
    ]
    skipped_files = [
        path for path in all_files
        if normalize_image_match_key(path.name) in skip_keys
    ]
    if not files:
        raise FileNotFoundError("all TIFF images were excluded by the skip list")
    output_dir.mkdir(parents=True, exist_ok=True)
    build_skip_measurement_report(
        all_files, skip_image_stems
    ).to_csv(
        output_dir / "skipped_images.csv",
        index=False,
        encoding="utf-8-sig",
    )

    edge_specs = build_edge_variants(
        v5_params.average_range_px, v5_params.smoothing_pixel
    )
    write_csv(build_variant_catalog_rows(edge_specs), output_dir / "variant_catalog.csv")
    (output_dir / "parameters.json").write_text(
        json.dumps(
            {
                "algorithm_version": ALGORITHM_VERSION,
                "v5_v2_parameters": asdict(v5_params),
                "physical_variant_parameters": asdict(variant_params),
                "primary_output": "raw_v2__all_submean / mean_per_space",
                "empirical_machine_fit": False,
                "default_skipped_image_stems": list(skip_image_stems),
                "skip_reason": DEFAULT_SKIP_REASON,
                "skip_behavior": "excluded before measurement and excluded from machine comparison",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    image_rows: list[dict[str, Any]] = []
    image_variant_rows: list[dict[str, Any]] = []
    space_variant_rows: list[dict[str, Any]] = []
    sample_rows: list[dict[str, Any]] = []
    base_space_rows: list[dict[str, Any]] = []
    candidate_rows: list[dict[str, Any]] = []

    print(
        f"Found {len(all_files)} TIFF file(s); "
        f"skipping {len(skipped_files)} low-quality image(s); "
        f"processing {len(files)}. No empirical correction is applied."
    )
    if skipped_files:
        print("  skipped: " + ", ".join(path.name for path in skipped_files))
    for number, path in enumerate(files, start=1):
        print(f"[{number}/{len(files)}] {path.name}")
        try:
            measurement = v5.measure_image(path, v5_params)
            per_space, per_image_variant, per_sample, image_row = (
                process_measurement_variants(
                    measurement, v5_params, variant_params, edge_specs
                )
            )
            image_rows.append(image_row)
            image_variant_rows.extend(per_image_variant)
            space_variant_rows.extend(per_space)
            sample_rows.extend(per_sample)
            base_space_rows.extend(measurement.space_rows)
            candidate_rows.extend(
                measurement.annotation_payload.get("candidate_diag", {}).get(
                    "candidate_debug_rows", []
                )
            )
            if save_annotations:
                v5.save_annotated_image(
                    path.name,
                    measurement.annotation_payload,
                    output_dir / "annotated_images" / f"{path.stem}_annotated.png",
                    v5_params,
                )
            if variant_params.save_diagnostic_plots:
                save_diagnostic_plot(
                    path.name,
                    per_sample,
                    output_dir / "diagnostic_plots" / f"{path.stem}_variants.png",
                )

            raw_cd = image_row.get("ACD_x__raw_v2__all_submean_nm", math.nan)
            raw_lwr = image_row.get("LWR_x__raw_v2__all_submean_nm", math.nan)
            plateau_cd = image_row.get(
                "ACD_x__global_plateau_mean50__all_submean_nm", math.nan
            )
            plateau_lwr = image_row.get(
                "LWR_x__global_plateau_mean50__all_submean_nm", math.nan
            )
            print(
                f"  valid={image_row.get('valid')} raw CD={raw_cd:.4f} "
                f"LWR={raw_lwr:.4f}; global-ref CD={plateau_cd:.4f} "
                f"LWR={plateau_lwr:.4f}"
            )
        except Exception as exc:
            print(f"  ERROR: {exc}", file=sys.stderr)
            image_rows.append(
                {
                    "algorithm_version": ALGORITHM_VERSION,
                    "image_name": path.name,
                    "valid": False,
                    "warning": f"processing error: {type(exc).__name__}: {exc}",
                }
            )
            error_dir = output_dir / "errors"
            error_dir.mkdir(parents=True, exist_ok=True)
            (error_dir / f"{path.stem}.txt").write_text(
                traceback.format_exc(), encoding="utf-8"
            )

    write_csv(image_rows, output_dir / "image_results.csv")
    write_csv(image_variant_rows, output_dir / "image_variant_results.csv")
    write_csv(space_variant_rows, output_dir / "per_space_variant_results.csv")
    write_csv(base_space_rows, output_dir / "per_space_results_v5_raw.csv")
    write_csv(sample_rows, output_dir / "per_sample_results.csv")
    write_csv(candidate_rows, output_dir / "candidate_debug.csv")

    print(f"Results folder: {output_dir.resolve()}")
    print("Primary compatibility result remains raw V2. Compare variants with compare_cdsem_physical_variants.py.")
    return 0 if image_rows else 2



@dataclass(frozen=True)
class MachineComparisonConfig:
    """Location and layout of the paired machine reference data.

    Defaults match the user's Data.xlsx exactly:
      - sheet: v2
      - rows: 2..84 (83 rows)
      - image name: B
      - CD: D
      - LER-left: E
      - LWR/CDR: F
    """

    excel_path: Path
    sheet_name: str = "v2"
    start_row: int = 2
    end_row: int = 84
    image_column: str = "B"
    cd_column: str = "D"
    ler_left_column: str = "E"
    lwr_column: str = "F"
    strict_expected_row_count: bool = True

    @property
    def expected_row_count(self) -> int:
        return int(self.end_row - self.start_row + 1)

    def validate(self) -> None:
        if self.start_row < 1:
            raise ValueError("machine start row must be >= 1")
        if self.end_row < self.start_row:
            raise ValueError("machine end row must be >= start row")
        for value, label in [
            (self.image_column, "image column"),
            (self.cd_column, "CD column"),
            (self.ler_left_column, "LER-left column"),
            (self.lwr_column, "LWR column"),
        ]:
            excel_column_to_zero_based(value)  # validation
        if not self.sheet_name:
            raise ValueError("machine sheet name cannot be empty")


def excel_column_to_zero_based(column: str) -> int:
    text = str(column).strip().upper()
    if not text or not re.fullmatch(r"[A-Z]+", text):
        raise ValueError(f"invalid Excel column: {column!r}")
    value = 0
    for char in text:
        value = value * 26 + (ord(char) - ord("A") + 1)
    return value - 1


def normalize_image_match_key(value: Any) -> str:
    """Normalize machine/actual TIFF names for deterministic one-to-one matching.

    Example:
      S10_M0008-01MS(0).tif -> s10_m0008-01ms
      S10_M0008-01MS.tif    -> s10_m0008-01ms

    Only terminal copy suffixes such as (0), (1), ... are removed. Internal
    parentheses are preserved. Matching is case-insensitive and ignores spaces.
    """
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    text = str(value).strip().replace("\\", "/")
    if not text:
        return ""
    name = text.rsplit("/", 1)[-1]
    stem = Path(name).stem.strip()
    stem = re.sub(r"(?:\(\s*\d+\s*\))+$", "", stem).strip()
    stem = stem.replace("\u3000", " ")
    stem = re.sub(r"\s+", "", stem)
    return stem.casefold()


def _read_machine_reference(config: MachineComparisonConfig) -> pd.DataFrame:
    config.validate()
    path = config.excel_path
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"machine Excel file does not exist: {path}")

    raw = pd.read_excel(
        path,
        sheet_name=config.sheet_name,
        header=None,
        skiprows=config.start_row - 1,
        nrows=config.expected_row_count,
        engine="openpyxl",
    )
    if config.strict_expected_row_count and len(raw) != config.expected_row_count:
        raise ValueError(
            f"Expected {config.expected_row_count} machine rows from Excel rows "
            f"{config.start_row}-{config.end_row}, but pandas read {len(raw)} rows."
        )

    indices = {
        "machine_image_name_raw": excel_column_to_zero_based(config.image_column),
        "machine_CD_nm": excel_column_to_zero_based(config.cd_column),
        "machine_LER_left_nm": excel_column_to_zero_based(config.ler_left_column),
        "machine_LWR_nm": excel_column_to_zero_based(config.lwr_column),
    }
    max_index = max(indices.values())
    if raw.shape[1] <= max_index:
        raise ValueError(
            f"Sheet {config.sheet_name!r} contains only {raw.shape[1]} readable columns; "
            f"required up to column index {max_index + 1}."
        )

    machine = pd.DataFrame(
        {name: raw.iloc[:, index].to_numpy() for name, index in indices.items()}
    )
    machine.insert(
        0,
        "machine_excel_row",
        np.arange(config.start_row, config.start_row + len(machine), dtype=int),
    )
    machine["image_match_key"] = machine["machine_image_name_raw"].map(
        normalize_image_match_key
    )
    for column in ("machine_CD_nm", "machine_LER_left_nm", "machine_LWR_nm"):
        machine[column] = pd.to_numeric(machine[column], errors="coerce")

    machine["machine_filename_valid"] = machine["image_match_key"].ne("")
    machine["machine_all_metrics_finite"] = np.isfinite(
        machine[["machine_CD_nm", "machine_LER_left_nm", "machine_LWR_nm"]]
        .to_numpy(dtype=float)
    ).all(axis=1)

    duplicate_mask = (
        machine["image_match_key"].ne("")
        & machine["image_match_key"].duplicated(keep=False)
    )
    if duplicate_mask.any():
        duplicate_rows = machine.loc[
            duplicate_mask,
            ["machine_excel_row", "machine_image_name_raw", "image_match_key"],
        ]
        preview = duplicate_rows.head(20).to_dict("records")
        raise ValueError(
            "Duplicate machine image names after removing terminal (0)/(1) suffixes. "
            f"Resolve them before comparison. Examples: {preview}"
        )
    return machine


def _build_tiff_inventory(input_dir: Path, recursive: bool) -> pd.DataFrame:
    paths = v5.find_tiff_files(input_dir, recursive=recursive)
    rows = [
        {
            "actual_image_name": path.name,
            "actual_image_path": str(path.resolve()),
            "image_match_key": normalize_image_match_key(path.name),
        }
        for path in paths
    ]
    inventory = pd.DataFrame(rows)
    if inventory.empty:
        return pd.DataFrame(
            columns=["actual_image_name", "actual_image_path", "image_match_key"]
        )
    duplicate_mask = inventory["image_match_key"].duplicated(keep=False)
    if duplicate_mask.any():
        preview = inventory.loc[duplicate_mask].head(20).to_dict("records")
        raise ValueError(
            "Multiple TIFF files map to the same normalized image name. "
            f"Examples: {preview}"
        )
    return inventory


def _read_variant_results(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"variant output not found: {path}")
    variants = pd.read_csv(path, encoding="utf-8-sig")
    required = {
        "image_name",
        "result_id",
        "edge_variant",
        "stat_mode",
        "aggregation_mode",
        "ACD_x_nm",
        "ACD_slant_nm",
        "LER_left_nm",
        "LWR_x_nm",
        "LWR_slant_nm",
    }
    missing = required - set(variants.columns)
    if missing:
        raise ValueError(f"image_variant_results.csv missing columns: {sorted(missing)}")
    variants = variants.copy()
    variants["image_match_key"] = variants["image_name"].map(
        normalize_image_match_key
    )
    for column in (
        "ACD_x_nm",
        "ACD_slant_nm",
        "LER_left_nm",
        "LWR_x_nm",
        "LWR_slant_nm",
    ):
        variants[column] = pd.to_numeric(variants[column], errors="coerce")

    identity_columns = [
        "image_match_key",
        "result_id",
        "aggregation_mode",
    ]
    duplicate_mask = variants.duplicated(identity_columns, keep=False)
    if duplicate_mask.any():
        preview = variants.loc[
            duplicate_mask,
            identity_columns + ["image_name"],
        ].head(20).to_dict("records")
        raise ValueError(
            "Calculated variant results are not unique by image/result/aggregation. "
            f"Examples: {preview}"
        )
    return variants


def _comparison_pair_columns(
    frame: pd.DataFrame,
    prefix: str,
    calculated_column: str,
    machine_column: str,
) -> None:
    calculated = pd.to_numeric(frame[calculated_column], errors="coerce")
    machine = pd.to_numeric(frame[machine_column], errors="coerce")
    valid = (
        np.isfinite(calculated.to_numpy(dtype=float))
        & np.isfinite(machine.to_numpy(dtype=float))
        & (np.abs(machine.to_numpy(dtype=float)) > EPS)
    )
    difference = calculated - machine
    signed_pct = pd.Series(np.nan, index=frame.index, dtype=float)
    signed_pct.loc[valid] = (
        difference.loc[valid] / machine.loc[valid].abs() * 100.0
    )
    frame[f"{prefix}_calculated_nm"] = calculated
    frame[f"{prefix}_machine_nm"] = machine
    frame[f"{prefix}_difference_nm"] = difference
    frame[f"{prefix}_signed_diff_pct"] = signed_pct
    frame[f"{prefix}_abs_diff_pct"] = signed_pct.abs()
    ratio = pd.Series(np.nan, index=frame.index, dtype=float)
    ratio.loc[valid] = calculated.loc[valid] / machine.loc[valid]
    frame[f"{prefix}_calculated_over_machine_ratio"] = ratio
    frame[f"{prefix}_comparison_valid"] = valid


def _build_match_report(
    machine: pd.DataFrame,
    inventory: pd.DataFrame,
    variants: pd.DataFrame,
) -> pd.DataFrame:
    calculated_images = (
        variants[["image_match_key", "image_name"]]
        .drop_duplicates("image_match_key")
        .rename(columns={"image_name": "calculated_image_name"})
    )
    report = machine.merge(
        inventory,
        on="image_match_key",
        how="outer",
        indicator="machine_vs_tiff",
    )
    report = report.merge(
        calculated_images,
        on="image_match_key",
        how="outer",
        indicator="previous_vs_calculation",
    )
    report["in_machine_excel"] = report["machine_excel_row"].notna()
    report["tiff_exists"] = report["actual_image_name"].notna()
    report["calculation_exists"] = report["calculated_image_name"].notna()
    report["ready_for_comparison"] = (
        report["in_machine_excel"]
        & report["tiff_exists"]
        & report["calculation_exists"]
    )

    conditions = [
        report["ready_for_comparison"],
        report["in_machine_excel"] & ~report["tiff_exists"],
        report["in_machine_excel"]
        & report["tiff_exists"]
        & ~report["calculation_exists"],
        ~report["in_machine_excel"] & report["tiff_exists"],
    ]
    labels = [
        "matched",
        "machine_row_missing_tiff",
        "tiff_found_but_calculation_missing",
        "extra_tiff_not_in_machine_excel",
    ]
    report["match_status"] = np.select(
        conditions, labels, default="unclassified"
    )
    report["_sort_row"] = pd.to_numeric(
        report["machine_excel_row"], errors="coerce"
    ).fillna(10**9)
    report = report.sort_values(
        ["_sort_row", "actual_image_name", "machine_image_name_raw"],
        na_position="last",
    ).drop(columns=["_sort_row"])
    return report


def _build_detailed_machine_comparison(
    variants: pd.DataFrame,
    machine: pd.DataFrame,
) -> pd.DataFrame:
    machine_merge_columns = [
        "machine_excel_row",
        "machine_image_name_raw",
        "image_match_key",
        "machine_CD_nm",
        "machine_LER_left_nm",
        "machine_LWR_nm",
        "machine_filename_valid",
        "machine_all_metrics_finite",
    ]
    detailed = variants.merge(
        machine[machine_merge_columns],
        on="image_match_key",
        how="left",
        validate="many_to_one",
    )
    detailed["machine_row_matched"] = detailed["machine_excel_row"].notna()
    detailed["method_id"] = (
        detailed["result_id"].astype(str)
        + " | "
        + detailed["aggregation_mode"].astype(str)
    )

    _comparison_pair_columns(
        detailed, "CD_x", "ACD_x_nm", "machine_CD_nm"
    )
    _comparison_pair_columns(
        detailed, "CD_slant", "ACD_slant_nm", "machine_CD_nm"
    )
    _comparison_pair_columns(
        detailed, "LER_left", "LER_left_nm", "machine_LER_left_nm"
    )
    _comparison_pair_columns(
        detailed, "LWR_x", "LWR_x_nm", "machine_LWR_nm"
    )
    _comparison_pair_columns(
        detailed, "LWR_slant", "LWR_slant_nm", "machine_LWR_nm"
    )

    preferred_front = [
        "machine_excel_row",
        "machine_image_name_raw",
        "image_name",
        "image_match_key",
        "method_id",
        "result_id",
        "edge_variant",
        "stat_mode",
        "aggregation_mode",
        "variant_category",
        "variant_interpretation",
        "machine_CD_nm",
        "ACD_x_nm",
        "CD_x_signed_diff_pct",
        "CD_x_abs_diff_pct",
        "ACD_slant_nm",
        "CD_slant_signed_diff_pct",
        "CD_slant_abs_diff_pct",
        "machine_LER_left_nm",
        "LER_left_nm",
        "LER_left_signed_diff_pct",
        "LER_left_abs_diff_pct",
        "machine_LWR_nm",
        "LWR_x_nm",
        "LWR_x_signed_diff_pct",
        "LWR_x_abs_diff_pct",
        "LWR_slant_nm",
        "LWR_slant_signed_diff_pct",
        "LWR_slant_abs_diff_pct",
    ]
    ordered = [column for column in preferred_front if column in detailed.columns]
    ordered += [column for column in detailed.columns if column not in ordered]
    detailed = detailed[ordered].sort_values(
        ["machine_excel_row", "image_name", "result_id", "aggregation_mode"],
        na_position="last",
    )
    return detailed


def _build_long_machine_comparison(detailed: pd.DataFrame) -> pd.DataFrame:
    definitions = [
        ("CD_x", "CD", "x_axis", "ACD_x_nm", "machine_CD_nm"),
        ("CD_slant", "CD", "trench_normal", "ACD_slant_nm", "machine_CD_nm"),
        ("LER_left", "LER_left", "x_axis", "LER_left_nm", "machine_LER_left_nm"),
        ("LWR_x", "LWR", "x_axis", "LWR_x_nm", "machine_LWR_nm"),
        ("LWR_slant", "LWR", "trench_normal", "LWR_slant_nm", "machine_LWR_nm"),
    ]
    common_columns = [
        column
        for column in [
            "machine_excel_row",
            "machine_image_name_raw",
            "image_name",
            "image_match_key",
            "method_id",
            "result_id",
            "edge_variant",
            "stat_mode",
            "aggregation_mode",
            "variant_category",
            "variant_interpretation",
        ]
        if column in detailed.columns
    ]
    frames: list[pd.DataFrame] = []
    for comparison_metric, machine_metric, geometry, calculated_column, machine_column in definitions:
        if calculated_column not in detailed.columns or machine_column not in detailed.columns:
            continue
        part = detailed[common_columns].copy()
        part["comparison_metric"] = comparison_metric
        part["machine_metric"] = machine_metric
        part["geometry"] = geometry
        part["calculated_value_nm"] = pd.to_numeric(
            detailed[calculated_column], errors="coerce"
        )
        part["machine_value_nm"] = pd.to_numeric(
            detailed[machine_column], errors="coerce"
        )
        part["difference_nm"] = (
            part["calculated_value_nm"] - part["machine_value_nm"]
        )
        valid = (
            np.isfinite(part["calculated_value_nm"].to_numpy(dtype=float))
            & np.isfinite(part["machine_value_nm"].to_numpy(dtype=float))
            & (np.abs(part["machine_value_nm"].to_numpy(dtype=float)) > EPS)
        )
        part["signed_diff_pct"] = np.nan
        part.loc[valid, "signed_diff_pct"] = (
            part.loc[valid, "difference_nm"]
            / part.loc[valid, "machine_value_nm"].abs()
            * 100.0
        )
        part["abs_diff_pct"] = part["signed_diff_pct"].abs()
        part["calculated_over_machine_ratio"] = np.nan
        part.loc[valid, "calculated_over_machine_ratio"] = (
            part.loc[valid, "calculated_value_nm"]
            / part.loc[valid, "machine_value_nm"]
        )
        part["comparison_valid"] = valid
        frames.append(part)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True).sort_values(
        [
            "comparison_metric",
            "machine_excel_row",
            "result_id",
            "aggregation_mode",
        ],
        na_position="last",
    )


def _safe_pearson_values(x: np.ndarray, y: np.ndarray) -> float:
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 3 or np.std(x) <= EPS or np.std(y) <= EPS:
        return math.nan
    return float(np.corrcoef(x, y)[0, 1])


def _summarize_machine_comparison(
    long_results: pd.DataFrame,
    machine: pd.DataFrame,
) -> pd.DataFrame:
    if long_results.empty:
        return pd.DataFrame()
    expected_counts = {
        "CD_x": int(np.isfinite(machine["machine_CD_nm"].to_numpy(float)).sum()),
        "CD_slant": int(np.isfinite(machine["machine_CD_nm"].to_numpy(float)).sum()),
        "LER_left": int(
            np.isfinite(machine["machine_LER_left_nm"].to_numpy(float)).sum()
        ),
        "LWR_x": int(np.isfinite(machine["machine_LWR_nm"].to_numpy(float)).sum()),
        "LWR_slant": int(np.isfinite(machine["machine_LWR_nm"].to_numpy(float)).sum()),
    }
    group_columns = [
        "comparison_metric",
        "machine_metric",
        "geometry",
        "result_id",
        "edge_variant",
        "stat_mode",
        "aggregation_mode",
    ]
    optional_columns = [
        column
        for column in ["variant_category", "variant_interpretation"]
        if column in long_results.columns
    ]
    group_columns += optional_columns

    rows: list[dict[str, Any]] = []
    for group_key, group in long_results.groupby(group_columns, dropna=False):
        if not isinstance(group_key, tuple):
            group_key = (group_key,)
        identity = dict(zip(group_columns, group_key))
        valid = group[group["comparison_valid"].fillna(False)].copy()
        machine_values = pd.to_numeric(
            valid["machine_value_nm"], errors="coerce"
        ).to_numpy(float)
        calculated_values = pd.to_numeric(
            valid["calculated_value_nm"], errors="coerce"
        ).to_numpy(float)
        difference = calculated_values - machine_values
        signed_pct = pd.to_numeric(valid["signed_diff_pct"], errors="coerce").to_numpy(float)
        abs_pct = np.abs(signed_pct)
        ratio = pd.to_numeric(
            valid["calculated_over_machine_ratio"], errors="coerce"
        ).to_numpy(float)
        metric_name = str(identity["comparison_metric"])
        expected = int(expected_counts.get(metric_name, len(machine)))
        n = int(len(valid))
        rows.append(
            {
                **identity,
                "method_id": f"{identity['result_id']} | {identity['aggregation_mode']}",
                "n_expected_machine_values": expected,
                "n_compared": n,
                "coverage_pct": 100.0 * n / expected if expected else math.nan,
                "mean_machine_nm": float(np.mean(machine_values)) if n else math.nan,
                "mean_calculated_nm": float(np.mean(calculated_values)) if n else math.nan,
                "mean_difference_nm": float(np.mean(difference)) if n else math.nan,
                "mae_nm": float(np.mean(np.abs(difference))) if n else math.nan,
                "rmse_nm": float(np.sqrt(np.mean(difference**2))) if n else math.nan,
                # Positive means calculated result is larger than machine result.
                "mean_signed_diff_pct": float(np.mean(signed_pct)) if n else math.nan,
                # This is the requested average percentage error magnitude (MAPE).
                "mean_abs_diff_pct": float(np.mean(abs_pct)) if n else math.nan,
                "median_signed_diff_pct": float(np.median(signed_pct)) if n else math.nan,
                "median_abs_diff_pct": float(np.median(abs_pct)) if n else math.nan,
                "std_signed_diff_pct": (
                    float(np.std(signed_pct, ddof=1)) if n > 1 else 0.0 if n == 1 else math.nan
                ),
                "min_signed_diff_pct": float(np.min(signed_pct)) if n else math.nan,
                "max_signed_diff_pct": float(np.max(signed_pct)) if n else math.nan,
                "mean_calculated_over_machine_ratio": (
                    float(np.mean(ratio)) if n else math.nan
                ),
                "pearson_r": _safe_pearson_values(machine_values, calculated_values),
            }
        )
    summary = pd.DataFrame(rows)
    if summary.empty:
        return summary
    summary["abs_mean_signed_diff_pct"] = summary["mean_signed_diff_pct"].abs()
    summary = summary.sort_values(
        [
            "comparison_metric",
            "mean_abs_diff_pct",
            "abs_mean_signed_diff_pct",
            "rmse_nm",
        ],
        na_position="last",
    )
    summary["rank_by_mean_abs_diff"] = (
        summary.groupby("comparison_metric", dropna=False).cumcount() + 1
    )
    return summary


def _write_comparison_workbook(
    path: Path,
    machine: pd.DataFrame,
    machine_skipped: pd.DataFrame,
    match_report: pd.DataFrame,
    detailed: pd.DataFrame,
    long_results: pd.DataFrame,
    summary: pd.DataFrame,
    best_methods: pd.DataFrame,
    primary_raw: pd.DataFrame,
    run_info: pd.DataFrame,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        machine.to_excel(writer, sheet_name="Machine_Data", index=False)
        machine_skipped.to_excel(writer, sheet_name="Skipped_Machine_Rows", index=False)
        match_report.to_excel(writer, sheet_name="Match_Report", index=False)
        primary_raw.to_excel(writer, sheet_name="Primary_Raw_V2", index=False)
        detailed.to_excel(writer, sheet_name="Detailed_Wide", index=False)
        long_results.to_excel(writer, sheet_name="Detailed_Long", index=False)
        summary.to_excel(writer, sheet_name="Method_Summary", index=False)
        best_methods.to_excel(writer, sheet_name="Best_By_Metric", index=False)
        run_info.to_excel(writer, sheet_name="Run_Info", index=False)

        from openpyxl.formatting.rule import ColorScaleRule
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter

        workbook = writer.book
        header_fill = PatternFill("solid", fgColor="1F4E78")
        header_font = Font(color="FFFFFF", bold=True)
        for worksheet in workbook.worksheets:
            worksheet.freeze_panes = "A2"
            if worksheet.max_row >= 1 and worksheet.max_column >= 1:
                worksheet.auto_filter.ref = worksheet.dimensions
            for cell in worksheet[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", vertical="center")
            # Widths are estimated from the header and at most 400 rows to keep
            # large detailed sheets fast and readable.
            sample_end = min(worksheet.max_row, 401)
            for column_index in range(1, worksheet.max_column + 1):
                header = str(worksheet.cell(1, column_index).value or "")
                maximum = len(header)
                for row_index in range(2, sample_end + 1):
                    value = worksheet.cell(row_index, column_index).value
                    if value is not None:
                        maximum = max(maximum, len(str(value)))
                worksheet.column_dimensions[get_column_letter(column_index)].width = min(
                    max(maximum + 2, 10), 38
                )
                if header.endswith("_nm") or "_nm" in header:
                    for row_index in range(2, worksheet.max_row + 1):
                        worksheet.cell(row_index, column_index).number_format = "0.0000"
                elif header.endswith("_pct") or "_pct" in header:
                    for row_index in range(2, worksheet.max_row + 1):
                        worksheet.cell(row_index, column_index).number_format = "0.000"
            # Highlight error magnitude columns from low (green) to high (red).
            header_map = {
                str(worksheet.cell(1, col).value): col
                for col in range(1, worksheet.max_column + 1)
            }
            for header, column_index in header_map.items():
                if "abs_diff_pct" in header and worksheet.max_row >= 2:
                    column_letter = get_column_letter(column_index)
                    worksheet.conditional_formatting.add(
                        f"{column_letter}2:{column_letter}{worksheet.max_row}",
                        ColorScaleRule(
                            start_type="min",
                            start_color="63BE7B",
                            mid_type="percentile",
                            mid_value=50,
                            mid_color="FFEB84",
                            end_type="max",
                            end_color="F8696B",
                        ),
                    )


def run_machine_comparison(
    input_dir: Path,
    output_dir: Path,
    config: MachineComparisonConfig,
    recursive: bool,
    skip_image_stems: Sequence[str] = DEFAULT_SKIP_IMAGE_STEMS,
) -> dict[str, Path]:
    """Compare all already-calculated V6 methods without changing calculations."""
    machine_all = _read_machine_reference(config)
    variants_all = _read_variant_results(output_dir / "image_variant_results.csv")
    inventory_all = _build_tiff_inventory(input_dir, recursive=recursive)

    skip_keys = normalize_skip_keys(skip_image_stems)
    machine_skip_mask = machine_all["image_match_key"].isin(skip_keys)
    inventory_skip_mask = inventory_all["image_match_key"].isin(skip_keys)
    variants_skip_mask = variants_all["image_match_key"].isin(skip_keys)

    machine_skipped = machine_all.loc[machine_skip_mask].copy()
    machine = machine_all.loc[~machine_skip_mask].copy()
    inventory = inventory_all.loc[~inventory_skip_mask].copy()
    variants = variants_all.loc[~variants_skip_mask].copy()

    match_report = _build_match_report(machine, inventory, variants)
    detailed = _build_detailed_machine_comparison(variants, machine)
    long_results = _build_long_machine_comparison(detailed)
    summary = _summarize_machine_comparison(long_results, machine)
    best_methods = (
        summary[summary["rank_by_mean_abs_diff"] <= 20].copy()
        if not summary.empty
        else pd.DataFrame()
    )
    primary_raw = detailed[
        (detailed["result_id"] == "raw_v2__all_submean")
        & (detailed["aggregation_mode"] == "mean_per_space")
    ].copy()

    matched_machine_rows = int(
        match_report.loc[match_report["in_machine_excel"], "ready_for_comparison"].sum()
    )
    run_info = pd.DataFrame(
        [
            {"item": "comparison_version", "value": COMPARISON_VERSION},
            {"item": "measurement_algorithm_version", "value": ALGORITHM_VERSION},
            {"item": "machine_excel", "value": str(config.excel_path.resolve())},
            {"item": "machine_sheet", "value": config.sheet_name},
            {
                "item": "machine_rows",
                "value": f"{config.start_row}-{config.end_row}",
            },
            {"item": "machine_image_column", "value": config.image_column},
            {"item": "machine_CD_column", "value": config.cd_column},
            {"item": "machine_LER_left_column", "value": config.ler_left_column},
            {"item": "machine_LWR_column", "value": config.lwr_column},
            {"item": "machine_rows_read_original", "value": len(machine_all)},
            {"item": "machine_rows_excluded_by_skip_list", "value": len(machine_skipped)},
            {"item": "machine_rows_used_for_comparison", "value": len(machine)},
            {"item": "matched_machine_rows", "value": matched_machine_rows},
            {"item": "skip_image_stems", "value": ";".join(skip_image_stems)},
            {"item": "skip_reason", "value": DEFAULT_SKIP_REASON},
            {
                "item": "signed_percent_definition",
                "value": "(calculated-machine)/abs(machine)*100; positive means calculated is high",
            },
            {
                "item": "average_percent_difference",
                "value": "Both mean_signed_diff_pct and mean_abs_diff_pct are reported",
            },
            {"item": "calculation_modified", "value": False},
        ]
    )

    paths = {
        "machine_cleaned": output_dir / "machine_data_cleaned.csv",
        "machine_skipped": output_dir / "machine_data_skipped_low_quality.csv",
        "match_report": output_dir / "machine_image_match_report.csv",
        "detailed": output_dir / "image_variant_results_with_machine_comparison.csv",
        "long": output_dir / "machine_comparison_long.csv",
        "summary": output_dir / "machine_comparison_method_summary.csv",
        "best": output_dir / "machine_comparison_best_methods.csv",
        "primary": output_dir / "primary_raw_v2_machine_comparison.csv",
        "workbook": output_dir / "machine_comparison.xlsx",
        "text_summary": output_dir / "machine_comparison_summary.txt",
        "manifest": output_dir / "machine_comparison_manifest.json",
    }
    write_csv(machine.to_dict("records"), paths["machine_cleaned"])
    write_csv(machine_skipped.to_dict("records"), paths["machine_skipped"])
    write_csv(match_report.to_dict("records"), paths["match_report"])
    write_csv(detailed.to_dict("records"), paths["detailed"])
    write_csv(long_results.to_dict("records"), paths["long"])
    write_csv(summary.to_dict("records"), paths["summary"])
    write_csv(best_methods.to_dict("records"), paths["best"])
    write_csv(primary_raw.to_dict("records"), paths["primary"])
    _write_comparison_workbook(
        paths["workbook"],
        machine,
        machine_skipped,
        match_report,
        detailed,
        long_results,
        summary,
        best_methods,
        primary_raw,
        run_info,
    )

    summary_lines = [
        "CD-SEM machine comparison; measurement calculations were not modified.",
        f"Machine Excel: {config.excel_path}",
        f"Sheet/rows: {config.sheet_name} / {config.start_row}-{config.end_row}",
        f"Machine rows read from Data.xlsx: {len(machine_all)}",
        f"Machine rows excluded by low-quality skip list: {len(machine_skipped)}",
        f"Machine rows used for comparison: {len(machine)}",
        f"Machine rows matched to TIFF and calculation: {matched_machine_rows}",
        "Skipped images are not included in MAPE, Bias, correlation, Pareto, or candidate scoring.",
        "Percent difference: (calculated - machine) / abs(machine) * 100.",
        "Positive signed percentage means the calculated result is larger.",
        "mean_abs_diff_pct is the average magnitude of percentage error.",
        "",
    ]
    if not summary.empty:
        for metric in summary["comparison_metric"].dropna().unique():
            top = summary[summary["comparison_metric"] == metric].head(10)
            summary_lines.append(f"[{metric}] Top 10 by mean_abs_diff_pct")
            for _, row in top.iterrows():
                summary_lines.append(
                    f"  #{int(row['rank_by_mean_abs_diff'])} "
                    f"{row['result_id']} | {row['aggregation_mode']}: "
                    f"n={int(row['n_compared'])}, "
                    f"mean signed={row['mean_signed_diff_pct']:.3f}%, "
                    f"mean abs={row['mean_abs_diff_pct']:.3f}%"
                )
            summary_lines.append("")
    paths["text_summary"].write_text("\n".join(summary_lines), encoding="utf-8")
    paths["manifest"].write_text(
        json.dumps(
            {
                "comparison_version": COMPARISON_VERSION,
                "measurement_algorithm_version": ALGORITHM_VERSION,
                "machine_config": {
                    **asdict(config),
                    "excel_path": str(config.excel_path),
                },
                "percent_difference_definition": (
                    "(calculated-machine)/abs(machine)*100"
                ),
                "skip_image_stems": list(skip_image_stems),
                "skip_reason": DEFAULT_SKIP_REASON,
                "machine_rows_read_original": int(len(machine_all)),
                "machine_rows_skipped": int(len(machine_skipped)),
                "machine_rows_used": int(len(machine)),
                "outputs": {key: str(value) for key, value in paths.items()},
                "measurement_calculation_modified": False,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(
        f"Machine comparison: {matched_machine_rows}/{len(machine)} effective machine rows matched "
        f"({len(machine_skipped)} low-quality rows excluded from {len(machine_all)} original rows)."
    )
    print(f"Comparison workbook: {paths['workbook'].resolve()}")
    print(f"Method summary: {paths['summary'].resolve()}")
    return paths


def run_candidate_selection(
    method_summary_path: Path,
    output_dir: Path,
    cd_target_pct: float = 3.0,
    ler_target_pct: float = 6.0,
    lwr_target_pct: float = 10.0,
    min_coverage_pct: float = 95.0,
    top_n: int = 12,
) -> dict[str, Path]:
    """Run the transparent multi-metric selector on already-computed comparison results."""
    if not method_summary_path.exists():
        raise FileNotFoundError(
            f"method summary not found for candidate selection: {method_summary_path}"
        )
    summary = pd.read_csv(method_summary_path, encoding="utf-8-sig")
    methods = candidate_selector.build_method_table(summary)
    ranked = candidate_selector.score_methods(
        methods,
        cd_target=float(cd_target_pct),
        ler_target=float(ler_target_pct),
        lwr_target=float(lwr_target_pct),
        min_coverage=float(min_coverage_pct),
    )
    top = candidate_selector.select_top_candidates(
        ranked,
        top_n=max(1, int(top_n)),
    )
    paths = candidate_selector.write_outputs(
        ranked,
        top,
        output_dir=output_dir,
        cd_target=float(cd_target_pct),
        ler_target=float(ler_target_pct),
        lwr_target=float(lwr_target_pct),
        min_coverage=float(min_coverage_pct),
    )
    candidate_selector.print_top(top)
    print(f"Candidate selection workbook: {paths['xlsx'].resolve()}")
    return paths



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "V1.15 rough locator + frozen V2 edge measurement + non-fitted physical variants "
            "for CD/LER/LWR implementation comparison."
        )
    )
    parser.add_argument("input_dir", type=Path, help="Folder containing 1024x1024 TIFF images")
    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        default=None,
        help="Default: <input_dir>/cdsem_results_v7",
    )
    parser.add_argument("--recursive", action="store_true")
    parser.add_argument("--no-annotated-images", action="store_true")
    parser.add_argument("--no-diagnostic-plots", action="store_true")
    parser.add_argument("--compact-sample-output", action="store_true")
    parser.add_argument(
        "--skip-image",
        action="append",
        default=[],
        help=(
            "Additional image stem/name to exclude before measurement and machine comparison. "
            "The five known low-quality images are already included by default."
        ),
    )
    parser.add_argument(
        "--no-default-quality-skip",
        action="store_true",
        help="Disable the five built-in low-quality skip names (normally keep them enabled).",
    )

    # Frozen V5/V2 recipe parameters.
    parser.add_argument("--pixel-size-nm", type=float, default=0.8789)
    parser.add_argument("--target-cd-nm", type=float, default=60.0)
    parser.add_argument("--center-x", type=float, default=586.0)
    parser.add_argument("--center-y", type=float, default=512.0)
    parser.add_argument("--search-in", type=int, default=33)
    parser.add_argument("--search-out", type=int, default=30)
    parser.add_argument("--extend-length", type=int, default=360)
    parser.add_argument("--sample-number", type=int, default=128)
    parser.add_argument("--average-range", type=int, default=32)
    parser.add_argument("--smoothing-pixel", type=int, default=3)
    parser.add_argument("--peak-order", type=int, default=1)
    parser.add_argument("--threshold-left", type=float, default=50.0)
    parser.add_argument("--threshold-right", type=float, default=50.0)
    parser.add_argument("--max-number", type=int, default=3)
    parser.add_argument("--min-number", type=int, default=3)
    parser.add_argument("--gray-tolerance", type=float, default=10.0)
    parser.add_argument("--grad-tolerance", type=float, default=1.0)
    parser.add_argument("--candidate-dark-tolerance", type=float, default=12.0)
    parser.add_argument("--candidate-min-contrast", type=float, default=3.0)
    parser.add_argument("--topology-min-contrast", type=float, default=2.5)
    parser.add_argument("--tracking-radius", type=float, default=13.0)
    parser.add_argument("--tracking-retry-radius", type=float, default=20.0)
    parser.add_argument("--tracking-max-jump", type=float, default=8.0)
    parser.add_argument("--postfilter-window", type=int, default=9)
    parser.add_argument("--postfilter-mad-multiplier", type=float, default=6.0)
    parser.add_argument("--postfilter-edge-tolerance", type=float, default=2.5)
    parser.add_argument("--minimum-valid-fraction", type=float, default=0.70)
    parser.add_argument("--allow-incomplete-triplet", action="store_true")
    parser.add_argument("--no-recovery", action="store_true")
    parser.add_argument(
        "--flyer-mode", choices=["reserve", "remove", "replace"], default="reserve"
    )
    parser.add_argument("--flyer-left-offset", type=float, default=20.0)
    parser.add_argument("--flyer-right-offset", type=float, default=20.0)

    # Variant controls; not machine-fitted values.
    parser.add_argument("--reference-band", type=int, default=9)
    parser.add_argument("--reference-gap", type=int, default=2)
    parser.add_argument("--reference-crossing-radius", type=float, default=5.0)
    parser.add_argument("--reference-max-shift", type=float, default=3.0)
    parser.add_argument("--reference-min-samples", type=int, default=24)
    parser.add_argument("--profile-redetect-radius", type=float, default=6.0)
    parser.add_argument("--profile-redetect-max-shift", type=float, default=4.0)
    parser.add_argument("--group-size", type=int, default=4)

    # Automatic paired comparison against Data.xlsx. These defaults exactly match
    # the user's current folder and workbook layout. Measurement calculations are
    # completed first; comparison is a separate post-processing stage.
    parser.add_argument(
        "--machine-excel",
        type=Path,
        default=None,
        help="Default: <input_dir>/Data.xlsx",
    )
    parser.add_argument("--machine-sheet", default="v2")
    parser.add_argument("--machine-start-row", type=int, default=2)
    parser.add_argument("--machine-end-row", type=int, default=84)
    parser.add_argument("--machine-image-column", default="B")
    parser.add_argument("--machine-cd-column", default="D")
    parser.add_argument("--machine-ler-left-column", default="E")
    parser.add_argument("--machine-lwr-column", default="F")
    parser.add_argument(
        "--allow-machine-row-count-mismatch",
        action="store_true",
        help="Do not require exactly end_row-start_row+1 rows from the sheet",
    )
    parser.add_argument(
        "--skip-machine-comparison",
        action="store_true",
        help="Run only measurement; do not read Data.xlsx or create comparison outputs",
    )
    parser.add_argument(
        "--skip-candidate-selection",
        action="store_true",
        help="Run measurement and machine comparison, but do not rank candidate methods",
    )
    parser.add_argument("--candidate-cd-target", type=float, default=3.0)
    parser.add_argument("--candidate-ler-target", type=float, default=6.0)
    parser.add_argument("--candidate-lwr-target", type=float, default=10.0)
    parser.add_argument("--candidate-min-coverage", type=float, default=95.0)
    parser.add_argument("--candidate-top-n", type=int, default=12)
    return parser


def params_from_args(
    args: argparse.Namespace,
) -> tuple[v5.MeasurementParams, PhysicalVariantParams]:
    v5_params = v5.MeasurementParams(
        pixel_size_nm=args.pixel_size_nm,
        target_cd_nm=args.target_cd_nm,
        center_x_px=args.center_x,
        center_y_px=args.center_y,
        search_range_in_px=args.search_in,
        search_range_out_px=args.search_out,
        extend_length_px=args.extend_length,
        sample_number=args.sample_number,
        average_range_px=args.average_range,
        smoothing_pixel=args.smoothing_pixel,
        peak_order=args.peak_order,
        edge_threshold_left_pct=args.threshold_left,
        edge_threshold_right_pct=args.threshold_right,
        max_number=args.max_number,
        min_number=args.min_number,
        gray_tolerance=args.gray_tolerance,
        grad_tolerance=args.grad_tolerance,
        candidate_dark_mean_tolerance_8bit=args.candidate_dark_tolerance,
        candidate_min_basin_contrast_8bit=args.candidate_min_contrast,
        topology_min_contrast_8bit=args.topology_min_contrast,
        tracking_search_radius_px=args.tracking_radius,
        tracking_retry_radius_px=args.tracking_retry_radius,
        tracking_max_edge_jump_px=args.tracking_max_jump,
        postfilter_window=args.postfilter_window,
        postfilter_mad_multiplier=args.postfilter_mad_multiplier,
        postfilter_min_edge_tolerance_px=args.postfilter_edge_tolerance,
        require_center_left_right=not args.allow_incomplete_triplet,
        recover_rejected_points=not args.no_recovery,
        minimum_valid_fraction=args.minimum_valid_fraction,
        flyer_mode=args.flyer_mode,
        flyer_left_offset_px=args.flyer_left_offset,
        flyer_right_offset_px=args.flyer_right_offset,
    )
    variant_params = PhysicalVariantParams(
        reference_band_px=args.reference_band,
        reference_gap_px=args.reference_gap,
        reference_crossing_radius_px=args.reference_crossing_radius,
        reference_max_shift_px=args.reference_max_shift,
        reference_min_samples=args.reference_min_samples,
        profile_redetect_radius_px=args.profile_redetect_radius,
        profile_redetect_max_shift_px=args.profile_redetect_max_shift,
        group_size=args.group_size,
        save_diagnostic_plots=not args.no_diagnostic_plots,
        save_sample_variant_edges=not args.compact_sample_output,
    )
    return v5_params, variant_params


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    v5_params, variant_params = params_from_args(args)
    output_dir = args.output_dir or (args.input_dir / "cdsem_results_v7")
    try:
        skip_image_stems = (
            [] if args.no_default_quality_skip else list(DEFAULT_SKIP_IMAGE_STEMS)
        )
        skip_image_stems.extend(args.skip_image)
        skip_image_stems = list(dict.fromkeys(skip_image_stems))
        result_code = run_batch(
            args.input_dir,
            output_dir,
            v5_params,
            variant_params,
            recursive=args.recursive,
            save_annotations=not args.no_annotated_images,
            skip_image_stems=skip_image_stems,
        )
        if not args.skip_machine_comparison:
            machine_excel = args.machine_excel or (args.input_dir / "Data.xlsx")
            comparison_config = MachineComparisonConfig(
                excel_path=machine_excel,
                sheet_name=args.machine_sheet,
                start_row=args.machine_start_row,
                end_row=args.machine_end_row,
                image_column=args.machine_image_column,
                cd_column=args.machine_cd_column,
                ler_left_column=args.machine_ler_left_column,
                lwr_column=args.machine_lwr_column,
                strict_expected_row_count=not args.allow_machine_row_count_mismatch,
            )
            comparison_paths = run_machine_comparison(
                args.input_dir,
                output_dir,
                comparison_config,
                recursive=args.recursive,
                skip_image_stems=skip_image_stems,
            )
            if not args.skip_candidate_selection:
                run_candidate_selection(
                    comparison_paths["summary"],
                    output_dir / "candidate_selection",
                    cd_target_pct=args.candidate_cd_target,
                    ler_target_pct=args.candidate_ler_target,
                    lwr_target_pct=args.candidate_lwr_target,
                    min_coverage_pct=args.candidate_min_coverage,
                    top_n=args.candidate_top_n,
                )
        return result_code
    except Exception as exc:
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
