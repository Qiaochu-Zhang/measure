# SEM CD 批处理 V1.10：原坐标 + 中心线旋转坐标

## 1. 主入口和兼容性

主入口：`sem_cd_measure_200k_batch_V1_10.py`

V1.10 基于 V1.9，输入格式、默认参数和目录行为保持不变：

- 递归处理 `--root` 下的全部 PNG，不按目录名或文件名筛选；
- 必须用 `--pattern trench` 或 `--pattern via` 指定整棵输入目录的图案；
- 标注图保留输入相对目录和原 PNG 文件名；
- 默认 `pixel size=1.3181 nm/pixel`；
- 默认 `sample number=128`、`average range=32`、`smoothing=3`、`Peak Order=1`、左右 50% threshold、Flyer Reserve；
- 未给 `--trench-reference-nm` 时，逐图自动估计检测参考 CD；
- 根目录存在 `Data.xlsx` 时，Trench 模式自动执行 Machine 对比；可用 `--no-auto-machine-comparison` 关闭。

V10/V13 没有 Via 算法，因此 `--pattern via` 完整复用 V1.7 Via 测量和统计路径。

## 2. 两套坐标结果

对每一条 trench 独立拟合平均中心线：

1. 每个有效采样点取左右边缘中点；
2. 用正交 PCA 拟合这些中点的主方向；
3. 将该方向定义为 `Y'`，与它垂直的 trench 法向定义为 `X'`；
4. 以有效中点均值为原点，将左右边缘点真正旋转到 `X'/Y'` 后重新计算 CD、LER、LWR。

若中心线相对图像 Y 轴的角度为 `theta`，则：

```text
X' = cos(theta) * (X-X0) - sin(theta) * (Y-Y0)
Y' = sin(theta) * (X-X0) + cos(theta) * (Y-Y0)
```

| 输出前缀 | 坐标定义 | 物理含义 |
|---|---|---|
| `unrotated_` | 原图 X/Y | 包含整条 trench 相对图像 Y 轴倾斜所造成的 X 漂移 |
| `rotated_` | Y' 沿平均中心线，X' 沿法向 | 去掉共同中心线倾斜，再观察法向宽度和边缘波动 |

V1.10 不再输出第三套独立 slant 数值列。旋转坐标已经明确表示沿 trench 法向的结果；旧的投影列若继续保留，会与 `rotated_` 重复。

这里不是简单把最终 LER 乘以 `cos(theta)`。每个边缘点都会先旋转，然后分别计算 `3 sigma(X'_left)` 和 `3 sigma(X'_right)`。所以完全笔直但整体倾斜的边缘，在旋转坐标中的 LER 会接近零；真实边缘若有弯曲、局部粗糙或与平均中心线方向不一致，旋转 LER 不一定必然小于原坐标 LER。

## 3. CD、LER、LWR 的算法来源

两套坐标都保持 V1.9 的算法路由：同一 PNG 分别运行 V10 和 V13 两套真实边缘识别，不是只更改字段名称。

| 最终指标 | 边缘引擎 | 统计序列 | 来源 ID |
|---|---|---|---|
| CD / ACD | V13 | 128 点 raw V2 | `raw_v2__all_submean` |
| LER-left / LER-right | V10 | 128 点 raw V2 | `raw_v2__all_submean` |
| LWR | V13 | 连续每 4 点先平均，再计算宽度 3σ | `raw_v2__group4_mean` |

V13 中心线用于旋转 CD/LWR 的边缘；V10 中心线用于旋转 LER 的边缘。输出中的 `rotation_angle_CD_LWR_*` 和 `rotation_angle_LER_*` 分别记录这两个角度，避免把两套边缘识别的角度混为一个值。

每条 trench 先独立计算；图像结果是所选 trench 结果的算术平均。

## 4. 安装和自检

```powershell
python -m pip install -r requirements_V1_10.txt
python .\self_check_V1_10.py
```

自检会验证：V1.7 默认接口、V1.9 指标来源路由、双坐标字段，以及理想倾斜直线在旋转坐标中不产生虚假 LER。

## 5. 运行示例

Trench，自动估计参考宽度：

```powershell
python .\sem_cd_measure_200k_batch_V1_10.py `
  --root "C:\SEM\input" `
  --pattern trench
```

Trench，显式参考宽度：

```powershell
python .\sem_cd_measure_200k_batch_V1_10.py `
  --root "C:\SEM\input" `
  --pattern trench `
  --pixel-size 1.3181 `
  --trench-reference-nm 60 `
  --space-reference-nm 100
```

Via：

```powershell
python .\sem_cd_measure_200k_batch_V1_10.py `
  --root "C:\SEM\via_png" `
  --pattern via
```

## 6. Data.xlsx 和统计

默认 Machine 表映射保持不变：

```text
sheet v2
B2:B84 = image
D2:D84 = CD
E2:E84 = LER_left
F2:F84 = LWR/CDR
```

同一份 Machine 数值分别与 `unrotated`、`rotated` 两种结果比较。统计包括 MAPE、signed bias、误差 SD、MAE、RMSE、Pearson r 和 Bland-Altman 95% limits，并按坐标模式分别生成图。

## 7. 主要输出

默认输出目录：

```text
<root>\CD_measure_output_200K_V1_10
```

核心文件：

```text
CD_measurement_200K_V1_10_results.xlsx
image_summary.csv
coordinate_system_results.csv
condition_summary.csv
trench_objects.csv
all_objects_long.csv
per_sample_results.csv
processing_errors.csv
settings.json
annotated\<原相对目录>\<原PNG文件名>
annotated_v10_ler\<原相对目录>\<原PNG文件名>
```

`image_summary.csv` 为宽表，同时包含：

```text
unrotated_CD_nm              rotated_CD_nm
unrotated_LER_left_nm        rotated_LER_left_nm
unrotated_LER_right_nm       rotated_LER_right_nm
unrotated_LWR_nm             rotated_LWR_nm
```

`coordinate_system_results.csv` 是长表，每张图固定两行，`coordinate_mode` 分别为 `unrotated` 和 `rotated`，更适合透视表和绘图。

为兼容 V1.9 下游脚本，`ACD_x_nm`、`LER_left_nm`、`LER_right_nm`、`LWR_x_nm` 仍存在，并明确等于对应的 `unrotated_` 值：

```text
ACD_x_nm     == unrotated_CD_nm
LER_left_nm  == unrotated_LER_left_nm
LER_right_nm == unrotated_LER_right_nm
LWR_x_nm     == unrotated_LWR_nm
```

完整来源审计文件以 `V1_10_V10_...` 和 `V1_10_V13_...` 命名。来源审计表也不发布重复的旧投影列；旋转后的逐点 `rotated_left_x_prime_px`、`rotated_right_x_prime_px`、`rotated_center_y_prime_px` 和 `rotated_local_cd_nm` 可用于核查。

执行 Machine 对比后还会生成：

```text
machine_comparison_detailed.csv
V1_10_statistics_summary.csv
V1_10_plot_index.csv
V1_10_statistics_and_machine_comparison.xlsx
plots\unrotated\...
plots\rotated\...
```

## 8. 状态

- `OK`：V10 和 V13 两套测量均满足默认有效性要求；
- `REVIEW`：两套主结果完整，但至少一套未满足严格 triplet/稳定条数要求；
- `ERROR`：不能同时形成 V10 raw LER、V13 raw CD 和 V13 group4 LWR；原因见 `processing_errors.csv`。

本程序是根据提供代码包组合的算法模拟，不代表任何 CD-SEM 厂商的官方源代码或官方算法说明。
