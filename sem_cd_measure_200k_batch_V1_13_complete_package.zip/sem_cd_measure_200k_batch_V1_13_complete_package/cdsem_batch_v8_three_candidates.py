#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CD-SEM V8：三个候选方案专用验证版
================================

V8 不再计算 V7 的几十种诊断组合，只固定比较上一轮筛选出的三个最值得验证的方案：

M1_Global50_Pooled
    edge_variant      = global_plateau_mean50
    stat_mode         = all_submean
    aggregation_mode  = pooled_residual

M2_V2_Group4_MeanSpace
    edge_variant      = raw_v2
    stat_mode         = group4_mean
    aggregation_mode  = mean_per_space

M3_Gaussian1_MeanSpace
    edge_variant      = avg32_gaussian1_v2ref
    stat_mode         = all_submean
    aggregation_mode  = mean_per_space

共同流程：
    - 跳过 5 张已确认低质量 TIFF；
    - V1.15 Basin-First 只负责粗 trench 定位；
    - V5/V2 负责具体边缘 tracking；
    - 分别计算三个候选；
    - x_axis 与 trench_normal 两种几何同时输出；
    - 自动读取 Data.xlsx / sheet v2；
    - 与 Machine 的 CD / LER_left / LWR 逐图比较；
    - 输出 MAPE、signed bias、RMSE、相关系数；
    - 对三个候选做透明的三指标综合排名。

没有经验校准：
    - 不给 CD 乘 1.03；
    - 不给 LWR 除 1.16；
    - 不根据 Machine 结果重新优化 edge 参数。
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import traceback
from dataclasses import asdict
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd

import cdsem_batch_v7_full_pipeline as v7


V8_VERSION = "V8_THREE_CANDIDATES_V115_LOCATOR_V2_EDGE_MACHINE_COMPARE"

DEFAULT_INPUT_DIR = Path(
    r"C:\Users\z00027644\PycharmProjects\dfjy\tif_images"
)

# V7 中已经验证过的低质量跳过名单，V8 继续沿用。
DEFAULT_SKIP_IMAGE_STEMS = v7.DEFAULT_SKIP_IMAGE_STEMS

# 三个固定候选：顺序也就是当前研究优先级，不代表最后结果排名。
METHODS = {
    "M1_Global50_Pooled": {
        "result_id": "global_plateau_mean50__all_submean",
        "edge_variant": "global_plateau_mean50",
        "stat_mode": "all_submean",
        "aggregation_mode": "pooled_residual",
        "cn_name": "全局亮暗平台50% + pooled residual",
        "physical_meaning": (
            "V2先找到可靠边缘路径；整条SPACE共用稳健的亮/暗平台参考，"
            "仍以50%阈值在V2边缘附近重新求亚像素交点；128点全部参与Sub_Mean；"
            "三条SPACE先各自减自身均值，再把残差合并后统一计算LER/LWR。"
        ),
    },
    "M2_V2_Group4_MeanSpace": {
        "result_id": "raw_v2__group4_mean",
        "edge_variant": "raw_v2",
        "stat_mode": "group4_mean",
        "aggregation_mode": "mean_per_space",
        "cn_name": "原V2边缘 + 每4点分组平均 + 三SPACE结果平均",
        "physical_meaning": (
            "完全保留原V2最终边缘；128个采样点连续每4点先平均成约32组；"
            "每条SPACE分别计算CD/LER/LWR，最后对最多3条SPACE的最终指标做算术平均。"
        ),
    },
    "M3_Gaussian1_MeanSpace": {
        "result_id": "avg32_gaussian1_v2ref__all_submean",
        "edge_variant": "avg32_gaussian1_v2ref",
        "stat_mode": "all_submean",
        "aggregation_mode": "mean_per_space",
        "cn_name": "Average Range 32 + Gaussian σ=1 + 三SPACE结果平均",
        "physical_meaning": (
            "以V2边缘为可靠参考，在同一Average Range=32 profile上将Smoothing Pixel=3"
            "的实现改为Gaussian sigma=1 px，并仅在V2边缘附近重新检测；"
            "128点全部做Sub_Mean；每条SPACE先独立计算，再对3条结果平均。"
        ),
    },
}

TARGETS = {
    "CD_mape_target_pct": 3.0,
    "LER_mape_target_pct": 6.0,
    "LWR_mape_target_pct": 10.0,
}


# -----------------------------------------------------------------------------
# Freeze V7 physical-variant engine down to only the three requested methods.
# -----------------------------------------------------------------------------

_ORIGINAL_BUILD_EDGE_VARIANTS = v7.build_edge_variants
_ORIGINAL_IMAGE_AGGREGATION_ROWS = v7.image_aggregation_rows


def build_edge_variants_v8(
    base_average_range: int,
    base_smoothing: int,
) -> list[v7.EdgeVariantSpec]:
    wanted = {
        "global_plateau_mean50",
        "raw_v2",
        "avg32_gaussian1_v2ref",
    }
    all_specs = _ORIGINAL_BUILD_EDGE_VARIANTS(
        base_average_range, base_smoothing
    )
    specs = [spec for spec in all_specs if spec.name in wanted]
    found = {spec.name for spec in specs}
    missing = wanted - found
    if missing:
        raise RuntimeError(f"V8 missing edge spec(s): {sorted(missing)}")

    # Stable output order: M1 edge, M2 edge, M3 edge.
    order = {
        "global_plateau_mean50": 0,
        "raw_v2": 1,
        "avg32_gaussian1_v2ref": 2,
    }
    return sorted(specs, key=lambda spec: order[spec.name])


def stat_modes_for_variant_v8(variant_name: str) -> list[str]:
    if variant_name == "global_plateau_mean50":
        return ["all_submean"]
    if variant_name == "raw_v2":
        return ["group4_mean"]
    if variant_name == "avg32_gaussian1_v2ref":
        return ["all_submean"]
    return []


def image_aggregation_rows_v8(
    image_name: str,
    result_id: str,
    edge_variant: str,
    stat_mode: str,
    per_space_records: Sequence[dict[str, Any]],
    per_space_sequences: Sequence[dict[str, Any]],
    ddof: int,
) -> list[dict[str, Any]]:
    rows = _ORIGINAL_IMAGE_AGGREGATION_ROWS(
        image_name,
        result_id,
        edge_variant,
        stat_mode,
        per_space_records,
        per_space_sequences,
        ddof,
    )

    desired = {
        METHODS["M1_Global50_Pooled"]["result_id"]:
            METHODS["M1_Global50_Pooled"]["aggregation_mode"],
        METHODS["M2_V2_Group4_MeanSpace"]["result_id"]:
            METHODS["M2_V2_Group4_MeanSpace"]["aggregation_mode"],
        METHODS["M3_Gaussian1_MeanSpace"]["result_id"]:
            METHODS["M3_Gaussian1_MeanSpace"]["aggregation_mode"],
    }
    aggregation = desired.get(result_id)
    if aggregation is None:
        return []
    return [
        row for row in rows
        if str(row.get("aggregation_mode")) == aggregation
    ]


# Monkeypatch only the variant catalogue/statistics selection layer.
# The V1.15 locator and V2 concrete edge measurement remain the original code.
v7.build_edge_variants = build_edge_variants_v8
v7.stat_modes_for_variant = stat_modes_for_variant_v8
v7.image_aggregation_rows = image_aggregation_rows_v8
v7.ALGORITHM_VERSION = V8_VERSION


def method_definition_rows() -> list[dict[str, Any]]:
    rows = []
    for order, (method_code, method) in enumerate(METHODS.items(), start=1):
        rows.append(
            {
                "research_priority": order,
                "method_code": method_code,
                "cn_name": method["cn_name"],
                "edge_variant": method["edge_variant"],
                "stat_mode": method["stat_mode"],
                "aggregation_mode": method["aggregation_mode"],
                "result_id": method["result_id"],
                "physical_meaning": method["physical_meaning"],
                "empirical_machine_fit": False,
            }
        )
    return rows


def method_code_from_row(row: pd.Series | dict[str, Any]) -> str | None:
    for code, method in METHODS.items():
        if (
            str(row.get("result_id", "")) == method["result_id"]
            and str(row.get("aggregation_mode", ""))
            == method["aggregation_mode"]
        ):
            return code
    return None


def run_batch_v8(
    input_dir: Path,
    output_dir: Path,
    v5_params: v7.v5.MeasurementParams,
    variant_params: v7.PhysicalVariantParams,
    recursive: bool,
    save_annotations: bool,
    skip_image_stems: Sequence[str],
) -> int:
    """V7 measurement engine, but only the three V8 candidates are emitted."""
    v5_params.validate()
    variant_params.validate()

    if not input_dir.exists() or not input_dir.is_dir():
        raise FileNotFoundError(f"input folder does not exist: {input_dir}")

    all_files = v7.v5.find_tiff_files(
        input_dir, recursive=recursive
    )
    if not all_files:
        raise FileNotFoundError(
            f"no .tif/.tiff files found in: {input_dir}"
        )

    skip_keys = v7.normalize_skip_keys(skip_image_stems)
    files = [
        path for path in all_files
        if v7.normalize_image_match_key(path.name) not in skip_keys
    ]
    skipped_files = [
        path for path in all_files
        if v7.normalize_image_match_key(path.name) in skip_keys
    ]

    if not files:
        raise RuntimeError("all TIFF images are excluded by skip list")

    output_dir.mkdir(parents=True, exist_ok=True)

    v7.build_skip_measurement_report(
        all_files, skip_image_stems
    ).to_csv(
        output_dir / "skipped_images.csv",
        index=False,
        encoding="utf-8-sig",
    )

    edge_specs = build_edge_variants_v8(
        v5_params.average_range_px,
        v5_params.smoothing_pixel,
    )

    pd.DataFrame(method_definition_rows()).to_csv(
        output_dir / "V8_method_definitions.csv",
        index=False,
        encoding="utf-8-sig",
    )

    v7.write_csv(
        v7.build_variant_catalog_rows(edge_specs),
        output_dir / "variant_catalog.csv",
    )

    (output_dir / "parameters.json").write_text(
        json.dumps(
            {
                "algorithm_version": V8_VERSION,
                "v5_v2_parameters": asdict(v5_params),
                "physical_variant_parameters": asdict(variant_params),
                "v8_methods": method_definition_rows(),
                "empirical_machine_fit": False,
                "skipped_image_stems": list(skip_image_stems),
                "skip_reason": v7.DEFAULT_SKIP_REASON,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    image_rows: list[dict[str, Any]] = []
    image_variant_rows: list[dict[str, Any]] = []
    space_variant_rows: list[dict[str, Any]] = []
    sample_rows: list[dict[str, Any]] = []
    base_space_rows: list[dict[str, Any]] = []
    candidate_rows: list[dict[str, Any]] = []

    print(
        f"V8: found {len(all_files)} TIFF(s); "
        f"skip {len(skipped_files)}; process {len(files)}."
    )
    if skipped_files:
        print("Skipped: " + ", ".join(p.name for p in skipped_files))

    for number, path in enumerate(files, start=1):
        print(f"[{number}/{len(files)}] {path.name}")
        try:
            measurement = v7.v5.measure_image(path, v5_params)

            per_space, per_image_variant, per_sample, image_row = (
                v7.process_measurement_variants(
                    measurement,
                    v5_params,
                    variant_params,
                    edge_specs,
                )
            )

            # Add short V8 method code for readability.
            for row in per_image_variant:
                row["method_code"] = method_code_from_row(row) or ""
            for row in per_space:
                row["method_code"] = method_code_from_row(row) or ""

            image_rows.append(image_row)
            image_variant_rows.extend(per_image_variant)
            space_variant_rows.extend(per_space)
            sample_rows.extend(per_sample)
            base_space_rows.extend(measurement.space_rows)
            candidate_rows.extend(
                measurement.annotation_payload.get(
                    "candidate_diag", {}
                ).get("candidate_debug_rows", [])
            )

            if save_annotations:
                v7.v5.save_annotated_image(
                    path.name,
                    measurement.annotation_payload,
                    output_dir
                    / "annotated_images"
                    / f"{path.stem}_annotated.png",
                    v5_params,
                )

            # Print the three candidate results for x-axis.
            by_code = {
                row.get("method_code"): row
                for row in per_image_variant
            }
            for code in METHODS:
                row = by_code.get(code)
                if row is None:
                    print(f"  {code}: no result")
                    continue
                print(
                    f"  {code}: "
                    f"CDx={float(row.get('ACD_x_nm', math.nan)):.4f} nm, "
                    f"LER-L={float(row.get('LER_left_nm', math.nan)):.4f} nm, "
                    f"LWRx={float(row.get('LWR_x_nm', math.nan)):.4f} nm"
                )

        except Exception as exc:
            print(
                f"  ERROR: {type(exc).__name__}: {exc}",
                file=sys.stderr,
            )
            image_rows.append(
                {
                    "algorithm_version": V8_VERSION,
                    "image_name": path.name,
                    "valid": False,
                    "warning": (
                        f"processing error: "
                        f"{type(exc).__name__}: {exc}"
                    ),
                }
            )
            error_dir = output_dir / "errors"
            error_dir.mkdir(parents=True, exist_ok=True)
            (
                error_dir / f"{path.stem}.txt"
            ).write_text(
                traceback.format_exc(),
                encoding="utf-8",
            )

    v7.write_csv(
        image_rows,
        output_dir / "image_results.csv",
    )
    v7.write_csv(
        image_variant_rows,
        output_dir / "image_variant_results.csv",
    )
    v7.write_csv(
        space_variant_rows,
        output_dir / "per_space_variant_results.csv",
    )
    v7.write_csv(
        base_space_rows,
        output_dir / "per_space_results_v5_raw.csv",
    )
    v7.write_csv(
        sample_rows,
        output_dir / "per_sample_results.csv",
    )
    v7.write_csv(
        candidate_rows,
        output_dir / "candidate_debug.csv",
    )

    return 0 if image_rows else 2


def _summary_row(
    summary: pd.DataFrame,
    method: dict[str, Any],
    metric: str,
) -> pd.Series | None:
    mask = (
        (summary["result_id"].astype(str) == method["result_id"])
        & (
            summary["aggregation_mode"].astype(str)
            == method["aggregation_mode"]
        )
        & (summary["comparison_metric"].astype(str) == metric)
    )
    rows = summary.loc[mask]
    if rows.empty:
        return None
    rows = rows.sort_values(
        ["coverage_pct", "mean_abs_diff_pct"],
        ascending=[False, True],
    )
    return rows.iloc[0]


def _f(row: pd.Series | None, name: str) -> float:
    if row is None or name not in row:
        return math.nan
    try:
        value = float(row[name])
        return value if np.isfinite(value) else math.nan
    except Exception:
        return math.nan


def build_three_method_summary(
    method_summary_csv: Path,
) -> pd.DataFrame:
    summary = pd.read_csv(
        method_summary_csv,
        encoding="utf-8-sig",
    )

    rows: list[dict[str, Any]] = []

    for method_code, method in METHODS.items():
        for geometry in ("x_axis", "trench_normal"):
            cd_metric = (
                "CD_x" if geometry == "x_axis" else "CD_slant"
            )
            lwr_metric = (
                "LWR_x" if geometry == "x_axis" else "LWR_slant"
            )

            cd = _summary_row(summary, method, cd_metric)
            ler = _summary_row(summary, method, "LER_left")
            lwr = _summary_row(summary, method, lwr_metric)

            if cd is None or ler is None or lwr is None:
                continue

            cd_mape = _f(cd, "mean_abs_diff_pct")
            ler_mape = _f(ler, "mean_abs_diff_pct")
            lwr_mape = _f(lwr, "mean_abs_diff_pct")

            norm = np.asarray(
                [
                    cd_mape / TARGETS["CD_mape_target_pct"],
                    ler_mape / TARGETS["LER_mape_target_pct"],
                    lwr_mape / TARGETS["LWR_mape_target_pct"],
                ],
                dtype=float,
            )
            balanced_score = (
                0.65 * float(np.nanmax(norm))
                + 0.35 * float(np.nanmean(norm))
            )

            rows.append(
                {
                    "method_code": method_code,
                    "cn_name": method["cn_name"],
                    "geometry": geometry,
                    "result_id": method["result_id"],
                    "edge_variant": method["edge_variant"],
                    "stat_mode": method["stat_mode"],
                    "aggregation_mode":
                        method["aggregation_mode"],
                    "physical_meaning":
                        method["physical_meaning"],

                    "CD_machine_mean_nm":
                        _f(cd, "mean_machine_nm"),
                    "CD_python_mean_nm":
                        _f(cd, "mean_calculated_nm"),
                    "CD_MAPE_pct": cd_mape,
                    "CD_bias_pct":
                        _f(cd, "mean_signed_diff_pct"),
                    "CD_std_signed_pct":
                        _f(cd, "std_signed_diff_pct"),
                    "CD_rmse_nm": _f(cd, "rmse_nm"),
                    "CD_pearson_r": _f(cd, "pearson_r"),

                    "LER_machine_mean_nm":
                        _f(ler, "mean_machine_nm"),
                    "LER_python_mean_nm":
                        _f(ler, "mean_calculated_nm"),
                    "LER_MAPE_pct": ler_mape,
                    "LER_bias_pct":
                        _f(ler, "mean_signed_diff_pct"),
                    "LER_std_signed_pct":
                        _f(ler, "std_signed_diff_pct"),
                    "LER_rmse_nm": _f(ler, "rmse_nm"),
                    "LER_pearson_r": _f(ler, "pearson_r"),

                    "LWR_machine_mean_nm":
                        _f(lwr, "mean_machine_nm"),
                    "LWR_python_mean_nm":
                        _f(lwr, "mean_calculated_nm"),
                    "LWR_MAPE_pct": lwr_mape,
                    "LWR_bias_pct":
                        _f(lwr, "mean_signed_diff_pct"),
                    "LWR_std_signed_pct":
                        _f(lwr, "std_signed_diff_pct"),
                    "LWR_rmse_nm": _f(lwr, "rmse_nm"),
                    "LWR_pearson_r": _f(lwr, "pearson_r"),

                    "coverage_pct": min(
                        _f(cd, "coverage_pct"),
                        _f(ler, "coverage_pct"),
                        _f(lwr, "coverage_pct"),
                    ),
                    "mean_of_3_MAPE_pct":
                        float(np.nanmean([cd_mape, ler_mape, lwr_mape])),
                    "worst_of_3_MAPE_pct":
                        float(np.nanmax([cd_mape, ler_mape, lwr_mape])),
                    "balanced_score": balanced_score,
                }
            )

    out = pd.DataFrame(rows)
    if out.empty:
        raise RuntimeError(
            "No complete V8 three-method comparison rows found."
        )

    out = out.sort_values(
        [
            "balanced_score",
            "worst_of_3_MAPE_pct",
            "mean_of_3_MAPE_pct",
        ],
        ascending=True,
    ).reset_index(drop=True)
    out["rank"] = np.arange(1, len(out) + 1)

    # Put rank first.
    cols = ["rank"] + [
        c for c in out.columns if c != "rank"
    ]
    return out[cols]


def build_per_image_three_method_table(
    detailed_csv: Path,
) -> pd.DataFrame:
    detailed = pd.read_csv(
        detailed_csv,
        encoding="utf-8-sig",
    )

    keep = np.zeros(len(detailed), dtype=bool)
    method_code = np.full(len(detailed), "", dtype=object)

    for code, method in METHODS.items():
        mask = (
            (detailed["result_id"].astype(str) == method["result_id"])
            & (
                detailed["aggregation_mode"].astype(str)
                == method["aggregation_mode"]
            )
        )
        keep |= mask.to_numpy()
        method_code[mask.to_numpy()] = code

    out = detailed.loc[keep].copy()
    out["method_code"] = method_code[keep]

    front = [
        "machine_excel_row",
        "machine_image_name_raw",
        "image_name",
        "method_code",
        "result_id",
        "edge_variant",
        "stat_mode",
        "aggregation_mode",
        "machine_CD_nm",
        "ACD_x_nm",
        "CD_x_signed_diff_pct",
        "CD_x_abs_diff_pct",
        "ACD_slant_nm",
        "CD_slant_signed_diff_pct",
        "CD_slant_abs_diff_pct",
        "machine_LER_left_nm",
        "LER_left_nm",
        "LER_left_signed_diff_pct",
        "LER_left_abs_diff_pct",
        "machine_LWR_nm",
        "LWR_x_nm",
        "LWR_x_signed_diff_pct",
        "LWR_x_abs_diff_pct",
        "LWR_slant_nm",
        "LWR_slant_signed_diff_pct",
        "LWR_slant_abs_diff_pct",
    ]
    ordered = [c for c in front if c in out.columns]
    ordered += [c for c in out.columns if c not in ordered]

    return out[ordered].sort_values(
        ["machine_excel_row", "method_code"],
        na_position="last",
    )


def write_v8_workbook(
    output_dir: Path,
    comparison_paths: dict[str, Path],
) -> dict[str, Path]:
    summary = build_three_method_summary(
        comparison_paths["summary"]
    )
    per_image = build_per_image_three_method_table(
        comparison_paths["detailed"]
    )
    definitions = pd.DataFrame(
        method_definition_rows()
    )

    skip_measure = pd.read_csv(
        output_dir / "skipped_images.csv",
        encoding="utf-8-sig",
    )
    machine_skip_path = comparison_paths["machine_skipped"]
    if machine_skip_path.exists() and machine_skip_path.stat().st_size > 4:
        machine_skip = pd.read_csv(
            machine_skip_path,
            encoding="utf-8-sig",
        )
    else:
        machine_skip = pd.DataFrame(
            columns=[
                "machine_excel_row",
                "machine_image_name_raw",
                "image_match_key",
                "machine_CD_nm",
                "machine_LER_left_nm",
                "machine_LWR_nm",
            ]
        )

    out_csv = output_dir / "V8_three_method_summary.csv"
    out_xlsx = output_dir / "V8_three_method_comparison.xlsx"
    per_image_csv = (
        output_dir / "V8_three_method_per_image_comparison.csv"
    )

    summary.to_csv(
        out_csv,
        index=False,
        encoding="utf-8-sig",
    )
    per_image.to_csv(
        per_image_csv,
        index=False,
        encoding="utf-8-sig",
    )

    run_info = pd.DataFrame(
        [
            ["algorithm_version", V8_VERSION],
            ["candidate_method_count", 3],
            ["empirical_machine_fit", False],
            [
                "skip_image_stems",
                ";".join(DEFAULT_SKIP_IMAGE_STEMS),
            ],
            [
                "machine_reference",
                "Data.xlsx / sheet v2 / B=image, D=CD, E=LER_left, F=LWR",
            ],
            [
                "ranking",
                "0.65*worst normalized MAPE + 0.35*mean normalized MAPE",
            ],
            [
                "CD_target_MAPE_pct",
                TARGETS["CD_mape_target_pct"],
            ],
            [
                "LER_target_MAPE_pct",
                TARGETS["LER_mape_target_pct"],
            ],
            [
                "LWR_target_MAPE_pct",
                TARGETS["LWR_mape_target_pct"],
            ],
        ],
        columns=["item", "value"],
    )

    with pd.ExcelWriter(
        out_xlsx,
        engine="openpyxl",
    ) as writer:
        summary.to_excel(
            writer,
            sheet_name="Three_Method_Summary",
            index=False,
        )
        per_image.to_excel(
            writer,
            sheet_name="Per_Image_Comparison",
            index=False,
        )
        definitions.to_excel(
            writer,
            sheet_name="Method_Definitions",
            index=False,
        )
        skip_measure.to_excel(
            writer,
            sheet_name="Skipped_TIFF",
            index=False,
        )
        machine_skip.to_excel(
            writer,
            sheet_name="Skipped_Machine",
            index=False,
        )
        run_info.to_excel(
            writer,
            sheet_name="Run_Info",
            index=False,
        )

    # Readable formatting.
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill
        from openpyxl.formatting.rule import ColorScaleRule
        from openpyxl.utils import get_column_letter

        wb = load_workbook(out_xlsx)
        header_fill = PatternFill(
            "solid",
            fgColor="1F4E78",
        )
        header_font = Font(
            color="FFFFFF",
            bold=True,
        )
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            if ws.max_row and ws.max_column:
                ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]:
                cell.fill = header_fill
                cell.font = header_font

            for col in range(1, ws.max_column + 1):
                header = str(ws.cell(1, col).value or "")
                width = len(header)
                for row in range(
                    2,
                    min(ws.max_row, 150) + 1,
                ):
                    value = ws.cell(row, col).value
                    if value is not None:
                        width = max(width, len(str(value)))
                ws.column_dimensions[
                    get_column_letter(col)
                ].width = min(max(width + 2, 11), 36)

            if ws.title == "Three_Method_Summary":
                header_map = {
                    str(ws.cell(1, c).value): c
                    for c in range(1, ws.max_column + 1)
                }
                for name in [
                    "CD_MAPE_pct",
                    "LER_MAPE_pct",
                    "LWR_MAPE_pct",
                    "balanced_score",
                ]:
                    col = header_map.get(name)
                    if col and ws.max_row >= 2:
                        letter = get_column_letter(col)
                        ws.conditional_formatting.add(
                            f"{letter}2:{letter}{ws.max_row}",
                            ColorScaleRule(
                                start_type="min",
                                start_color="63BE7B",
                                mid_type="percentile",
                                mid_value=50,
                                mid_color="FFEB84",
                                end_type="max",
                                end_color="F8696B",
                            ),
                        )
        wb.save(out_xlsx)
    except Exception:
        pass

    return {
        "summary_csv": out_csv,
        "per_image_csv": per_image_csv,
        "workbook": out_xlsx,
    }


def print_v8_summary(summary_csv: Path) -> None:
    df = pd.read_csv(summary_csv, encoding="utf-8-sig")
    cols = [
        "rank",
        "method_code",
        "geometry",
        "CD_MAPE_pct",
        "CD_bias_pct",
        "LER_MAPE_pct",
        "LER_bias_pct",
        "LWR_MAPE_pct",
        "LWR_bias_pct",
        "mean_of_3_MAPE_pct",
        "worst_of_3_MAPE_pct",
        "balanced_score",
        "coverage_pct",
    ]
    print("\n=== V8 three-candidate Machine comparison ===")
    print(
        df[cols]
        .round(3)
        .to_string(index=False)
    )


def build_parser() -> argparse.ArgumentParser:
    # Reuse V7's complete recipe CLI, so all established V2/V5 parameters
    # remain available and unchanged.
    parser = v7.build_parser()
    parser.description = (
        "CD-SEM V8: only three selected candidate algorithms, "
        "with automatic Data.xlsx machine comparison."
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    v5_params, variant_params = v7.params_from_args(args)
    output_dir = (
        args.output_dir
        or (args.input_dir / "cdsem_results_v8")
    )

    try:
        skip_image_stems = (
            []
            if args.no_default_quality_skip
            else list(DEFAULT_SKIP_IMAGE_STEMS)
        )
        skip_image_stems.extend(args.skip_image)
        skip_image_stems = list(
            dict.fromkeys(skip_image_stems)
        )

        result_code = run_batch_v8(
            args.input_dir,
            output_dir,
            v5_params,
            variant_params,
            recursive=args.recursive,
            save_annotations=not args.no_annotated_images,
            skip_image_stems=skip_image_stems,
        )

        if args.skip_machine_comparison:
            print("Machine comparison skipped by user.")
            return result_code

        machine_excel = (
            args.machine_excel
            or (args.input_dir / "Data.xlsx")
        )
        comparison_config = v7.MachineComparisonConfig(
            excel_path=machine_excel,
            sheet_name=args.machine_sheet,
            start_row=args.machine_start_row,
            end_row=args.machine_end_row,
            image_column=args.machine_image_column,
            cd_column=args.machine_cd_column,
            ler_left_column=args.machine_ler_left_column,
            lwr_column=args.machine_lwr_column,
            strict_expected_row_count=(
                not args.allow_machine_row_count_mismatch
            ),
        )

        comparison_paths = v7.run_machine_comparison(
            args.input_dir,
            output_dir,
            comparison_config,
            recursive=args.recursive,
            skip_image_stems=skip_image_stems,
        )

        v8_paths = write_v8_workbook(
            output_dir,
            comparison_paths,
        )
        print_v8_summary(v8_paths["summary_csv"])

        print("\nV8 finished.")
        print(f"Results folder: {output_dir.resolve()}")
        print(
            "Main V8 workbook: "
            f"{v8_paths['workbook'].resolve()}"
        )
        return result_code

    except Exception as exc:
        parser.error(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
