﻿param(
    [Parameter(Mandatory=$true)][string]$Root,
    [ValidateSet("trench", "via")][string]$Pattern = "trench",
    [double]$PixelSize = 1.3181,
    [ValidateRange(0,100)][int]$Continuity = 0,
    [string]$Output = ""
)
$entryPath = Join-Path $PSScriptRoot "sem_cd_measure_200k_batch_V1_12.py"
$runArgs = @($entryPath, "--root", $Root, "--pattern", $Pattern, "--pixel-size", $PixelSize.ToString([System.Globalization.CultureInfo]::InvariantCulture), "--edge-continuity", $Continuity)
if ($Output) { $runArgs += @("--output", $Output) }
& python @runArgs
exit $LASTEXITCODE
