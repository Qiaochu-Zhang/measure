#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SEM PNG batch measurement V1.12 / unrotated + centerline-rotated axes
======================================================================

Input and top-level defaults follow sem_cd_measure_200k_batch_V1_7.py:

* recursively process every PNG below ``--root``;
* do not infer or filter by directory/file name;
* ``--pattern via|trench`` applies to the complete input tree;
* keep the input relative directory and original PNG name for annotations;
* default pixel size is 1.3181 nm/pixel;
* estimate the reference CD from each image unless a CLI reference is supplied.

Algorithm routing:

* via: the complete V1.7 via detector/QC/statistics is reused because V10 does
  not define a via algorithm.
* trench: preserve the V1.9 source routing (V13 raw CD, V10 raw LER, V13
  group-of-four LWR) and report two coordinate systems. ``unrotated`` uses the
  image X/Y axes. ``rotated`` defines Y' along each trench's fitted mean
  centerline and X' along its normal. No separate ``slant`` primary result is
  needed because the rotated coordinates already contain that projection.

This program is a simulator based on the supplied V10 package.  It is not the
official source code of any CD-SEM vendor.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
import traceback
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

import sem_cd_measure_200k_batch_V1_7 as v17
import cdsem_batch_v10_hybrid_statistics as v10
import cdsem_v13_edge_engine as v13v5
from cdsem_v112_psd import PSDBatch


SCRIPT_VERSION = "2026-09-10-V1.12-PSD-CONTINUITY-DUAL-COORDINATE-V13-CD-LWR-V10-LER"
DEFAULT_ROOT = v17.DEFAULT_ROOT
DEFAULT_OUTPUT_NAME = "CD_measure_output_200K_V1_12"
EPS = 1e-12

V112_METHOD_CODE = "V112_DualAxis_V13RawCD_V10RawLER_V13Group4LWR"
V112_RESULT_ID = "dual_axis__v13_raw_cd__v10_raw_ler__v13_group4_lwr"
V112_STAT_MODE = "unrotated_and_centerline_rotated"
V112_AGGREGATION = "mean_per_space"
V10_THRESHOLD_MODE = "v10_center40_dark_median_peak3_bright_median50"
V13_THRESHOLD_MODE = "v17_side_band_mean50"
V13_ALGORITHM_VERSION = "V13_V17_THRESHOLD_V10_STATISTICS"

v7 = v10.v9.v8.v7
v5 = v7.v5


def read_png_for_engine(path: Path, engine: Any) -> tuple[np.ndarray, list[str]]:
    """Unicode-safe PNG read followed by the selected engine's normalization."""
    raw = v17.unicode_imread(path)
    if raw.ndim == 3:
        if raw.shape[2] == 4:
            raw = v17.cv2.cvtColor(raw, v17.cv2.COLOR_BGRA2GRAY)
        else:
            raw = v17.cv2.cvtColor(raw, v17.cv2.COLOR_BGR2GRAY)
    image, warnings = engine.normalize_to_8bit_float(raw)
    return image, [message.replace("TIFF", "PNG") for message in warnings]


def read_png_for_v10(path: Path) -> tuple[np.ndarray, list[str]]:
    return read_png_for_engine(path, v5)


def read_png_for_v13(path: Path) -> tuple[np.ndarray, list[str]]:
    return read_png_for_engine(path, v13v5)


# The supplied V10 engine calls this loader from measure_image().  Replacing
# only the loader leaves Basin-First, V2 tracking and statistics untouched.
v5.read_tiff = read_png_for_v10
v13v5.read_tiff = read_png_for_v13


def finite_float(value: Any, default: float = math.nan) -> float:
    try:
        result = float(value)
        return result if np.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def safe_mean(values: Iterable[Any]) -> float:
    array = np.asarray([finite_float(value) for value in values], dtype=float)
    array = array[np.isfinite(array)]
    return float(np.mean(array)) if array.size else math.nan


def safe_std(values: Iterable[Any], ddof: int = 1) -> float:
    array = np.asarray([finite_float(value) for value in values], dtype=float)
    array = array[np.isfinite(array)]
    return float(np.std(array, ddof=ddof)) if array.size > ddof else math.nan


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding="utf-8-sig")


def dataframe_or_empty(rows: Sequence[dict[str, Any]], columns: Sequence[str] = ()) -> pd.DataFrame:
    if rows:
        return pd.DataFrame(rows)
    return pd.DataFrame(columns=list(columns))


def without_legacy_slant_columns(frame: pd.DataFrame) -> pd.DataFrame:
    """Remove legacy projection fields from user-facing V1.12 tables.

    The underlying V10/V13 engines still calculate their historical slant
    fields internally. V1.12 exposes the same physical idea more explicitly
    as a complete ``rotated`` coordinate-system result, so keeping both would
    be redundant and easy to misinterpret.
    """
    obsolete = [column for column in frame.columns if "slant" in str(column).casefold()]
    return frame.drop(columns=obsolete) if obsolete else frame


def jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def relative_key(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.name


def metadata_for(parsed: v17.ParsedImage, general: v17.GeneralConfig) -> dict[str, Any]:
    return {
        "folder_name": parsed.folder_name,
        "folder_nominal_nm": parsed.folder_nominal_nm,
        "pretreatment_nm": parsed.pretreatment_nm,
        "dose_mj": parsed.dose_mj,
        "sample_id": parsed.sample_id,
        "metadata_source": parsed.metadata_source,
        "image": parsed.path.name,
        "image_key": relative_key(parsed.path, general.root_dir),
        "path": str(parsed.path),
        "pattern": "trench",
        "pixel_size_nm": general.pixel_size_nm,
        "design_trench_nm": parsed.design_trench_nm,
        "design_space_nm": parsed.design_space_nm,
    }


def _bounded_odd(value: int, maximum: int) -> int:
    result = max(1, min(int(value), max(1, int(maximum))))
    if result % 2 == 0:
        result = result - 1 if result > 1 else 1
    return result


def build_v10_params(
    parsed: v17.ParsedImage,
    gray: np.ndarray,
    general: v17.GeneralConfig,
    args: argparse.Namespace,
) -> v5.MeasurementParams:
    """Create one V10 parameter set while allowing arbitrary PNG dimensions."""
    height, width = gray.shape
    center_x = float(args.center_x) if args.center_x is not None else (width - 1.0) / 2.0
    center_y = float(args.center_y) if args.center_y is not None else (height - 1.0) / 2.0
    average_range = max(1, min(int(args.average_range), height))
    smoothing = _bounded_odd(int(args.smoothing_pixel), width)
    extend_length = (
        int(args.extend_length)
        if args.extend_length is not None
        else min(360, height)
    )
    extend_length = max(2, min(extend_length, height))
    measurement_width = min(512, width)
    measurement_height = min(512, height)

    target_cd = finite_float(parsed.design_trench_nm)
    if not np.isfinite(target_cd) or target_cd <= 0:
        raise ValueError("无法取得有效 Trench 参考宽度")

    return v5.MeasurementParams(
        expected_width_px=width,
        expected_height_px=height,
        pixel_size_nm=general.pixel_size_nm,
        target_cd_nm=target_cd,
        center_x_px=center_x,
        center_y_px=center_y,
        search_range_in_px=int(args.search_in),
        search_range_out_px=int(args.search_out),
        extend_length_px=extend_length,
        peak_order=int(args.peak_order),
        edge_threshold_left_pct=float(args.threshold_left),
        edge_threshold_right_pct=float(args.threshold_right),
        smoothing_pixel=smoothing,
        sample_number=int(args.sample_number),
        average_range_px=average_range,
        topology_min_contrast_8bit=float(args.topology_min_contrast),
        tracking_search_radius_px=float(args.tracking_radius),
        tracking_retry_radius_px=float(args.tracking_retry_radius),
        tracking_max_edge_jump_px=float(args.tracking_max_jump),
        postfilter_window=int(args.postfilter_window),
        postfilter_mad_multiplier=float(args.postfilter_mad_multiplier),
        postfilter_min_edge_tolerance_px=float(args.postfilter_edge_tolerance),
        recover_rejected_points=not bool(args.no_recovery),
        edge_continuity=int(args.edge_continuity),
        max_number=int(args.max_number),
        min_number=int(args.min_number),
        candidate_dark_mean_tolerance_8bit=float(args.candidate_dark_tolerance),
        candidate_min_basin_contrast_8bit=float(args.candidate_min_contrast),
        require_center_left_right=not bool(args.allow_incomplete_triplet),
        meas_area_width_px=measurement_width,
        meas_area_height_px=measurement_height,
        minimum_valid_fraction=float(args.minimum_valid_fraction),
        flyer_mode=str(args.flyer_mode),
        flyer_left_offset_px=float(args.flyer_left_offset),
        flyer_right_offset_px=float(args.flyer_right_offset),
    )


def build_v13_params(params: v5.MeasurementParams) -> v13v5.MeasurementParams:
    """Clone every V1.8/V10 public parameter into the V13 edge engine."""
    return v13v5.MeasurementParams(**asdict(params))


def set_measurement_image_key(measurement: Any, image_key: str) -> None:
    measurement.image_row["image_name"] = image_key
    for row in measurement.space_rows:
        row["image_name"] = image_key
    for row in measurement.sample_rows:
        row["image_name"] = image_key
    for row in measurement.annotation_payload.get("candidate_diag", {}).get(
        "candidate_debug_rows", []
    ):
        row["image_name"] = image_key


def enrich_source_rows(
    rows: Sequence[dict[str, Any]],
    parsed: v17.ParsedImage,
    general: v17.GeneralConfig,
    source_engine: str,
    source_algorithm_version: str,
) -> list[dict[str, Any]]:
    meta = metadata_for(parsed, general)
    enriched: list[dict[str, Any]] = []
    for row in rows:
        item = dict(row)
        item["pipeline_algorithm_version"] = item.get("algorithm_version", "")
        item["source_algorithm_version"] = source_algorithm_version
        item["source_engine"] = source_engine
        item.update(meta)
        item["algorithm_version"] = SCRIPT_VERSION
        enriched.append(item)
    return enriched


def _first_result(
    rows: Sequence[dict[str, Any]], result_id: str
) -> dict[str, Any] | None:
    for row in rows:
        if str(row.get("result_id", "")) == result_id:
            return dict(row)
    return None


def _joined_warning(*rows: dict[str, Any]) -> str:
    warnings = [str(row.get("warning", "")).strip() for row in rows]
    return " | ".join(value for value in warnings if value)


def coordinate_metrics_by_space(
    sample_rows: list[dict[str, Any]],
    params: Any,
    group_size: int,
) -> dict[int, dict[str, Any]]:
    """Calculate unrotated and true centerline-rotated metrics per trench.

    The fitted centerline direction is Y'.  Its normal is X'.  Rotating the
    edge coordinates makes LER a 3sigma fluctuation of X', so a perfectly
    straight but tilted edge no longer receives artificial LER from its slope.
    ``sample_rows`` is updated with rotated coordinates for full auditability.
    """
    groups: dict[int, list[dict[str, Any]]] = {}
    for row in sample_rows:
        groups.setdefault(int(row["space_index"]), []).append(row)

    output: dict[int, dict[str, Any]] = {}
    for space_index, rows in groups.items():
        rows.sort(key=lambda item: int(item["sample_index"]))
        y = np.asarray([finite_float(item.get("sample_y")) for item in rows], dtype=float)
        left = np.asarray(
            [finite_float(item.get("left_edge_x")) for item in rows], dtype=float
        )
        right = np.asarray(
            [finite_float(item.get("right_edge_x")) for item in rows], dtype=float
        )
        valid_flags = np.asarray([bool(item.get("valid", False)) for item in rows])
        valid = (
            valid_flags
            & np.isfinite(y)
            & np.isfinite(left)
            & np.isfinite(right)
            & (right > left)
        )
        left[~valid] = np.nan
        right[~valid] = np.nan

        fit = v5.fit_centerline_and_width_factor(y, left, right)
        angle_deg = finite_float(fit.get("angle_from_vertical_deg"), 0.0)
        theta = math.radians(angle_deg)
        cos_theta = math.cos(theta)
        sin_theta = math.sin(theta)

        midpoint = 0.5 * (left + right)
        origin_x = safe_mean(midpoint)
        origin_y = safe_mean(y[valid])
        if not np.isfinite(origin_x):
            origin_x = 0.0
        if not np.isfinite(origin_y):
            origin_y = 0.0

        # Rotation about the mean center. Translation does not affect standard
        # deviations or widths, but keeps audit coordinates numerically compact.
        left_prime = cos_theta * (left - origin_x) - sin_theta * (y - origin_y)
        right_prime = cos_theta * (right - origin_x) - sin_theta * (y - origin_y)
        center_y_prime = (
            sin_theta * (midpoint - origin_x) + cos_theta * (y - origin_y)
        )

        for index, row in enumerate(rows):
            row["rotated_axis_angle_from_vertical_deg"] = angle_deg
            row["rotated_axis_normal_factor"] = abs(cos_theta)
            row["rotated_left_x_prime_px"] = finite_float(left_prime[index])
            row["rotated_right_x_prime_px"] = finite_float(right_prime[index])
            row["rotated_center_y_prime_px"] = finite_float(center_y_prime[index])
            row["rotated_local_cd_nm"] = (
                finite_float((right_prime[index] - left_prime[index]) * params.pixel_size_nm)
                if valid[index]
                else math.nan
            )

        unrotated_raw = v7.sequence_metrics(
            y,
            left,
            right,
            params.pixel_size_nm,
            1.0,
            params.standard_deviation_ddof,
        )
        rotated_raw = v7.sequence_metrics(
            center_y_prime,
            left_prime,
            right_prime,
            params.pixel_size_nm,
            1.0,
            params.standard_deviation_ddof,
        )
        unrot_y4, unrot_left4, unrot_right4 = v7.apply_stat_mode(
            y, left, right, "group4_mean", params, group_size
        )
        rot_y4, rot_left4, rot_right4 = v7.apply_stat_mode(
            center_y_prime,
            left_prime,
            right_prime,
            "group4_mean",
            params,
            group_size,
        )
        unrotated_group4 = v7.sequence_metrics(
            unrot_y4,
            unrot_left4,
            unrot_right4,
            params.pixel_size_nm,
            1.0,
            params.standard_deviation_ddof,
        )
        rotated_group4 = v7.sequence_metrics(
            rot_y4,
            rot_left4,
            rot_right4,
            params.pixel_size_nm,
            1.0,
            params.standard_deviation_ddof,
        )

        output[space_index] = {
            "space_index": space_index,
            "space_role": str(rows[0].get("space_role", "")),
            "rotation_angle_from_vertical_deg": angle_deg,
            "rotation_normal_factor": abs(cos_theta),
            "valid_sample_count": int(valid.sum()),
            "unrotated_raw_CD_nm": finite_float(unrotated_raw["mean_cd_x_nm"]),
            "unrotated_raw_LER_left_nm": finite_float(unrotated_raw["ler_left_nm"]),
            "unrotated_raw_LER_right_nm": finite_float(unrotated_raw["ler_right_nm"]),
            "unrotated_group4_LWR_nm": finite_float(unrotated_group4["lwr_x_nm"]),
            "rotated_raw_CD_nm": finite_float(rotated_raw["mean_cd_x_nm"]),
            "rotated_raw_LER_left_nm": finite_float(rotated_raw["ler_left_nm"]),
            "rotated_raw_LER_right_nm": finite_float(rotated_raw["ler_right_nm"]),
            "rotated_group4_LWR_nm": finite_float(rotated_group4["lwr_x_nm"]),
        }
    return output


def aggregate_coordinate_metrics(
    metrics_by_space: dict[int, dict[str, Any]],
    selected_indices: Sequence[int],
) -> dict[str, Any]:
    selected = [
        metrics_by_space[index]
        for index in selected_indices
        if index in metrics_by_space
    ]
    if not selected:
        return {}
    metric_names = [
        "unrotated_raw_CD_nm",
        "unrotated_raw_LER_left_nm",
        "unrotated_raw_LER_right_nm",
        "unrotated_group4_LWR_nm",
        "rotated_raw_CD_nm",
        "rotated_raw_LER_left_nm",
        "rotated_raw_LER_right_nm",
        "rotated_group4_LWR_nm",
    ]
    result = {
        name: safe_mean(item.get(name) for item in selected)
        for name in metric_names
    }
    angles = [finite_float(item.get("rotation_angle_from_vertical_deg")) for item in selected]
    result.update(
        {
            "selected_space_count": len(selected),
            "rotation_angle_mean_deg": safe_mean(angles),
            "rotation_angle_abs_mean_deg": safe_mean(abs(value) for value in angles),
            "rotation_angle_min_deg": min(value for value in angles if np.isfinite(value)),
            "rotation_angle_max_deg": max(value for value in angles if np.isfinite(value)),
        }
    )
    return result


def add_coordinate_fields_to_image(
    row: dict[str, Any],
    v10_coordinate: dict[str, Any],
    v13_coordinate: dict[str, Any],
) -> dict[str, Any]:
    row.update(
        {
            "coordinate_definition": (
                "unrotated=image X/Y; rotated=Y' along fitted trench centerline, "
                "X' along trench normal"
            ),
            "unrotated_CD_nm": finite_float(row.get("ACD_x_nm")),
            "unrotated_LER_left_nm": finite_float(row.get("LER_left_nm")),
            "unrotated_LER_right_nm": finite_float(row.get("LER_right_nm")),
            "unrotated_LWR_nm": finite_float(row.get("LWR_x_nm")),
            "rotated_CD_nm": finite_float(v13_coordinate.get("rotated_raw_CD_nm")),
            "rotated_LER_left_nm": finite_float(v10_coordinate.get("rotated_raw_LER_left_nm")),
            "rotated_LER_right_nm": finite_float(v10_coordinate.get("rotated_raw_LER_right_nm")),
            "rotated_LWR_nm": finite_float(v13_coordinate.get("rotated_group4_LWR_nm")),
            "rotation_angle_CD_LWR_mean_deg": finite_float(v13_coordinate.get("rotation_angle_mean_deg")),
            "rotation_angle_LER_mean_deg": finite_float(v10_coordinate.get("rotation_angle_mean_deg")),
            "rotation_angle_CD_LWR_abs_mean_deg": finite_float(v13_coordinate.get("rotation_angle_abs_mean_deg")),
            "rotation_angle_LER_abs_mean_deg": finite_float(v10_coordinate.get("rotation_angle_abs_mean_deg")),
            "audit_v13_rotated_raw_CD_nm": finite_float(v13_coordinate.get("rotated_raw_CD_nm")),
            "audit_v10_rotated_raw_LER_left_nm": finite_float(v10_coordinate.get("rotated_raw_LER_left_nm")),
            "audit_v10_rotated_raw_LER_right_nm": finite_float(v10_coordinate.get("rotated_raw_LER_right_nm")),
            "audit_v13_rotated_group4_LWR_nm": finite_float(v13_coordinate.get("rotated_group4_LWR_nm")),
        }
    )
    # V1.9 aliases stay for downstream compatibility and mean unrotated values.
    row["ACD_x_nm"] = row["unrotated_CD_nm"]
    row["LER_left_nm"] = row["unrotated_LER_left_nm"]
    row["LER_right_nm"] = row["unrotated_LER_right_nm"]
    row["LWR_x_nm"] = row["unrotated_LWR_nm"]
    for obsolete in [
        key
        for key in row
        if "slant" in key.casefold() or key in {
            "mean_trench_normal_width_nm",
            "trench_normal_lwr_3sigma_nm",
        }
    ]:
        row.pop(obsolete, None)
    return row


def add_coordinate_fields_to_objects(
    rows: list[dict[str, Any]],
    v10_metrics: dict[int, dict[str, Any]],
    v13_metrics: dict[int, dict[str, Any]],
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for source in rows:
        row = dict(source)
        v10_item = v10_metrics.get(int(row["v10_space_index"]), {})
        v13_item = v13_metrics.get(int(row["v13_space_index"]), {})
        row.update(
            {
                "unrotated_CD_nm": finite_float(row.get("mean_cd_x_nm")),
                "unrotated_LER_left_nm": finite_float(row.get("ler_left_nm")),
                "unrotated_LER_right_nm": finite_float(row.get("ler_right_nm")),
                "unrotated_LWR_nm": finite_float(row.get("lwr_x_nm")),
                "rotated_CD_nm": finite_float(v13_item.get("rotated_raw_CD_nm")),
                "rotated_LER_left_nm": finite_float(v10_item.get("rotated_raw_LER_left_nm")),
                "rotated_LER_right_nm": finite_float(v10_item.get("rotated_raw_LER_right_nm")),
                "rotated_LWR_nm": finite_float(v13_item.get("rotated_group4_LWR_nm")),
                "rotation_angle_CD_LWR_deg": finite_float(v13_item.get("rotation_angle_from_vertical_deg")),
                "rotation_angle_LER_deg": finite_float(v10_item.get("rotation_angle_from_vertical_deg")),
            }
        )
        for obsolete in [
            key
            for key in row
            if "slant" in key.casefold() or key in {
                "mean_normal_width_nm", "normal_lwr_3sigma_nm",
            }
        ]:
            row.pop(obsolete, None)
        output.append(row)
    return output


def hybrid_primary_image(
    v10_source_rows: Sequence[dict[str, Any]],
    v13_source_rows: Sequence[dict[str, Any]],
    parsed: v17.ParsedImage,
    general: v17.GeneralConfig,
    v10_base_image_row: dict[str, Any],
    v13_base_image_row: dict[str, Any],
) -> dict[str, Any] | None:
    v10_raw = _first_result(v10_source_rows, v10.RAW_RESULT_ID)
    v10_group4 = _first_result(v10_source_rows, v10.GROUP4_RESULT_ID)
    v13_raw = _first_result(v13_source_rows, v10.RAW_RESULT_ID)
    v13_group4 = _first_result(v13_source_rows, v10.GROUP4_RESULT_ID)
    if any(row is None for row in (v10_raw, v10_group4, v13_raw, v13_group4)):
        return None
    assert v10_raw is not None and v10_group4 is not None
    assert v13_raw is not None and v13_group4 is not None

    row = dict(v13_raw)
    row.update(metadata_for(parsed, general))
    row.update(
        {
            "algorithm_version": SCRIPT_VERSION,
            "method_code": V112_METHOD_CODE,
            "result_id": V112_RESULT_ID,
            "edge_variant": "v13_raw_cd_lwr__v10_raw_ler",
            "stat_mode": V112_STAT_MODE,
            "aggregation_mode": V112_AGGREGATION,
            "variant_category": "cross_engine_hybrid_statistics",
            "variant_interpretation": (
                "CD=V13 raw V2; LER=V10 raw V2; "
                "LWR=V13 consecutive group-of-four"
            ),
            "ACD_x_nm": finite_float(v13_raw.get("ACD_x_nm")),
            "ACD_slant_nm": finite_float(v13_raw.get("ACD_slant_nm")),
            "LER_left_nm": finite_float(v10_raw.get("LER_left_nm")),
            "LER_right_nm": finite_float(v10_raw.get("LER_right_nm")),
            "LWR_x_nm": finite_float(v13_group4.get("LWR_x_nm")),
            "LWR_slant_nm": finite_float(v13_group4.get("LWR_slant_nm")),
            "source_CD_engine": "V13",
            "source_LER_engine": "V10",
            "source_LWR_engine": "V13",
            "source_CD_threshold_mode": V13_THRESHOLD_MODE,
            "source_LER_threshold_mode": V10_THRESHOLD_MODE,
            "source_LWR_threshold_mode": V13_THRESHOLD_MODE,
            "source_CD_result_id": v10.RAW_RESULT_ID,
            "source_LER_result_id": v10.RAW_RESULT_ID,
            "source_LWR_result_id": v10.GROUP4_RESULT_ID,
            "CD_stat_mode": "all_submean",
            "LER_stat_mode": "all_submean",
            "LWR_stat_mode": "group4_mean",
            "status": (
                "OK"
                if bool(v10_base_image_row.get("valid", False))
                and bool(v13_base_image_row.get("valid", False))
                else "REVIEW"
            ),
            "v10_measurement_valid": bool(v10_base_image_row.get("valid", False)),
            "v13_measurement_valid": bool(v13_base_image_row.get("valid", False)),
            "v10_triplet_complete": bool(v10_base_image_row.get("triplet_complete", False)),
            "v13_triplet_complete": bool(v13_base_image_row.get("triplet_complete", False)),
            "v10_selected_roles": v10_base_image_row.get("selected_roles", ""),
            "v13_selected_roles": v13_base_image_row.get("selected_roles", ""),
            "v10_selected_trench_count": int(v10_base_image_row.get("selected_space_count", 0)),
            "v13_selected_trench_count": int(v13_base_image_row.get("selected_space_count", 0)),
            "v10_stable_trench_count": int(v10_base_image_row.get("stable_space_count", 0)),
            "v13_stable_trench_count": int(v13_base_image_row.get("stable_space_count", 0)),
            "selected_trench_count": int(v13_base_image_row.get("selected_space_count", 0)),
            "stable_trench_count": int(v13_base_image_row.get("stable_space_count", 0)),
            "warning": _joined_warning(v10_base_image_row, v13_base_image_row),
            "audit_v10_raw_ACD_x_nm": finite_float(v10_raw.get("ACD_x_nm")),
            "audit_v10_raw_ACD_slant_nm": finite_float(v10_raw.get("ACD_slant_nm")),
            "audit_v10_raw_LER_left_nm": finite_float(v10_raw.get("LER_left_nm")),
            "audit_v10_raw_LER_right_nm": finite_float(v10_raw.get("LER_right_nm")),
            "audit_v10_raw_LWR_x_nm": finite_float(v10_raw.get("LWR_x_nm")),
            "audit_v10_raw_LWR_slant_nm": finite_float(v10_raw.get("LWR_slant_nm")),
            "audit_v10_group4_LWR_x_nm": finite_float(v10_group4.get("LWR_x_nm")),
            "audit_v10_group4_LWR_slant_nm": finite_float(v10_group4.get("LWR_slant_nm")),
            "audit_v13_raw_ACD_x_nm": finite_float(v13_raw.get("ACD_x_nm")),
            "audit_v13_raw_ACD_slant_nm": finite_float(v13_raw.get("ACD_slant_nm")),
            "audit_v13_raw_LER_left_nm": finite_float(v13_raw.get("LER_left_nm")),
            "audit_v13_raw_LER_right_nm": finite_float(v13_raw.get("LER_right_nm")),
            "audit_v13_raw_LWR_x_nm": finite_float(v13_raw.get("LWR_x_nm")),
            "audit_v13_raw_LWR_slant_nm": finite_float(v13_raw.get("LWR_slant_nm")),
            "audit_v13_group4_LWR_x_nm": finite_float(v13_group4.get("LWR_x_nm")),
            "audit_v13_group4_LWR_slant_nm": finite_float(v13_group4.get("LWR_slant_nm")),
        }
    )
    row.update(
        {
            "mean_trench_width_nm": row["ACD_x_nm"],
            "ler_left_3sigma_nm": row["LER_left_nm"],
            "ler_right_3sigma_nm": row["LER_right_nm"],
            "lwr_3sigma_nm": row["LWR_x_nm"],
            "mean_trench_normal_width_nm": row["ACD_slant_nm"],
            "trench_normal_lwr_3sigma_nm": row["LWR_slant_nm"],
        }
    )
    return row


def hybrid_primary_objects(
    v10_source_rows: Sequence[dict[str, Any]],
    v13_source_rows: Sequence[dict[str, Any]],
    parsed: v17.ParsedImage,
    general: v17.GeneralConfig,
) -> list[dict[str, Any]]:
    if not v10_source_rows or not v13_source_rows:
        return []
    v10_hybrid = v10.hybrid_space_rows(pd.DataFrame(v10_source_rows))
    v13_hybrid = v10.hybrid_space_rows(pd.DataFrame(v13_source_rows))
    if v10_hybrid.empty or v13_hybrid.empty:
        return []

    def pair_key(record: pd.Series) -> tuple[str, Any]:
        role = str(record.get("space_role", "")).strip()
        return ("role", role) if role else ("index", int(record["space_index"]))

    v10_by_key = {pair_key(record): record for _, record in v10_hybrid.iterrows()}
    output: list[dict[str, Any]] = []
    meta = metadata_for(parsed, general)
    for _, v13_record in v13_hybrid.iterrows():
        v10_record = v10_by_key.get(pair_key(v13_record))
        if v10_record is None:
            continue
        row = v13_record.to_dict()
        row.update(meta)
        row.update(
            {
                "algorithm_version": SCRIPT_VERSION,
                "method_code": V112_METHOD_CODE,
                "result_id": V112_RESULT_ID,
                "edge_variant": "v13_raw_cd_lwr__v10_raw_ler",
                "stat_mode": V112_STAT_MODE,
                "aggregation_mode": V112_AGGREGATION,
                "pattern": "trench",
                "trench_id": int(v13_record["space_index"]),
                "v10_space_index": int(v10_record["space_index"]),
                "v13_space_index": int(v13_record["space_index"]),
                "mean_cd_x_nm": finite_float(v13_record.get("mean_cd_x_nm")),
                "mean_cd_slant_nm": finite_float(v13_record.get("mean_cd_slant_nm")),
                "ler_left_nm": finite_float(v10_record.get("ler_left_nm")),
                "ler_right_nm": finite_float(v10_record.get("ler_right_nm")),
                "lwr_x_nm": finite_float(v13_record.get("lwr_x_nm")),
                "lwr_slant_nm": finite_float(v13_record.get("lwr_slant_nm")),
                "source_CD_engine": "V13",
                "source_LER_engine": "V10",
                "source_LWR_engine": "V13",
                "source_CD_result_id": v10.RAW_RESULT_ID,
                "source_LER_result_id": v10.RAW_RESULT_ID,
                "source_LWR_result_id": v10.GROUP4_RESULT_ID,
                "audit_v10_raw_LER_left_nm": finite_float(v10_record.get("ler_left_nm")),
                "audit_v10_raw_LER_right_nm": finite_float(v10_record.get("ler_right_nm")),
                "audit_v13_raw_ACD_x_nm": finite_float(v13_record.get("mean_cd_x_nm")),
                "audit_v13_raw_ACD_slant_nm": finite_float(v13_record.get("mean_cd_slant_nm")),
                "audit_v13_group4_LWR_x_nm": finite_float(v13_record.get("lwr_x_nm")),
                "audit_v13_group4_LWR_slant_nm": finite_float(v13_record.get("lwr_slant_nm")),
                "mean_width_nm": finite_float(v13_record.get("mean_cd_x_nm")),
                "ler_left_3sigma_nm": finite_float(v10_record.get("ler_left_nm")),
                "ler_right_3sigma_nm": finite_float(v10_record.get("ler_right_nm")),
                "lwr_3sigma_nm": finite_float(v13_record.get("lwr_x_nm")),
                "mean_normal_width_nm": finite_float(v13_record.get("mean_cd_slant_nm")),
                "normal_lwr_3sigma_nm": finite_float(v13_record.get("lwr_slant_nm")),
                "used_for_statistics": True,
            }
        )
        output.append(row)
    return output


def build_condition_summary(image_df: pd.DataFrame) -> pd.DataFrame:
    if image_df.empty:
        return pd.DataFrame()
    metrics = [
        "unrotated_CD_nm",
        "unrotated_LER_left_nm",
        "unrotated_LER_right_nm",
        "unrotated_LWR_nm",
        "rotated_CD_nm",
        "rotated_LER_left_nm",
        "rotated_LER_right_nm",
        "rotated_LWR_nm",
    ]
    rows: list[dict[str, Any]] = []
    for folder, group in image_df.groupby("folder_name", dropna=False, sort=True):
        row: dict[str, Any] = {
            "folder_name": folder,
            "pattern": "trench",
            "image_count": int(len(group)),
            "ok_image_count": int((group["status"].astype(str) == "OK").sum()),
            "review_image_count": int((group["status"].astype(str) == "REVIEW").sum()),
            "mean_design_trench_nm": safe_mean(group["design_trench_nm"]),
        }
        for metric in metrics:
            values = pd.to_numeric(group.get(metric), errors="coerce")
            row[f"{metric}_n"] = int(values.notna().sum())
            row[f"{metric}_mean"] = safe_mean(values)
            row[f"{metric}_std"] = safe_std(values)
            row[f"{metric}_median"] = (
                float(values.median()) if values.notna().any() else math.nan
            )
        rows.append(row)
    return pd.DataFrame(rows)


def build_object_long(trench_df: pd.DataFrame) -> pd.DataFrame:
    if trench_df.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for _, item in trench_df.iterrows():
        for mode in ("unrotated", "rotated"):
            rows.append(
                {
                    "folder_name": item.get("folder_name"),
                    "image": item.get("image"),
                    "image_key": item.get("image_key"),
                    "path": item.get("path"),
                    "pattern": "trench",
                    "object_id": item.get("trench_id"),
                    "coordinate_mode": mode,
                    "metric": "trench_width",
                    "design_nm": item.get("design_trench_nm"),
                    "measured_object_nm": item.get(f"{mode}_CD_nm"),
                    "ler_left_3sigma_nm": item.get(f"{mode}_LER_left_nm"),
                    "ler_right_3sigma_nm": item.get(f"{mode}_LER_right_nm"),
                    "roughness_3sigma_nm": item.get(f"{mode}_LWR_nm"),
                    "axis_angle_CD_LWR_from_vertical_deg": (
                        0.0 if mode == "unrotated"
                        else item.get("rotation_angle_CD_LWR_deg")
                    ),
                    "axis_angle_LER_from_vertical_deg": (
                        0.0 if mode == "unrotated"
                        else item.get("rotation_angle_LER_deg")
                    ),
                    "method": V112_METHOD_CODE,
                }
            )
    return pd.DataFrame(rows)


def build_image_coordinate_results(image_df: pd.DataFrame) -> pd.DataFrame:
    if image_df.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    meta = [
        "folder_name", "image", "image_key", "path", "pattern",
        "pixel_size_nm", "design_trench_nm", "status", "warning",
    ]
    for _, item in image_df.iterrows():
        common = {name: item.get(name) for name in meta}
        for mode in ("unrotated", "rotated"):
            rows.append(
                {
                    **common,
                    "algorithm_version": SCRIPT_VERSION,
                    "method_code": V112_METHOD_CODE,
                    "result_id": V112_RESULT_ID,
                    "coordinate_mode": mode,
                    "axis_definition": (
                        "image X/Y"
                        if mode == "unrotated"
                        else "Y' along fitted trench centerline; X' along normal"
                    ),
                    "CD_nm": item.get(f"{mode}_CD_nm"),
                    "LER_left_nm": item.get(f"{mode}_LER_left_nm"),
                    "LER_right_nm": item.get(f"{mode}_LER_right_nm"),
                    "LWR_nm": item.get(f"{mode}_LWR_nm"),
                    "axis_angle_CD_LWR_from_vertical_deg": (
                        0.0 if mode == "unrotated"
                        else item.get("rotation_angle_CD_LWR_mean_deg")
                    ),
                    "axis_angle_LER_from_vertical_deg": (
                        0.0 if mode == "unrotated"
                        else item.get("rotation_angle_LER_mean_deg")
                    ),
                    "CD_engine": "V13",
                    "LER_engine": "V10",
                    "LWR_engine": "V13",
                }
            )
    return pd.DataFrame(rows)


def build_combined_sample_results(
    v10_frame: pd.DataFrame,
    v13_frame: pd.DataFrame,
    compact: bool,
) -> pd.DataFrame:
    """One aligned sample table with explicit V10 and V13 field prefixes."""
    if v10_frame.empty and v13_frame.empty:
        return pd.DataFrame()
    keys = ["image_key", "space_role", "sample_index"]
    meta_columns = [
        "folder_name", "folder_nominal_nm", "pretreatment_nm", "dose_mj",
        "sample_id", "metadata_source", "image", "path", "pattern",
        "pixel_size_nm", "design_trench_nm", "design_space_nm",
    ]
    compact_columns = [
        "space_index", "image_name", "sample_y", "left_edge_x", "right_edge_x",
        "local_cd_nm", "local_cd_x_nm", "rotated_local_cd_nm", "valid",
        "failure_reason", "recovered", "postfilter_rejected", "left_is_flyer",
        "right_is_flyer", "left_threshold", "right_threshold", "dark_level",
        "threshold_reference_mode", "threshold_dark_level",
        "left_threshold_bright_level", "right_threshold_bright_level",
        "rotated_axis_angle_from_vertical_deg", "rotated_axis_normal_factor",
        "rotated_left_x_prime_px", "rotated_right_x_prime_px",
        "rotated_center_y_prime_px",
        "continuity_original_valid", "continuity_original_left_x", "continuity_original_right_x",
        "continuity_original_failure_reason", "continuity_original_postfilter_rejected",
        "continuity_source", "continuity_strength_used", "continuity_synthetic", "continuity_method",
    ]

    def prepare(frame: pd.DataFrame, prefix: str) -> pd.DataFrame:
        if frame.empty:
            return pd.DataFrame(columns=keys)
        selected = [name for name in frame.columns if name not in meta_columns]
        if compact:
            selected = keys + [name for name in compact_columns if name in frame.columns]
        selected = list(dict.fromkeys(name for name in selected if name in frame.columns))
        table = frame[selected].copy()
        rename = {name: f"{prefix}_{name}" for name in table.columns if name not in keys}
        return table.rename(columns=rename)

    left = prepare(v13_frame, "v13")
    right = prepare(v10_frame, "v10")
    merged = left.merge(right, on=keys, how="outer", validate="one_to_one")

    meta_sources = [frame for frame in (v13_frame, v10_frame) if not frame.empty]
    meta = pd.concat(meta_sources, ignore_index=True, sort=False)
    keep_meta = keys + [name for name in meta_columns if name in meta.columns]
    meta = meta[keep_meta].drop_duplicates(keys, keep="first")
    merged = meta.merge(merged, on=keys, how="right", validate="one_to_one")
    merged["primary_CD_engine"] = "V13"
    merged["primary_LER_engine"] = "V10"
    merged["primary_LWR_engine"] = "V13"
    return merged


def save_internal_plots(image_df: pd.DataFrame, audit_df: pd.DataFrame, output_dir: Path, dpi: int) -> None:
    plot_dir = output_dir / "plots" / "internal"
    plot_dir.mkdir(parents=True, exist_ok=True)
    if not image_df.empty:
        metrics = [
            ("CD", "CD (nm)"),
            ("LER_left", "LER-left 3sigma (nm)"),
            ("LWR", "V13 group4 LWR 3sigma (nm)"),
        ]
        fig, axes = plt.subplots(3, 1, figsize=(10, 10), sharex=True)
        x = np.arange(1, len(image_df) + 1)
        for axis, (metric, label) in zip(axes, metrics):
            for mode, style in (("unrotated", "-"), ("rotated", "--")):
                y = pd.to_numeric(image_df[f"{mode}_{metric}_nm"], errors="coerce")
                axis.plot(
                    x, y, linestyle=style, marker="o", markersize=3,
                    linewidth=1, label=mode,
                )
            axis.set_ylabel(label)
            axis.grid(True, alpha=0.25)
            axis.legend()
        axes[-1].set_xlabel("Processed PNG index")
        fig.suptitle("V1.12: unrotated versus centerline-rotated coordinates")
        fig.tight_layout()
        fig.savefig(plot_dir / "primary_metrics_by_image.png", dpi=dpi, bbox_inches="tight")
        plt.close(fig)

    if not audit_df.empty and "result_id" in audit_df.columns:
        raw = audit_df[audit_df["result_id"].astype(str) == v10.RAW_RESULT_ID]
        grouped = audit_df[audit_df["result_id"].astype(str) == v10.GROUP4_RESULT_ID]
        merged = raw[["image_key", "LWR_x_nm"]].merge(
            grouped[["image_key", "LWR_x_nm"]], on="image_key", suffixes=("_raw", "_group4")
        )
        if not merged.empty:
            fig, axis = plt.subplots(figsize=(7, 6))
            axis.scatter(merged["LWR_x_nm_raw"], merged["LWR_x_nm_group4"], alpha=0.75)
            both = merged[["LWR_x_nm_raw", "LWR_x_nm_group4"]].to_numpy(dtype=float)
            finite = both[np.isfinite(both)]
            if finite.size:
                lo, hi = float(np.min(finite)), float(np.max(finite))
                axis.plot([lo, hi], [lo, hi], linestyle="--", color="gray")
            axis.set_xlabel("V13 raw V2 LWR (nm)")
            axis.set_ylabel("V13 group4 LWR used by V1.12 (nm)")
            axis.set_title("V13 raw versus group-of-four LWR")
            axis.grid(True, alpha=0.25)
            fig.savefig(plot_dir / "raw_vs_group4_lwr.png", dpi=dpi, bbox_inches="tight")
            plt.close(fig)


def excel_column_index(label: str) -> int:
    text = str(label).strip().upper()
    if not re.fullmatch(r"[A-Z]+", text):
        raise ValueError(f"无效 Excel 列名：{label}")
    value = 0
    for char in text:
        value = value * 26 + ord(char) - ord("A") + 1
    return value - 1


def normalize_match_key(value: Any) -> str:
    name = Path(str(value).strip()).name
    stem = Path(name).stem
    stem = re.sub(r"\(\d+\)$", "", stem).strip()
    return stem.casefold()


def configure_statistics_for_v110() -> None:
    """Reuse the proven V9 statistic primitives for both V1.12 axes."""
    v10.v9.METHOD_CODE = V112_METHOD_CODE
    v10.v9.METHOD = {
        "result_id": V112_RESULT_ID,
        "edge_variant": "v13_raw_cd_lwr__v10_raw_ler",
        "stat_mode": V112_STAT_MODE,
        "aggregation_mode": V112_AGGREGATION,
        "cn_name": "V1.12 原坐标与中心线旋转坐标",
        "physical_meaning": (
            "V13/V1.7侧带50%阈值边缘提供raw CD与group4 LWR；"
            "V10峰值中位数50%阈值边缘提供raw LER；"
            "同时报告图像坐标和以trench中心线为Y'轴的旋转坐标。"
        ),
    }
    v10.v9.V9_VERSION = SCRIPT_VERSION
    v10.v9.GEOMETRIES = {
        "unrotated": {
            "folder": "unrotated",
            "title": "Unrotated image X/Y coordinates",
            "metrics": {
                "CD": {
                    "machine_col": "machine_CD_nm",
                    "calc_col": "unrotated_CD_nm",
                    "signed_pct_col": "unrotated_CD_signed_diff_pct",
                    "abs_pct_col": "unrotated_CD_abs_diff_pct",
                    "unit": "nm",
                    "note": "V13 raw CD along the original image X axis.",
                },
                "LER_left": {
                    "machine_col": "machine_LER_left_nm",
                    "calc_col": "unrotated_LER_left_nm",
                    "signed_pct_col": "unrotated_LER_left_signed_diff_pct",
                    "abs_pct_col": "unrotated_LER_left_abs_diff_pct",
                    "unit": "nm",
                    "note": "V10 raw left-edge X-position 3sigma.",
                },
                "LWR": {
                    "machine_col": "machine_LWR_nm",
                    "calc_col": "unrotated_LWR_nm",
                    "signed_pct_col": "unrotated_LWR_signed_diff_pct",
                    "abs_pct_col": "unrotated_LWR_abs_diff_pct",
                    "unit": "nm",
                    "note": "V13 group4 width 3sigma along image X.",
                },
            },
        },
        "rotated": {
            "folder": "rotated",
            "title": "Centerline-rotated X'/Y' coordinates",
            "metrics": {
                "CD": {
                    "machine_col": "machine_CD_nm",
                    "calc_col": "rotated_CD_nm",
                    "signed_pct_col": "rotated_CD_signed_diff_pct",
                    "abs_pct_col": "rotated_CD_abs_diff_pct",
                    "unit": "nm",
                    "note": "V13 raw CD along X', normal to the fitted centerline.",
                },
                "LER_left": {
                    "machine_col": "machine_LER_left_nm",
                    "calc_col": "rotated_LER_left_nm",
                    "signed_pct_col": "rotated_LER_left_signed_diff_pct",
                    "abs_pct_col": "rotated_LER_left_abs_diff_pct",
                    "unit": "nm",
                    "note": "V10 raw left-edge X' 3sigma after centerline rotation.",
                },
                "LWR": {
                    "machine_col": "machine_LWR_nm",
                    "calc_col": "rotated_LWR_nm",
                    "signed_pct_col": "rotated_LWR_signed_diff_pct",
                    "abs_pct_col": "rotated_LWR_abs_diff_pct",
                    "unit": "nm",
                    "note": "V13 group4 width 3sigma along centerline-normal X'.",
                },
            },
        },
    }


def generate_coordinate_statistics(
    detailed: pd.DataFrame,
    output_dir: Path,
    dpi: int,
    make_plots: bool,
) -> pd.DataFrame:
    configure_statistics_for_v110()
    summary_rows: list[dict[str, Any]] = []
    plot_rows: list[dict[str, Any]] = []
    for mode, mode_spec in v10.v9.GEOMETRIES.items():
        for metric in ("CD", "LER_left", "LWR"):
            stats = v10.v9.metric_statistics(detailed, mode, metric)
            stats["method_code"] = V112_METHOD_CODE
            stats["method_name"] = v10.v9.METHOD["cn_name"]
            stats["coordinate_mode"] = mode
            summary_rows.append(stats)

            if not make_plots:
                continue
            metric_dir = output_dir / "plots" / mode_spec["folder"] / metric
            metric_dir.mkdir(parents=True, exist_ok=True)
            plot_specs = [
                ("machine_vs_python", "01_machine_vs_python.png", v10.v9._save_machine_vs_python),
                ("per_image_percent_error", "02_percent_error_by_image.png", v10.v9._save_error_by_image),
                ("percent_error_histogram", "03_percent_error_histogram.png", v10.v9._save_error_histogram),
                ("bland_altman", "04_bland_altman.png", v10.v9._save_bland_altman),
            ]
            for plot_type, filename, function in plot_specs:
                target = metric_dir / filename
                function(detailed, mode, metric, target, dpi)
                plot_rows.append(
                    {
                        "coordinate_mode": mode,
                        "metric": metric,
                        "plot_type": plot_type,
                        "relative_path": str(target.relative_to(output_dir)),
                    }
                )

        if make_plots:
            mode_summary = pd.DataFrame(
                [row for row in summary_rows if row["coordinate_mode"] == mode]
            )
            summary_dir = output_dir / "plots" / mode_spec["folder"]
            for record in v10.v9._save_geometry_summary_bars(
                mode_summary, mode, summary_dir, dpi
            ):
                plot_rows.append(
                    {
                        "coordinate_mode": mode,
                        "metric": record["metric"],
                        "plot_type": record["plot_type"],
                        "relative_path": str(
                            Path(record["relative_path"]).relative_to(output_dir)
                        ),
                    }
                )

    summary = pd.DataFrame(summary_rows)
    write_csv(summary, output_dir / "V1_12_statistics_summary.csv")
    write_csv(pd.DataFrame(plot_rows), output_dir / "V1_12_plot_index.csv")
    write_workbook(
        output_dir / "V1_12_statistics_and_machine_comparison.xlsx",
        {
            "Statistics_Summary": summary,
            "Machine_Per_Image": detailed,
            "Plot_Index": pd.DataFrame(plot_rows),
        },
    )
    return summary


def build_machine_comparison(
    image_df: pd.DataFrame,
    excel_path: Path,
    args: argparse.Namespace,
    output_dir: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    raw = pd.read_excel(excel_path, sheet_name=args.machine_sheet, header=None)
    start = max(0, int(args.machine_start_row) - 1)
    end = min(len(raw), int(args.machine_end_row)) if args.machine_end_row else len(raw)
    image_col = excel_column_index(args.machine_image_column)
    cd_col = excel_column_index(args.machine_cd_column)
    ler_col = excel_column_index(args.machine_ler_left_column)
    lwr_col = excel_column_index(args.machine_lwr_column)

    machine_rows: list[dict[str, Any]] = []
    for index in range(start, end):
        image_value = raw.iat[index, image_col] if image_col < raw.shape[1] else None
        if pd.isna(image_value) or not str(image_value).strip():
            continue
        machine_rows.append(
            {
                "machine_excel_row": index + 1,
                "machine_image_name_raw": str(image_value),
                "match_key": normalize_match_key(image_value),
                "machine_CD_nm": finite_float(raw.iat[index, cd_col]) if cd_col < raw.shape[1] else math.nan,
                "machine_LER_left_nm": finite_float(raw.iat[index, ler_col]) if ler_col < raw.shape[1] else math.nan,
                "machine_LWR_nm": finite_float(raw.iat[index, lwr_col]) if lwr_col < raw.shape[1] else math.nan,
            }
        )
    machine_df = pd.DataFrame(machine_rows)

    calc = image_df.copy()
    calc["match_key"] = calc["image"].map(normalize_match_key)
    duplicated = calc[calc["match_key"].duplicated(keep=False)].copy()
    unique_calc = calc.drop_duplicates("match_key", keep=False)
    detailed = machine_df.merge(unique_calc, on="match_key", how="inner", suffixes=("_machine", ""))
    if detailed.empty:
        raise RuntimeError("Data.xlsx 与 PNG 文件名没有可匹配记录")
    detailed["image_name"] = detailed["image_key"]
    detailed["result_id"] = V112_RESULT_ID
    detailed["aggregation_mode"] = V112_AGGREGATION
    detailed["method_code"] = V112_METHOD_CODE

    pairs = [
        ("unrotated_CD", "unrotated_CD_nm", "machine_CD_nm"),
        ("unrotated_LER_left", "unrotated_LER_left_nm", "machine_LER_left_nm"),
        ("unrotated_LWR", "unrotated_LWR_nm", "machine_LWR_nm"),
        ("rotated_CD", "rotated_CD_nm", "machine_CD_nm"),
        ("rotated_LER_left", "rotated_LER_left_nm", "machine_LER_left_nm"),
        ("rotated_LWR", "rotated_LWR_nm", "machine_LWR_nm"),
    ]
    for prefix, calc_col, machine_col in pairs:
        calc_values = pd.to_numeric(detailed[calc_col], errors="coerce")
        machine_values = pd.to_numeric(detailed[machine_col], errors="coerce")
        signed = (calc_values - machine_values) / machine_values.abs() * 100.0
        signed = signed.where(machine_values.abs() > EPS)
        detailed[f"{prefix}_signed_diff_pct"] = signed
        detailed[f"{prefix}_abs_diff_pct"] = signed.abs()

    matched_machine = set(detailed["machine_excel_row"].astype(int))
    unmatched_machine = machine_df[~machine_df["machine_excel_row"].isin(matched_machine)].copy()
    matched_keys = set(detailed["match_key"].astype(str))
    unmatched_png = calc[~calc["match_key"].isin(matched_keys)].copy()
    if not duplicated.empty:
        duplicated = duplicated.assign(unmatched_reason="duplicate_basename_in_recursive_tree")
        unmatched_png = pd.concat([unmatched_png, duplicated], ignore_index=True).drop_duplicates(
            subset=["image_key"], keep="last"
        )

    detailed_path = output_dir / "machine_comparison_detailed.csv"
    write_csv(detailed, detailed_path)
    write_csv(unmatched_machine, output_dir / "machine_unmatched_rows.csv")
    write_csv(unmatched_png, output_dir / "machine_unmatched_png.csv")

    summary = generate_coordinate_statistics(
        detailed,
        output_dir,
        dpi=max(80, int(args.plot_dpi)),
        make_plots=not bool(args.skip_statistics_plots),
    )
    return detailed, summary, pd.concat(
        [
            unmatched_machine.assign(unmatched_type="machine_row"),
            unmatched_png.assign(unmatched_type="png"),
        ],
        ignore_index=True,
        sort=False,
    )


def autofit_worksheet(worksheet, max_width: int = 42) -> None:
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    worksheet.freeze_panes = "A2"
    if worksheet.max_row and worksheet.max_column:
        worksheet.auto_filter.ref = worksheet.dimensions
    for cell in worksheet[1]:
        cell.fill = header_fill
        cell.font = header_font
    for column in range(1, worksheet.max_column + 1):
        maximum = 0
        for row in range(1, min(worksheet.max_row, 250) + 1):
            value = worksheet.cell(row=row, column=column).value
            maximum = max(maximum, len(str(value)) if value is not None else 0)
        worksheet.column_dimensions[get_column_letter(column)].width = min(max(maximum + 2, 10), max_width)
    for row in worksheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top")


def write_workbook(path: Path, sheets: dict[str, pd.DataFrame]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for name, frame in sheets.items():
            safe = frame.copy()
            if safe.empty and len(safe.columns) == 0:
                safe = pd.DataFrame({"note": ["No records"]})
            safe.to_excel(writer, sheet_name=name[:31], index=False)
        for worksheet in writer.book.worksheets:
            autofit_worksheet(worksheet)


def process_trench(
    general: v17.GeneralConfig,
    args: argparse.Namespace,
) -> dict[str, Path]:
    general.validate()
    output_dir = general.resolved_output_dir()
    output_dir.mkdir(parents=True, exist_ok=True)

    parsed_images, discovery_errors = v17.discover_images(general)
    if not parsed_images:
        raise RuntimeError("没有找到可处理的 PNG；程序会递归扫描 root 并排除输出目录")

    print(f"脚本版本：{SCRIPT_VERSION}")
    print(f"输入目录：{general.root_dir}")
    print(f"输出目录：{output_dir}")
    print(f"整目录图案类型：{general.force_pattern.upper()}")
    print(f"找到 {len(parsed_images)} 张 PNG（没有按目录名或文件名过滤）。")

    image_rows: list[dict[str, Any]] = []
    object_rows: list[dict[str, Any]] = []
    v10_source_image_rows: list[dict[str, Any]] = []
    v13_source_image_rows: list[dict[str, Any]] = []
    v10_source_object_rows: list[dict[str, Any]] = []
    v13_source_object_rows: list[dict[str, Any]] = []
    v10_base_object_rows: list[dict[str, Any]] = []
    v13_base_object_rows: list[dict[str, Any]] = []
    v10_sample_rows: list[dict[str, Any]] = []
    v13_sample_rows: list[dict[str, Any]] = []
    v10_candidate_rows: list[dict[str, Any]] = []
    v13_candidate_rows: list[dict[str, Any]] = []
    errors = list(discovery_errors)
    parameter_rows: list[dict[str, Any]] = []
    psd_batch = PSDBatch(args, output_dir) if not args.skip_psd else None

    variant_params = v7.PhysicalVariantParams(
        group_size=int(args.group_size),
        save_diagnostic_plots=bool(args.save_debug_masks),
        save_sample_variant_edges=not bool(args.compact_sample_output),
    )
    variant_params.validate()

    for number, parsed in enumerate(parsed_images, start=1):
        key = relative_key(parsed.path, general.root_dir)
        print(f"[{number}/{len(parsed_images)}] TRENCH {key}", flush=True)
        try:
            gray = v17.read_gray_png(parsed.path)
            v10_params = build_v10_params(parsed, gray, general, args)
            v13_params = build_v13_params(v10_params)
            v10_params.validate()
            v13_params.validate()
            parameter_rows.append(
                {
                    "image_key": key,
                    "v10_threshold_mode": V10_THRESHOLD_MODE,
                    "v13_threshold_mode": V13_THRESHOLD_MODE,
                    **jsonable(asdict(v10_params)),
                }
            )

            # Two true edge passes are required: V10 LER cannot be reconstructed
            # from V13 edges, and V13 CD/LWR cannot be reconstructed from V10 edges.
            v10_measurement = v5.measure_image(parsed.path, v10_params)
            v13_measurement = v13v5.measure_image(parsed.path, v13_params)
            set_measurement_image_key(v10_measurement, key)
            set_measurement_image_key(v13_measurement, key)
            if psd_batch is not None:
                psd_batch.add_measurement(v10_measurement, key, "V10", v10_params)
                psd_batch.add_measurement(v13_measurement, key, "V13", v13_params)


            edge_specs = v10.build_edge_variants_v10(
                v10_params.average_range_px, v10_params.smoothing_pixel
            )
            (
                v10_per_object_source,
                v10_per_image_source,
                v10_per_sample,
                v10_base_image,
            ) = v7.process_measurement_variants(
                v10_measurement, v10_params, variant_params, edge_specs
            )
            (
                v13_per_object_source,
                v13_per_image_source,
                v13_per_sample,
                v13_base_image,
            ) = v7.process_measurement_variants(
                v13_measurement, v13_params, variant_params, edge_specs
            )

            v10_coordinate_by_space = coordinate_metrics_by_space(
                v10_per_sample, v10_params, int(args.group_size)
            )
            v13_coordinate_by_space = coordinate_metrics_by_space(
                v13_per_sample, v13_params, int(args.group_size)
            )
            v10_selected_indices = v7.choose_aggregate_space_indices(
                v10_measurement.space_rows, v10_params.min_number
            )
            v13_selected_indices = v7.choose_aggregate_space_indices(
                v13_measurement.space_rows, v13_params.min_number
            )
            v10_coordinate_image = aggregate_coordinate_metrics(
                v10_coordinate_by_space, v10_selected_indices
            )
            v13_coordinate_image = aggregate_coordinate_metrics(
                v13_coordinate_by_space, v13_selected_indices
            )

            primary = hybrid_primary_image(
                v10_per_image_source,
                v13_per_image_source,
                parsed,
                general,
                v10_base_image,
                v13_base_image,
            )
            if primary is None:
                raise RuntimeError(
                    "V1.12 主结果缺少 V10/V13 raw_v2 或 group4 来源；"
                    "请检查候选和有效采样比例"
                )
            primary = add_coordinate_fields_to_image(
                primary, v10_coordinate_image, v13_coordinate_image
            )
            objects = hybrid_primary_objects(
                v10_per_object_source, v13_per_object_source, parsed, general
            )
            if not objects:
                raise RuntimeError("V10 与 V13 没有可按 trench role 对齐的对象结果")
            objects = add_coordinate_fields_to_objects(
                objects, v10_coordinate_by_space, v13_coordinate_by_space
            )
            primary["edge_continuity"] = int(args.edge_continuity)
            primary["quality_status_before_synthetic_review"] = primary.get("status", "")
            synthetic_used = False
            for engine_name, measurement in [("v10", v10_measurement), ("v13", v13_measurement)]:
                samples = measurement.sample_rows
                original = sum(bool(r.get("continuity_original_valid")) for r in samples)
                relaxed = sum(r.get("continuity_source") == "relaxed_redetect" for r in samples)
                synthetic = sum(bool(r.get("continuity_synthetic")) for r in samples)
                primary[engine_name + "_original_valid_count"] = original
                primary[engine_name + "_continuity_redetected_count"] = relaxed
                primary[engine_name + "_synthetic_count"] = synthetic
                primary[engine_name + "_detected_fraction"] = (original+relaxed)/max(1,len(samples))
                primary[engine_name + "_filled_fraction"] = (original+relaxed+synthetic)/max(1,len(samples))
                synthetic_used |= synthetic > 0
            if synthetic_used:
                primary["status"] = "REVIEW"
            for obj in objects:
                obj["edge_continuity"] = int(args.edge_continuity)
            image_rows.append(primary)
            object_rows.extend(objects)

            v10_source_image_rows.extend(
                enrich_source_rows(
                    v10_per_image_source, parsed, general, "V10", v10.V10_VERSION
                )
            )
            v13_source_image_rows.extend(
                enrich_source_rows(
                    v13_per_image_source, parsed, general, "V13", V13_ALGORITHM_VERSION
                )
            )
            v10_source_object_rows.extend(
                enrich_source_rows(
                    v10_per_object_source, parsed, general, "V10", v10.V10_VERSION
                )
            )
            v13_source_object_rows.extend(
                enrich_source_rows(
                    v13_per_object_source, parsed, general, "V13", V13_ALGORITHM_VERSION
                )
            )
            v10_base_object_rows.extend(
                enrich_source_rows(
                    v10_measurement.space_rows, parsed, general, "V10", v10.V10_VERSION
                )
            )
            v13_base_object_rows.extend(
                enrich_source_rows(
                    v13_measurement.space_rows, parsed, general, "V13", V13_ALGORITHM_VERSION
                )
            )
            v10_sample_rows.extend(
                enrich_source_rows(
                    v10_per_sample, parsed, general, "V10", v10.V10_VERSION
                )
            )
            v13_sample_rows.extend(
                enrich_source_rows(
                    v13_per_sample, parsed, general, "V13", V13_ALGORITHM_VERSION
                )
            )
            v10_candidate_rows.extend(
                enrich_source_rows(
                    v10_measurement.annotation_payload.get("candidate_diag", {}).get(
                        "candidate_debug_rows", []
                    ),
                    parsed,
                    general,
                    "V10",
                    v10.V10_VERSION,
                )
            )
            v13_candidate_rows.extend(
                enrich_source_rows(
                    v13_measurement.annotation_payload.get("candidate_diag", {}).get(
                        "candidate_debug_rows", []
                    ),
                    parsed,
                    general,
                    "V13",
                    V13_ALGORITHM_VERSION,
                )
            )

            if not args.no_annotated_images:
                # Standard annotation follows the V13 edges used by final CD/LWR.
                annotation_target = (
                    output_dir / "annotated" / Path(key)
                )
                v13v5.save_annotated_image(
                    parsed.path.name,
                    v13_measurement.annotation_payload,
                    annotation_target,
                    v13_params,
                )
                # Additional annotation exposes the independent V10 LER edge pass.
                v10_annotation_target = (
                    output_dir
                    / "annotated_v10_ler"
                    / Path(key)
                )
                v5.save_annotated_image(
                    parsed.path.name,
                    v10_measurement.annotation_payload,
                    v10_annotation_target,
                    v10_params,
                )
            if args.save_debug_masks:
                debug_dir = output_dir / "debug" / Path(key).parent
                v7.save_diagnostic_plot(
                    parsed.path.name,
                    v10_per_sample,
                    debug_dir / f"{parsed.path.stem}_v10_ler.png",
                )
                v7.save_diagnostic_plot(
                    parsed.path.name,
                    v13_per_sample,
                    debug_dir / f"{parsed.path.stem}_v13_cd_lwr.png",
                )

            print(
                "  "
                f"status={primary['status']} trenches={len(objects)} "
                f"CD={finite_float(primary['unrotated_CD_nm']):.4f}/"
                f"{finite_float(primary['rotated_CD_nm']):.4f} nm "
                f"LER-L={finite_float(primary['unrotated_LER_left_nm']):.4f}/"
                f"{finite_float(primary['rotated_LER_left_nm']):.4f} nm "
                f"LWR={finite_float(primary['unrotated_LWR_nm']):.4f}/"
                f"{finite_float(primary['rotated_LWR_nm']):.4f} nm "
                "(unrotated/rotated)"
            )
        except Exception as exc:
            error = {
                **metadata_for(parsed, general),
                "stage": "v112_dual_coordinate_measurement",
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "traceback": traceback.format_exc(),
            }
            errors.append(error)
            if psd_batch is not None:
                psd_batch.manifest.append(dict(image_key=key, engine="pipeline",
                    detected_trenches=0, measurement_valid=False,
                    warning=f"{type(exc).__name__}: {exc}"))
            image_rows.append(
                {
                    **metadata_for(parsed, general),
                    "algorithm_version": SCRIPT_VERSION,
                    "status": "ERROR",
                    "error_type": type(exc).__name__,
                    "error_message": str(exc),
                }
            )
            print(f"  ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
            if not general.continue_on_error:
                raise

    image_df = dataframe_or_empty(image_rows)
    trench_df = dataframe_or_empty(object_rows)
    v10_source_image_df = dataframe_or_empty(v10_source_image_rows)
    v13_source_image_df = dataframe_or_empty(v13_source_image_rows)
    v10_source_object_df = dataframe_or_empty(v10_source_object_rows)
    v13_source_object_df = dataframe_or_empty(v13_source_object_rows)
    v10_base_object_df = dataframe_or_empty(v10_base_object_rows)
    v13_base_object_df = dataframe_or_empty(v13_base_object_rows)
    v10_sample_df = dataframe_or_empty(v10_sample_rows)
    v13_sample_df = dataframe_or_empty(v13_sample_rows)
    sample_df = build_combined_sample_results(
        v10_sample_df, v13_sample_df, bool(args.compact_sample_output)
    )
    v10_candidate_df = dataframe_or_empty(v10_candidate_rows)
    v13_candidate_df = dataframe_or_empty(v13_candidate_rows)
    errors_df = dataframe_or_empty(
        errors,
        columns=(
            "folder_name", "image", "image_key", "path", "pattern", "stage",
            "error_type", "error_message", "traceback",
        ),
    )

    # Do not publish a third, legacy "slant" result family. V1.12's rotated
    # tables are the explicit centerline-aligned replacement. This also keeps
    # low-level source-audit CSVs from presenting duplicate projections.
    v10_source_image_df = without_legacy_slant_columns(v10_source_image_df)
    v13_source_image_df = without_legacy_slant_columns(v13_source_image_df)
    v10_source_object_df = without_legacy_slant_columns(v10_source_object_df)
    v13_source_object_df = without_legacy_slant_columns(v13_source_object_df)
    v10_base_object_df = without_legacy_slant_columns(v10_base_object_df)
    v13_base_object_df = without_legacy_slant_columns(v13_base_object_df)
    v10_sample_df = without_legacy_slant_columns(v10_sample_df)
    v13_sample_df = without_legacy_slant_columns(v13_sample_df)
    sample_df = without_legacy_slant_columns(sample_df)
    v10_candidate_df = without_legacy_slant_columns(v10_candidate_df)
    v13_candidate_df = without_legacy_slant_columns(v13_candidate_df)
    valid_images = image_df[image_df.get("status", "") != "ERROR"].copy()
    condition_df = build_condition_summary(valid_images)
    coordinate_df = build_image_coordinate_results(valid_images)
    object_long_df = build_object_long(trench_df)
    via_df = pd.DataFrame(columns=["note"])
    space_df = pd.DataFrame(columns=["note"])

    machine_detail = pd.DataFrame()
    machine_summary = pd.DataFrame()
    machine_unmatched = pd.DataFrame()
    machine_excel = args.machine_excel
    if machine_excel is None and not args.no_auto_machine_comparison:
        candidate = general.root_dir / "Data.xlsx"
        if candidate.exists():
            machine_excel = candidate
    if machine_excel is not None:
        machine_excel = Path(machine_excel)
        if not machine_excel.exists():
            raise FileNotFoundError(f"Machine 参考表不存在：{machine_excel}")
        valid_primary = image_df[image_df.get("status", "") != "ERROR"].copy()
        machine_detail, machine_summary, machine_unmatched = build_machine_comparison(
            valid_primary, machine_excel, args, output_dir
        )

    outputs = {
        "excel": output_dir / "CD_measurement_200K_V1_12_results.xlsx",
        "image_summary": output_dir / "image_summary.csv",
        "coordinate_results": output_dir / "coordinate_system_results.csv",
        "condition_summary": output_dir / "condition_summary.csv",
        "all_objects_long": output_dir / "all_objects_long.csv",
        "via_objects": output_dir / "via_objects.csv",
        "trench_objects": output_dir / "trench_objects.csv",
        "space_objects": output_dir / "space_objects.csv",
        "v10_source_image_audit": output_dir / "V1_12_V10_image_source_audit.csv",
        "v13_source_image_audit": output_dir / "V1_12_V13_image_source_audit.csv",
        "v10_source_object_audit": output_dir / "V1_12_V10_trench_source_audit.csv",
        "v13_source_object_audit": output_dir / "V1_12_V13_trench_source_audit.csv",
        "v10_base_object_audit": output_dir / "V1_12_V10_base_tracking_audit.csv",
        "v13_base_object_audit": output_dir / "V1_12_V13_base_tracking_audit.csv",
        "v10_sample_audit": output_dir / "V1_12_V10_per_sample_audit.csv",
        "v13_sample_audit": output_dir / "V1_12_V13_per_sample_audit.csv",
        "sample_results": output_dir / "per_sample_results.csv",
        "v10_candidate_debug": output_dir / "V1_12_V10_candidate_debug.csv",
        "v13_candidate_debug": output_dir / "V1_12_V13_candidate_debug.csv",
        "errors": output_dir / "processing_errors.csv",
        "settings": output_dir / "settings.json",
    }
    frame_outputs = {
        "image_summary": image_df,
        "coordinate_results": coordinate_df,
        "condition_summary": condition_df,
        "all_objects_long": object_long_df,
        "via_objects": via_df,
        "trench_objects": trench_df,
        "space_objects": space_df,
        "v10_source_image_audit": v10_source_image_df,
        "v13_source_image_audit": v13_source_image_df,
        "v10_source_object_audit": v10_source_object_df,
        "v13_source_object_audit": v13_source_object_df,
        "v10_base_object_audit": v10_base_object_df,
        "v13_base_object_audit": v13_base_object_df,
        "v10_sample_audit": v10_sample_df,
        "v13_sample_audit": v13_sample_df,
        "sample_results": sample_df,
        "v10_candidate_debug": v10_candidate_df,
        "v13_candidate_debug": v13_candidate_df,
        "errors": errors_df,
    }
    for key_name, frame in frame_outputs.items():
        write_csv(frame, outputs[key_name])

    settings = {
        "script_version": SCRIPT_VERSION,
        "input_contract": "V1.7 recursive all-PNG folder pattern",
        "algorithm": (
            "dual V1.15 Basin-First/V2 passes: "
            "V13 raw CD + V10 raw LER + V13 group4 LWR; "
            "unrotated image coordinates plus centerline-rotated coordinates"
        ),
        "primary_definition": {
            "CD": {"engine": "V13", "threshold": V13_THRESHOLD_MODE, "result_id": v10.RAW_RESULT_ID},
            "LER": {"engine": "V10", "threshold": V10_THRESHOLD_MODE, "result_id": v10.RAW_RESULT_ID},
            "LWR": {"engine": "V13", "threshold": V13_THRESHOLD_MODE, "result_id": v10.GROUP4_RESULT_ID},
            "group_size": int(args.group_size),
            "aggregation": "mean_per_trench",
        },
        "coordinate_systems": {
            "unrotated": "original image X/Y axes",
            "rotated": (
                "per-trench PCA centerline is Y'; its normal is X'; "
                "edge coordinates are explicitly rotated before statistics"
            ),
            "separate_slant_primary_columns": False,
            "rotation_origin": "mean of valid trench midpoint samples",
            "CD_LWR_axis_engine": "V13",
            "LER_axis_engine": "V10",
        },
        "general": jsonable(asdict(general)),
        "v1_12_cli": jsonable(vars(args)),
        "physical_variant_params": jsonable(asdict(variant_params)),
        "per_image_params": parameter_rows,
        "processed_png_count": len(parsed_images),
        "ok_count": int((image_df.get("status", pd.Series(dtype=str)) == "OK").sum()),
        "review_count": int((image_df.get("status", pd.Series(dtype=str)) == "REVIEW").sum()),
        "error_count": len(errors_df),
        "machine_comparison_excel": str(machine_excel) if machine_excel is not None else None,
    }
    outputs["settings"].write_text(
        json.dumps(jsonable(settings), ensure_ascii=False, indent=2), encoding="utf-8"
    )

    if not args.skip_statistics_plots:
        save_internal_plots(
            image_df[image_df.get("status", "") != "ERROR"],
            v13_source_image_df,
            output_dir,
            int(args.plot_dpi),
        )

    settings_df = pd.DataFrame(
        [
            ["script_version", SCRIPT_VERSION],
            ["input_contract", "recursive all PNG; one --pattern for complete tree"],
            ["CD_source", f"V13/{V13_THRESHOLD_MODE}/{v10.RAW_RESULT_ID}"],
            ["LER_source", f"V10/{V10_THRESHOLD_MODE}/{v10.RAW_RESULT_ID}"],
            ["LWR_source", f"V13/{V13_THRESHOLD_MODE}/{v10.GROUP4_RESULT_ID}"],
            ["unrotated_axis", "original image X/Y"],
            ["rotated_axis", "Y' fitted centerline; X' trench normal"],
            ["separate_slant_primary_columns", False],
            ["group_size", int(args.group_size)],
            ["sample_number", int(args.sample_number)],
            ["average_range", int(args.average_range)],
            ["pixel_size_nm", general.pixel_size_nm],
            ["machine_excel", str(machine_excel) if machine_excel is not None else "not used"],
        ],
        columns=["item", "value"],
    )
    sheets = {
        "image_summary": image_df,
        "coordinate_results": coordinate_df,
        "condition_summary": condition_df,
        "all_objects_long": object_long_df,
        "trench_objects": trench_df,
        "V10_image_source": v10_source_image_df,
        "V13_image_source": v13_source_image_df,
        "V10_trench_source": v10_source_object_df,
        "V13_trench_source": v13_source_object_df,
        "V10_base_tracking": v10_base_object_df,
        "V13_base_tracking": v13_base_object_df,
        "per_sample_results": sample_df,
        "V10_candidate_debug": v10_candidate_df,
        "V13_candidate_debug": v13_candidate_df,
        "processing_errors": errors_df,
        "settings": settings_df,
    }
    if not machine_detail.empty:
        sheets["Machine_Per_Image"] = machine_detail
        sheets["Statistics_Summary"] = machine_summary
        sheets["Machine_Unmatched"] = machine_unmatched
    write_workbook(outputs["excel"], sheets)

    print("\n处理完成：")
    print(f"  PNG 图像：{len(parsed_images)}")
    print(f"  V1.12 双坐标结果：{int((image_df.get('status', pd.Series(dtype=str)) != 'ERROR').sum())}")
    print(f"  Trench 对象：{len(trench_df)}")
    print(f"  错误记录：{len(errors_df)}")
    print(f"  Excel：{outputs['excel']}")
    print(f"  V13 CD/LWR Annotated：{output_dir / 'annotated'}")
    print(f"  V10 LER Annotated：{output_dir / 'annotated_v10_ler'}")
    if psd_batch is not None:
        outputs["psd_excel"] = psd_batch.finalize()
        print(f"  PSD：{outputs['psd_excel']}")
    return outputs


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "基于V1.9的V1.12双坐标口径：原图X/Y与沿trench中心线旋转的X'/Y'；"
            "V13计算CD/LWR，V10计算LER；递归处理所有PNG，"
            "不按目录名/文件名过滤，由 --pattern 指定整目录图案。"
        )
    )
    # V1.7-compatible public interface and defaults.
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT, help=f"输入根目录；默认：{DEFAULT_ROOT}")
    parser.add_argument(
        "--output", type=Path, default=None,
        help=f"输出目录；默认在 root 下创建 {DEFAULT_OUTPUT_NAME}",
    )
    parser.add_argument("--pixel-size", type=float, default=1.3181, help="nm/pixel；默认 1.3181")
    parser.add_argument(
        "--pattern", type=str.casefold, choices=("via", "trench"), required=True,
        help="必填：整个 root（含全部子文件夹）的统一图案类型",
    )
    parser.add_argument("--via-reference-nm", type=float, default=None, help="可选：统一 Via 检测参考直径")
    parser.add_argument("--trench-reference-nm", type=float, default=None, help="可选：统一 Trench 检测参考宽度")
    parser.add_argument("--space-reference-nm", type=float, default=None, help="可选：统一亮 Space 参考宽度；用于记录和自动估计")
    parser.add_argument("--save-debug-masks", action="store_true", help="额外保存调试图")
    parser.add_argument("--stop-on-error", action="store_true", help="任一图出错立即停止；默认记录后继续")

    # V1.8 measurement defaults. Center defaults to the current image center so
    # the V1.7 arbitrary-folder input contract does not depend on one data set.
    parser.add_argument("--center-x", type=float, default=None, help="测量中心 X；默认逐图使用图像中心")
    parser.add_argument("--center-y", type=float, default=None, help="测量中心 Y；默认逐图使用图像中心")
    parser.add_argument("--search-in", type=int, default=33)
    parser.add_argument("--search-out", type=int, default=30)
    parser.add_argument("--extend-length", type=int, default=None, help="默认 min(360, 图像高度)")
    parser.add_argument("--sample-number", type=int, default=128)
    parser.add_argument("--average-range", type=int, default=32)
    parser.add_argument("--smoothing-pixel", type=int, default=3)
    parser.add_argument("--peak-order", type=int, default=1)
    parser.add_argument("--threshold-left", type=float, default=50.0)
    parser.add_argument("--threshold-right", type=float, default=50.0)
    parser.add_argument("--max-number", type=int, default=3)
    parser.add_argument("--min-number", type=int, default=3)
    parser.add_argument("--candidate-dark-tolerance", type=float, default=12.0)
    parser.add_argument("--candidate-min-contrast", type=float, default=3.0)
    parser.add_argument("--topology-min-contrast", type=float, default=2.5)
    parser.add_argument("--tracking-radius", type=float, default=13.0)
    parser.add_argument("--tracking-retry-radius", type=float, default=20.0)
    parser.add_argument("--tracking-max-jump", type=float, default=8.0)
    parser.add_argument("--postfilter-window", type=int, default=9)
    parser.add_argument("--postfilter-mad-multiplier", type=float, default=6.0)
    parser.add_argument("--postfilter-edge-tolerance", type=float, default=2.5)
    parser.add_argument("--minimum-valid-fraction", type=float, default=0.70)
    parser.add_argument("--allow-incomplete-triplet", action="store_true")
    parser.add_argument("--no-recovery", action="store_true")
    parser.add_argument("--flyer-mode", choices=("reserve", "remove", "replace"), default="reserve")
    parser.add_argument("--flyer-left-offset", type=float, default=20.0)
    parser.add_argument("--flyer-right-offset", type=float, default=20.0)
    parser.add_argument(
        "--group-size", type=int, choices=(4,), default=4,
        help="V13 LWR 固定连续 4 点分组；保留参数用于运行记录",
    )
    parser.add_argument("--no-annotated-images", action="store_true")
    parser.add_argument("--compact-sample-output", action="store_true")

    # Optional V1.8-compatible comparison with Data.xlsx.
    parser.add_argument("--machine-excel", type=Path, default=None, help="Machine 参考 Data.xlsx；默认自动检查 root/Data.xlsx")
    parser.add_argument("--no-auto-machine-comparison", action="store_true", help="即使 root 有 Data.xlsx 也不自动比较")
    parser.add_argument("--machine-sheet", default="v2")
    parser.add_argument("--machine-start-row", type=int, default=2)
    parser.add_argument("--machine-end-row", type=int, default=84)
    parser.add_argument("--machine-image-column", default="B")
    parser.add_argument("--machine-cd-column", default="D")
    parser.add_argument("--machine-ler-left-column", default="E")
    parser.add_argument("--machine-lwr-column", default="F")
    parser.add_argument("--skip-statistics-plots", action="store_true")
    parser.add_argument("--plot-dpi", type=int, default=180)
    parser.add_argument("--edge-continuity", type=int, default=0,
        help="0保持V1.10；1-99逐级放宽仅重测缺点；100对剩余缺点强制补齐并标记")
    parser.add_argument("--skip-psd", action="store_true", help="不计算PSD")
    parser.add_argument("--psd-axis", choices=("unrotated", "normal", "both"), default="both")
    parser.add_argument("--psd-method", choices=("welch", "periodogram"), default="welch")
    parser.add_argument("--psd-window", choices=("hann", "boxcar", "blackmanharris"), default="hann")
    parser.add_argument("--psd-detrend", choices=("linear", "constant", "none"), default="linear")
    parser.add_argument("--psd-nperseg", type=int, default=64)
    parser.add_argument("--psd-overlap", type=float, default=0.5, help="Welch重叠比例[0,1)")
    parser.add_argument("--psd-min-segment", type=int, default=16, help="PSD最短连续有效段点数")
    parser.add_argument("--psd-gap-mode", choices=("segments", "interpolate"), default="segments")
    parser.add_argument("--psd-max-gap", type=int, default=2, help="PSD插值允许的最大内部缺点数")
    parser.add_argument("--psd-include-synthetic", action="store_true", help="允许强制补点参与PSD，默认排除")
    parser.add_argument("--psd-split-wavelength", type=float, default=100.0, help="低高频分界波长nm；默认100")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    if not 0 <= args.edge_continuity <= 100:
        raise SystemExit("--edge-continuity 必须在0到100之间")
    if args.psd_min_segment < 4 or args.psd_nperseg < 4:
        raise SystemExit("PSD段长度至少为4")
    if args.psd_method == "welch" and args.psd_nperseg < args.psd_min_segment:
        raise SystemExit("--psd-nperseg 不能小于 --psd-min-segment")
    if not 0 <= args.psd_overlap < 1 or args.psd_max_gap < 0:
        raise SystemExit("PSD overlap必须在[0,1)，max-gap必须非负")
    if not math.isfinite(args.psd_split_wavelength) or args.psd_split_wavelength <= 0:
        raise SystemExit("PSD分界波长必须为正有限数")
    output_dir = args.output or (args.root / DEFAULT_OUTPUT_NAME)
    general = v17.GeneralConfig(
        root_dir=args.root,
        output_dir=output_dir,
        pixel_size_nm=args.pixel_size,
        force_pattern=args.pattern,
        via_reference_nm=args.via_reference_nm,
        trench_reference_nm=args.trench_reference_nm,
        space_reference_nm=args.space_reference_nm,
        save_debug_masks=bool(args.save_debug_masks),
        continue_on_error=not bool(args.stop_on_error),
    )
    try:
        if args.pattern == "via":
            if args.edge_continuity != 0:
                raise ValueError("V1.12的edge-continuity只支持trench；Via请使用0")
            print("说明：Via沿用V1.7；本版空间PSD仅支持trench，Via不产生PSD文件。")
            print(
                "说明：V10/V13 没有 Via 算法；本次使用完整 V1.7 Via 测量与统计，"
                "输入和输出目录仍由本入口控制。"
            )
            v17.process_all(general, v17.ViaConfig(), v17.TrenchConfig())
        else:
            process_trench(general, args)
        return 0
    except KeyboardInterrupt:
        print("用户中断。", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"程序失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
